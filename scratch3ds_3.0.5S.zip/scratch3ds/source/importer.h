
#ifndef IMPORTER_H
#define IMPORTER_H

#include <stddef.h>
#include "project.h"

#define IMP_MAX_ENTRIES 48
#define IMP_PATH_LEN    200

typedef struct {
    char name[TEXT_LEN];
    char path[IMP_PATH_LEN];
    int  is_dir;
} ImportEntry;

int imp_scan(const char *root, ImportEntry *out, int max);

int imp_load_sprite(const ImportEntry *e, Sprite *out, char *err, size_t errn);

int  img_decode(const char *path, int *w, int *h, unsigned char **rgba, char *err, size_t errn);
void img_to_costume(const unsigned char *rgba, int w, int h, Costume *c);
int  wav_load(const char *path, int16_t **pcm, int *n, int *rate, char *err, size_t errn);
int  inflate_zlib(const unsigned char *src, size_t n, unsigned char *dst, size_t cap, size_t *outlen);

#endif
