
#include <assert.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "assets.h"
#include "editor.h"
#include "runtime.h"

static Project P;
static Runtime RT;

static int near(float a, float b) { return fabsf(a - b) < 0.01f; }
static void run(int frames) { for (int i = 0; i < frames; i++) rt_tick(&RT, &P, 1.f / 60.f); }
static Script *scr(int sp, int s) { return &P.sprites[sp].scripts[s]; }

static int ins(int after, BlockKind k)
{
    int at = prj_insert_block(&P, 0, 0, after, k);
    assert(at >= 0);
    return at;
}
static void lit(int blk, int slot, const char *text) { strcpy(scr(0, 0)->blocks[blk].a[slot].text, text); }
static Block *sub(int blk, const int *path, int depth)
{
    Block *n = prj_node(scr(0, 0), blk, path, depth);
    assert(n);
    return n;
}
static void fresh(void) { prj_init(&P); rt_reset(&RT, &P); }

static void check_table(void)
{
    int pal[CAT_COUNT + 1] = { 0 };
    for (int k = 0; k < BK_COUNT; k++) {
        const BlockInfo *bi = &BLOCK_INFO[k];
        int ns = block_nslots(k);
        assert(ns <= MAX_ARGS);
        int refs = 0;
        for (const char *l = bi->label; *l; l++)
            if (l[0] == '%' && l[1] >= '1' && l[1] <= '3') { assert(l[1] - '1' < ns); refs++; }
        assert(refs == ns || bi->shape == SH_HAT);
        for (int i = 0; i < ns; i++) assert(strchr("nsbcokmtpqvlefaxiyzu", bi->slots[i]));
        assert(bi->shape <= SH_ELSE);
        assert(bi->category <= CAT_COUNT);
        if (bi->shape != SH_END && bi->shape != SH_ELSE) { assert(bi->selector[0]); assert(bi->category < CAT_COUNT); }
        if (bi->shape == SH_BOOL || bi->shape == SH_REP || bi->shape == SH_CMD || bi->shape == SH_C ||
            bi->shape == SH_CELSE || bi->shape == SH_HAT) pal[bi->category]++;
        for (int j = 0; j < k; j++)
            if (bi->selector[0] && strcmp(bi->selector, BLOCK_INFO[j].selector) == 0)
                assert(strcmp(bi->selector, "EventHatMorph") == 0);
        Block b = block_default(k);
        for (int i = 0; i < MAX_ARGS; i++) assert(b.a[i].expr == -1 && strlen(b.a[i].text) < TEXT_LEN);
    }
    int total = 0;
    for (int c = 0; c < CAT_COUNT; c++) { assert(pal[c] > 0); total += pal[c]; }
    printf("block table: %d palette blocks (+2 internal markers) in %d categories\n", total, CAT_COUNT);
    assert(total >= 100);
}

int main(void)
{
    char buf[128];
    check_table();

    fresh();
    assert(P.nsprites == 1 && P.sprites[0].nscripts == 1 && P.sprites[0].ncostumes == 1);
    assert(ins(0, BK_MOVE) == 1);
    assert(ins(1, BK_TURN_R) == 2);
    assert(ins(0, BK_SAY) == 1 && scr(0, 0)->blocks[1].kind == BK_SAY);
    assert(prj_insert_block(&P, 0, 0, 0, BK_HAT_FLAG) == -1);
    assert(prj_insert_block(&P, 0, 0, 0, BK_ADD) == -1);
    assert(prj_insert_block(&P, 0, 0, 0, BK_END) == -1);
    assert(prj_delete_block(&P, 0, 0, 0) == -1);
    assert(prj_delete_block(&P, 0, 0, 1) == 0 && scr(0, 0)->nblocks == 3);
    prj_format_block(scr(0, 0), &scr(0, 0)->blocks[1], buf, sizeof buf);
    assert(strcmp(buf, "move 10 steps") == 0);
    assert(prj_delete_script(&P, 0, 0) == -1);

    fresh();
    {
        int fo = ins(0, BK_FOREVER);
        int s1 = ins(fo, BK_SAY_FOR); strcpy(scr(0, 0)->blocks[s1].a[0].text, "A"); strcpy(scr(0, 0)->blocks[s1].a[1].text, "2");
        int mv = ins(s1, BK_MOVE); (void)mv;
        int w1 = ins(s1 + 1, BK_WAIT); strcpy(scr(0, 0)->blocks[w1].a[0].text, "1");
        int s2 = ins(w1, BK_SAY); strcpy(scr(0, 0)->blocks[s2].a[0].text, "B");
        rt_green_flag(&RT, &P);
        int seenA = 0, seenB = 0, ticksB = 0;
        for (int t = 0; t < 60 * 8; t++) {
            run(1);
            if (!strcmp(RT.spr[0].say, "A")) seenA++;
            if (!strcmp(RT.spr[0].say, "B")) { seenB++; ticksB++; }
        }
        printf("say test: A shown %d ticks, B shown %d ticks (loop without a wait after B)\n", seenA, seenB);
        assert(seenA > 100 && seenB >= 1);

        int w2 = ins(s2, BK_WAIT); strcpy(scr(0, 0)->blocks[w2].a[0].text, "2");
        rt_green_flag(&RT, &P);
        seenB = 0;
        for (int t = 0; t < 60 * 8; t++) { run(1); if (!strcmp(RT.spr[0].say, "B")) seenB++; }
        printf("say test: with wait 2 after B -> B shown %d ticks\n", seenB);
        assert(seenB > 100);
    }

    fresh();
    {
        int g = ins(0, BK_GOTO_SPRITE);
        assert(strcmp(scr(0, 0)->blocks[g].a[0].text, "mouse-pointer") == 0);
        rt_green_flag(&RT, &P); rt_pointer(&RT, 100, -50, 1); run(3);
        assert(near(RT.spr[0].x, 100.f) && near(RT.spr[0].y, -50.f));

        P.sprites[0].x = 30; P.sprites[0].y = 40;
        rt_green_flag(&RT, &P); rt_pointer(&RT, 100, -50, 0); run(3);
        assert(near(RT.spr[0].x, 30.f) && near(RT.spr[0].y, 40.f));
        int pt = ins(g, BK_POINT_TOWARDS); (void)pt;
        rt_green_flag(&RT, &P); rt_pointer(&RT, 100, 100, 1); run(3);
        assert(near(RT.spr[0].x, 100.f) && near(RT.spr[0].y, 100.f));
    }

    fresh();
    int f = ins(0, BK_FOREVER);
    assert(f == 1 && scr(0, 0)->nblocks == 3 && scr(0, 0)->blocks[2].kind == BK_END);
    int m = ins(1, BK_MOVE);
    assert(m == 2 && scr(0, 0)->blocks[3].kind == BK_END);
    int ie = ins(2, BK_IF_ELSE);
    assert(ie == 3 && scr(0, 0)->blocks[4].kind == BK_ELSE && scr(0, 0)->blocks[5].kind == BK_END);
    assert(prj_match_end(scr(0, 0), 1) == 6 && prj_match_end(scr(0, 0), 3) == 5 && prj_match_else(scr(0, 0), 3) == 4);
    assert(prj_match_else(scr(0, 0), 1) == -1);
    assert(prj_indent(scr(0, 0), 1) == 0 && prj_indent(scr(0, 0), 2) == 1 && prj_indent(scr(0, 0), 3) == 1);
    assert(prj_indent(scr(0, 0), 4) == 1 && prj_indent(scr(0, 0), 5) == 1 && prj_indent(scr(0, 0), 6) == 0);
    ins(3, BK_SHOW);
    assert(prj_indent(scr(0, 0), 4) == 2);
    assert(prj_delete_block(&P, 0, 0, 5) == -1 && prj_delete_block(&P, 0, 0, 6) == -1);
    assert(prj_delete_block(&P, 0, 0, 3) == 0);
    assert(scr(0, 0)->nblocks == 5 && scr(0, 0)->blocks[3].kind == BK_SHOW && prj_match_end(scr(0, 0), 1) == 4);
    assert(prj_delete_block(&P, 0, 0, 1) == 0);
    assert(scr(0, 0)->nblocks == 3 && scr(0, 0)->blocks[1].kind == BK_MOVE && scr(0, 0)->blocks[2].kind == BK_SHOW);
    fresh();
    while (prj_insert_block(&P, 0, 0, 0, BK_IF) >= 0) {}
    assert(scr(0, 0)->nblocks <= MAX_BLOCKS && scr(0, 0)->nblocks >= MAX_BLOCKS - 1);

    fresh();
    prj_add_var(&P, "score");
    int sv = ins(0, BK_SET_VAR);
    assert(strcmp(scr(0, 0)->blocks[sv].a[0].text, "score") == 0);
    Script *sc = scr(0, 0);
    assert(prj_plug(&P, 0, sc, &sc->blocks[sv], 1, BK_ADD, NULL) == 0);
    int p0[1] = { 1 };
    Block *add = sub(sv, p0, 1);
    assert(add->kind == BK_ADD);
    assert(prj_plug(&P, 0, sc, add, 0, BK_VAR, "score") == 0);
    strcpy(add->a[1].text, "5");
    prj_format_block(sc, &sc->blocks[sv], buf, sizeof buf);
    assert(strcmp(buf, "set score to ((score) + 5)") == 0);
    int p1[2] = { 1, 0 };
    assert(sub(sv, p1, 2)->kind == BK_VAR);
    assert(prj_node(sc, sv, (int[]){ 1, 1 }, 2) == NULL);
    assert(prj_plug(&P, 0, sc, &sc->blocks[sv], 5, BK_ADD, NULL) == -1);
    assert(prj_plug(&P, 0, sc, &sc->blocks[sv], 1, BK_MOVE, NULL) == -1);
    int ifb = ins(sv, BK_IF);
    assert(prj_plug(&P, 0, sc, &sc->blocks[ifb], 0, BK_ADD, NULL) == -3);
    assert(prj_plug(&P, 0, sc, &sc->blocks[ifb], 0, BK_AND, NULL) == 0);
    prj_format_block(sc, &sc->blocks[ifb], buf, sizeof buf);
    assert(strcmp(buf, "if <<> and <>>") == 0);
    int used = 0;
    for (int i = 0; i < MAX_EXPR; i++) used += sc->ex_used[i];
    assert(used == 3);
    assert(prj_unplug(sc, &sc->blocks[sv], 1) == 0 && sc->blocks[sv].a[1].expr == -1);
    used = 0;
    for (int i = 0; i < MAX_EXPR; i++) used += sc->ex_used[i];
    assert(used == 1);
    assert(prj_delete_block(&P, 0, 0, ifb) == 0);
    for (int i = 0; i < MAX_EXPR; i++) assert(!sc->ex_used[i]);
    int pn = ins(0, BK_MOVE);
    int path[MAX_EXPR] = { 0 };
    for (int d = 0; d < MAX_EXPR; d++) {
        Block *n = prj_node(sc, pn, path, d);
        assert(n && prj_plug(&P, 0, sc, n, 0, BK_ADD, NULL) == 0);
    }
    assert(prj_plug(&P, 0, sc, prj_node(sc, pn, path, MAX_EXPR), 0, BK_ADD, NULL) == -2);
    prj_format_block(sc, &sc->blocks[pn], buf, sizeof buf);
    rt_green_flag(&RT, &P); run(2);
    assert(prj_unplug(sc, &sc->blocks[pn], 0) == 0);
    for (int i = 0; i < MAX_EXPR; i++) assert(!sc->ex_used[i]);

    fresh();
    prj_add_sprite(&P);
    prj_add_sound(&P, 0);
    prj_add_var(&P, "a"); prj_add_list(&P, "L");
    char it[MENU_MAX][TEXT_LEN];
    assert(prj_menu_items(&P, 0, 'c', it, MENU_MAX) == 1 && strcmp(it[0], "costume1") == 0);
    assert(prj_menu_items(&P, 0, 'o', it, MENU_MAX) == 1);
    assert(prj_menu_items(&P, 0, 'k', it, MENU_MAX) == KEY_NAME_COUNT);
    assert(prj_menu_items(&P, 0, 't', it, MENU_MAX) == 3 && strcmp(it[2], "Sprite2") == 0);
    assert(prj_menu_items(&P, 0, 'p', it, MENU_MAX) == 2);
    assert(prj_menu_items(&P, 0, 'q', it, MENU_MAX) == 2);
    assert(prj_menu_items(&P, 0, 'v', it, MENU_MAX) == 1 && prj_menu_items(&P, 0, 'l', it, MENU_MAX) == 1);
    assert(prj_menu_items(&P, 0, 'e', it, MENU_MAX) == 7 && prj_menu_items(&P, 0, 'f', it, MENU_MAX) == 12);
    assert(prj_menu_items(&P, 0, 'a', it, MENU_MAX) == 6 && prj_menu_items(&P, 0, 'x', it, MENU_MAX) == 15);
    int nm = prj_menu_items(&P, 0, 'm', it, MENU_MAX);
    assert(nm == 1 && strcmp(it[0], "new message...") == 0);
    ins(0, BK_BROADCAST);
    nm = prj_menu_items(&P, 0, 'm', it, MENU_MAX);
    assert(nm == 2 && strcmp(it[0], "message1") == 0);
    assert(key_index("space") == 0 && key_index("z") == 30 && key_index("9") == 40 && key_index("nope") == -1);
    assert(slot_is_text('n') && slot_is_text('s') && !slot_is_text('c') && slot_is_menu('c') && !slot_is_menu('b'));

    fresh();
    assert(prj_add_sprite(&P) == 1 && strcmp(P.sprites[1].name, "Sprite2") == 0);
    int tb = ins(0, BK_SAY);
    sc = scr(0, 0);
    assert(prj_plug(&P, 0, sc, &sc->blocks[tb], 0, BK_TOUCHING, NULL) == 0);
    strcpy(sub(tb, (int[]){ 0 }, 1)->a[0].text, "Sprite2");
    prj_rename_sprite(&P, 1, "Enemy");
    prj_format_block(sc, &sc->blocks[tb], buf, sizeof buf);
    assert(strcmp(buf, "say <touching Enemy ?>") == 0);
    prj_delete_sprite(&P, 1);
    prj_format_block(sc, &sc->blocks[tb], buf, sizeof buf);
    assert(strcmp(buf, "say <touching mouse-pointer ?>") == 0);
    while (prj_add_sprite(&P) >= 0) {}
    assert(P.nsprites == MAX_SPRITES);
    prj_rename_sprite(&P, 1, "Sprite1");
    assert(strcmp(P.sprites[1].name, "Sprite1") != 0);
    fresh();
    assert(prj_delete_sprite(&P, 0) == -1);

    Sprite *s = &P.sprites[0];
    assert(prj_add_costume(&P, 0) == 1 && s->ncostumes == 2 && s->cur_costume == 1);
    assert(strcmp(s->costumes[1].name, "costume2") == 0);
    costume_fill(&s->costumes[1], 0, 0, 12);
    assert(s->costumes[1].px[0] == 12 && s->costumes[0].px[0] == 0);
    int idx = ins(0, BK_SWITCH_COSTUME);
    assert(strcmp(scr(0, 0)->blocks[idx].a[0].text, "costume2") == 0);
    assert(prj_rename_costume(&P, 0, 1, "jump") == 0 && strcmp(scr(0, 0)->blocks[idx].a[0].text, "jump") == 0);
    assert(prj_rename_costume(&P, 0, 1, "costume1") == -1);
    assert(prj_delete_costume(&P, 0, 1) == 0 && s->ncostumes == 1);
    assert(strcmp(scr(0, 0)->blocks[idx].a[0].text, "costume1") == 0);
    assert(prj_delete_costume(&P, 0, 0) == -1);
    while (prj_add_costume(&P, 0) >= 0) {}
    assert(s->ncostumes == MAX_COSTUMES);

    fresh();
    s = &P.sprites[0];
    assert(prj_add_sound(&P, 0) == 0 && strcmp(s->sounds[0].name, "beep1") == 0);
    assert(prj_add_sound(&P, 0) == 1 && strcmp(s->sounds[1].name, "beep2") == 0);
    int16_t tone[2000];
    for (int i = 0; i < 2000; i++) tone[i] = (int16_t)(sinf(i * 0.2f) * 8000);
    assert(prj_add_recording(&P, 0, tone, 2000, REC_RATE) == 2);
    assert(strcmp(s->sounds[2].name, "recording3") == 0 && snd_is_recorded(&s->sounds[2]) && s->sounds[2].npcm == 2000);
    assert(snd_rate(&s->sounds[2]) == REC_RATE && snd_duration_ms(&s->sounds[2]) == 2000 * 1000 / REC_RATE);
    assert(prj_add_recording(&P, 0, tone, 0, REC_RATE) == -1 && prj_add_recording(&P, 0, tone, REC_MAX_SAMPLES + 1, REC_RATE) == -1);
    int ps = ins(0, BK_PLAY_SOUND);
    assert(strcmp(scr(0, 0)->blocks[ps].a[0].text, "beep1") == 0);
    assert(prj_rename_sound(&P, 0, 0, "ding") == 0 && strcmp(scr(0, 0)->blocks[ps].a[0].text, "ding") == 0);
    assert(prj_rename_sound(&P, 0, 0, "beep2") == -1);
    assert(prj_delete_sound(&P, 0, 0) == 0 && s->nsounds == 2);
    assert(strcmp(scr(0, 0)->blocks[ps].a[0].text, "beep2") == 0);
    assert(snd_is_recorded(&s->sounds[1]) && !s->sounds[2].pcm);
    assert(prj_add_sound(&P, 0) == 2 && strcmp(s->sounds[2].name, "beep3") == 0 && !snd_is_recorded(&s->sounds[2]));
    assert(prj_find_sound(s, "beep2") == 0);
    prj_add_sprite(&P);
    prj_add_recording(&P, 1, tone, 100, 8180);
    assert(prj_delete_sprite(&P, 0) == 0);
    assert(snd_is_recorded(&P.sprites[0].sounds[0]) && P.sprites[0].sounds[0].npcm == 100);

    fresh();
    assert(prj_add_var(&P, "a") == 0 && prj_add_var(&P, "b") == 1 && prj_add_var(&P, "a") == 0 && P.nvars == 2);
    for (int i = 2; i < MAX_VARS; i++) { char n[8]; snprintf(n, 8, "v%d", i); assert(prj_add_var(&P, n) == i); }
    assert(prj_add_var(&P, "overflow") == -1 && prj_add_var(&P, "") == -1);
    fresh();
    prj_add_var(&P, "a"); prj_add_var(&P, "b");
    int cv = ins(0, BK_CHANGE_VAR);
    strcpy(scr(0, 0)->blocks[cv].a[0].text, "b");
    assert(prj_delete_var(&P, 1) == 0 && strcmp(scr(0, 0)->blocks[cv].a[0].text, "a") == 0);
    assert(prj_delete_var(&P, 0) == 0 && scr(0, 0)->blocks[cv].a[0].text[0] == 0 && P.nvars == 0);
    assert(prj_delete_var(&P, 0) == -1);
    assert(prj_add_list(&P, "L") == 0 && prj_add_list(&P, "L") == 0 && prj_find_list(&P, "L") == 0);
    assert(prj_delete_list(&P, 0) == 0 && P.nlists == 0);

    fresh();
    f = ins(0, BK_FOREVER);
    ins(f, BK_MOVE);
    rt_green_flag(&RT, &P);
    run(5);
    assert(near(RT.spr[0].x, 50.f) && near(RT.spr[0].y, 0.f) && rt_running(&RT));
    rt_stop(&RT);
    assert(!rt_running(&RT));

    fresh();
    int rp = ins(0, BK_REPEAT);
    lit(rp, 0, "3");
    int t1 = ins(rp, BK_TURN_R); lit(t1, 0, "90");
    ins(t1, BK_MOVE);
    int after = prj_match_end(scr(0, 0), rp);
    int cx = ins(after, BK_CHANGE_X); lit(cx, 0, "100");
    rt_green_flag(&RT, &P);
    run(10);
    assert(!rt_running(&RT));
    assert(near(RT.spr[0].dir, 0.f));
    assert(near(RT.spr[0].x, 90.f) && near(RT.spr[0].y, 0.f));

    fresh();
    int w = ins(0, BK_WAIT); lit(w, 0, "1");
    int c1 = ins(w, BK_CHANGE_X);
    (void)c1;
    rt_green_flag(&RT, &P);
    run(30);
    assert(near(RT.spr[0].x, 0.f));
    run(40);
    assert(near(RT.spr[0].x, 10.f) && !rt_running(&RT));

    fresh();
    int k = prj_new_script(&P, 0, BK_HAT_KEY);
    strcpy(P.sprites[0].scripts[k].blocks[0].a[0].text, "up arrow");
    prj_insert_block(&P, 0, k, 0, BK_CHANGE_Y);
    rt_reset(&RT, &P);
    rt_key(&RT, &P, "space"); run(1);
    assert(near(RT.spr[0].y, 0.f));
    rt_key(&RT, &P, "up arrow"); run(1);
    assert(near(RT.spr[0].y, 10.f));

    fresh();
    prj_add_var(&P, "score");
    int a1 = ins(0, BK_SET_VAR); lit(a1, 1, "0");
    int r1 = ins(a1, BK_REPEAT); lit(r1, 0, "5");
    int a2 = ins(r1, BK_CHANGE_VAR); lit(a2, 1, "2");
    int e1 = prj_match_end(scr(0, 0), r1);
    int ib = ins(e1, BK_IF_ELSE);
    int say1 = ins(ib, BK_SAY); lit(say1, 0, "big");
    int el = prj_match_else(scr(0, 0), ib);
    int say2 = ins(el, BK_SAY); lit(say2, 0, "small");
    sc = scr(0, 0);
    assert(prj_plug(&P, 0, sc, &sc->blocks[ib], 0, BK_GT, NULL) == 0);
    Block *gt = sub(ib, (int[]){ 0 }, 1);
    assert(prj_plug(&P, 0, sc, gt, 0, BK_VAR, "score") == 0);
    strcpy(gt->a[1].text, "5");
    rt_green_flag(&RT, &P);
    run(30);
    assert(!rt_running(&RT));
    assert(near(RT.var[0].n, 10.f) && strcmp(RT.spr[0].say, "big") == 0);
    lit(a2, 1, "0.5");
    rt_green_flag(&RT, &P);
    run(30);
    assert(near(RT.var[0].n, 2.5f) && strcmp(RT.spr[0].say, "small") == 0);

    fresh();
    prj_add_var(&P, "r");
    int sv2 = ins(0, BK_SET_VAR);
    sc = scr(0, 0);
    struct { BlockKind k; const char *a, *b; float num; const char *str; } ops[] = {
        { BK_ADD, "2", "3", 5, NULL }, { BK_SUB, "2", "3", -1, NULL }, { BK_MUL, "4", "2.5", 10, NULL },
        { BK_DIV, "9", "3", 3, NULL }, { BK_DIV, "1", "0", 0, NULL }, { BK_MOD, "10", "3", 1, NULL },
        { BK_MOD, "-1", "3", 2, NULL }, { BK_LT, "1", "2", 1, "true" }, { BK_GT, "1", "2", 0, "false" },
        { BK_EQ, "abc", "ABC", 1, "true" }, { BK_EQ, "10", "10.0", 1, "true" }, { BK_EQ, "a", "b", 0, "false" },
        { BK_JOIN, "hello ", "world", 0, "hello world" }, { BK_LETTER, "2", "world", 0, "o" },
        { BK_LETTER, "9", "world", 0, "" }, { BK_LENGTH, "world", "", 5, NULL },
    };
    for (unsigned i = 0; i < sizeof ops / sizeof ops[0]; i++) {
        assert(prj_plug(&P, 0, sc, &sc->blocks[sv2], 1, ops[i].k, NULL) == 0);
        Block *op = sub(sv2, (int[]){ 1 }, 1);
        strcpy(op->a[0].text, ops[i].a);
        strcpy(op->a[1].text, ops[i].b);
        if (ops[i].k == BK_LENGTH) strcpy(op->a[0].text, ops[i].a);
        rt_green_flag(&RT, &P);
        run(2);
        char got[TEXT_LEN];
        val_to_str(&RT.var[0], got, sizeof got);
        if (ops[i].str) assert(strcmp(got, ops[i].str) == 0);
        else { char want[TEXT_LEN]; snprintf(want, sizeof want, "%d", (int)ops[i].num); assert(strcmp(got, want) == 0); }
    }

    assert(prj_plug(&P, 0, sc, &sc->blocks[sv2], 1, BK_FUNC, NULL) == 0);
    Block *fn = sub(sv2, (int[]){ 1 }, 1);
    strcpy(fn->a[0].text, "sqrt"); strcpy(fn->a[1].text, "49");
    rt_green_flag(&RT, &P); run(2); assert(near(RT.var[0].n, 7.f));
    strcpy(fn->a[0].text, "sin"); strcpy(fn->a[1].text, "90");
    rt_green_flag(&RT, &P); run(2); assert(near(RT.var[0].n, 1.f));
    strcpy(fn->a[0].text, "10 ^"); strcpy(fn->a[1].text, "2");
    rt_green_flag(&RT, &P); run(2); assert(near(RT.var[0].n, 100.f));
    strcpy(fn->a[0].text, "atan"); strcpy(fn->a[1].text, "1");
    rt_green_flag(&RT, &P); run(2); assert(near(RT.var[0].n, 45.f));
    assert(prj_plug(&P, 0, sc, &sc->blocks[sv2], 1, BK_RANDOM, NULL) == 0);
    Block *rn = sub(sv2, (int[]){ 1 }, 1);
    strcpy(rn->a[0].text, "3"); strcpy(rn->a[1].text, "5");
    int seen[3] = { 0 };
    for (int i = 0; i < 60; i++) {
        rt_green_flag(&RT, &P); RT.rng = 77u + (unsigned)i * 7919u; run(2);
        int v = (int)RT.var[0].n;
        assert(v >= 3 && v <= 5 && near(RT.var[0].n, (float)v));
        seen[v - 3] = 1;
    }
    assert(seen[0] && seen[1] && seen[2]);
    assert(prj_plug(&P, 0, sc, &sc->blocks[sv2], 1, BK_ROUND, NULL) == 0);
    strcpy(sub(sv2, (int[]){ 1 }, 1)->a[0].text, "2.6");
    rt_green_flag(&RT, &P); run(2); assert(near(RT.var[0].n, 3.f));

    fresh();
    prj_add_var(&P, "n");
    int ru = ins(0, BK_UNTIL);
    int cvn = ins(ru, BK_CHANGE_VAR); lit(cvn, 1, "1");
    sc = scr(0, 0);
    assert(prj_plug(&P, 0, sc, &sc->blocks[ru], 0, BK_GT, NULL) == 0);
    Block *g2 = sub(ru, (int[]){ 0 }, 1);
    assert(prj_plug(&P, 0, sc, g2, 0, BK_VAR, "n") == 0);
    strcpy(g2->a[1].text, "3");
    rt_green_flag(&RT, &P); run(20);
    assert(near(RT.var[0].n, 4.f) && !rt_running(&RT));

    fresh();
    prj_add_var(&P, "n");
    int fv = ins(0, BK_FOREVER);
    int cvn2 = ins(fv, BK_CHANGE_VAR); lit(cvn2, 1, "1");
    (void)cvn2;
    int s2 = prj_new_script(&P, 0, BK_HAT_FLAG);
    int wu = prj_insert_block(&P, 0, s2, 0, BK_WAIT_UNTIL);
    int mv2 = prj_insert_block(&P, 0, s2, wu, BK_CHANGE_X);
    (void)mv2;
    Script *sc2 = &P.sprites[0].scripts[s2];
    assert(prj_plug(&P, 0, sc2, &sc2->blocks[wu], 0, BK_GT, NULL) == 0);
    Block *g3 = prj_node(sc2, wu, (int[]){ 0 }, 1);
    assert(prj_plug(&P, 0, sc2, g3, 0, BK_VAR, "n") == 0);
    strcpy(g3->a[1].text, "6");
    rt_green_flag(&RT, &P);
    run(5);
    assert(near(RT.spr[0].x, 0.f));
    run(5);
    assert(near(RT.spr[0].x, 10.f));
    rt_stop(&RT);

    fresh();
    prj_add_sprite(&P);
    int bw = ins(0, BK_BROADCAST_WAIT); lit(bw, 0, "go");
    int sy = ins(bw, BK_SAY); lit(sy, 0, "done");
    int rcv = prj_new_script(&P, 1, BK_HAT_RECV);
    strcpy(P.sprites[1].scripts[rcv].blocks[0].a[0].text, "go");
    int wt = prj_insert_block(&P, 1, rcv, 0, BK_WAIT);
    strcpy(P.sprites[1].scripts[rcv].blocks[wt].a[0].text, "0.5");
    prj_insert_block(&P, 1, rcv, wt, BK_CHANGE_X);
    float x0 = (float)P.sprites[1].x;
    rt_green_flag(&RT, &P);
    run(10);
    assert(near(RT.spr[1].x, x0) && RT.spr[0].say[0] == 0);
    run(30);
    assert(near(RT.spr[1].x, x0 + 10.f));
    run(5);
    assert(strcmp(RT.spr[0].say, "done") == 0);

    fresh();
    prj_add_sprite(&P);
    int bc = ins(0, BK_BROADCAST); lit(bc, 0, "go");
    rcv = prj_new_script(&P, 1, BK_HAT_RECV);
    strcpy(P.sprites[1].scripts[rcv].blocks[0].a[0].text, "go");
    prj_insert_block(&P, 1, rcv, 0, BK_CHANGE_X);
    x0 = (float)P.sprites[1].x;
    rt_green_flag(&RT, &P);
    run(1);
    assert(near(RT.spr[1].x, x0));
    run(2);
    assert(near(RT.spr[1].x, x0 + 10.f));

    fresh();
    int gl = ins(0, BK_GLIDE); lit(gl, 0, "1"); lit(gl, 1, "60"); lit(gl, 2, "-30");
    int sf = ins(gl, BK_SAY_FOR); lit(sf, 0, "hi"); lit(sf, 1, "0.5");
    rt_green_flag(&RT, &P);
    run(30);
    assert(RT.spr[0].x > 20.f && RT.spr[0].x < 40.f);
    run(40);
    assert(near(RT.spr[0].x, 60.f) && near(RT.spr[0].y, -30.f) && strcmp(RT.spr[0].say, "hi") == 0);
    run(40);
    assert(RT.spr[0].say[0] == 0 && !rt_running(&RT));
    fresh();
    int pt = ins(0, BK_POINT_TOWARDS); lit(pt, 0, "mouse-pointer");
    rt_green_flag(&RT, &P); rt_pointer(&RT, 100, 100, 1);
    run(2);
    assert(near(RT.spr[0].dir, 45.f));
    rt_green_flag(&RT, &P); RT.spr[0].dir = 10; rt_pointer(&RT, 100, 100, 0);
    run(2);
    assert(near(RT.spr[0].dir, 10.f));
    fresh();
    int gt2 = ins(0, BK_GOTO_XY); lit(gt2, 0, "12"); lit(gt2, 1, "34");
    int ssz = ins(gt2, BK_SET_SIZE); lit(ssz, 0, "50");
    int sef = ins(ssz, BK_SET_EFFECT); lit(sef, 0, "ghost"); lit(sef, 1, "40");
    rt_green_flag(&RT, &P); run(2);
    assert(near(RT.spr[0].x, 12.f) && near(RT.spr[0].y, 34.f) && near(RT.spr[0].size, 50.f) && near(RT.spr[0].ghost, 40.f));
    fresh();
    prj_add_sprite(&P); prj_add_sprite(&P);
    int fr = ins(0, BK_FRONT); (void)fr;
    rt_green_flag(&RT, &P); run(2);
    assert(RT.order[P.nsprites - 1] == 0);
    fresh();
    f = ins(0, BK_FOREVER);
    int mvb = ins(f, BK_MOVE); lit(mvb, 0, "30");
    ins(mvb, BK_BOUNCE);
    rt_green_flag(&RT, &P);
    for (int i = 0; i < 500; i++) { run(1); assert(fabsf(RT.spr[0].x) <= 241.f); }

    fresh();
    prj_add_costume(&P, 0);
    prj_add_sound(&P, 0);
    P.sprites[0].cur_costume = 0;
    int hd = ins(0, BK_HIDE); int nx = ins(hd, BK_NEXT_COSTUME); int pl = ins(nx, BK_PLAY_SOUND); ins(pl, BK_SHOW);
    int nt = ins(pl + 1, BK_NOTE); lit(nt, 0, "69"); lit(nt, 1, "1");
    rt_green_flag(&RT, &P); run(1);
    assert(RT.spr[0].costume == 1 && RT.spr[0].visible == 1);
    SoundEvt ev;
    assert(rt_pop_sound(&RT, &ev) && ev.sprite == 0 && ev.sound == 0);
    assert(rt_pop_sound(&RT, &ev) && ev.sound == SND_TONE && ev.freq == 440 && ev.ms == 1000);
    assert(!rt_pop_sound(&RT, &ev) && rt_running(&RT));
    run(70);
    assert(!rt_running(&RT));

    fresh();
    prj_add_sprite(&P);
    prj_add_var(&P, "t");
    {
        int red = pal_find("red"), blue = pal_find("blue"), green = pal_find("green");
        assert(red != blue && red != green);
        memset(P.sprites[0].costumes[0].px, red, COSTUME_W * COSTUME_H);
        memset(P.sprites[1].costumes[0].px, blue, COSTUME_W * COSTUME_H);
        memset(P.sprites[STAGE_IDX].costumes[0].px, 0, COSTUME_W * COSTUME_H);
        for (int r = 0; r < COSTUME_H; r++) for (int c = COSTUME_W / 2; c < COSTUME_W; c++)
            P.sprites[STAGE_IDX].costumes[0].px[r * COSTUME_W + c] = (uint8_t)green;
        P.sprites[0].x = -150; P.sprites[0].y = 0; P.sprites[1].x = 150; P.sprites[1].y = 0;
        sv = ins(0, BK_SET_VAR);
        sc = scr(0, 0);
        assert(prj_plug(&P, 0, sc, &sc->blocks[sv], 1, BK_TOUCHING_COLOR, NULL) == 0);
        char got[TEXT_LEN];
        strcpy(sub(sv, (int[]){ 1 }, 1)->a[0].text, "green");
        rt_green_flag(&RT, &P); run(2); val_to_str(&RT.var[0], got, sizeof got); assert(strcmp(got, "false") == 0);
        P.sprites[0].x = 150; P.sprites[0].y = 100;
        rt_green_flag(&RT, &P); run(2); val_to_str(&RT.var[0], got, sizeof got); assert(strcmp(got, "true") == 0);
        strcpy(sub(sv, (int[]){ 1 }, 1)->a[0].text, "blue");
        rt_green_flag(&RT, &P); run(2); val_to_str(&RT.var[0], got, sizeof got); assert(strcmp(got, "false") == 0);
        P.sprites[0].y = 40;
        rt_green_flag(&RT, &P); run(2); val_to_str(&RT.var[0], got, sizeof got); assert(strcmp(got, "true") == 0);
        P.sprites[0].visible = 0;
        rt_green_flag(&RT, &P); run(2); val_to_str(&RT.var[0], got, sizeof got); assert(strcmp(got, "false") == 0);
        P.sprites[0].visible = 1;
        assert(prj_plug(&P, 0, sc, &sc->blocks[sv], 1, BK_COLOR_SEES, NULL) == 0);
        strcpy(sub(sv, (int[]){ 1 }, 1)->a[0].text, "red");
        strcpy(sub(sv, (int[]){ 1 }, 1)->a[1].text, "blue");
        rt_green_flag(&RT, &P); run(2); val_to_str(&RT.var[0], got, sizeof got); assert(strcmp(got, "true") == 0);
        strcpy(sub(sv, (int[]){ 1 }, 1)->a[0].text, "green");
        rt_green_flag(&RT, &P); run(2); val_to_str(&RT.var[0], got, sizeof got); assert(strcmp(got, "false") == 0);

        assert(rt_pixel_at(&RT, &P, 150, 40) == red);
        assert(rt_pixel_at(&RT, &P, 150, -20) == blue);
        assert(rt_pixel_at(&RT, &P, 200, -150) == green);
        assert(rt_pixel_at(&RT, &P, -200, -150) == 0);
    }

    fresh();
    prj_add_sprite(&P);
    prj_add_var(&P, "t");
    P.sprites[1].x = 0; P.sprites[1].y = 0; P.sprites[0].x = 10; P.sprites[0].y = 10;
    sv = ins(0, BK_SET_VAR);
    sc = scr(0, 0);
    assert(prj_plug(&P, 0, sc, &sc->blocks[sv], 1, BK_TOUCHING, NULL) == 0);
    strcpy(sub(sv, (int[]){ 1 }, 1)->a[0].text, "Sprite2");
    rt_green_flag(&RT, &P); run(2);
    char got[TEXT_LEN]; val_to_str(&RT.var[0], got, sizeof got);
    assert(strcmp(got, "true") == 0);
    P.sprites[0].x = 200;
    rt_green_flag(&RT, &P); run(2); val_to_str(&RT.var[0], got, sizeof got);
    assert(strcmp(got, "false") == 0);
    strcpy(sub(sv, (int[]){ 1 }, 1)->a[0].text, "edge");
    P.sprites[0].x = 230;
    rt_green_flag(&RT, &P); run(2); val_to_str(&RT.var[0], got, sizeof got);
    assert(strcmp(got, "true") == 0);
    assert(prj_plug(&P, 0, sc, &sc->blocks[sv], 1, BK_MOUSE_X, NULL) == 0);
    rt_green_flag(&RT, &P); rt_pointer(&RT, 77, 0, 1); run(2);
    assert(near(RT.var[0].n, 77.f));
    assert(prj_plug(&P, 0, sc, &sc->blocks[sv], 1, BK_KEY_PRESSED, NULL) == 0);
    strcpy(sub(sv, (int[]){ 1 }, 1)->a[0].text, "left arrow");
    rt_green_flag(&RT, &P); rt_set_key(&RT, "left arrow", 1); run(2);
    val_to_str(&RT.var[0], got, sizeof got); assert(strcmp(got, "true") == 0);
    assert(prj_plug(&P, 0, sc, &sc->blocks[sv], 1, BK_LOUDNESS, NULL) == 0);
    rt_green_flag(&RT, &P); rt_set_loudness(&RT, 42); run(2);
    assert(near(RT.var[0].n, 42.f));

    assert(prj_plug(&P, 0, sc, &sc->blocks[sv], 1, BK_SENSOR_VALUE, NULL) == 0);
    {
        char zi[8][TEXT_LEN];
        assert(prj_menu_items(&P, 0, 'z', zi, 8) == 5 && strcmp(zi[0], "slider") == 0);
        for (int i = 0; i < 5; i++) assert(strcmp(zi[i], "brightness") != 0);
        for (int i = 0; i < 5; i++) assert(strcmp(zi[i], "light") != 0);
        assert(prj_menu_items(&P, 0, 'u', zi, 8) == 5);
    }
    rt_green_flag(&RT, &P); rt_set_pico(&RT, 80, 20, 30, 40, 1); run(2);

    assert(near(RT.var[0].n, 80.f));
    strcpy(sub(sv, (int[]){ 1 }, 1)->a[0].text, "resistance-A");
    rt_green_flag(&RT, &P); rt_set_pico(&RT, 80, 20, 30, 40, 1); run(2); assert(near(RT.var[0].n, 20.f));
    strcpy(sub(sv, (int[]){ 1 }, 1)->a[0].text, "resistance-C");
    rt_green_flag(&RT, &P); rt_set_pico(&RT, 80, 20, 30, 40, 1); run(2); assert(near(RT.var[0].n, 40.f));
    strcpy(sub(sv, (int[]){ 1 }, 1)->a[0].text, "sound");
    rt_green_flag(&RT, &P); rt_set_loudness(&RT, 61); run(2); assert(near(RT.var[0].n, 61.f));
    assert(prj_plug(&P, 0, sc, &sc->blocks[sv], 1, BK_SENSOR_BTN, NULL) == 0);
    rt_green_flag(&RT, &P); rt_set_pico(&RT, 0, 0, 0, 0, 1); run(2);
    val_to_str(&RT.var[0], got, sizeof got); assert(strcmp(got, "true") == 0);
    rt_green_flag(&RT, &P); rt_set_pico(&RT, 0, 0, 0, 0, 0); run(2);
    val_to_str(&RT.var[0], got, sizeof got); assert(strcmp(got, "false") == 0);
    strcpy(sub(sv, (int[]){ 1 }, 1)->a[0].text, "D connected");
    rt_green_flag(&RT, &P); run(2); val_to_str(&RT.var[0], got, sizeof got); assert(strcmp(got, "false") == 0);
    assert(prj_plug(&P, 0, sc, &sc->blocks[sv], 1, BK_DISTANCE, NULL) == 0);
    strcpy(sub(sv, (int[]){ 1 }, 1)->a[0].text, "Sprite2");
    P.sprites[0].x = 30; P.sprites[0].y = 40;
    rt_green_flag(&RT, &P); run(2);
    assert(near(RT.var[0].n, 50.f));
    assert(prj_plug(&P, 0, sc, &sc->blocks[sv], 1, BK_ATTR_OF, NULL) == 0);
    Block *ao = sub(sv, (int[]){ 1 }, 1);
    strcpy(ao->a[0].text, "y position"); strcpy(ao->a[1].text, "Sprite1");
    rt_green_flag(&RT, &P); run(2);
    assert(near(RT.var[0].n, 40.f));

    fresh();
    prj_add_var(&P, "who");
    int ak = ins(0, BK_ASK); lit(ak, 0, "Name?");
    sv = ins(ak, BK_SET_VAR);
    sc = scr(0, 0);
    assert(prj_plug(&P, 0, sc, &sc->blocks[sv], 1, BK_ANSWER, NULL) == 0);
    rt_green_flag(&RT, &P); run(3);
    assert(rt_ask_pending(&RT) && strcmp(rt_ask_pending(&RT), "Name?") == 0 && rt_running(&RT));
    rt_answer(&RT, "Ana"); run(3);
    char ans[TEXT_LEN]; val_to_str(&RT.var[0], ans, sizeof ans);
    assert(strcmp(ans, "Ana") == 0 && !rt_running(&RT) && !rt_ask_pending(&RT));

    fresh();
    int lh = prj_new_script(&P, 0, BK_HAT_SENSOR);
    strcpy(P.sprites[0].scripts[lh].blocks[0].a[0].text, "loudness");
    strcpy(P.sprites[0].scripts[lh].blocks[0].a[1].text, "30");
    prj_insert_block(&P, 0, lh, 0, BK_CHANGE_X);
    rt_reset(&RT, &P);
    run(3); assert(near(RT.spr[0].x, 0.f));
    rt_set_loudness(&RT, 80); run(3); assert(near(RT.spr[0].x, 10.f));
    run(5); assert(near(RT.spr[0].x, 10.f));
    rt_set_loudness(&RT, 5); run(2); rt_set_loudness(&RT, 80); run(3); assert(near(RT.spr[0].x, 20.f));

    fresh();
    prj_add_list(&P, "L"); prj_add_var(&P, "out");
    int la = ins(0, BK_LIST_ADD); lit(la, 0, "one");
    int lb = ins(la, BK_LIST_ADD); lit(lb, 0, "three");
    int li = ins(lb, BK_LIST_INSERT); lit(li, 0, "two"); lit(li, 1, "2");
    int lr = ins(li, BK_LIST_REPLACE); lit(lr, 0, "3"); lit(lr, 2, "THREE");
    int ld = ins(lr, BK_LIST_DELETE); lit(ld, 0, "1");
    sv = ins(ld, BK_SET_VAR);
    sc = scr(0, 0);
    assert(prj_plug(&P, 0, sc, &sc->blocks[sv], 1, BK_LIST_ITEM, NULL) == 0);
    strcpy(sub(sv, (int[]){ 1 }, 1)->a[0].text, "last");
    rt_green_flag(&RT, &P); run(2);
    assert(RT.list[0].n == 2 && strcmp(RT.list[0].item[0].s, "two") == 0 && strcmp(RT.var[0].s, "THREE") == 0);
    assert(prj_plug(&P, 0, sc, &sc->blocks[sv], 1, BK_LIST_LEN, NULL) == 0);
    rt_green_flag(&RT, &P); run(2);
    assert(near(RT.var[0].n, 2.f));

    fresh();
    int pd = ins(0, BK_PEN_DOWN);
    int pc = ins(pd, BK_PEN_COLOR); lit(pc, 0, "blue");
    int ps2 = ins(pc, BK_PEN_SIZE_SET); lit(ps2, 0, "3");
    int mv3 = ins(ps2, BK_MOVE); lit(mv3, 0, "50");
    int st = ins(mv3, BK_STAMP);
    ins(st, BK_PEN_UP);
    rt_green_flag(&RT, &P); run(2);
    assert(RT.pen_count == 2);
    assert(near(RT.pen[0].x0, RT.pen[0].x1) && near(RT.pen[0].y0, RT.pen[0].y1));
    assert(near(RT.pen[1].x1, 50.f) && near(RT.pen[1].size, 3.f) && RT.pen[1].rgb == PALETTE_RGB[9]);

    fresh();
    {
        int a1 = ins(0, BK_MOVE); lit(a1, 0, "10");
        int a2 = ins(a1, BK_PEN_DOWN);
        int a3 = ins(a2, BK_MOVE); lit(a3, 0, "10");
        int a4 = ins(a3, BK_PEN_UP);
        int a5 = ins(a4, BK_MOVE); lit(a5, 0, "10");
        int a6 = ins(a5, BK_MOVE); lit(a6, 0, "10");
        rt_green_flag(&RT, &P); run(2);
        assert(RT.pen_count == 2 && !RT.spr[0].pen_down && near(RT.spr[0].x, 40.f));
        assert(near(RT.pen[1].x0, 10.f) && near(RT.pen[1].x1, 20.f));
    }

    fresh();
    prj_add_var(&P, "a"); prj_add_var(&P, "b"); prj_add_var(&P, "c");
    {
        Script *scp = scr(0, 0);
        int b1 = ins(0, BK_SET_VAR); strcpy(scp->blocks[b1].a[0].text, "a");
        int b2 = ins(b1, BK_PEN_DOWN);
        int b3 = ins(b2, BK_SET_VAR); strcpy(scp->blocks[b3].a[0].text, "b");
        int b4 = ins(b3, BK_PEN_UP);
        int b5 = ins(b4, BK_SET_VAR); strcpy(scp->blocks[b5].a[0].text, "c");
        assert(prj_plug(&P, 0, scp, &scp->blocks[b1], 1, BK_PEN_IS_DOWN, NULL) == 0);
        assert(prj_plug(&P, 0, scp, &scp->blocks[b3], 1, BK_PEN_IS_DOWN, NULL) == 0);
        assert(prj_plug(&P, 0, scp, &scp->blocks[b5], 1, BK_PEN_IS_DOWN, NULL) == 0);
        rt_green_flag(&RT, &P); run(2);
        assert(RT.var[0].n == 0.f && RT.var[1].n == 1.f && RT.var[2].n == 0.f);
    }
    fresh();
    ins(0, BK_PEN_DOWN); ins(1, BK_PEN_UP);
    rt_green_flag(&RT, &P); run(2);
    assert(RT.pen_count == 1);
    fresh();
    pd = ins(0, BK_PEN_DOWN);
    pc = ins(pd, BK_PEN_COLOR); lit(pc, 0, "blue");
    ps2 = ins(pc, BK_PEN_SIZE_SET); lit(ps2, 0, "3");
    mv3 = ins(ps2, BK_MOVE); lit(mv3, 0, "50");
    st = ins(mv3, BK_STAMP);
    ins(st, BK_PEN_UP);
    rt_green_flag(&RT, &P); run(2);
    assert(RT.nstamps == 1 && near(RT.stamps[0].x, 50.f));
    fresh();
    f = ins(0, BK_PEN_DOWN);
    f = ins(f, BK_FOREVER);
    mvb = ins(f, BK_MOVE); lit(mvb, 0, "10");
    { int tb = ins(mvb, BK_TURN_R); lit(tb, 0, "15"); }
    rt_green_flag(&RT, &P); run(PEN_SEGS + 200);
    assert(RT.pen_count == PEN_SEGS);

    fresh();
    {
        int a = ins(0, BK_PEN_DOWN);
        int f2 = ins(a, BK_FOREVER);
        int m2 = ins(f2, BK_MOVE); lit(m2, 0, "10");
        rt_green_flag(&RT, &P); run(3000);
        float lim = STAGE_W / 2.f + 64.f;
        assert(fabsf(RT.spr[0].x) <= lim && fabsf(RT.spr[0].y) <= lim);
        for (int i = 0; i < RT.pen_count; i++) {
            const PenSeg *g = &RT.pen[(RT.pen_head + i) % PEN_SEGS];
            assert(fabsf(g->x0) <= lim && fabsf(g->x1) <= lim && fabsf(g->y0) <= lim && fabsf(g->y1) <= lim);
        }
    }

    fresh();
    {
        int rp = ins(0, BK_REPEAT); lit(rp, 0, "23");
        int q1 = ins(rp, BK_MOVE); lit(q1, 0, "10");
        int q2 = ins(q1, BK_MOVE); lit(q2, 0, "15");
        int q3 = ins(q2, BK_TURN_R); lit(q3, 0, "20");
        assert(scr(0, 0)->blocks[q3 + 1].kind == BK_END);
        int pd2 = ins(q3 + 1, BK_PEN_DOWN);
        int tl = ins(pd2, BK_TURN_L);
        int fv = ins(tl, BK_FOREVER);
        int mv2 = ins(fv, BK_MOVE); lit(mv2, 0, "10");
        int ib = ins(mv2, BK_IF);
        Script *scp = scr(0, 0);
        assert(prj_plug(&P, 0, scp, &scp->blocks[ib], 0, BK_PEN_IS_DOWN, NULL) == 0);
        int sy = ins(ib, BK_SAY); lit(sy, 0, "drawing");
        (void)sy;
        rt_green_flag(&RT, &P); run(3000);
        float lim = STAGE_W / 2.f + 64.f;
        assert(fabsf(RT.spr[0].x) <= lim && fabsf(RT.spr[0].y) <= lim);
        assert(RT.spr[0].pen_down && strcmp(RT.spr[0].say, "drawing") == 0);
        for (int i = 0; i < RT.pen_count; i++) {
            const PenSeg *g = &RT.pen[(RT.pen_head + i) % PEN_SEGS];
            assert(fabsf(g->x0) <= lim && fabsf(g->x1) <= lim && fabsf(g->y0) <= lim && fabsf(g->y1) <= lim);
        }
    }
    fresh();
    {
        int g1 = ins(0, BK_GOTO_XY); lit(g1, 0, "100000000"); lit(g1, 1, "-100000000");
        rt_green_flag(&RT, &P); run(2);
        assert(fabsf(RT.spr[0].x) < 1000.f && fabsf(RT.spr[0].y) < 1000.f);
        assert(RT.spr[0].x > 0.f && RT.spr[0].y < 0.f);
    }

    fresh();
    prj_add_sprite(&P);
    f = ins(0, BK_FOREVER); ins(f, BK_CHANGE_X);
    int sn = prj_new_script(&P, 1, BK_HAT_FLAG);
    int w2 = prj_insert_block(&P, 1, sn, 0, BK_WAIT); strcpy(P.sprites[1].scripts[sn].blocks[w2].a[0].text, "0.1");
    prj_insert_block(&P, 1, sn, w2, BK_STOP_ALL);
    rt_green_flag(&RT, &P);
    run(3); assert(rt_running(&RT));
    run(10); assert(!rt_running(&RT));
    fresh();
    prj_add_var(&P, "go");
    int fi = ins(0, BK_FOREVER_IF);
    ins(fi, BK_CHANGE_X);
    sc = scr(0, 0);
    assert(prj_plug(&P, 0, sc, &sc->blocks[fi], 0, BK_EQ, NULL) == 0);
    Block *eq = sub(fi, (int[]){ 0 }, 1);
    assert(prj_plug(&P, 0, sc, eq, 0, BK_VAR, "go") == 0);
    strcpy(eq->a[1].text, "1");
    rt_green_flag(&RT, &P); run(5);
    assert(near(RT.spr[0].x, 0.f));
    RT.var[0] = (Val){ .t = V_NUM, .n = 1 }; run(3);
    assert(near(RT.spr[0].x, 30.f));

    fresh();
    int ch = prj_new_script(&P, 0, BK_HAT_CLICK);
    prj_insert_block(&P, 0, ch, 0, BK_CHANGE_Y);
    rt_reset(&RT, &P);
    rt_click(&RT, &P, 100, 100); run(2); assert(near(RT.spr[0].y, 0.f));
    rt_click(&RT, &P, 5, 5); run(2); assert(near(RT.spr[0].y, 10.f));

    fresh();
    sc = scr(0, 0);
    sc->blocks[1] = block_default(BK_FOREVER); sc->nblocks = 2;
    rt_green_flag(&RT, &P); run(3);
    sc->blocks[1] = block_default(BK_END); sc->blocks[2] = block_default(BK_ELSE); sc->nblocks = 3;
    rt_green_flag(&RT, &P); run(3);
    sc->nblocks = 1;
    sc->blocks[sc->nblocks] = block_default(BK_MOVE); sc->nblocks++;
    sc->blocks[1].a[0].expr = 3;
    rt_green_flag(&RT, &P); run(3);
    sc->blocks[1].a[0].expr = 0; sc->ex_used[0] = 1; sc->ex[0] = block_default(BK_ADD);
    sc->ex[0].a[0].expr = 0;
    rt_green_flag(&RT, &P); run(3);
    memset(sc->ex_used, 0, sizeof sc->ex_used);
    sc->blocks[1].a[0].expr = -1;

    Costume c;
    costume_clear(&c);
    costume_fill(&c, 5, 5, 6);
    for (int i = 0; i < COSTUME_W * COSTUME_H; i++) assert(c.px[i] == 6);
    c.px[0] = 3;
    costume_flip_h(&c);
    assert(c.px[COSTUME_W - 1] == 3 && c.px[0] == 6);
    assert(costume_argb(0) == 0 && costume_argb(3) == (0xFF000000u | PALETTE_RGB[3]));
    for (int v = 0; v < 4; v++) {
        costume_make_default(&c, v);
        int n = 0;
        for (int i = 0; i < COSTUME_W * COSTUME_H; i++) n += c.px[i] != 0;
        assert(n > 100);
    }
    assert(pal_find("red") == 3 && pal_find("unknown") == 3 && pal_find("blue") == 9);
    assert(pen_rgb(0, 50) == 0xFF0000 && pen_rgb(0, 0) == 0x000000 && pen_rgb(0, 100) == 0xFFFFFF);
    assert(near(pen_hue_of(0x00FF00), 66.67f) || fabsf(pen_hue_of(0x00FF00) - 66.67f) < 0.1f);

    static int16_t pcm[SND_BUF_MAX];
    Sound snd;
    snd_default(&snd);
    int n = snd_render(&snd, pcm, SND_BUF_MAX);
    assert(n == SND_RATE * 300 / 1000 && snd_rate(&snd) == SND_RATE && snd_duration_ms(&snd) == 300);
    int peak = 0, zc = 0;
    for (int i = 0; i < n; i++) {
        if (abs(pcm[i]) > peak) peak = abs(pcm[i]);
        if (i && ((pcm[i - 1] < 0) != (pcm[i] < 0))) zc++;
    }
    assert(peak > 15000 && peak < 32767 && zc > 250 && zc < 280);
    assert(pcm[0] == 0 && abs(pcm[n - 1]) < 2000);
    snd.ms = 99999; snd.freq = 1; snd.vol = 500;
    assert(snd_render(&snd, pcm, SND_MAX_SAMPLES) == SND_MAX_SAMPLES);
    for (int w3 = 0; w3 < WAVE_COUNT; w3++) { snd.wave = w3; assert(snd_render(&snd, pcm, 1000) == 1000); }
    snd.vol = 0; snd_render(&snd, pcm, 1000);
    for (int i = 0; i < 1000; i++) assert(pcm[i] == 0);

    enum { RING = 4096 };
    static uint8_t ring[RING];
    static int16_t dest[REC_MAX_SAMPLES];
    Recorder rec;
    rec_begin(&rec, dest, REC_MAX_SAMPLES, 0);
    int produced = 0;
    uint32_t wr = 0;
    for (int chunk = 0; chunk < 40; chunk++) {
        for (int i = 0; i < 300; i++) {
            int16_t v = (int16_t)(produced < 3000 ? 0 : (produced % 200) * 100 - 10000);
            if (produced >= 6000 && produced < 9000) v = (int16_t)(v / 50);
            if (produced >= 9000) v = 0;
            ring[wr] = (uint8_t)(v & 255); ring[wr + 1] = (uint8_t)((v >> 8) & 255);
            wr = (wr + 2) % RING;
            produced++;
        }
        int got2 = rec_consume(&rec, ring, RING, wr);
        assert(got2 == 300);
    }
    assert(rec.n == 12000 && !rec.full && produced == 12000);
    for (int i = 3000; i < 6000; i++) assert(dest[i] == (int16_t)((i % 200) * 100 - 10000));
    assert(rec_consume(&rec, ring, RING, wr) == 0);
    Recorder mon;
    rec_begin(&mon, NULL, 0, 1);
    ring[0] = 0xFF; ring[1] = 0x3F;
    assert(rec_consume(&mon, ring, RING, 2) == 1 && mon.level >= 99.f && mon.n == 0);
    Recorder small;
    rec_begin(&small, dest, 100, 0);
    rec_consume(&small, ring, RING, 1000);
    assert(small.n == 100 && small.full);

    memset(dest, 0, 100 * sizeof dest[0]);
    fresh();
    prj_add_recording(&P, 0, dest, 12000, REC_RATE);
    Sound *rs = &P.sprites[0].sounds[0];
    assert(snd_trim(rs) == 0 && rs->npcm < 12000 && rs->npcm > 1000);
    assert(abs(rs->pcm[0]) < 2000 && rs->npcm < 9500);
    int before = rs->npcm;
    assert(snd_normalize(rs) == 0);
    peak = 0; for (int i = 0; i < rs->npcm; i++) if (abs(rs->pcm[i]) > peak) peak = abs(rs->pcm[i]);
    assert(peak > 30000 && peak < 32000 && rs->npcm == before);
    int16_t first = rs->pcm[0], last = rs->pcm[rs->npcm - 1];
    assert(snd_reverse(rs) == 0 && rs->pcm[0] == last && rs->pcm[rs->npcm - 1] == first);
    rs->vol = 50;
    n = snd_render(rs, pcm, SND_BUF_MAX);
    assert(n == rs->npcm && abs(pcm[100]) <= abs(rs->pcm[100]) / 2 + 1);
    Sound synth; snd_default(&synth);
    assert(snd_trim(&synth) == -1 && snd_normalize(&synth) == -1 && snd_reverse(&synth) == -1);
    int16_t silence[500] = { 0 };
    prj_add_recording(&P, 0, silence, 500, REC_RATE);
    assert(snd_trim(&P.sprites[0].sounds[1]) == -1 && snd_normalize(&P.sprites[0].sounds[1]) == -1);

    prj_clear(&P);

    fresh();
    {
        int a = ins(0, BK_MOVE), b = ins(a, BK_SAY), c = ins(b, BK_IF), d = ins(c, BK_WAIT), e = ins(d, BK_TURN_R);
        Script *q = scr(0, 0);
        assert(c < d && q->blocks[e].kind == BK_TURN_R);
        int n0 = q->nblocks;

        int r = prj_move_block(&P, 0, 0, a, q->nblocks - 1);
        assert(r == q->nblocks - 1 && q->nblocks == n0 && q->blocks[r].kind == BK_MOVE && q->blocks[1].kind == BK_SAY);

        int ci = 2; assert(q->blocks[ci].kind == BK_IF);
        int endi = prj_match_end(q, ci);
        r = prj_move_block(&P, 0, 0, ci, 0);
        assert(r == 1 && q->blocks[1].kind == BK_IF && q->nblocks == n0);
        endi--;
        assert(prj_match_end(q, 1) == endi);

        assert(prj_move_block(&P, 0, 0, 1, 1) == -2);
        assert(prj_move_block(&P, 0, 0, 1, endi) == -2);

        assert(prj_move_block(&P, 0, 0, 0, 3) == -1);
        assert(prj_move_block(&P, 0, 0, endi, 0) == -1);

        r = prj_move_block(&P, 0, 0, q->nblocks - 1, 1);
        assert(r == 2 && prj_match_end(q, 1) == endi + 1);

        int e2 = prj_match_end(q, 1);
        r = prj_move_block(&P, 0, 0, 2, e2);
        assert(r == e2 && q->blocks[e2].kind != BK_END && prj_match_end(q, 1) == e2 - 1);
    }

    fresh();
    {
        int cl = prj_new_script(&P, 0, BK_HAT_CLONE);
        int m = prj_insert_block(&P, 0, cl, 0, BK_CHANGE_X); strcpy(scr(0, cl)->blocks[m].a[0].text, "10");
        int w = prj_insert_block(&P, 0, cl, m, BK_WAIT); strcpy(scr(0, cl)->blocks[w].a[0].text, "0.5");
        prj_insert_block(&P, 0, cl, w, BK_CLONE_DEL);
        int rp = ins(0, BK_REPEAT); strcpy(scr(0, 0)->blocks[rp].a[0].text, "3");
        int cc = ins(rp, BK_CLONE); assert(!strcmp(scr(0, 0)->blocks[cc].a[0].text, "myself"));
        rt_green_flag(&RT, &P);
        assert(rt_nclones(&RT) == 0 && RT.norder == 1);
        run(1);
        assert(rt_nclones(&RT) == 1);
        run(10);
        assert(rt_nclones(&RT) == 3 && RT.norder == 4);
        assert(RT.spr[MAX_SPRITES].is_clone && RT.spr[MAX_SPRITES].def == 0 && RT.spr[0].is_clone == 0);
        assert(near(RT.spr[0].x, 0.f) && RT.spr[MAX_SPRITES].x > 0.f);
        run(60);
        assert(rt_nclones(&RT) == 0 && RT.norder == 1);
        assert(!rt_running(&RT));

        rt_green_flag(&RT, &P); run(12);
        assert(rt_nclones(&RT) == 3);
        rt_stop(&RT);
        assert(rt_nclones(&RT) == 0 && RT.norder == 1 && !rt_running(&RT));

        fresh();
        ins(0, BK_CLONE_DEL); int sa = ins(1, BK_SAY); strcpy(scr(0, 0)->blocks[sa].a[0].text, "alive");
        rt_green_flag(&RT, &P); run(3);
        assert(!strcmp(RT.spr[0].say, "alive") && RT.spr[0].alive);

        fresh();
        prj_add_sprite(&P);
        int c1 = prj_new_script(&P, 1, BK_HAT_CLONE);
        int s1 = prj_insert_block(&P, 1, c1, 0, BK_SAY); strcpy(P.sprites[1].scripts[c1].blocks[s1].a[0].text, "hi");
        int fv = ins(0, BK_FOREVER);
        int k = ins(fv, BK_CLONE); strcpy(scr(0, 0)->blocks[k].a[0].text, P.sprites[1].name);
        rt_green_flag(&RT, &P); run(MAX_CLONES + 20);
        assert(rt_nclones(&RT) == MAX_CLONES);
        for (int i = MAX_SPRITES; i < MAX_SPRITES + MAX_CLONES; i++) assert(RT.spr[i].def == 1 && !strcmp(RT.spr[i].say, "hi"));

        assert(RT.norder == 2 + MAX_CLONES);

        prj_rename_sprite(&P, 1, "Enemy");
        assert(!strcmp(scr(0, 0)->blocks[k].a[0].text, "Enemy"));
        prj_delete_sprite(&P, 1);
        assert(!strcmp(scr(0, 0)->blocks[k].a[0].text, "myself"));
        char items[MENU_MAX][TEXT_LEN];
        assert(prj_menu_items(&P, 0, 'y', items, MENU_MAX) == 1 && !strcmp(items[0], "myself"));
    }

    fresh();
    {
        UndoStack U; memset(&U, 0, sizeof U);
        assert(undo_undo(&U, &P) == -1 && undo_redo(&U, &P) == -1);
        undo_checkpoint(&U, &P, 0);
        int a = ins(0, BK_MOVE);
        undo_checkpoint(&U, &P, 0);
        int b = ins(a, BK_SAY);
        assert(scr(0, 0)->nblocks == 3 && b == 2);
        assert(undo_undo(&U, &P) == 0 && scr(0, 0)->nblocks == 2);
        assert(undo_undo(&U, &P) == 0 && scr(0, 0)->nblocks == 1);
        assert(undo_undo(&U, &P) == -1);
        assert(undo_redo(&U, &P) == 0 && scr(0, 0)->nblocks == 2);
        assert(undo_redo(&U, &P) == 0 && scr(0, 0)->nblocks == 3 && scr(0, 0)->blocks[2].kind == BK_SAY);
        assert(undo_redo(&U, &P) == -1);

        undo_checkpoint(&U, &P, 0);
        prj_new_script(&P, 0, BK_HAT_KEY);
        assert(P.sprites[0].nscripts == 2);
        undo_undo(&U, &P); assert(P.sprites[0].nscripts == 1);
        undo_redo(&U, &P); assert(P.sprites[0].nscripts == 2);

        undo_checkpoint(&U, &P, 0); undo_discard(&U);
        undo_undo(&U, &P); assert(P.sprites[0].nscripts == 1);
        undo_checkpoint(&U, &P, 0); assert(U.nredo == 0);

        for (int i = 0; i < UNDO_DEPTH + 10; i++) undo_checkpoint(&U, &P, 0);
        assert(U.nundo == UNDO_DEPTH);

        prj_add_sprite(&P);
        undo_clear(&U);
        ins(2, BK_WAIT);
        undo_checkpoint(&U, &P, 1);
        prj_delete_sprite(&P, 1);
        assert(undo_undo(&U, &P) == -1);
        undo_clear(&U);
        assert(U.nundo == 0 && U.nredo == 0);
    }

    fresh();
    {
        int a = ins(0, BK_SAY);
        int r = ins(a, BK_REPEAT); lit(r, 0, "4");
        int m = ins(r, BK_CHANGE_X);
        Script *q = scr(0, 0);
        assert(prj_plug(&P, 0, q, &q->blocks[m], 0, BK_ADD, NULL) == 0);
        Block *add = sub(m, (int[]){ 0 }, 1);
        assert(prj_plug(&P, 0, q, add, 0, BK_MUL, NULL) == 0);
        int n0 = q->nblocks;
        int d = prj_duplicate_block(&P, 0, 0, r);
        assert(d > r && q->nblocks == n0 + 3 && q->blocks[d].kind == BK_REPEAT && !strcmp(q->blocks[d].a[0].text, "4"));
        assert(prj_match_end(q, d) == d + 2 && q->blocks[d + 1].kind == BK_CHANGE_X);

        Block *c1 = prj_node(q, m, (int[]){ 0 }, 1), *c2 = prj_node(q, d + 1, (int[]){ 0 }, 1);
        assert(c1 && c2 && c1 != c2 && c1->kind == BK_ADD && c2->kind == BK_ADD);
        strcpy(c2->a[1].text, "99");
        assert(strcmp(c1->a[1].text, "99") != 0);
        assert(prj_node(q, d + 1, (int[]){ 0, 0 }, 2) != prj_node(q, m, (int[]){ 0, 0 }, 2));

        assert(prj_duplicate_block(&P, 0, 0, 0) == -1);
        assert(prj_duplicate_block(&P, 0, 0, prj_match_end(q, r)) == -1);
        Script before = *q;
        for (int i = 0; i < MAX_EXPR; i++) if (!q->ex_used[i]) { q->ex_used[i] = 1; }
        Script full = *q;
        assert(prj_duplicate_block(&P, 0, 0, m) == -2);
        assert(memcmp(&full, q, sizeof full) == 0);
        (void)before;
        fresh();
        int last = 0;
        for (int i = 0; i < MAX_BLOCKS - 1; i++) last = ins(last, BK_MOVE);
        assert(scr(0, 0)->nblocks == MAX_BLOCKS && prj_duplicate_block(&P, 0, 0, 1) == -1);

        fresh();
        ins(0, BK_MOVE);
        int sd = prj_duplicate_script(&P, 0, 0);
        assert(sd == 1 && scr(0, 1)->nblocks == 2 && scr(0, 1)->blocks[1].kind == BK_MOVE && P.sprites[0].nscripts == 2);
        while (P.sprites[0].nscripts < MAX_SCRIPTS) prj_duplicate_script(&P, 0, 0);
        assert(prj_duplicate_script(&P, 0, 0) == -1);
    }

    fresh();
    {
        for (int k = 0; k < SND_PRESET_COUNT; k++) {
            Sound s; snd_default(&s);
            assert(snd_make_preset(&s, k) == 0 && snd_is_recorded(&s) && s.npcm > 150 && s.npcm <= 11025);
            int peak = 0; for (int i = 0; i < s.npcm; i++) { int v = abs(s.pcm[i]); if (v > peak) peak = v; }
            assert(peak > 3000 && peak < 32768);
            assert(abs(s.pcm[0]) < 3000);
            snd_free(&s);
        }
        Sound bad; snd_default(&bad);
        assert(snd_make_preset(&bad, -1) == -1 && snd_make_preset(&bad, SND_PRESET_COUNT) == -1);
        int e1 = prj_add_effect(&P, 0, 0), e2 = prj_add_effect(&P, 0, 0);
        assert(e1 >= 0 && e2 == e1 + 1 && strcmp(P.sprites[0].sounds[e1].name, P.sprites[0].sounds[e2].name) != 0);
        int dup = prj_duplicate_sound(&P, 0, e1);
        assert(dup >= 0 && P.sprites[0].sounds[dup].pcm != P.sprites[0].sounds[e1].pcm && P.sprites[0].sounds[dup].npcm == P.sprites[0].sounds[e1].npcm);
        assert(memcmp(P.sprites[0].sounds[dup].pcm, P.sprites[0].sounds[e1].pcm, (size_t)P.sprites[0].sounds[dup].npcm * 2) == 0);
        assert(strcmp(P.sprites[0].sounds[dup].name, P.sprites[0].sounds[e1].name) != 0);
        assert(prj_add_effect(&P, 0, 99) == -1 && prj_duplicate_sound(&P, 0, 50) == -1);
        assert(prj_add_effect(&P, STAGE_IDX, 1) >= 0);
    }

    puts("all editor/runtime/assets tests passed");
    return 0;
}
