#include "svg.h"

#include <ctype.h>
#include <math.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_PTS   60000
#define MAX_SUBS  4000
#define MAX_DEPTH 24
#define CURVE_SEGS 14

typedef struct { double a, b, c, d, e, f; } Mat;

typedef struct {
    int fill, stroke;
    double sw, fo, so, op;
    int evenodd;
    Mat m;
} Style;

typedef struct {
    unsigned char *buf;
    int w, h;
    double *x, *y;
    int npts;
    int *start;
    int nsub;
    double *cx;
    int ccap;
} Ctx;

static Mat mat_id(void) { Mat m = { 1, 0, 0, 1, 0, 0 }; return m; }

static Mat mat_mul(Mat A, Mat B)
{
    Mat r;
    r.a = A.a * B.a + A.c * B.b;
    r.b = A.b * B.a + A.d * B.b;
    r.c = A.a * B.c + A.c * B.d;
    r.d = A.b * B.c + A.d * B.d;
    r.e = A.a * B.e + A.c * B.f + A.e;
    r.f = A.b * B.e + A.d * B.f + A.f;
    return r;
}

static const char *skip_ws(const char *p, const char *end)
{
    while (p < end && (isspace((unsigned char)*p) || *p == ',')) p++;
    return p;
}

static int parse_num(const char **pp, const char *end, double *out)
{
    const char *p = skip_ws(*pp, end);
    if (p >= end) return 0;
    char tmp[48];
    int n = 0;
    const char *q = p;
    if (q < end && (*q == '+' || *q == '-')) tmp[n++] = *q++;
    int digits = 0, dot = 0;
    while (q < end && n < 40) {
        if (isdigit((unsigned char)*q)) { tmp[n++] = *q++; digits++; }
        else if (*q == '.' && !dot) { dot = 1; tmp[n++] = *q++; }
        else break;
    }
    if (!digits) return 0;
    if (q < end && (*q == 'e' || *q == 'E')) {
        const char *r = q + 1;
        if (r < end && (*r == '+' || *r == '-')) r++;
        if (r < end && isdigit((unsigned char)*r)) {
            tmp[n++] = 'e';
            q++;
            if (*q == '+' || *q == '-') tmp[n++] = *q++;
            while (q < end && isdigit((unsigned char)*q) && n < 46) tmp[n++] = *q++;
        }
    }
    tmp[n] = 0;
    *out = atof(tmp);
    *pp = q;
    return 1;
}

static int get_attr(const char *t, const char *te, const char *name, char *out, size_t on)
{
    size_t nl = strlen(name);
    for (const char *p = t; p + nl + 2 < te; p++) {
        if (strncmp(p, name, nl) != 0) continue;
        if (p > t && !isspace((unsigned char)p[-1])) continue;
        const char *q = p + nl;
        while (q < te && isspace((unsigned char)*q)) q++;
        if (q >= te || *q != '=') continue;
        q++;
        while (q < te && isspace((unsigned char)*q)) q++;
        if (q >= te || (*q != '"' && *q != '\'')) continue;
        char quote = *q++;
        size_t i = 0;
        while (q < te && *q != quote && i + 1 < on) out[i++] = *q++;
        out[i] = 0;
        return 1;
    }
    return 0;
}

static int get_prop(const char *t, const char *te, const char *name, char *out, size_t on)
{
    char st[512];
    if (get_attr(t, te, "style", st, sizeof st)) {
        size_t nl = strlen(name);
        const char *p = st;
        while (*p) {
            while (*p == ' ' || *p == ';') p++;
            if (!strncmp(p, name, nl)) {
                const char *q = p + nl;
                while (*q == ' ') q++;
                if (*q == ':') {
                    q++;
                    while (*q == ' ') q++;
                    size_t i = 0;
                    while (*q && *q != ';' && i + 1 < on) out[i++] = *q++;
                    while (i > 0 && out[i - 1] == ' ') i--;
                    out[i] = 0;
                    return 1;
                }
            }
            while (*p && *p != ';') p++;
        }
    }
    return get_attr(t, te, name, out, on);
}

static int hexv(char c)
{
    if (c >= '0' && c <= '9') return c - '0';
    if (c >= 'a' && c <= 'f') return c - 'a' + 10;
    if (c >= 'A' && c <= 'F') return c - 'A' + 10;
    return -1;
}

static int find_gradient_color(const char *svg, const char *end, const char *id, int depth);

static int parse_color(const char *s, const char *svg, const char *end, int depth)
{
    while (*s == ' ') s++;
    if (!*s || !strncmp(s, "none", 4) || !strncmp(s, "transparent", 11)) return -1;
    if (s[0] == '#') {
        int d[6], n = 0;
        for (const char *p = s + 1; hexv(*p) >= 0 && n < 6; p++) d[n++] = hexv(*p);
        if (n == 3) return (d[0] * 17) << 16 | (d[1] * 17) << 8 | (d[2] * 17);
        if (n >= 6) return (d[0] << 4 | d[1]) << 16 | (d[2] << 4 | d[3]) << 8 | (d[4] << 4 | d[5]);
        return 0;
    }
    if (!strncmp(s, "rgb", 3)) {
        const char *p = strchr(s, '(');
        double v[3] = { 0, 0, 0 };
        if (p) {
            p++;
            for (int i = 0; i < 3; i++) {
                if (!parse_num(&p, p + 40, &v[i])) break;
                if (*p == '%') { v[i] = v[i] * 2.55; p++; }
            }
        }
        for (int i = 0; i < 3; i++) { if (v[i] < 0) v[i] = 0; if (v[i] > 255) v[i] = 255; }
        return ((int)v[0] << 16) | ((int)v[1] << 8) | (int)v[2];
    }
    if (!strncmp(s, "url(", 4)) {
        const char *h = strchr(s, '#');
        char id[64];
        int n = 0;
        if (h) for (h++; *h && *h != ')' && *h != '"' && *h != '\'' && n < 60; h++) id[n++] = *h;
        id[n] = 0;
        if (!n || depth > 3) return 0x808080;
        int c = find_gradient_color(svg, end, id, depth + 1);
        return c < 0 ? 0x808080 : c;
    }
    static const struct { const char *n; int c; } names[] = {
        { "black", 0x000000 }, { "white", 0xFFFFFF }, { "red", 0xFF0000 }, { "green", 0x008000 }, { "blue", 0x0000FF },
        { "yellow", 0xFFFF00 }, { "orange", 0xFFA500 }, { "purple", 0x800080 }, { "pink", 0xFFC0CB }, { "gray", 0x808080 },
        { "grey", 0x808080 }, { "brown", 0xA52A2A }, { "cyan", 0x00FFFF }, { "magenta", 0xFF00FF }, { "lime", 0x00FF00 },
        { "navy", 0x000080 }, { "teal", 0x008080 }, { "maroon", 0x800000 }, { "silver", 0xC0C0C0 },
    };
    for (unsigned i = 0; i < sizeof names / sizeof names[0]; i++) {
        size_t l = strlen(names[i].n);
        if (!strncmp(s, names[i].n, l) && !isalpha((unsigned char)s[l])) return names[i].c;
    }
    return 0;
}

static int find_gradient_color(const char *svg, const char *end, const char *id, int depth)
{
    char pat[80];
    snprintf(pat, sizeof pat, "id=\"%s\"", id);
    const char *p = strstr(svg, pat);
    if (!p) { snprintf(pat, sizeof pat, "id='%s'", id); p = strstr(svg, pat); }
    if (!p || p >= end) return -1;
    const char *ts = p;
    while (ts > svg && *ts != '<') ts--;
    const char *te = memchr(p, '>', (size_t)(end - p));
    if (!te) return -1;
    const char *stop = strstr(te, "<stop");
    const char *close = strstr(te, "</");
    if (!stop || (close && close < stop)) {
        char href[80];
        if (depth < 4 && (get_attr(ts, te, "xlink:href", href, sizeof href) || get_attr(ts, te, "href", href, sizeof href)) && href[0] == '#')
            return find_gradient_color(svg, end, href + 1, depth + 1);
        return -1;
    }
    const char *se = memchr(stop, '>', (size_t)(end - stop));
    if (!se) return -1;
    char col[64];
    if (!get_prop(stop, se, "stop-color", col, sizeof col)) return 0x808080;
    return parse_color(col, svg, end, depth + 1);
}

static int parse_transform(const char *s, Mat *out)
{
    Mat m = mat_id();
    const char *p = s;
    while (*p) {
        while (*p && !isalpha((unsigned char)*p)) p++;
        if (!*p) break;
        char name[16];
        int n = 0;
        while (isalpha((unsigned char)*p) && n < 14) name[n++] = *p++;
        name[n] = 0;
        while (*p == ' ') p++;
        if (*p != '(') break;
        p++;
        const char *close = strchr(p, ')');
        if (!close) break;
        double v[6] = { 0, 0, 0, 0, 0, 0 };
        int cnt = 0;
        const char *q = p;
        while (cnt < 6 && parse_num(&q, close, &v[cnt])) cnt++;
        Mat t = mat_id();
        if (!strcmp(name, "matrix") && cnt == 6) { t.a = v[0]; t.b = v[1]; t.c = v[2]; t.d = v[3]; t.e = v[4]; t.f = v[5]; }
        else if (!strcmp(name, "translate")) { t.e = v[0]; t.f = cnt > 1 ? v[1] : 0; }
        else if (!strcmp(name, "scale")) { t.a = v[0]; t.d = cnt > 1 ? v[1] : v[0]; }
        else if (!strcmp(name, "rotate")) {
            double r = v[0] * 3.14159265358979 / 180.0, cs = cos(r), sn = sin(r);
            t.a = cs; t.b = sn; t.c = -sn; t.d = cs;
            if (cnt >= 3) { t.e = v[1] - cs * v[1] + sn * v[2]; t.f = v[2] - sn * v[1] - cs * v[2]; }
        }
        else if (!strcmp(name, "skewX")) t.c = tan(v[0] * 3.14159265358979 / 180.0);
        else if (!strcmp(name, "skewY")) t.b = tan(v[0] * 3.14159265358979 / 180.0);
        m = mat_mul(m, t);
        p = close + 1;
    }
    *out = m;
    return 1;
}

static void apply_style(Style *st, const char *svg, const char *end, const char *t, const char *te)
{
    char v[256];
    if (get_prop(t, te, "fill", v, sizeof v)) st->fill = parse_color(v, svg, end, 0);
    if (get_prop(t, te, "stroke", v, sizeof v)) st->stroke = parse_color(v, svg, end, 0);
    if (get_prop(t, te, "stroke-width", v, sizeof v)) st->sw = atof(v);
    if (get_prop(t, te, "fill-opacity", v, sizeof v)) st->fo = atof(v);
    if (get_prop(t, te, "stroke-opacity", v, sizeof v)) st->so = atof(v);
    if (get_prop(t, te, "opacity", v, sizeof v)) st->op *= atof(v);
    if (get_prop(t, te, "fill-rule", v, sizeof v)) st->evenodd = strstr(v, "evenodd") != NULL;
    if (get_attr(t, te, "transform", v, sizeof v)) { Mat m; parse_transform(v, &m); st->m = mat_mul(st->m, m); }
}

static void blend(Ctx *c, int x, int y, int rgb, double alpha)
{
    if (x < 0 || y < 0 || x >= c->w || y >= c->h || alpha <= 0) return;
    if (alpha > 1) alpha = 1;
    unsigned char *d = c->buf + ((size_t)y * (size_t)c->w + (size_t)x) * 4;
    double da = d[3] / 255.0;
    double oa = alpha + da * (1 - alpha);
    if (oa <= 0) return;
    double sr = (rgb >> 16) & 255, sg = (rgb >> 8) & 255, sb = rgb & 255;
    d[0] = (unsigned char)((sr * alpha + d[0] * da * (1 - alpha)) / oa + 0.5);
    d[1] = (unsigned char)((sg * alpha + d[1] * da * (1 - alpha)) / oa + 0.5);
    d[2] = (unsigned char)((sb * alpha + d[2] * da * (1 - alpha)) / oa + 0.5);
    d[3] = (unsigned char)(oa * 255 + 0.5);
}

static void fill_polys(Ctx *c, int rgb, double alpha, int evenodd)
{
    if (c->nsub == 0 || c->npts < 3) return;
    double ymin = 1e30, ymax = -1e30;
    for (int i = 0; i < c->npts; i++) { if (c->y[i] < ymin) ymin = c->y[i]; if (c->y[i] > ymax) ymax = c->y[i]; }
    int y0 = (int)floor(ymin), y1 = (int)ceil(ymax);
    if (y0 < 0) y0 = 0;
    if (y1 > c->h) y1 = c->h;
    for (int y = y0; y < y1; y++) {
        double yc = y + 0.5;
        int n = 0;
        for (int s = 0; s < c->nsub; s++) {
            int a = c->start[s], b = (s + 1 < c->nsub ? c->start[s + 1] : c->npts);
            if (b - a < 2) continue;
            for (int i = a; i < b; i++) {
                int j = (i + 1 < b) ? i + 1 : a;
                double ya = c->y[i], yb = c->y[j];
                if ((ya <= yc) == (yb <= yc)) continue;
                double x = c->x[i] + (yc - ya) * (c->x[j] - c->x[i]) / (yb - ya);
                if (n >= c->ccap) {
                    int nc = c->ccap * 2;
                    double *nx = realloc(c->cx, (size_t)nc * 2 * sizeof *nx);
                    if (!nx) return;
                    c->cx = nx; c->ccap = nc;
                }
                c->cx[n * 2] = x; c->cx[n * 2 + 1] = yb > ya ? 1 : -1;
                n++;
            }
        }
        for (int i = 1; i < n; i++) {
            double kx = c->cx[i * 2], kd = c->cx[i * 2 + 1];
            int j = i - 1;
            while (j >= 0 && c->cx[j * 2] > kx) { c->cx[(j + 1) * 2] = c->cx[j * 2]; c->cx[(j + 1) * 2 + 1] = c->cx[j * 2 + 1]; j--; }
            c->cx[(j + 1) * 2] = kx; c->cx[(j + 1) * 2 + 1] = kd;
        }
        int wind = 0;
        for (int i = 0; i + 1 < n; i++) {
            wind += (int)c->cx[i * 2 + 1];
            int inside = evenodd ? ((i + 1) & 1) : (wind != 0);
            if (!inside) continue;
            int xa = (int)ceil(c->cx[i * 2] - 0.5), xb = (int)ceil(c->cx[(i + 1) * 2] - 0.5);
            if (xa < 0) xa = 0;
            if (xb > c->w) xb = c->w;
            for (int x = xa; x < xb; x++) blend(c, x, y, rgb, alpha);
        }
    }
}

static void poly_reset(Ctx *c) { c->npts = 0; c->nsub = 0; }

static void sub_begin(Ctx *c)
{
    if (c->nsub < MAX_SUBS) c->start[c->nsub++] = c->npts;
}

static void pt_add(Ctx *c, const Mat *m, double x, double y)
{
    if (c->npts >= MAX_PTS) return;
    c->x[c->npts] = m->a * x + m->c * y + m->e;
    c->y[c->npts] = m->b * x + m->d * y + m->f;
    c->npts++;
}

static void flatten_cubic(Ctx *c, const Mat *m, double x0, double y0, double x1, double y1, double x2, double y2, double x3, double y3)
{
    for (int i = 1; i <= CURVE_SEGS; i++) {
        double t = (double)i / CURVE_SEGS, u = 1 - t;
        pt_add(c, m, u * u * u * x0 + 3 * u * u * t * x1 + 3 * u * t * t * x2 + t * t * t * x3,
               u * u * u * y0 + 3 * u * u * t * y1 + 3 * u * t * t * y2 + t * t * t * y3);
    }
}

static void flatten_quad(Ctx *c, const Mat *m, double x0, double y0, double x1, double y1, double x2, double y2)
{
    for (int i = 1; i <= CURVE_SEGS; i++) {
        double t = (double)i / CURVE_SEGS, u = 1 - t;
        pt_add(c, m, u * u * x0 + 2 * u * t * x1 + t * t * x2, u * u * y0 + 2 * u * t * y1 + t * t * y2);
    }
}

static void flatten_arc(Ctx *c, const Mat *m, double x1, double y1, double rx, double ry, double phi, int fa, int fs, double x2, double y2)
{
    if (rx == 0 || ry == 0 || (x1 == x2 && y1 == y2)) { pt_add(c, m, x2, y2); return; }
    rx = fabs(rx); ry = fabs(ry);
    double ph = phi * 3.14159265358979 / 180.0, cp = cos(ph), sp = sin(ph);
    double dx = (x1 - x2) / 2, dy = (y1 - y2) / 2;
    double x1p = cp * dx + sp * dy, y1p = -sp * dx + cp * dy;
    double lam = x1p * x1p / (rx * rx) + y1p * y1p / (ry * ry);
    if (lam > 1) { double s = sqrt(lam); rx *= s; ry *= s; }
    double num = rx * rx * ry * ry - rx * rx * y1p * y1p - ry * ry * x1p * x1p;
    double den = rx * rx * y1p * y1p + ry * ry * x1p * x1p;
    double co = den == 0 ? 0 : sqrt(fmax(0, num / den));
    if (fa == fs) co = -co;
    double cxp = co * rx * y1p / ry, cyp = -co * ry * x1p / rx;
    double cx = cp * cxp - sp * cyp + (x1 + x2) / 2, cy = sp * cxp + cp * cyp + (y1 + y2) / 2;
    double th1 = atan2((y1p - cyp) / ry, (x1p - cxp) / rx);
    double th2 = atan2((-y1p - cyp) / ry, (-x1p - cxp) / rx);
    double dth = th2 - th1;
    if (fs && dth < 0) dth += 2 * 3.14159265358979;
    if (!fs && dth > 0) dth -= 2 * 3.14159265358979;
    int n = CURVE_SEGS + 6;
    for (int i = 1; i <= n; i++) {
        double t = th1 + dth * i / n;
        double ex = rx * cos(t), ey = ry * sin(t);
        pt_add(c, m, cp * ex - sp * ey + cx, sp * ex + cp * ey + cy);
    }
}

static int parse_path(Ctx *c, const Mat *m, const char *d, const char *de, int *closed_flags)
{
    double cx = 0, cy = 0, sx = 0, sy = 0, lcx = 0, lcy = 0;
    char cmd = 0, prev = 0;
    const char *p = d;
    int nsubs = 0, need_new = 0;
    for (;;) {
        p = skip_ws(p, de);
        if (p >= de) break;
        if (isalpha((unsigned char)*p)) { cmd = *p++; }
        else if (!cmd) break;
        char up = (char)toupper((unsigned char)cmd);
        int rel = cmd >= 'a';
        double v[7];
        if (up == 'Z') {
            if (c->nsub > 0 && nsubs > 0) closed_flags[nsubs - 1] = 1;
            cx = sx; cy = sy;
            need_new = 1;
            prev = 'Z';
            cmd = 0;
            continue;
        }
        int need = up == 'M' || up == 'L' || up == 'T' ? 2 : up == 'H' || up == 'V' ? 1 : up == 'C' ? 6 : up == 'S' || up == 'Q' ? 4 : up == 'A' ? 7 : 0;
        if (!need) break;
        for (int i = 0; i < need; i++) {
            if (up == 'A' && (i == 3 || i == 4)) {
                p = skip_ws(p, de);
                if (p >= de || (*p != '0' && *p != '1')) return nsubs;
                v[i] = *p - '0';
                p++;
            } else if (!parse_num(&p, de, &v[i])) return nsubs;
        }
        double ox = rel ? cx : 0, oy = rel ? cy : 0;
        if (up != 'M' && (need_new || c->nsub == 0)) {
            sub_begin(c);
            if (nsubs < MAX_SUBS) closed_flags[nsubs++] = 0;
            pt_add(c, m, cx, cy);
            need_new = 0;
        }
        switch (up) {
        case 'M':
            cx = v[0] + ox; cy = v[1] + oy; sx = cx; sy = cy;
            sub_begin(c);
            if (nsubs < MAX_SUBS) closed_flags[nsubs++] = 0;
            pt_add(c, m, cx, cy);
            need_new = 0;
            cmd = rel ? 'l' : 'L';
            lcx = cx; lcy = cy;
            break;
        case 'L':
            cx = v[0] + ox; cy = v[1] + oy;
            pt_add(c, m, cx, cy);
            lcx = cx; lcy = cy;
            break;
        case 'H':
            cx = v[0] + ox;
            pt_add(c, m, cx, cy);
            lcx = cx; lcy = cy;
            break;
        case 'V':
            cy = v[0] + oy;
            pt_add(c, m, cx, cy);
            lcx = cx; lcy = cy;
            break;
        case 'C': {
            double x1 = v[0] + ox, y1 = v[1] + oy, x2 = v[2] + ox, y2 = v[3] + oy, x3 = v[4] + ox, y3 = v[5] + oy;
            flatten_cubic(c, m, cx, cy, x1, y1, x2, y2, x3, y3);
            lcx = x2; lcy = y2; cx = x3; cy = y3;
            break; }
        case 'S': {
            double x1 = (prev == 'C' || prev == 'S') ? 2 * cx - lcx : cx, y1 = (prev == 'C' || prev == 'S') ? 2 * cy - lcy : cy;
            double x2 = v[0] + ox, y2 = v[1] + oy, x3 = v[2] + ox, y3 = v[3] + oy;
            flatten_cubic(c, m, cx, cy, x1, y1, x2, y2, x3, y3);
            lcx = x2; lcy = y2; cx = x3; cy = y3;
            break; }
        case 'Q': {
            double x1 = v[0] + ox, y1 = v[1] + oy, x2 = v[2] + ox, y2 = v[3] + oy;
            flatten_quad(c, m, cx, cy, x1, y1, x2, y2);
            lcx = x1; lcy = y1; cx = x2; cy = y2;
            break; }
        case 'T': {
            double x1 = (prev == 'Q' || prev == 'T') ? 2 * cx - lcx : cx, y1 = (prev == 'Q' || prev == 'T') ? 2 * cy - lcy : cy;
            double x2 = v[0] + ox, y2 = v[1] + oy;
            flatten_quad(c, m, cx, cy, x1, y1, x2, y2);
            lcx = x1; lcy = y1; cx = x2; cy = y2;
            break; }
        case 'A': {
            double x2 = v[5] + ox, y2 = v[6] + oy;
            flatten_arc(c, m, cx, cy, v[0], v[1], v[2], (int)v[3], (int)v[4], x2, y2);
            cx = x2; cy = y2;
            break; }
        default: break;
        }
        prev = up;
    }
    return nsubs;
}

static double signed_area(const double *x, const double *y, int n)
{
    double a = 0;
    for (int i = 0; i < n; i++) { int j = (i + 1) % n; a += x[i] * y[j] - x[j] * y[i]; }
    return a / 2;
}

static void stroke_polys(Ctx *c, const Style *st, const int *closed, double scale, double *sx, double *sy, int *sstart, int nsub, int npts, Ctx *out)
{
    double hw = st->sw * scale / 2;
    if (hw < 0.25) hw = 0.25;
    poly_reset(out);
    for (int s = 0; s < nsub; s++) {
        int a = sstart[s], b = (s + 1 < nsub ? sstart[s + 1] : npts);
        int n = b - a;
        if (n < 1) continue;
        int segs = closed[s] ? n : n - 1;
        if (n == 1) segs = 0;
        for (int i = 0; i < segs; i++) {
            int j = (a + i + 1 < b) ? a + i + 1 : a;
            double x0 = sx[a + i], y0 = sy[a + i], x1 = sx[j], y1 = sy[j];
            double dx = x1 - x0, dy = y1 - y0, l = sqrt(dx * dx + dy * dy);
            if (l < 1e-6) continue;
            double nx = -dy / l * hw, ny = dx / l * hw;
            double qx[4] = { x0 + nx, x1 + nx, x1 - nx, x0 - nx }, qy[4] = { y0 + ny, y1 + ny, y1 - ny, y0 - ny };
            if (out->nsub >= MAX_SUBS || out->npts + 4 > MAX_PTS) break;
            sub_begin(out);
            if (signed_area(qx, qy, 4) < 0) for (int k = 3; k >= 0; k--) { out->x[out->npts] = qx[k]; out->y[out->npts] = qy[k]; out->npts++; }
            else for (int k = 0; k < 4; k++) { out->x[out->npts] = qx[k]; out->y[out->npts] = qy[k]; out->npts++; }
        }
        if (hw > 0.8) {
            int ring = hw > 6 ? 16 : 10;
            for (int i = 0; i < n; i++) {
                if (out->nsub >= MAX_SUBS || out->npts + ring > MAX_PTS) break;
                sub_begin(out);
                for (int k = 0; k < ring; k++) {
                    double t = 2 * 3.14159265358979 * k / ring;
                    out->x[out->npts] = sx[a + i] + hw * cos(t);
                    out->y[out->npts] = sy[a + i] + hw * sin(t);
                    out->npts++;
                }
            }
        }
    }
    (void)c;
}

static void draw_shape(Ctx *c, const Style *st, int has_fill, int has_stroke, const int *closed, int nsubs_parsed)
{
    (void)nsubs_parsed;
    if (c->npts < 2) { poly_reset(c); return; }
    if (has_fill && st->fill >= 0) fill_polys(c, st->fill, st->fo * st->op, st->evenodd);
    if (has_stroke && st->stroke >= 0 && st->sw > 0) {
        double scale = sqrt(fabs(st->m.a * st->m.d - st->m.b * st->m.c));
        int n = c->npts, ns = c->nsub;
        double *cx = malloc((size_t)n * sizeof *cx), *cy = malloc((size_t)n * sizeof *cy);
        int *cs = malloc((size_t)(ns > 0 ? ns : 1) * sizeof *cs);
        if (cx && cy && cs) {
            memcpy(cx, c->x, (size_t)n * sizeof *cx);
            memcpy(cy, c->y, (size_t)n * sizeof *cy);
            memcpy(cs, c->start, (size_t)ns * sizeof *cs);
            Ctx out = *c;
            stroke_polys(c, st, closed, scale, cx, cy, cs, ns, n, &out);
            c->npts = out.npts; c->nsub = out.nsub;
            fill_polys(c, st->stroke, st->so * st->op, 0);
        }
        free(cx); free(cy); free(cs);
    }
    poly_reset(c);
}

static int tag_name_is(const char *t, const char *n)
{
    size_t l = strlen(n);
    return !strncmp(t, n, l) && !isalnum((unsigned char)t[l]) && t[l] != '-' && t[l] != ':';
}

int svg_size(const char *svg, size_t len, double *w, double *h)
{
    const char *end = svg + len;
    const char *root = strstr(svg, "<svg");
    if (!root) return -1;
    const char *re = memchr(root, '>', (size_t)(end - root));
    if (!re) return -1;
    char t[96];
    double vx, vy, vw = 0, vh = 0;
    if (get_attr(root, re, "viewBox", t, sizeof t)) {
        const char *p = t;
        if (parse_num(&p, t + strlen(t), &vx) && parse_num(&p, t + strlen(t), &vy) && parse_num(&p, t + strlen(t), &vw) && parse_num(&p, t + strlen(t), &vh) && vw > 0 && vh > 0) { *w = vw; *h = vh; return 0; }
    }
    if (get_attr(root, re, "width", t, sizeof t)) vw = atof(t);
    if (get_attr(root, re, "height", t, sizeof t)) vh = atof(t);
    if (vw <= 0 || vh <= 0) return -1;
    *w = vw; *h = vh;
    return 0;
}

unsigned char *svg_render(const char *svg, size_t len, int pw, int ph)
{
    if (pw < 1 || ph < 1 || pw > 2048 || ph > 2048) return NULL;
    const char *end = svg + len;
    const char *root = strstr(svg, "<svg");
    if (!root) return NULL;
    double vw = 0, vh = 0, vx = 0, vy = 0;
    {
        const char *re = memchr(root, '>', (size_t)(end - root));
        char t[96];
        if (!re) return NULL;
        if (get_attr(root, re, "viewBox", t, sizeof t)) {
            const char *p = t;
            const char *te = t + strlen(t);
            parse_num(&p, te, &vx); parse_num(&p, te, &vy); parse_num(&p, te, &vw); parse_num(&p, te, &vh);
        }
        if (vw <= 0 || vh <= 0) {
            vx = vy = 0;
            if (svg_size(svg, len, &vw, &vh) != 0) return NULL;
        }
    }
    Ctx c;
    memset(&c, 0, sizeof c);
    c.w = pw; c.h = ph;
    c.buf = calloc((size_t)pw * (size_t)ph, 4);
    c.x = malloc(MAX_PTS * sizeof *c.x);
    c.y = malloc(MAX_PTS * sizeof *c.y);
    c.start = malloc(MAX_SUBS * sizeof *c.start);
    c.ccap = 256;
    c.cx = malloc((size_t)c.ccap * 2 * sizeof *c.cx);
    int *closed = malloc(MAX_SUBS * sizeof *closed);
    if (!c.buf || !c.x || !c.y || !c.start || !c.cx || !closed) {
        free(c.buf); free(c.x); free(c.y); free(c.start); free(c.cx); free(closed);
        return NULL;
    }

    Style stack[MAX_DEPTH];
    int depth = 0;
    Style base;
    memset(&base, 0, sizeof base);
    base.fill = 0; base.stroke = -1; base.sw = 1; base.fo = 1; base.so = 1; base.op = 1;
    base.m = mat_id();
    base.m.a = pw / vw; base.m.d = ph / vh;
    base.m.e = -vx * base.m.a; base.m.f = -vy * base.m.d;
    stack[0] = base;

    const char *p = root;
    int guard = 0;
    while (p < end && guard++ < 200000) {
        const char *lt = memchr(p, '<', (size_t)(end - p));
        if (!lt) break;
        if (!strncmp(lt, "<!--", 4)) { const char *e = strstr(lt, "-->"); if (!e) break; p = e + 3; continue; }
        if (lt[1] == '?' || lt[1] == '!') { const char *e = memchr(lt, '>', (size_t)(end - lt)); if (!e) break; p = e + 1; continue; }
        const char *te = lt + 1;
        char q = 0;
        while (te < end && (q || *te != '>')) {
            if (q) { if (*te == q) q = 0; }
            else if (*te == '"' || *te == '\'') q = *te;
            te++;
        }
        if (te >= end) break;
        p = te + 1;
        if (lt[1] == '/') {
            if ((tag_name_is(lt + 2, "g") || tag_name_is(lt + 2, "a")) && depth > 0) depth--;
            continue;
        }
        const char *name = lt + 1;
        int selfclose = te[-1] == '/';
        Style *cur = &stack[depth];
        if (tag_name_is(name, "g") || tag_name_is(name, "a")) {
            if (!selfclose && depth + 1 < MAX_DEPTH) {
                stack[depth + 1] = *cur;
                depth++;
                apply_style(&stack[depth], svg, end, lt, te);
            }
            continue;
        }
        if (tag_name_is(name, "defs") || tag_name_is(name, "clipPath") || tag_name_is(name, "mask") || tag_name_is(name, "linearGradient")
            || tag_name_is(name, "radialGradient") || tag_name_is(name, "symbol") || tag_name_is(name, "style") || tag_name_is(name, "text")
            || tag_name_is(name, "metadata") || tag_name_is(name, "title") || tag_name_is(name, "desc")) {
            if (!selfclose) {
                char closer[40];
                const char *nm = name;
                int n = 0;
                while (isalnum((unsigned char)nm[n]) && n < 30) n++;
                snprintf(closer, sizeof closer, "</%.*s", n, nm);
                const char *e = strstr(p, closer);
                if (!e) break;
                const char *ee = memchr(e, '>', (size_t)(end - e));
                p = ee ? ee + 1 : end;
            }
            continue;
        }
        Style st = *cur;
        char v[64];
        if (get_prop(lt, te, "display", v, sizeof v) && !strncmp(v, "none", 4)) continue;
        apply_style(&st, svg, end, lt, te);
        poly_reset(&c);
        int has_fill = 1, has_stroke = 1;
        int nsub = 0;
        memset(closed, 0, MAX_SUBS * sizeof *closed);
        char val[64];
        double x = 0, y = 0, w = 0, h = 0, rx = 0, ry = 0;
        if (tag_name_is(name, "path")) {
            char *d = malloc(len + 1);
            if (!d) continue;
            if (get_attr(lt, te, "d", d, len)) nsub = parse_path(&c, &st.m, d, d + strlen(d), closed);
            free(d);
        } else if (tag_name_is(name, "rect")) {
            if (get_attr(lt, te, "x", val, sizeof val)) x = atof(val);
            if (get_attr(lt, te, "y", val, sizeof val)) y = atof(val);
            if (get_attr(lt, te, "width", val, sizeof val)) w = atof(val);
            if (get_attr(lt, te, "height", val, sizeof val)) h = atof(val);
            if (w <= 0 || h <= 0) continue;
            sub_begin(&c);
            pt_add(&c, &st.m, x, y); pt_add(&c, &st.m, x + w, y); pt_add(&c, &st.m, x + w, y + h); pt_add(&c, &st.m, x, y + h);
            closed[0] = 1; nsub = 1;
        } else if (tag_name_is(name, "circle") || tag_name_is(name, "ellipse")) {
            int circ = tag_name_is(name, "circle");
            if (get_attr(lt, te, "cx", val, sizeof val)) x = atof(val);
            if (get_attr(lt, te, "cy", val, sizeof val)) y = atof(val);
            if (circ) { if (get_attr(lt, te, "r", val, sizeof val)) rx = ry = atof(val); }
            else {
                if (get_attr(lt, te, "rx", val, sizeof val)) rx = atof(val);
                if (get_attr(lt, te, "ry", val, sizeof val)) ry = atof(val);
            }
            if (rx <= 0 || ry <= 0) continue;
            sub_begin(&c);
            for (int k = 0; k < 48; k++) {
                double t = 2 * 3.14159265358979 * k / 48;
                pt_add(&c, &st.m, x + rx * cos(t), y + ry * sin(t));
            }
            closed[0] = 1; nsub = 1;
        } else if (tag_name_is(name, "line")) {
            double x1 = 0, y1 = 0, x2 = 0, y2 = 0;
            if (get_attr(lt, te, "x1", val, sizeof val)) x1 = atof(val);
            if (get_attr(lt, te, "y1", val, sizeof val)) y1 = atof(val);
            if (get_attr(lt, te, "x2", val, sizeof val)) x2 = atof(val);
            if (get_attr(lt, te, "y2", val, sizeof val)) y2 = atof(val);
            sub_begin(&c);
            pt_add(&c, &st.m, x1, y1); pt_add(&c, &st.m, x2, y2);
            nsub = 1; has_fill = 0;
        } else if (tag_name_is(name, "polyline") || tag_name_is(name, "polygon")) {
            char *d = malloc(len + 1);
            if (!d) continue;
            if (get_attr(lt, te, "points", d, len)) {
                const char *pp = d, *de = d + strlen(d);
                double a, b;
                sub_begin(&c);
                while (parse_num(&pp, de, &a) && parse_num(&pp, de, &b)) pt_add(&c, &st.m, a, b);
                nsub = 1;
                closed[0] = tag_name_is(name, "polygon");
                if (!closed[0]) has_fill = has_fill && 1;
            }
            free(d);
        } else continue;
        draw_shape(&c, &st, has_fill, has_stroke, closed, nsub);
    }

    free(c.x); free(c.y); free(c.start); free(c.cx); free(closed);
    return c.buf;
}
