#include "templates.h"

#include <stdio.h>
#include <string.h>

#include "assets.h"
#include "editor.h"

typedef struct { const char *name, *info; int (*build)(Project *); } Tpl;

static Script *sc_of(Project *p, int sp, int s) { return &p->sprites[sp].scripts[s]; }

static int add(Project *p, int sp, int s, int after, BlockKind kind, const char *a0, const char *a1, const char *a2)
{
    int at = prj_insert_block(p, sp, s, after, kind);
    if (at < 0) return -1;
    Block *b = &sc_of(p, sp, s)->blocks[at];
    if (a0) project_copy_text(b->a[0].text, a0);
    if (a1) project_copy_text(b->a[1].text, a1);
    if (a2) project_copy_text(b->a[2].text, a2);
    return at;
}

static Block *plug(Project *p, int sp, int s, int blk, int slot, BlockKind kind, const char *param)
{
    Script *sc = sc_of(p, sp, s);
    prj_plug(p, sp, sc, &sc->blocks[blk], slot, kind, param);
    int e = sc->blocks[blk].a[slot].expr;
    return e >= 0 ? &sc->ex[e] : NULL;
}

static Block *plug_in(Project *p, int sp, int s, Block *outer, int slot, BlockKind kind, const char *param)
{
    Script *sc = sc_of(p, sp, s);
    prj_plug(p, sp, sc, outer, slot, kind, param);
    int e = outer->a[slot].expr;
    return e >= 0 ? &sc->ex[e] : NULL;
}

static void set_arg(Block *b, int slot, const char *text) { if (b) project_copy_text(b->a[slot].text, text); }

static int hat(Project *p, int sp, BlockKind k, const char *a0)
{
    int s = prj_new_script(p, sp, k);
    if (s >= 0 && a0) project_copy_text(sc_of(p, sp, s)->blocks[0].a[0].text, a0);
    return s;
}

static int goto_random_x(Project *p, int sp, int s, int after, const char *y)
{
    int g = add(p, sp, s, after, BK_GOTO_XY, "0", y, NULL);
    Block *r = plug(p, sp, s, g, 0, BK_RANDOM, NULL);
    set_arg(r, 0, "-200"); set_arg(r, 1, "200");
    return g;
}

static void px_rect(Costume *c, int x0, int y0, int x1, int y1, int col)
{
    for (int y = y0; y <= y1; y++)
        for (int x = x0; x <= x1; x++)
            if (x >= 0 && x < COSTUME_W && y >= 0 && y < COSTUME_H) c->px[y * COSTUME_W + x] = (uint8_t)col;
}

static void px_disc(Costume *c, int cx, int cy, int r, int col, int edge)
{
    for (int y = 0; y < COSTUME_H; y++)
        for (int x = 0; x < COSTUME_W; x++) {
            int d2 = (x - cx) * (x - cx) + (y - cy) * (y - cy);
            if (d2 <= r * r) c->px[y * COSTUME_W + x] = (uint8_t)col;
            else if (edge && d2 <= (r + 1) * (r + 1)) c->px[y * COSTUME_W + x] = (uint8_t)edge;
        }
}

static void set_costume(Project *p, int sp, void (*paint)(Costume *), const char *name)
{
    Costume *c = &p->sprites[sp].costumes[0];
    costume_clear(c);
    paint(c);
    if (name) project_copy_text(c->name, name);
}

static void paint_basket(Costume *c)
{
    for (int y = 12; y < 28; y++) px_rect(c, 3 + (y - 12) / 4, y, 28 - (y - 12) / 4, y, (y % 4 == 0) ? 13 : 4);
    px_rect(c, 2, 10, 29, 12, 13);
}
static void paint_apple(Costume *c)
{
    px_disc(c, 16, 18, 10, 3, 1);
    px_rect(c, 15, 4, 16, 9, 13);
    px_rect(c, 17, 5, 21, 7, 6);
}
static void paint_ball(Costume *c) { px_disc(c, 16, 16, 13, 5, 4); }
static void paint_bat(Costume *c) { px_rect(c, 0, 8, 31, 24, 9); px_rect(c, 0, 8, 31, 10, 8); }
static void paint_bullet(Costume *c) { px_rect(c, 14, 4, 17, 27, 5); px_rect(c, 15, 2, 16, 4, 4); }
static void paint_cannon(Costume *c)
{
    px_rect(c, 14, 4, 17, 16, 14);
    px_rect(c, 6, 16, 25, 28, 10);
    px_rect(c, 8, 18, 23, 20, 9);
}
static void paint_alien(Costume *c)
{
    px_disc(c, 16, 16, 12, 6, 7);
    px_rect(c, 9, 12, 12, 15, 2); px_rect(c, 19, 12, 22, 15, 2);
    px_rect(c, 10, 13, 11, 14, 1); px_rect(c, 20, 13, 21, 14, 1);
    px_rect(c, 11, 21, 20, 22, 1);
}
static void paint_pen(Costume *c) { px_disc(c, 16, 16, 5, 12, 11); }
static void paint_note(Costume *c)
{
    px_disc(c, 12, 24, 5, 11, 1);
    px_rect(c, 16, 4, 17, 24, 1);
    px_rect(c, 17, 4, 24, 8, 1);
}

static void backdrop_sky(Project *p, int ground)
{
    Costume *b = &p->sprites[STAGE_IDX].costumes[0];
    memset(b->px, 8, sizeof b->px);
    for (int y = 0; y < 10; y++) memset(&b->px[y * COSTUME_W], 15, COSTUME_W);
    for (int y = 10; y < 14; y++) memset(&b->px[y * COSTUME_W], 8, COSTUME_W);
    if (ground) for (int y = COSTUME_H - 4; y < COSTUME_H; y++) memset(&b->px[y * COSTUME_W], 6, COSTUME_W);
}
static void backdrop_solid(Project *p, int col) { memset(p->sprites[STAGE_IDX].costumes[0].px, col, COSTUME_W * COSTUME_H); }

static int new_sprite(Project *p, const char *name, void (*paint)(Costume *), int x, int y, int size)
{
    int i = prj_add_sprite(p);
    if (i < 0) return -1;
    prj_rename_sprite(p, i, name);
    set_costume(p, i, paint, "costume1");
    p->sprites[i].x = x; p->sprites[i].y = y; p->sprites[i].size = size;
    return i;
}

static int first_sprite(Project *p, const char *name, void (*paint)(Costume *), int x, int y, int size)
{
    prj_rename_sprite(p, 0, name);
    set_costume(p, 0, paint, "costume1");
    p->sprites[0].x = x; p->sprites[0].y = y; p->sprites[0].size = size;
    return 0;
}

static int flag_script(Project *p, int sp)
{
    Sprite *s = &p->sprites[sp];
    if (s->nscripts == 1 && s->scripts[0].nblocks == 1) return 0;
    return hat(p, sp, BK_HAT_FLAG, NULL);
}

static int build_blank(Project *p) { (void)p; return 0; }

static int build_catch(Project *p)
{
    backdrop_sky(p, 1);
    int pl = first_sprite(p, "Basket", paint_basket, 0, -140, 70);
    int ap = new_sprite(p, "Apple", paint_apple, 0, 150, 45);
    prj_add_var(p, "score");
    int fx = prj_add_effect(p, ap, 2);
    char coin[TEXT_LEN];
    project_copy_text(coin, p->sprites[ap].sounds[fx].name);

    int s = flag_script(p, pl);
    int g = add(p, pl, s, 0, BK_GOTO_XY, "0", "-140", NULL);
    int f = add(p, pl, s, g, BK_FOREVER, NULL, NULL, NULL);
    int i1 = add(p, pl, s, f, BK_IF, NULL, NULL, NULL);
    set_arg(plug(p, pl, s, i1, 0, BK_KEY_PRESSED, NULL), 0, "left arrow");
    add(p, pl, s, i1, BK_CHANGE_X, "-10", NULL, NULL);
    int i2 = add(p, pl, s, prj_match_end(sc_of(p, pl, s), i1), BK_IF, NULL, NULL, NULL);
    set_arg(plug(p, pl, s, i2, 0, BK_KEY_PRESSED, NULL), 0, "right arrow");
    add(p, pl, s, i2, BK_CHANGE_X, "10", NULL, NULL);
    int i3 = add(p, pl, s, prj_match_end(sc_of(p, pl, s), i2), BK_IF, NULL, NULL, NULL);
    plug(p, pl, s, i3, 0, BK_MOUSE_DOWN, NULL);
    int sx = add(p, pl, s, i3, BK_SET_X, "0", NULL, NULL);
    plug(p, pl, s, sx, 0, BK_MOUSE_X, NULL);

    s = flag_script(p, ap);
    int a = add(p, ap, s, 0, BK_SET_VAR, "score", "0", NULL);
    a = add(p, ap, s, a, BK_SHOW_VAR, "score", NULL, NULL);
    a = goto_random_x(p, ap, s, a, "150");
    f = add(p, ap, s, a, BK_FOREVER, NULL, NULL, NULL);
    add(p, ap, s, f, BK_CHANGE_Y, "-6", NULL, NULL);
    int t = add(p, ap, s, f + 1, BK_IF, NULL, NULL, NULL);
    set_arg(plug(p, ap, s, t, 0, BK_TOUCHING, NULL), 0, "Basket");
    int c = add(p, ap, s, t, BK_CHANGE_VAR, "score", "1", NULL);
    c = add(p, ap, s, c, BK_PLAY_SOUND, coin, NULL, NULL);
    goto_random_x(p, ap, s, c, "150");
    int lo = add(p, ap, s, prj_match_end(sc_of(p, ap, s), t), BK_IF, NULL, NULL, NULL);
    Block *lt = plug(p, ap, s, lo, 0, BK_LT, NULL);
    plug_in(p, ap, s, lt, 0, BK_YPOS, NULL);
    set_arg(lt, 1, "-160");
    goto_random_x(p, ap, s, lo, "150");
    return 0;
}

static int build_pong(Project *p)
{
    backdrop_solid(p, 1);
    int bat = first_sprite(p, "Bat", paint_bat, 0, -150, 55);
    int ball = new_sprite(p, "Ball", paint_ball, 0, 0, 30);
    prj_add_var(p, "score");
    int fx = prj_add_effect(p, ball, 6);
    char blip[TEXT_LEN];
    project_copy_text(blip, p->sprites[ball].sounds[fx].name);

    int s = flag_script(p, bat);
    int f = add(p, bat, s, 0, BK_FOREVER, NULL, NULL, NULL);
    int sx = add(p, bat, s, f, BK_SET_X, "0", NULL, NULL);
    plug(p, bat, s, sx, 0, BK_MOUSE_X, NULL);
    int i1 = add(p, bat, s, sx, BK_IF, NULL, NULL, NULL);
    set_arg(plug(p, bat, s, i1, 0, BK_KEY_PRESSED, NULL), 0, "left arrow");
    add(p, bat, s, i1, BK_CHANGE_X, "-12", NULL, NULL);
    int i2 = add(p, bat, s, prj_match_end(sc_of(p, bat, s), i1), BK_IF, NULL, NULL, NULL);
    set_arg(plug(p, bat, s, i2, 0, BK_KEY_PRESSED, NULL), 0, "right arrow");
    add(p, bat, s, i2, BK_CHANGE_X, "12", NULL, NULL);

    s = flag_script(p, ball);
    int a = add(p, ball, s, 0, BK_SET_VAR, "score", "0", NULL);
    a = add(p, ball, s, a, BK_SHOW_VAR, "score", NULL, NULL);
    a = add(p, ball, s, a, BK_GOTO_XY, "0", "40", NULL);
    a = add(p, ball, s, a, BK_POINT_DIR, "35", NULL, NULL);
    f = add(p, ball, s, a, BK_FOREVER, NULL, NULL, NULL);
    int m = add(p, ball, s, f, BK_MOVE, "7", NULL, NULL);
    m = add(p, ball, s, m, BK_BOUNCE, NULL, NULL, NULL);
    int t = add(p, ball, s, m, BK_IF, NULL, NULL, NULL);
    set_arg(plug(p, ball, s, t, 0, BK_TOUCHING, NULL), 0, "Bat");
    int pd = add(p, ball, s, t, BK_POINT_DIR, "0", NULL, NULL);
    Block *sub = plug(p, ball, s, pd, 0, BK_SUB, NULL);
    set_arg(sub, 0, "180");
    plug_in(p, ball, s, sub, 1, BK_DIRECTION, NULL);
    int mv = add(p, ball, s, pd, BK_MOVE, "14", NULL, NULL);
    mv = add(p, ball, s, mv, BK_CHANGE_VAR, "score", "1", NULL);
    add(p, ball, s, mv, BK_PLAY_SOUND, blip, NULL, NULL);
    return 0;
}

static int build_shooter(Project *p)
{
    backdrop_solid(p, 10);
    int cn = first_sprite(p, "Cannon", paint_cannon, 0, -140, 55);
    int bu = new_sprite(p, "Bullet", paint_bullet, 0, -120, 30);
    int al = new_sprite(p, "Alien", paint_alien, 0, 150, 50);
    prj_add_var(p, "score");
    int fx = prj_add_effect(p, cn, 0);
    char laser[TEXT_LEN];
    project_copy_text(laser, p->sprites[cn].sounds[fx].name);
    fx = prj_add_effect(p, al, 4);
    char boom[TEXT_LEN];
    project_copy_text(boom, p->sprites[al].sounds[fx].name);

    int s = flag_script(p, cn);
    int f = add(p, cn, s, 0, BK_FOREVER, NULL, NULL, NULL);
    int i0 = add(p, cn, s, f, BK_IF, NULL, NULL, NULL);
    plug(p, cn, s, i0, 0, BK_MOUSE_DOWN, NULL);
    int sx = add(p, cn, s, i0, BK_SET_X, "0", NULL, NULL);
    plug(p, cn, s, sx, 0, BK_MOUSE_X, NULL);
    int i1 = add(p, cn, s, prj_match_end(sc_of(p, cn, s), i0), BK_IF, NULL, NULL, NULL);
    set_arg(plug(p, cn, s, i1, 0, BK_KEY_PRESSED, NULL), 0, "left arrow");
    add(p, cn, s, i1, BK_CHANGE_X, "-10", NULL, NULL);
    int i2 = add(p, cn, s, prj_match_end(sc_of(p, cn, s), i1), BK_IF, NULL, NULL, NULL);
    set_arg(plug(p, cn, s, i2, 0, BK_KEY_PRESSED, NULL), 0, "right arrow");
    add(p, cn, s, i2, BK_CHANGE_X, "10", NULL, NULL);
    s = hat(p, cn, BK_HAT_KEY, "space");
    int b = add(p, cn, s, 0, BK_BROADCAST, "fire", NULL, NULL);
    add(p, cn, s, b, BK_PLAY_SOUND, laser, NULL, NULL);
    s = hat(p, cn, BK_HAT_CLICK, NULL);
    add(p, cn, s, 0, BK_BROADCAST, "fire", NULL, NULL);

    s = flag_script(p, bu);
    add(p, bu, s, 0, BK_HIDE, NULL, NULL, NULL);
    s = hat(p, bu, BK_HAT_RECV, "fire");
    add(p, bu, s, 0, BK_CLONE, "myself", NULL, NULL);
    s = hat(p, bu, BK_HAT_CLONE, NULL);
    int g = add(p, bu, s, 0, BK_GOTO_XY, "0", "-120", NULL);
    Block *ao = plug(p, bu, s, g, 0, BK_ATTR_OF, NULL);
    set_arg(ao, 0, "x position"); set_arg(ao, 1, "Cannon");
    int sh = add(p, bu, s, g, BK_SHOW, NULL, NULL, NULL);
    int r = add(p, bu, s, sh, BK_REPEAT, "30", NULL, NULL);
    add(p, bu, s, r, BK_CHANGE_Y, "12", NULL, NULL);
    add(p, bu, s, prj_match_end(sc_of(p, bu, s), r), BK_CLONE_DEL, NULL, NULL, NULL);

    s = flag_script(p, al);
    int a = add(p, al, s, 0, BK_SET_VAR, "score", "0", NULL);
    a = add(p, al, s, a, BK_SHOW_VAR, "score", NULL, NULL);
    a = goto_random_x(p, al, s, a, "150");
    f = add(p, al, s, a, BK_FOREVER, NULL, NULL, NULL);
    add(p, al, s, f, BK_CHANGE_Y, "-3", NULL, NULL);
    int t = add(p, al, s, f + 1, BK_IF, NULL, NULL, NULL);
    set_arg(plug(p, al, s, t, 0, BK_TOUCHING, NULL), 0, "Bullet");
    int c = add(p, al, s, t, BK_CHANGE_VAR, "score", "1", NULL);
    c = add(p, al, s, c, BK_PLAY_SOUND, boom, NULL, NULL);
    goto_random_x(p, al, s, c, "150");
    int lo = add(p, al, s, prj_match_end(sc_of(p, al, s), t), BK_IF, NULL, NULL, NULL);
    Block *lt = plug(p, al, s, lo, 0, BK_LT, NULL);
    plug_in(p, al, s, lt, 0, BK_YPOS, NULL);
    set_arg(lt, 1, "-170");
    goto_random_x(p, al, s, lo, "150");
    return 0;
}

static int build_pen(Project *p)
{
    backdrop_solid(p, 2);
    int pn = first_sprite(p, "Pen", paint_pen, 0, 0, 20);
    int s = flag_script(p, pn);
    int a = add(p, pn, s, 0, BK_PEN_CLEAR, NULL, NULL, NULL);
    a = add(p, pn, s, a, BK_PEN_SIZE_SET, "4", NULL, NULL);
    int f = add(p, pn, s, a, BK_FOREVER, NULL, NULL, NULL);
    int g = add(p, pn, s, f, BK_GOTO_XY, "0", "0", NULL);
    plug(p, pn, s, g, 0, BK_MOUSE_X, NULL);
    plug(p, pn, s, g, 1, BK_MOUSE_Y, NULL);
    int ie = add(p, pn, s, g, BK_IF_ELSE, NULL, NULL, NULL);
    plug(p, pn, s, ie, 0, BK_MOUSE_DOWN, NULL);
    add(p, pn, s, ie, BK_PEN_DOWN, NULL, NULL, NULL);
    int el = prj_match_else(sc_of(p, pn, s), ie);
    add(p, pn, s, el, BK_PEN_UP, NULL, NULL, NULL);
    s = hat(p, pn, BK_HAT_KEY, "space");
    add(p, pn, s, 0, BK_PEN_CLEAR, NULL, NULL, NULL);
    s = hat(p, pn, BK_HAT_KEY, "a");
    add(p, pn, s, 0, BK_PEN_HUE_CHANGE, "15", NULL, NULL);
    s = hat(p, pn, BK_HAT_KEY, "b");
    add(p, pn, s, 0, BK_PEN_SIZE_CHANGE, "2", NULL, NULL);
    return 0;
}

static int build_music(Project *p)
{
    backdrop_solid(p, 11);
    int n = first_sprite(p, "Keys", paint_note, 0, 0, 120);
    static const struct { const char *key; const char *note; const char *msg; } k[] = {
        { "left arrow", "60", "do" }, { "up arrow", "64", "mi" }, { "right arrow", "67", "sol" }, { "down arrow", "72", "do (high)" },
        { "space", "69", "la" }, { "x", "62", "re" }, { "y", "65", "fa" },
    };
    for (unsigned i = 0; i < sizeof k / sizeof k[0]; i++) {
        int s = hat(p, n, BK_HAT_KEY, k[i].key);
        if (s < 0) break;
        int a = add(p, n, s, 0, BK_SAY, k[i].msg, NULL, NULL);
        a = add(p, n, s, a, BK_NOTE, k[i].note, "0.5", NULL);
        add(p, n, s, a, BK_SAY, "", NULL, NULL);
        if (p->sprites[n].nscripts >= MAX_SCRIPTS) break;
    }
    return 0;
}

static const Tpl TPLS[] = {
    { "Blank project",        "One sprite and a green-flag script.", build_blank },
    { "Catch the apples",     "D-pad or touch moves the basket. Score +1 per apple.", build_catch },
    { "Pong",                 "Touch or D-pad moves the bat; keep the ball in play.", build_pong },
    { "Space shooter (clones)", "A / touch fires: every shot is a clone. Hit the alien.", build_shooter },
    { "Pen sketch",           "Draw on the touch screen. A = colour, B = size, space = clear.", build_pen },
    { "Music keys",           "D-pad, A, X and Y play notes.", build_music },
};

int tpl_count(void) { return (int)(sizeof TPLS / sizeof TPLS[0]); }
const char *tpl_name(int i) { return i >= 0 && i < tpl_count() ? TPLS[i].name : ""; }
const char *tpl_info(int i) { return i >= 0 && i < tpl_count() ? TPLS[i].info : ""; }

int tpl_build(Project *p, int i)
{
    if (i < 0 || i >= tpl_count()) return -1;
    prj_init(p);
    return TPLS[i].build(p);
}
