#ifndef SB_WRITER_H
#define SB_WRITER_H

#include "project.h"

int sb_write_project(const Project *p, const char *path, const char *author);

#endif
