
#include <3ds.h>
#include <citro2d.h>

#include <malloc.h>
#include <math.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>

#include "assets.h"
#include "editor.h"
#include "importer.h"
#include "runtime.h"
#include "sb3_writer.h"
#include "templates.h"
#include "about.h"

#define Z 0.5f

#define CRGB(hex)  C2D_Color32(((hex) >> 16) & 255, ((hex) >> 8) & 255, (hex) & 255, 255)
#define CRGBA(hex, a) C2D_Color32(((hex) >> 16) & 255, ((hex) >> 8) & 255, (hex) & 255, (a))
static int g_light = 0;

static unsigned th_hex(unsigned h)
{
    if (!g_light) return h;
    unsigned r = (h >> 16) & 255, g = (h >> 8) & 255, b = h & 255;
    unsigned mx = r > g ? (r > b ? r : b) : (g > b ? g : b), mn = r < g ? (r < b ? r : b) : (g < b ? g : b);
    if (mx - mn > 48) return h;
    return ((255 - r) << 16) | ((255 - g) << 8) | (255 - b);
}
#define RGB(hex)  CRGB(th_hex(hex))
#define RGBA(hex, a) CRGBA(th_hex(hex), a)

#define SAVE_DIR  "sdmc:/3ds/scratch-editor"
#define IMPORT_DIR SAVE_DIR "/sprites"

#define TAB_H      15
#define SPR_Y      17
#define SPR_H      14
#define BTN_Y      208
#define BTN_H      18

#define CAT_Y      34
#define CAT_H      13
#define CAT_W      34
#define CAT_STEP   35
#define PAL_X      2
#define PAL_W      120
#define PAL_Y      50
#define PAL_ROW    15
#define PAL_ROWS   8
#define PALBTN_Y   171
#define PALBTN_H   14
#define SCRNAV_Y   188
#define SCRNAV_H   16
#define SCR_X      126
#define SCR_Y      48
#define SCR_ROW    20
#define SCR_ROWS   7
#define SCRBTN_X   304
#define SCRBTN_W   15
#define SCRBTN_H   66
#define SCRBTN_GAP 8
#define ARG_Y      190
#define ARG_H      16
#define ARG_UP_W   16
#define ARG_X      144
#define ARG_W      56
#define ARG_STEP   58

#define BTN_N      7
#define BTN_STEP   46
#define BTN_W      44

#define PK_Y       50
#define PK_ROW     20
#define PK_ROWS    6
#define PK_COLW    156
#define PK_COLSTEP 158
#define PK_NAV_Y   176
#define PK_PER_PAGE (PK_ROWS * 2)

#define CV_X       4
#define CV_Y       36
#define CV_CELL    5

#define SN_LIST_Y  36
#define SN_ROW     19
#define SN_BTN_Y   152
#define SN_REC_Y   172

#define STAGE_S    0.6f
#define STAGE_OX   56
#define STAGE_OY   12
#define PAD_S      (320.0f / STAGE_W)

enum { MODE_SCRIPTS = 0, MODE_COSTUMES, MODE_SOUNDS, MODE_ABOUT, MODE_COUNT };
enum { PK_NONE = 0, PK_ARG, PK_DEL_VAR, PK_DEL_LIST, PK_SPRITE_LIST, PK_SPRITE_MENU, PK_IMPORT, PK_FX, PK_TEMPLATE, PK_TEMPLATE_OK };
enum { SM_RENAME = 0, SM_DUPLICATE, SM_BACK, SM_FRONT, SM_X, SM_Y, SM_DIR, SM_SIZE, SM_VISIBLE, SM_IMPORT, SM_IMPORT_ALL, SM_TEMPLATES, SM_COUNT };

enum { PE_NEW_VAR = -1, PE_DEL_VAR = -2, PE_NEW_LIST = -3, PE_DEL_LIST = -4 };
typedef struct { int kind; int param; } PalEntry;
#define PAL_MAX (BK_COUNT + MAX_VARS + 8)

static C2D_TextBuf g_text;
static Project     g_prj;
static Runtime     g_rt;

static int  g_mode   = MODE_SCRIPTS;
static int  g_sprite = 0;
static int  g_script = 0, g_sel = 0, g_scroll = 0, g_cat = CAT_MOTION, g_pal_scroll = 0;

enum { BS_OFF = 0, BS_MOVE, BS_PICK };
static int  g_bs = BS_OFF;
static int  g_about_scroll;
#define ABOUT_ROWS 15
#define ABOUT_ROW_H 12
#define BS_BTN_Y 2
static int  g_color  = 1, g_tool = 0;
static int  g_snd    = -1;
static int  g_run_bottom = 0;
static int  g_play   = 0;
static char g_name[TEXT_LEN] = "project";
static char g_status[96] = "Tap a block to add it. Tabs: Scripts / Costumes / Sounds.";

static struct { int depth; int path[MAX_EXPR]; int slot; } g_foc;

static UndoStack g_undo;
static void checkpoint(void) { if (g_sprite != STAGE_IDX) undo_checkpoint(&g_undo, &g_prj, g_sprite); }

static struct { int action; char title[40]; int n; char items[MENU_MAX][TEXT_LEN]; int page; char slot; } g_pk;

static Sprite *cur(void) { return &g_prj.sprites[g_sprite]; }
static Script *cur_script(void) { return &cur()->scripts[g_script]; }

static void set_status(const char *fmt, ...) __attribute__((format(printf, 1, 2)));
static void set_status(const char *fmt, ...)
{
    va_list ap;
    va_start(ap, fmt);
    vsnprintf(g_status, sizeof g_status, fmt, ap);
    va_end(ap);
}

#define VOICES 4
typedef struct { ndspWaveBuf wb; int16_t *buf; } Voice;
static Voice g_voice[VOICES];
static int   g_next_voice = 0;
static int   g_audio_ok   = 0;
static Result g_audio_err = 0;

static void audio_init(void)
{
    g_audio_err = ndspInit();
    if (R_FAILED(g_audio_err)) return;
    ndspSetOutputMode(NDSP_OUTPUT_STEREO);
    for (int i = 0; i < VOICES; i++) {
        g_voice[i].buf = (int16_t *)linearAlloc(SND_BUF_MAX * sizeof(int16_t));
        if (!g_voice[i].buf) { g_audio_err = -1; return; }
        ndspChnReset(i);
        ndspChnSetInterp(i, NDSP_INTERP_LINEAR);
        ndspChnSetRate(i, (float)SND_RATE);
        ndspChnSetFormat(i, NDSP_FORMAT_MONO_PCM16);
        float mix[12] = { 0 };
        mix[0] = 1.0f; mix[1] = 1.0f;
        ndspChnSetMix(i, mix);
        memset(&g_voice[i].wb, 0, sizeof g_voice[i].wb);
    }
    g_audio_ok = 1;
}

static void audio_explain(void)
{
    if (g_audio_err == -1) set_status("%s", "No sound: not enough linear memory for the audio buffers.");
    else set_status("No sound: ndspInit failed (0x%08X). Put dspfirm.cdc in sd:/3ds/ (emulator: sdmc/3ds/).", (unsigned)g_audio_err);
}

static void audio_exit(void)
{
    if (!g_audio_ok) return;
    for (int i = 0; i < VOICES; i++) { ndspChnWaveBufClear(i); linearFree(g_voice[i].buf); }
    ndspExit();
}

static void audio_stop_all(void)
{
    if (!g_audio_ok) return;
    for (int i = 0; i < VOICES; i++) ndspChnWaveBufClear(i);
}

static void audio_play(const Sound *s, int vol_pct)
{
    if (!g_audio_ok) { audio_explain(); return; }
    Sound tmp = *s;
    tmp.vol = tmp.vol * vol_pct / 100;
    int ch = g_next_voice;
    g_next_voice = (g_next_voice + 1) % VOICES;
    Voice *v = &g_voice[ch];
    ndspChnWaveBufClear(ch);
    int n = snd_render(&tmp, v->buf, SND_BUF_MAX);
    ndspChnSetRate(ch, (float)snd_rate(&tmp));
    DSP_FlushDataCache(v->buf, (u32)n * sizeof(int16_t));
    memset(&v->wb, 0, sizeof v->wb);
    v->wb.data_vaddr = v->buf;
    v->wb.nsamples = (u32)n;
    ndspChnWaveBufAdd(ch, &v->wb);
}

static void audio_tone(int freq, int ms, int wave, int vol)
{
    if (!g_audio_ok) return;
    Sound t;
    snd_default(&t);
    t.freq = freq; t.ms = ms; t.wave = wave; t.vol = 100;
    audio_play(&t, vol);
}

#define MIC_BUF_BYTES 0x30000
static u8      *g_micbuf;
static u32      g_micsize;
static int      g_mic_ok;
static int      g_mic_running;
static Recorder g_rec;
static int16_t *g_recbuf;
static int      g_recording;
static int      g_new3ds;
static int      g_monitoring;

static void mic_init(void)
{
    g_recbuf = (int16_t *)malloc(REC_MAX_SAMPLES * sizeof(int16_t));
    g_micbuf = (u8 *)memalign(0x1000, MIC_BUF_BYTES);
    if (!g_recbuf || !g_micbuf) return;
    if (R_FAILED(micInit(g_micbuf, MIC_BUF_BYTES))) return;
    g_micsize = micGetSampleDataSize();
    if (g_micsize < 0x1000) { micExit(); return; }
    g_mic_ok = 1;
}

static void mic_exit(void)
{
    if (g_mic_ok) {
        if (g_mic_running) { MICU_StopSampling(); MICU_SetPower(false); }
        micExit();
    }
    free(g_micbuf);
    free(g_recbuf);
}

static int mic_start(int monitor)
{
    if (!g_mic_ok) return -1;
    if (g_mic_running) { MICU_StopSampling(); g_mic_running = 0; }
    MICU_SetPower(true);
    if (R_FAILED(MICU_StartSampling(MICU_ENCODING_PCM16_SIGNED, MICU_SAMPLE_RATE_10910, 0, g_micsize, true))) return -1;
    g_mic_running = 1;
    rec_begin(&g_rec, g_recbuf, REC_MAX_SAMPLES, monitor);
    g_rec.pos = micGetLastSampleOffset() & ~1u;
    return 0;
}

static void mic_stop(void)
{
    if (g_mic_running) { MICU_StopSampling(); MICU_SetPower(false); }
    g_mic_running = 0;
}

static void mic_poll(void)
{
    if (!g_mic_running) return;
    rec_consume(&g_rec, g_micbuf, g_micsize, micGetLastSampleOffset());
}

static void text(const char *s, float x, float y, float scale, u32 color)
{
    C2D_Text t;
    C2D_TextParse(&t, g_text, s);
    C2D_TextOptimize(&t);
    C2D_DrawText(&t, C2D_WithColor, x, y, Z, scale, scale, color);
}

static int hit(int px, int py, int x, int y, int w, int h)
{
    return px >= x && px < x + w && py >= y && py < y + h;
}

static void rect(float x, float y, float w, float h, u32 hex)
{
    C2D_DrawRectSolid(x, y, Z, w, h, RGB(hex));
}

static void rectc(float x, float y, float w, float h, u32 hex)
{
    C2D_DrawRectSolid(x, y, Z, w, h, CRGB(hex));
}

static void frame(float x, float y, float w, float h, u32 hex)
{
    rect(x - 1, y - 1, w + 2, 1, hex);
    rect(x - 1, y + h, w + 2, 1, hex);
    rect(x - 1, y, 1, h, hex);
    rect(x + w, y, 1, h, hex);
}

static void fit(char *out, const char *s, int maxc)
{
    int n = (int)strlen(s);
    if (n <= maxc) { strcpy(out, s); return; }
    if (maxc < 3) maxc = 3;
    memcpy(out, s, (size_t)maxc - 2);
    out[maxc - 2] = '.'; out[maxc - 1] = '.'; out[maxc] = 0;
}

static void button(float x, float y, float w, float h, const char *label, u32 hex, int on)
{
    rect(x, y, w, h, hex);
    if (on) frame(x, y, w, h, 0xFFFFFF);
    char lab[48];
    fit(lab, label, (int)(w / 5.6f));
    text(lab, x + 3, y + (h > 16 ? 2 : 0), 0.42f, RGB(0xFFFFFF));
}

static void draw_costume_a(const Costume *c, float x, float y, float s, float ghost)
{
    int alpha = (int)(255.f * (100.f - ghost) / 100.f);
    if (alpha < 0) alpha = 0;
    for (int r = 0; r < COSTUME_H; r++) {
        int cx = 0;
        while (cx < COSTUME_W) {
            uint8_t v = c->px[r * COSTUME_W + cx];
            int e = cx + 1;
            while (e < COSTUME_W && c->px[r * COSTUME_W + e] == v) e++;
            if (v) C2D_DrawRectSolid(x + cx * s, y + r * s, Z, (e - cx) * s, s, CRGBA(PALETTE_RGB[v], alpha));
            cx = e;
        }
    }
}
static void draw_costume(const Costume *c, float x, float y, float s) { draw_costume_a(c, x, y, s, 0.f); }

static void format_val(const Val *v, char *out, int n) { val_to_str(v, out, n); }

static void draw_backdrop(const Costume *c, float x, float y, float w, float h)
{
    float cw = w / COSTUME_W, ch = h / COSTUME_H;
    for (int r = 0; r < COSTUME_H; r++) {
        int cx = 0;
        while (cx < COSTUME_W) {
            uint8_t v = c->px[r * COSTUME_W + cx];
            int e = cx + 1;
            while (e < COSTUME_W && c->px[r * COSTUME_W + e] == v) e++;
            if (v) C2D_DrawRectSolid(x + cx * cw, y + r * ch, Z, (e - cx) * cw, ch + 0.5f, CRGB(PALETTE_RGB[v]));
            cx = e;
        }
    }
}

static void draw_stage_view(float ox, float oy, float S)
{
    frame(ox, oy, STAGE_W * S, STAGE_H * S, 0x555555);
    rect(ox, oy, STAGE_W * S, STAGE_H * S, 0xFFFFFF);
    {
        const Sprite *stg = &g_prj.sprites[STAGE_IDX];
        if (stg->ncostumes > 0) draw_backdrop(&stg->costumes[stg->cur_costume], ox, oy, STAGE_W * S, STAGE_H * S);
    }

    for (int i = 0; i < g_rt.pen_count; i++) {
        const PenSeg *g = &g_rt.pen[(g_rt.pen_head + i) % PEN_SEGS];
        float w = g->size * S + 0.5f;
        if (g->x0 == g->x1 && g->y0 == g->y1)
            rectc(ox + (STAGE_W / 2 + g->x0) * S - w / 2, oy + (STAGE_H / 2 - g->y0) * S - w / 2, w, w, g->rgb);
        else
            C2D_DrawLine(ox + (STAGE_W / 2 + g->x0) * S, oy + (STAGE_H / 2 - g->y0) * S, CRGB(g->rgb),
                         ox + (STAGE_W / 2 + g->x1) * S, oy + (STAGE_H / 2 - g->y1) * S, CRGB(g->rgb), w, Z);
    }
    for (int i = 0; i < g_rt.nstamps; i++) {
        const Stamp *st = &g_rt.stamps[i];
        float cs = COSTUME_SB_SCALE * S * st->size / 100.f, half = COSTUME_W * cs / 2;
        draw_costume_a(&g_prj.sprites[st->sprite].costumes[st->costume],
                       ox + (STAGE_W / 2 + st->x) * S - half, oy + (STAGE_H / 2 - st->y) * S - half, cs, st->ghost);
    }
    for (int k = 0; k < g_rt.norder; k++) {
        int i = g_rt.order[k];
        const SpriteRT *r = &g_rt.spr[i];
        const Sprite *sp = &g_prj.sprites[r->def];
        if (!r->visible) continue;
        float cs = COSTUME_SB_SCALE * S * r->size / 100.f;
        float cx = ox + (STAGE_W / 2 + r->x) * S;
        float cy = oy + (STAGE_H / 2 - r->y) * S;
        float half = COSTUME_W * cs / 2;
        if (i == g_sprite && !r->is_clone && !g_play) frame(cx - half, cy - half, 2 * half, 2 * half, 0x3B7DD8);
        draw_costume_a(&sp->costumes[r->costume], cx - half, cy - half, cs, r->ghost);
        if (i == g_sprite && !r->is_clone && !g_play) {
            float rad = r->dir * 3.14159265f / 180.f;
            C2D_DrawLine(cx, cy, CRGB(0x1A1A1A), cx + 14 * sinf(rad), cy - 14 * cosf(rad), CRGB(0x1A1A1A), 2, Z);
        }
    }
    for (int i = 0; i < RT_SLOTS; i++) {
        const SpriteRT *r = &g_rt.spr[i];
        if (!r->alive || !r->visible || !r->say[0]) continue;
        float cx = ox + (STAGE_W / 2 + r->x) * S, cy = oy + (STAGE_H / 2 - r->y) * S;
        float w = 6.0f * (float)strlen(r->say) + 8;
        rect(cx - 5, cy - 40, w + 2, 18, r->thinking ? 0x8888AA : 0x333333);
        rect(cx - 4, cy - 39, w, 16, 0xFFFFFF);
        text(r->say, cx, cy - 38, 0.45f, RGB(0x000000));
    }
    int row = 0;
    for (int v = 0; v < g_prj.nvars; v++) {
        if (!g_rt.var_shown[v]) continue;
        char val[TEXT_LEN], line[2 * TEXT_LEN + 4];
        format_val(&g_rt.var[v], val, sizeof val);
        snprintf(line, sizeof line, "%s: %s", g_prj.vars[v].name, val);
        rect(ox + 4, oy + 4 + row * 14, 6.0f * (float)strlen(line) + 6, 13, 0xEE7D16);
        text(line, ox + 7, oy + 4 + row * 14, 0.4f, RGB(0xFFFFFF));
        row++;
    }
}

static void draw_top_stage(void)
{
    draw_stage_view(STAGE_OX, STAGE_OY, STAGE_S);

    text(g_new3ds ? APP_NAME " v" APP_VERSION "  (New 3DS speed-up on)" : APP_NAME " v" APP_VERSION, 8, 0, 0.4f, RGB(0xCCCCCC));
    char info[96];
    const SpriteRT *r = &g_rt.spr[g_sprite];
    if (g_play) snprintf(info, sizeof info, "%s  x:%d y:%d dir:%d  mouse:%d,%d", cur()->name, (int)r->x, (int)r->y, (int)r->dir,
                         (int)g_rt.mouse_x, (int)g_rt.mouse_y);
    else snprintf(info, sizeof info, "%s  x:%d y:%d dir:%d", cur()->name, (int)r->x, (int)r->y, (int)r->dir);
    text(info, 8, 226, 0.4f, RGB(0xCCCCCC));
    if (g_play && g_monitoring) {
        char lv[24];
        snprintf(lv, sizeof lv, "mic %d", (int)g_rt.loudness);
        text(lv, 350, 226, 0.4f, RGB(0xCCCCCC));
    }
}

static void draw_top_costume(void)
{
    const Sprite *sp = cur();
    const float s = 6.0f, x = 104, y = 22;
    for (int r = 0; r < 4; r++)
        for (int c = 0; c < 4; c++) rect(x + c * 48, y + r * 48, 48, 48, ((r + c) & 1) ? 0x3A3A44 : 0x2E2E36);
    draw_costume(&sp->costumes[sp->cur_costume], x, y, s);
    char info[96];
    snprintf(info, sizeof info, "%s: costume %d/%d  \"%s\"", sp->name, sp->cur_costume + 1, sp->ncostumes,
             sp->costumes[sp->cur_costume].name);
    text(info, 8, 226, 0.42f, RGB(0xCCCCCC));
}

static void draw_top_sound(void)
{
    rect(20, 30, 360, 160, 0x2A2A32);
    rect(20, 109, 360, 1, 0x55555F);
    if (g_recording) {
        float lv = g_rec.level;
        rect(20, 30, 360 * lv / 100.f, 160, 0x7A2A2A);
        char info[96];
        snprintf(info, sizeof info, "Recording...  %.1f s / %d s   level %d", (float)g_rec.n / REC_RATE, REC_MAX_SECS, (int)lv);
        text(info, 24, 34, 0.5f, RGB(0xFFFFFF));
        text("Tap Stop to finish.", 24, 52, 0.42f, RGB(0xDDDDDD));
        return;
    }
    if (g_snd >= 0 && g_snd < cur()->nsounds) {
        const Sound *s = &cur()->sounds[g_snd];
        if (snd_is_recorded(s)) {
            for (int col = 0; col < 358; col++) {
                int i0 = (int)((int64_t)col * s->npcm / 358), i1 = (int)((int64_t)(col + 1) * s->npcm / 358);
                if (i1 <= i0) i1 = i0 + 1;
                int lo = 0, hi = 0;
                for (int i = i0; i < i1 && i < s->npcm; i++) { if (s->pcm[i] < lo) lo = s->pcm[i]; if (s->pcm[i] > hi) hi = s->pcm[i]; }
                float y0 = 109 - hi * 75.0f / 32768.0f, y1 = 109 - lo * 75.0f / 32768.0f;
                rect(21 + col, y0, 1, y1 - y0 + 1, 0xE0804A);
            }
        } else {
            static int16_t pcm[1000];
            Sound tmp = *s;
            if (tmp.ms > 90) tmp.ms = 90;
            int n = snd_render(&tmp, pcm, 1000);
            for (int col = 0; col < 359 && n > 1; col++) {
                int i0 = col * (n - 1) / 359, i1 = (col + 1) * (n - 1) / 359;
                float y0 = 109 - pcm[i0] * 75.0f / 32768.0f, y1 = 109 - pcm[i1] * 75.0f / 32768.0f;
                C2D_DrawLine(20 + col, y0, RGB(0x4AD0E0), 21 + col, y1, RGB(0x4AD0E0), 1.5f, Z);
            }
        }
        char info[96];
        if (snd_is_recorded(s))
            snprintf(info, sizeof info, "\"%s\"  recording  %.2f s  %d Hz  vol %d%%", s->name, snd_duration_ms(s) / 1000.f, s->rate, s->vol);
        else
            snprintf(info, sizeof info, "\"%s\"  %s  %d Hz  %d ms  vol %d%%", s->name, snd_wave_name(s->wave), s->freq, s->ms, s->vol);
        text(info, 8, 226, 0.42f, RGB(0xCCCCCC));
    } else {
        text("No sound selected. Tap New or Rec.", 90, 100, 0.5f, RGB(0xAAAAAA));
    }
}

static int palette_entries(int cat, PalEntry *out)
{
    int n = 0;
    if (cat == CAT_VARIABLES) {
        out[n++] = (PalEntry){ PE_NEW_VAR, 0 };
        out[n++] = (PalEntry){ PE_DEL_VAR, 0 };
        for (int v = 0; v < g_prj.nvars; v++) out[n++] = (PalEntry){ BK_VAR, v };
    } else if (cat == CAT_LISTS) {
        out[n++] = (PalEntry){ PE_NEW_LIST, 0 };
        out[n++] = (PalEntry){ PE_DEL_LIST, 0 };
    }
    for (int k = 0; k < BK_COUNT; k++)
        if (BLOCK_INFO[k].category == cat && k != BK_VAR) out[n++] = (PalEntry){ k, 0 };
    return n;
}

static void palette_label(const PalEntry *e, char *out, int n)
{
    switch (e->kind) {
    case PE_NEW_VAR:  snprintf(out, (size_t)n, "%s", "+ New variable"); return;
    case PE_DEL_VAR:  snprintf(out, (size_t)n, "%s", "- Delete variable"); return;
    case PE_NEW_LIST: snprintf(out, (size_t)n, "%s", "+ New list"); return;
    case PE_DEL_LIST: snprintf(out, (size_t)n, "%s", "- Delete list"); return;
    default: break;
    }
    char body[64];
    if (e->kind == BK_VAR) snprintf(body, sizeof body, "%s", g_prj.vars[e->param].name);
    else { Block d = block_default(e->kind); prj_format_block(NULL, &d, body, sizeof body); }
    int sh = BLOCK_INFO[e->kind].shape;
    snprintf(out, (size_t)n, sh == SH_REP ? "(%s)" : (sh == SH_BOOL ? "<%s>" : "%s"), body);
}

static u32 palette_color(const PalEntry *e)
{
    return e->kind < 0 ? 0x666670 : category_color(BLOCK_INFO[e->kind].category);
}

static void focus_reset(void)
{
    g_foc.depth = 0;
    g_foc.slot = 0;
}

static Block *focus_node(void)
{
    Script *s = cur_script();
    if (g_sel < 0 || g_sel >= s->nblocks) return NULL;
    return prj_node(s, g_sel, g_foc.path, g_foc.depth);
}

static char focus_slot_char(const Block *node, int slot)
{
    return slot >= 0 && slot < block_nslots(node->kind) ? BLOCK_INFO[node->kind].slots[slot] : 0;
}

static void select_block(int b)
{
    Script *s = cur_script();
    if (b < 0) b = 0;
    if (b >= s->nblocks) b = s->nblocks - 1;
    if (b != g_sel) focus_reset();
    g_sel = b;
    if (g_sel < g_scroll) g_scroll = g_sel;
    if (g_sel >= g_scroll + SCR_ROWS) g_scroll = g_sel - SCR_ROWS + 1;
}

static void script_page(int dir)
{
    int max = cur_script()->nblocks - SCR_ROWS;
    if (max < 0) max = 0;
    g_scroll += dir * (SCR_ROWS - 1);
    if (g_scroll < 0) g_scroll = 0;
    if (g_scroll > max) g_scroll = max;
}

static void script_jump(int end)
{
    select_block(end ? cur_script()->nblocks - 1 : 0);
    if (!end) g_scroll = 0;
}

static void draw_picker(void)
{
    rect(0, 34, 320, 172, 0x24242C);
    text(g_pk.title, 4, 36, 0.45f, RGB(0xFFFFFF));
    int first = g_pk.page * PK_PER_PAGE;
    for (int i = 0; i < PK_PER_PAGE && first + i < g_pk.n; i++) {
        int col = i / PK_ROWS, row = i % PK_ROWS;
        button(2 + col * PK_COLSTEP, PK_Y + row * PK_ROW, PK_COLW, PK_ROW - 2, g_pk.items[first + i], 0x4A4A58, 0);
    }
    button(2, PK_NAV_Y, 100, 18, "< Prev", 0x66666F, 0);
    button(110, PK_NAV_Y, 100, 18, "Cancel", 0xC0392B, 0);
    button(218, PK_NAV_Y, 100, 18, "Next >", 0x66666F, 0);
}

#define NOTCH_X 7
static void draw_block_row(float x, float y, float w, float h, u32 color, const char *label, int selected,
                           u32 bg, int style, float nx)
{
    if (selected) frame(x, y, w, h - 1, 0xFFFFFF);
    rect(x, y, w, h - 1, color);
    if (style == 2) {
        rect(x, y, 2, 1, bg); rect(x + w - 2, y, 2, 1, bg);
        rect(x, y + h - 2, 2, 1, bg); rect(x + w - 2, y + h - 2, 2, 1, bg);
        rect(x, y, 1, 2, bg); rect(x + w - 1, y, 1, 2, bg);
        rect(x, y + h - 3, 1, 2, bg); rect(x + w - 1, y + h - 3, 1, 2, bg);
    } else {
        if (style == 1) {
            rect(x, y, 4, 1, bg); rect(x, y + 1, 2, 1, bg); rect(x + w - 2, y, 2, 1, bg);
        } else {
            rect(x, y, 1, 1, bg); rect(x + w - 1, y, 1, 1, bg);
            rect(x + NOTCH_X, y, 16, 1, bg); rect(x + NOTCH_X + 2, y + 1, 12, 1, bg);
        }
        rect(x, y + h - 2, 1, 1, bg); rect(x + w - 1, y + h - 2, 1, 1, bg);
        if (nx >= 0) {
            rect(nx + NOTCH_X, y + h - 1, 16, 2, color);
            rect(nx + NOTCH_X + 2, y + h + 1, 12, 1, color);
        }
    }
    char lab[64];
    fit(lab, label, (int)((w - 4) / 5.2f));
    text(lab, x + 3, y + 1, 0.42f, RGB(0xFFFFFF));
}

typedef struct {
    int  src;
    int  active;
    int  sx, sy, x, y;
    PalEntry pe;
    int  block;
    char label[64];
    u32  color;
} Drag;
static Drag g_drag;
#define DRAG_THRESHOLD 6

static int script_gap(int y)
{
    int k = y - SCR_Y + SCR_ROW / 2;
    k = k < 0 ? 0 : k / SCR_ROW;
    return k > SCR_ROWS ? SCR_ROWS : k;
}
static int gap_after(int k)
{
    int a = g_scroll + k - 1, n = g_prj.sprites[g_sprite].scripts[g_script].nblocks;
    if (a > n - 1) a = n - 1;
    return a < 0 ? 0 : a;
}

static void draw_drag(void)
{
    if (!g_drag.active) return;
    int in_script = g_drag.x >= SCR_X - 4 && g_drag.y >= SCR_Y - 4 && g_drag.y < SCR_Y + SCR_ROWS * SCR_ROW + 4;
    int reporter = g_drag.src == 1 && g_drag.pe.kind >= 0 && block_is_reporter(g_drag.pe.kind);
    int hat = g_drag.src == 1 && g_drag.pe.kind >= 0 && block_is_hat(g_drag.pe.kind);
    if (g_drag.src == 2 && g_drag.x >= PAL_X && g_drag.x < PAL_X + PAL_W && g_drag.y >= PAL_Y && g_drag.y < PAL_Y + PAL_ROWS * PAL_ROW)
        frame(PAL_X, PAL_Y, PAL_W, PAL_ROWS * PAL_ROW, 0xFF4040);
    else if (reporter) {
        if (in_script) {
            int r = (g_drag.y - SCR_Y) / SCR_ROW;
            if (r >= 0 && r < SCR_ROWS) frame(SCR_X - 2, SCR_Y + r * SCR_ROW - 1, 320 - SCR_X + 2, SCR_ROW + 1, 0xFFFFFF);
        }
        for (int i = 0; i < MAX_ARGS; i++)
            if (g_drag.x >= ARG_X + i * ARG_STEP && g_drag.x < ARG_X + i * ARG_STEP + ARG_W && g_drag.y >= ARG_Y && g_drag.y < ARG_Y + ARG_H)
                frame(ARG_X + i * ARG_STEP, ARG_Y, ARG_W, ARG_H, 0xFFFFFF);
    } else if (in_script && !hat) {
        int shown = gap_after(script_gap(g_drag.y)) + 1 - g_scroll;
        if (shown < 0) shown = 0;
        if (shown > SCR_ROWS) shown = SCR_ROWS;
        rect(SCR_X - 2, SCR_Y + shown * SCR_ROW - 1, 320 - SCR_X + 2, 3, 0xFFFFFF);
    }
    float w = 6.0f * (float)strlen(g_drag.label) + 10;
    if (w > 150) w = 150;
    rect(g_drag.x - 12, g_drag.y - 20, w, SCR_ROW - 2, g_drag.color);
    frame(g_drag.x - 12, g_drag.y - 20, w, SCR_ROW - 2, 0xFFFFFF);
    text(g_drag.label, g_drag.x - 8, g_drag.y - 18, 0.4f, RGB(0xFFFFFF));
}

static void draw_bottom_scripts(void)
{
    static const char *cat_names[CAT_COUNT] = { "Mot", "Look", "Snd", "Pen", "Ctl", "Sens", "Ops", "Var", "List" };
    for (int c = 0; c < CAT_COUNT; c++) button(2 + c * CAT_STEP, CAT_Y, CAT_W, CAT_H, cat_names[c], category_color(c), c == g_cat);

    PalEntry pe[PAL_MAX];
    int n = palette_entries(g_cat, pe);
    int pn = n - g_pal_scroll < PAL_ROWS ? n - g_pal_scroll : PAL_ROWS;
    for (int i = pn - 1; i >= 0; i--) {
        char lab[64];
        const PalEntry *e = &pe[g_pal_scroll + i];
        palette_label(e, lab, sizeof lab);
        int st = e->kind >= 0 && block_is_reporter(e->kind) ? 2 : (e->kind >= 0 && block_is_hat(e->kind) ? 1 : 0);
        draw_block_row(PAL_X, PAL_Y + i * PAL_ROW, PAL_W, PAL_ROW, palette_color(e), lab, 0, 0x2B2B33, st, i + 1 < pn ? PAL_X : -1);
    }
    button(PAL_X, PALBTN_Y, 58, PALBTN_H, "^", 0x66666F, 0);
    button(PAL_X + 62, PALBTN_Y, 58, PALBTN_H, "v", 0x66666F, 0);

    const Sprite *sp = cur();
    const Script *s = &sp->scripts[g_script];
    char head[32];
    snprintf(head, sizeof head, "S%d/%d", g_script + 1, sp->nscripts);
    button(PAL_X, SCRNAV_Y, 17, SCRNAV_H, "<", 0x66666F, 0);
    button(PAL_X + 19, SCRNAV_Y, 17, SCRNAV_H, ">", 0x66666F, 0);
    text(head, PAL_X + 39, SCRNAV_Y + 3, 0.40f, RGB(0xFFFFFF));
    button(PAL_X + 70, SCRNAV_Y, 24, SCRNAV_H, "Top", 0x3A6EA5, 0);
    button(PAL_X + 96, SCRNAV_Y, 24, SCRNAV_H, "End", 0x3A6EA5, 0);

    rect(SCR_X - 2, SCR_Y - 1, 320 - SCR_X + 2, SCR_ROWS * SCR_ROW + 2, 0x3A3A46);
    int srows = s->nblocks - g_scroll < SCR_ROWS ? s->nblocks - g_scroll : SCR_ROWS;
    for (int row = srows - 1; row >= 0; row--) {
        int b = g_scroll + row;
        char lab[96];
        prj_format_block(s, &s->blocks[b], lab, sizeof lab);
        float x = SCR_X + prj_indent(s, b) * 8;
        int sh = BLOCK_INFO[s->blocks[b].kind].shape;
        u32 col = (sh == SH_END || sh == SH_ELSE) ? COL_CONTROL : category_color(BLOCK_INFO[s->blocks[b].kind].category);
        float nx = row + 1 < srows ? SCR_X + prj_indent(s, b + 1) * 8 : -1;
        draw_block_row(x, SCR_Y + row * SCR_ROW, SCRBTN_X - 3 - x, SCR_ROW, col, lab, b == g_sel, 0x3A3A46, sh == SH_HAT ? 1 : 0, nx);
    }

    button(SCRBTN_X, SCR_Y, SCRBTN_W, SCRBTN_H, "^", 0x66666F, 0);
    button(SCRBTN_X, SCR_Y + SCRBTN_H + SCRBTN_GAP, SCRBTN_W, SCRBTN_H, "v", 0x66666F, 0);

    Block *node = (g_sel < s->nblocks) ? prj_node((Script *)s, g_sel, g_foc.path, g_foc.depth) : NULL;
    button(SCR_X, ARG_Y, ARG_UP_W, ARG_H, "^", g_foc.depth > 0 ? 0x2E9E4F : 0x555560, 0);
    int ns = node ? block_nslots(node->kind) : 0;
    for (int i = 0; i < MAX_ARGS; i++) {
        float x = ARG_X + i * ARG_STEP;
        if (i >= ns) { rect(x, ARG_Y, ARG_W, ARG_H, 0x33333B); continue; }
        char lab[64];
        prj_format_arg(s, &node->a[i], focus_slot_char(node, i), lab, sizeof lab);
        button(x, ARG_Y, ARG_W, ARG_H, lab, 0x4A4A58, i == g_foc.slot);
    }
    draw_drag();
}

static void draw_bottom_costumes(void)
{
    const Sprite *sp = cur();
    const Costume *c = &sp->costumes[sp->cur_costume];
    frame(CV_X, CV_Y, COSTUME_W * CV_CELL, COSTUME_H * CV_CELL, 0x888888);
    rect(CV_X, CV_Y, COSTUME_W * CV_CELL, COSTUME_H * CV_CELL, 0x33333C);
    for (int r = 0; r < 8; r++)
        for (int q = 0; q < 8; q++)
            if ((r + q) & 1) rect(CV_X + q * 20, CV_Y + r * 20, 20, 20, 0x3C3C46);
    draw_costume(c, CV_X, CV_Y, CV_CELL);

    for (int i = 0; i < PAL_N; i++) {
        float x = 172 + (i / 8) * 20, y = 36 + (i % 8) * 20;
        if (i == g_color) frame(x, y, 18, 18, 0xFFFFFF);
        if (i == 0) { rect(x, y, 18, 18, 0x55555F); text("x", x + 6, y + 1, 0.5f, RGB(0xFFFFFF)); }
        else rectc(x, y, 18, 18, PALETTE_RGB[i]);
    }
    static const char *tools[6] = { "Pen", "Fill", "Flip", "Clear", "New", "Name" };
    for (int i = 0; i < 6; i++)
        button(214 + (i % 2) * 52, 36 + (i / 2) * 22, 50, 20, tools[i],
               (i < 2) ? 0x3B7DD8 : 0x66666F, (i < 2) && g_tool == i);
    button(214, 102, 50, 20, "<", 0x66666F, 0);
    button(266, 102, 50, 20, ">", 0x66666F, 0);
    char info[64];
    snprintf(info, sizeof info, "Costume %d/%d", sp->cur_costume + 1, sp->ncostumes);
    text(info, 214, 126, 0.42f, RGB(0xFFFFFF));
    text(c->name, 214, 138, 0.42f, RGB(0xCCCCCC));
    text("Color x = erase", 214, 156, 0.38f, RGB(0xAAAAAA));
}

static void draw_bottom_sounds(void)
{
    const Sprite *sp = cur();
    for (int i = 0; i < sp->nsounds; i++) {
        char lab[64];
        snprintf(lab, sizeof lab, "%s (%s)", sp->sounds[i].name, snd_is_recorded(&sp->sounds[i]) ? "mic" : snd_wave_name(sp->sounds[i].wave));
        button(2, SN_LIST_Y + i * SN_ROW, 148, 18, lab, COL_SOUND, i == g_snd);
    }
    button(2, SN_BTN_Y, 46, 18, "New", 0x3B7DD8, 0);
    button(52, SN_BTN_Y, 46, 18, "Play", 0x2E9E4F, 0);
    button(102, SN_BTN_Y, 46, 18, "Name", 0x66666F, 0);
    button(2, SN_REC_Y, 146, 22, g_recording ? "Stop recording" : "Rec (microphone)", g_recording ? 0xC0392B : 0xA03030, g_recording);
    button(156, SN_REC_Y, 160, 22, "Sound effects...", 0x4C8F8F, 0);
    if (!g_mic_ok) text("No microphone available.", 4, 198, 0.38f, RGB(0xAAAAAA));

    if (g_snd >= 0 && g_snd < sp->nsounds && !g_recording) {
        const Sound *s = &sp->sounds[g_snd];
        if (snd_is_recorded(s)) {
            static const char *edit[3] = { "Trim silence", "Normalize", "Reverse" };
            for (int k = 0; k < 3; k++) button(156, 36 + k * 28, 160, 24, edit[k], 0x66666F, 0);
            char v[40];
            snprintf(v, 40, "Vol: %d%%", s->vol);
            rect(156, 36 + 3 * 28, 102, 24, 0x3A3A46);
            text(v, 160, 36 + 3 * 28 + 5, 0.45f, RGB(0xFFFFFF));
            button(262, 36 + 3 * 28, 26, 24, "-", 0x66666F, 0);
            button(290, 36 + 3 * 28, 26, 24, "+", 0x66666F, 0);
        } else {
            char v[4][40];
            snprintf(v[0], 40, "Wave: %s", snd_wave_name(s->wave));
            snprintf(v[1], 40, "Freq: %d Hz", s->freq);
            snprintf(v[2], 40, "Time: %d ms", s->ms);
            snprintf(v[3], 40, "Vol: %d%%", s->vol);
            for (int k = 0; k < 4; k++) {
                float y = 36 + k * 28;
                rect(156, y, 102, 24, 0x3A3A46);
                text(v[k], 160, y + 5, 0.45f, RGB(0xFFFFFF));
                button(262, y, 26, 24, "-", 0x66666F, 0);
                button(290, y, 26, 24, "+", 0x66666F, 0);
            }
            text("Tap a value to type it.", 156, 152, 0.38f, RGB(0xAAAAAA));
        }
    }
}

static void draw_bottom_stage(void)
{
    draw_stage_view(0, 0, PAD_S);
    if (g_rt.mouse_down) rect(g_rt.mouse_x * PAD_S + 160 - 3, 120 - g_rt.mouse_y * PAD_S - 3, 6, 6, 0x000000);
    text("B = stop", 270, 228, 0.4f, RGB(0x666666));
}

static void draw_top_run_info(void)
{
    text("Project running on the bottom screen", 8, 4, 0.5f, RGB(0xFFFFFF));
    text("Touch = mouse   D-pad/A/X/Y/L/R = keys   B = stop", 8, 20, 0.36f, RGB(0xBBBBBB));
    int y = 40;
    for (int i = 0; i < g_prj.nsprites && y < 150; i++) {
        const SpriteRT *r = &g_rt.spr[i];
        char line[96];
        snprintf(line, sizeof line, "%s  x:%d y:%d dir:%d%s", g_prj.sprites[i].name, (int)r->x, (int)r->y, (int)r->dir, r->visible ? "" : " (hidden)");
        text(line, 8, y, 0.4f, RGB(0xDDDDDD));
        y += 13;
    }
    y += 6;
    for (int v = 0; v < g_prj.nvars && y < 210; v++) {
        char val[TEXT_LEN], line[2 * TEXT_LEN + 4];
        format_val(&g_rt.var[v], val, sizeof val);
        snprintf(line, sizeof line, "%s = %s", g_prj.vars[v].name, val);
        text(line, 8, y, 0.4f, RGB(0xEE9D46));
        y += 13;
    }
    char info[64];
    snprintf(info, sizeof info, "timer %.1f  answer: %.14s%s%s", g_rt.timer, g_rt.answer, g_monitoring ? "  mic on" : "", "");
    text(info, 8, 226, 0.4f, RGB(0xCCCCCC));
}

static void draw_top_about(void)
{
    rect(0, 0, 400, 240, 0x20242C);
    text(APP_NAME, 100, 70, 0.9f, RGB(0xFFAB19));
    text("version " APP_VERSION, 150, 110, 0.5f, RGB(0xFFFFFF));
    text("unofficial block editor, by probeta", 100, 136, 0.45f, RGB(0xCCCCCC));
    text("Scratch is a project of the MIT Media Lab.", 90, 156, 0.4f, RGB(0x999999));
    text("Not affiliated with or endorsed by MIT or Scratch.", 78, 170, 0.4f, RGB(0x999999));
}

static void draw_bottom_about(void)
{
    for (int r = 0; r < ABOUT_ROWS; r++) {
        int i = g_about_scroll + r;
        if (i >= ABOUT_N) break;
        const char *l = ABOUT_LINES[i];
        float y = 20 + r * ABOUT_ROW_H;
        if (l[0] == '#') text(l + 1, 6, y, 0.46f, RGB(0xFFAB19));
        else if (l[0] == '*') text(l + 1, 6, y, 0.44f, RGB(0x4C97FF));
        else text(l, 6, y, 0.38f, RGB(0xDDDDDD));
    }
    button(294, 20, 24, 40, "^", 0x66666F, 0);
    button(294, 162, 24, 40, "v", 0x66666F, 0);
}

static void draw_top(void)
{
    if (g_play) { if (g_run_bottom) draw_top_run_info(); else draw_top_stage(); return; }
    switch (g_mode) {
    case MODE_SCRIPTS:  draw_top_stage();   break;
    case MODE_COSTUMES: draw_top_costume(); break;
    case MODE_ABOUT:    draw_top_about();   break;
    default:            draw_top_sound();   break;
    }
}

static void draw_bottom_pad(void)
{
    rect(0, 0, 320, 240, 0x20242C);
    for (int k = 0; k < g_rt.norder; k++) {
        int i = g_rt.order[k];
        const SpriteRT *r = &g_rt.spr[i];
        if (!r->visible) continue;
        float h = COSTUME_W * COSTUME_SB_SCALE / 2.0f * r->size / 100.f * PAD_S;
        float cx = (STAGE_W / 2 + r->x) * PAD_S, cy = (STAGE_H / 2 - r->y) * PAD_S;
        uint8_t px = g_prj.sprites[r->def].costumes[r->costume].px[(COSTUME_H / 2) * COSTUME_W + COSTUME_W / 2];
        rect(cx - h, cy - h, 2 * h, 2 * h, px ? PALETTE_RGB[px] : 0x888888);
    }
    if (g_rt.mouse_down) rect(g_rt.mouse_x * PAD_S + 160 - 3, 120 - g_rt.mouse_y * PAD_S - 3, 6, 6, 0xFFFFFF);
    text("Touch = mouse     B = stop", 6, 226, 0.42f, RGB(0xCCCCCC));
}

static void draw_bottom_bstage(void)
{
    draw_stage_view(0, 0, PAD_S);
    if (g_bs == BS_PICK) {
        button(2, BS_BTN_Y, 36, 16, "List", 0x66666F, 0);
        button(40, BS_BTN_Y, 48, 16, "Cancel", 0xC0392B, 0);
        rect(0, 222, 320, 18, 0x20242C);
        text("Eyedropper: tap a colour on the stage", 4, 225, 0.42f, RGB(0xFFFFFF));
    } else {
        button(2, BS_BTN_Y, 44, 16, "Done", 0x2E9E4F, 0);
        rect(0, 222, 320, 18, 0x20242C);
        char info[64];
        snprintf(info, sizeof info, "%.14s  x:%d y:%d  (drag to move)", cur()->name, cur()->x, cur()->y);
        text(info, 4, 225, 0.42f, RGB(0xFFFFFF));
    }
}

static void draw_bottom(void)
{
    if (g_play) { if (g_run_bottom) draw_bottom_stage(); else draw_bottom_pad(); return; }
    if (g_bs && g_pk.action == PK_NONE) { draw_bottom_bstage(); return; }
    static const char *tabs[MODE_COUNT] = { "Scripts", "Costumes", "Sounds", "About" };
    for (int m = 0; m < MODE_COUNT; m++) button(1 + m * 70, 0, 68, TAB_H, tabs[m], 0x4A4A58, m == g_mode);
    if (g_mode == MODE_ABOUT) {
        draw_bottom_about();
        static const char *lb[BTN_N] = { "Flag", "Stop", "Save", "Del", "Undo", "Redo", "Dup" };
        static const u32 cl[BTN_N] = { 0x2E9E4F, 0xC0392B, 0x3B7DD8, 0x777777, 0x7A5CC0, 0x7A5CC0, 0x4C8F8F };
        for (int i = 0; i < BTN_N; i++) button(i * BTN_STEP + 1, BTN_Y, BTN_W, BTN_H, lb[i], cl[i], 0);
        text(g_status, 4, 228, 0.38f, RGB(0xDDDDDD));
        return;
    }

    char lab[64];
    if (g_sprite == STAGE_IDX) snprintf(lab, sizeof lab, "Stage: %d backdrop(s)", cur()->ncostumes);
    else snprintf(lab, sizeof lab, "%d/%d %s", g_sprite + 1, g_prj.nsprites, cur()->name);
    text(lab, 4, SPR_Y + 1, 0.42f, RGB(0xFFFFFF));
    button(160, SPR_Y, 34, SPR_H, g_run_bottom ? "Run:B" : "Run:T", 0x8A55D7, 0);
    button(196, SPR_Y, 22, SPR_H, "<", 0x66666F, 0);
    button(220, SPR_Y, 22, SPR_H, ">", 0x66666F, 0);
    button(244, SPR_Y, 22, SPR_H, "+", 0x2E9E4F, 0);
    button(268, SPR_Y, 22, SPR_H, "-", 0xC0392B, 0);
    button(292, SPR_Y, 26, SPR_H, "Spr", 0x3B7DD8, 0);

    if (g_pk.action != PK_NONE) draw_picker();
    else switch (g_mode) {
    case MODE_SCRIPTS:  draw_bottom_scripts();  break;
    case MODE_COSTUMES: draw_bottom_costumes(); break;
    default:            draw_bottom_sounds();   break;
    }

    static const char *labels[BTN_N] = { "Flag", "Stop", "Save", "Del", "Undo", "Redo", "Dup" };
    static const u32 cols[BTN_N] = { 0x2E9E4F, 0xC0392B, 0x3B7DD8, 0x777777, 0x7A5CC0, 0x7A5CC0, 0x4C8F8F };
    for (int i = 0; i < BTN_N; i++) button(i * BTN_STEP + 1, BTN_Y, BTN_W, BTN_H, labels[i], cols[i], 0);
    text(g_status, 4, 228, 0.38f, RGB(0xDDDDDD));
}

static int ask(const char *hint, const char *init, char *out, size_t outlen)
{
    SwkbdState kb;
    swkbdInit(&kb, SWKBD_TYPE_NORMAL, 2, (int)outlen - 1);
    swkbdSetHintText(&kb, hint);
    swkbdSetInitialText(&kb, init);
    swkbdSetButton(&kb, SWKBD_BUTTON_LEFT, "Cancel", false);
    swkbdSetButton(&kb, SWKBD_BUTTON_RIGHT, "OK", true);
    return swkbdInputText(&kb, out, outlen) == SWKBD_BUTTON_RIGHT;
}

static int ask_numpad(const char *hint, const char *init, char *out, size_t outlen, const char *left_label)
{
    SwkbdState kb;
    swkbdInit(&kb, SWKBD_TYPE_NUMPAD, 2, (int)outlen - 1);
    swkbdSetHintText(&kb, hint);
    swkbdSetInitialText(&kb, init);
    swkbdSetNumpadKeys(&kb, '-', '.');
    swkbdSetButton(&kb, SWKBD_BUTTON_LEFT, left_label, false);
    swkbdSetButton(&kb, SWKBD_BUTTON_RIGHT, "OK", true);
    SwkbdButton b = swkbdInputText(&kb, out, outlen);
    return b == SWKBD_BUTTON_RIGHT ? 1 : (b == SWKBD_BUTTON_LEFT ? 2 : 0);
}

static int ask_slot(char slot, const char *hint, const char *init, char *out, size_t outlen)
{
    if (slot != 'n') return ask(hint, init, out, outlen);
    int r = ask_numpad(hint, init, out, outlen, "Abc");
    if (r == 2) return ask(hint, init, out, outlen);
    return r == 1;
}

static int ask_number(const char *hint, int current, int *value)
{
    char init[TEXT_LEN], buf[TEXT_LEN];
    snprintf(init, sizeof init, "%d", current);
    if (ask_numpad(hint, init, buf, sizeof buf, "Cancel") != 1) return 0;
    *value = atoi(buf);
    return 1;
}

static void select_sprite(int i)
{
    if (i != STAGE_IDX && (i < 0 || i >= g_prj.nsprites)) return;
    g_sprite = i;
    g_script = 0; g_sel = 0; g_scroll = 0;
    focus_reset();
    g_snd = cur()->nsounds > 0 ? 0 : -1;
    if (i == STAGE_IDX && g_mode == MODE_SCRIPTS) g_mode = MODE_COSTUMES;
}

static void sprite_step(int d)
{
    if (g_sprite == STAGE_IDX) select_sprite(d < 0 ? g_prj.nsprites - 1 : 0);
    else select_sprite(g_sprite + d);
}

static ImportEntry g_imp[IMP_MAX_ENTRIES];
static int         g_nimp;
static Sprite      g_imp_sprite;

static void open_sprite_menu(void)
{
    char t[40];
    const Sprite *sp = cur();
    static const char *fixed[SM_COUNT] = { "Rename...", "Duplicate", "Layer back <", "Layer front >", "", "", "", "", "", "Import sprite...", "Import ALL", "New from template..." };
    for (int i = 0; i < SM_COUNT; i++) project_copy_text(g_pk.items[i], fixed[i]);
    snprintf(g_pk.items[SM_X], TEXT_LEN, "x: %d", sp->x);
    snprintf(g_pk.items[SM_Y], TEXT_LEN, "y: %d", sp->y);
    snprintf(g_pk.items[SM_DIR], TEXT_LEN, "Direction: %d", sp->direction);
    snprintf(g_pk.items[SM_SIZE], TEXT_LEN, "Size: %d%%", sp->size > 0 ? sp->size : 100);
    snprintf(g_pk.items[SM_VISIBLE], TEXT_LEN, "Visible: %s", sp->visible ? "yes" : "no");
    snprintf(t, sizeof t, "Sprite: %.24s", sp->name);
    g_pk.action = PK_SPRITE_MENU; g_pk.n = SM_COUNT; g_pk.page = 0; g_pk.slot = 0;
    snprintf(g_pk.title, sizeof g_pk.title, "%s", t);
}

static void import_one(int idx)
{
    char err[96];
    if (g_prj.nsprites >= MAX_SPRITES) { set_status("%s", "Maximum number of sprites reached."); return; }
    if (imp_load_sprite(&g_imp[idx], &g_imp_sprite, err, sizeof err) != 0) { set_status("%s: %s", g_imp[idx].name, err); return; }
    int i = prj_add_imported(&g_prj, &g_imp_sprite);
    if (i < 0) {
        for (int k = 0; k < MAX_SOUNDS; k++) snd_free(&g_imp_sprite.sounds[k]);
        set_status("%s", "Could not add the sprite.");
        return;
    }
    select_sprite(i);
    if (err[0]) set_status("Imported %s (%s)", g_prj.sprites[i].name, err); else set_status("Imported %s", g_prj.sprites[i].name);
}

static void open_import(int all)
{
    g_nimp = imp_scan(IMPORT_DIR, g_imp, IMP_MAX_ENTRIES);
    if (g_nimp == 0) { set_status("%s", "Nothing in sd:/3ds/scratch-editor/sprites/"); return; }
    if (all) {
        int ok = 0, fail = 0;
        for (int i = 0; i < g_nimp && g_prj.nsprites < MAX_SPRITES; i++) {
            char err[96];
            if (imp_load_sprite(&g_imp[i], &g_imp_sprite, err, sizeof err) != 0) { fail++; continue; }
            if (prj_add_imported(&g_prj, &g_imp_sprite) >= 0) { ok++; select_sprite(g_prj.nsprites - 1); }
            else { for (int k = 0; k < MAX_SOUNDS; k++) snd_free(&g_imp_sprite.sounds[k]); fail++; }
        }
        set_status("Imported %d sprite(s)%s", ok, fail ? ", some failed or did not fit" : "");
        return;
    }
    int n = g_nimp < MENU_MAX ? g_nimp : MENU_MAX;
    for (int i = 0; i < n; i++) snprintf(g_pk.items[i], TEXT_LEN, "%s%.20s", g_imp[i].is_dir ? "[+] " : "", g_imp[i].name);
    g_pk.action = PK_IMPORT; g_pk.n = n; g_pk.page = 0; g_pk.slot = 0;
    snprintf(g_pk.title, sizeof g_pk.title, "%s", "Import which sprite?  [+] = folder");
}

static void open_templates(void)
{
    for (int i = 0; i < tpl_count() && i < MENU_MAX; i++) project_copy_text(g_pk.items[i], tpl_name(i));
    g_pk.action = PK_TEMPLATE; g_pk.n = tpl_count(); g_pk.page = 0; g_pk.slot = 0;
    snprintf(g_pk.title, sizeof g_pk.title, "%s", "New from template (replaces project)");
}

static int g_tpl_idx;

static void load_template(int idx)
{
    if (tpl_build(&g_prj, idx) != 0) { set_status("%s", "Could not build the template."); return; }
    undo_clear(&g_undo);
    snprintf(g_name, sizeof g_name, "%s", "project");
    g_sprite = 0; g_mode = MODE_SCRIPTS;
    select_sprite(0);
    rt_reset(&g_rt, &g_prj);
    set_status("Template: %s. %s", tpl_name(idx), tpl_info(idx));
}

static void sprite_menu_choose(int idx)
{
    Sprite *sp = cur();
    char buf[TEXT_LEN];
    int v, reopen = 1;
    switch (idx) {
    case SM_RENAME: if (ask("Sprite name", sp->name, buf, sizeof buf)) prj_rename_sprite(&g_prj, g_sprite, buf); break;
    case SM_DUPLICATE: { int i = prj_duplicate_sprite(&g_prj, g_sprite); if (i < 0) set_status("%s", "Maximum number of sprites reached."); else select_sprite(i); break; }
    case SM_BACK:  undo_clear(&g_undo); g_sprite = prj_move_sprite(&g_prj, g_sprite, -1); break;
    case SM_FRONT: undo_clear(&g_undo); g_sprite = prj_move_sprite(&g_prj, g_sprite, +1); break;
    case SM_X:   if (ask_number("x (-240..240)", sp->x, &v)) sp->x = v < -STAGE_W / 2 ? -STAGE_W / 2 : v > STAGE_W / 2 ? STAGE_W / 2 : v; break;
    case SM_Y:   if (ask_number("y (-180..180)", sp->y, &v)) sp->y = v < -STAGE_H / 2 ? -STAGE_H / 2 : v > STAGE_H / 2 ? STAGE_H / 2 : v; break;
    case SM_DIR: if (ask_number("Direction (90 = right)", sp->direction, &v)) { v %= 360; if (v > 180) v -= 360; if (v <= -180) v += 360; sp->direction = v; } break;
    case SM_SIZE: if (ask_number("Size % (5..500)", sp->size, &v)) sp->size = v < 5 ? 5 : v > 500 ? 500 : v; break;
    case SM_VISIBLE: sp->visible = !sp->visible; break;
    case SM_IMPORT: open_import(0); reopen = 0; break;
    case SM_IMPORT_ALL: open_import(1); reopen = 0; break;
    case SM_TEMPLATES: open_templates(); reopen = 0; break;
    default: reopen = 0; break;
    }
    if (reopen && idx != SM_DUPLICATE) open_sprite_menu();
}

static void clamp_state(void)
{
    if (g_sprite != STAGE_IDX && g_sprite >= g_prj.nsprites) g_sprite = g_prj.nsprites - 1;
    Sprite *sp = cur();
    if (g_sprite == STAGE_IDX) {
        if (g_snd >= sp->nsounds) g_snd = sp->nsounds - 1;
        return;
    }
    if (g_script >= sp->nscripts) g_script = sp->nscripts - 1;
    if (g_sel >= sp->scripts[g_script].nblocks) g_sel = sp->scripts[g_script].nblocks - 1;
    if (g_sel < 0) g_sel = 0;
    if (g_scroll > g_sel) g_scroll = g_sel;
    if (g_snd >= sp->nsounds) g_snd = sp->nsounds - 1;
    if (!focus_node()) focus_reset();
}

static void picker_open(int action, const char *title, char slot, int n)
{
    g_pk.action = action;
    g_pk.n = n;
    g_pk.page = 0;
    g_pk.slot = slot;
    snprintf(g_pk.title, sizeof g_pk.title, "%s", title);
}

static void picker_close(void) { g_pk.action = PK_NONE; }

static void picker_choose(int idx)
{
    int action = g_pk.action;
    char slot = g_pk.slot;
    int last = g_pk.n - 1;
    picker_close();
    switch (action) {
    case PK_ARG: {
        Block *node = focus_node();
        if (!node || g_foc.slot >= block_nslots(node->kind)) return;
        Arg *a = &node->a[g_foc.slot];
        if (slot == 'm' && idx == last) {
            char buf[TEXT_LEN];
            if (ask("Message", a->text, buf, sizeof buf) && buf[0]) { checkpoint(); project_copy_text(a->text, buf); }
        } else { checkpoint(); project_copy_text(a->text, g_pk.items[idx]); }
        break; }
    case PK_DEL_VAR:  prj_delete_var(&g_prj, idx);  set_status("%s", "Variable deleted."); break;
    case PK_DEL_LIST: prj_delete_list(&g_prj, idx); set_status("%s", "List deleted."); break;
    case PK_SPRITE_LIST: select_sprite(idx == g_prj.nsprites ? STAGE_IDX : idx); break;
    case PK_SPRITE_MENU: sprite_menu_choose(idx); break;
    case PK_IMPORT: if (idx < g_nimp) import_one(idx); break;
    case PK_FX: {
        int i = prj_add_effect(&g_prj, g_sprite, idx);
        if (i < 0) { set_status("%s", "Maximum number of sounds reached."); break; }
        g_snd = i;
        audio_play(&cur()->sounds[i], 100);
        set_status("Added %s.", cur()->sounds[i].name);
        break; }
    case PK_TEMPLATE:
        g_tpl_idx = idx;
        project_copy_text(g_pk.items[0], "Yes: replace the project");
        project_copy_text(g_pk.items[1], "No: keep working");
        picker_open(PK_TEMPLATE_OK, "Unsaved work will be lost. Continue?", 0, 2);
        break;
    case PK_TEMPLATE_OK: if (idx == 0) load_template(g_tpl_idx); break;
    default: break;
    }
}

static const char *slot_hint(char slot)
{
    switch (slot) {
    case 'n': return "Number";
    case 's': return "Text";
    default:  return "Value";
    }
}

static void open_arg_menu(char sl)
{
    int n = prj_menu_items(&g_prj, g_sprite, sl, g_pk.items, MENU_MAX);
    if (n == 0) {
        set_status("%s", sl == 'v' ? "No variables yet: Var tab, + New variable."
                       : sl == 'l' ? "No lists yet: List tab, + New list."
                       : sl == 'o' ? "This sprite has no sounds (Sounds tab)." : "Nothing to choose.");
        return;
    }
    picker_open(PK_ARG, "Choose a value", sl, n);
}

static void edit_focused(void)
{
    Block *node = focus_node();
    if (!node) return;
    if (g_foc.slot >= block_nslots(node->kind)) { set_status("%s", "This block has no argument."); return; }
    Arg *a = &node->a[g_foc.slot];
    char sl = focus_slot_char(node, g_foc.slot);
    if (a->expr >= 0) {
        if (g_foc.depth >= MAX_EXPR - 1) return;
        g_foc.path[g_foc.depth++] = g_foc.slot;
        g_foc.slot = 0;
        return;
    }
    if (sl == 'b') { set_status("%s", "Needs a <boolean> block: pick one from Sens/Ops."); return; }
    if (slot_is_text(sl)) {
        char buf[TEXT_LEN];
        if (ask_slot(sl, slot_hint(sl), a->text, buf, sizeof buf)) { checkpoint(); project_copy_text(a->text, buf); }
        return;
    }
    if (sl == 'x' && (node->kind == BK_TOUCHING_COLOR || node->kind == BK_COLOR_SEES)) {
        g_bs = BS_PICK;
        set_status("%s", "Tap a colour on the stage. List = colour menu.");
        return;
    }
    open_arg_menu(sl);
}

static void focus_up(void)
{
    if (g_foc.depth > 0) { g_foc.depth--; g_foc.slot = g_foc.path[g_foc.depth]; }
}

static void focus_move(int d)
{
    Block *node = focus_node();
    if (!node) return;
    int ns = block_nslots(node->kind), s = g_foc.slot + d;
    if (d > 0 && s >= ns && ns > 0) s = 0;
    if (s >= 0 && s < ns) g_foc.slot = s;
}

static void plug_reporter(int kind, const char *param)
{
    Block *node = focus_node();
    if (!node || block_nslots(node->kind) == 0) { set_status("%s", "Select a block with an argument box first."); return; }
    checkpoint();
    int rc = prj_plug(&g_prj, g_sprite, cur_script(), node, g_foc.slot, (BlockKind)kind, param);
    if (rc != 0) undo_discard(&g_undo);
    switch (rc) {
    case 0:
        if (block_nslots(kind) > 0 && g_foc.depth < MAX_EXPR - 1) {
            g_foc.path[g_foc.depth++] = g_foc.slot;
            g_foc.slot = 0;
        }
        set_status("%s", "Plugged in. ^ goes back up.");
        break;
    case -2: set_status("%s", "Too many reporters in this script."); break;
    case -3: set_status("%s", "That slot needs a <boolean> block."); break;
    default: set_status("%s", "Can't plug that here."); break;
    }
}

static void add_from_palette(const PalEntry *e)
{
    char buf[TEXT_LEN];
    switch (e->kind) {
    case PE_NEW_VAR:
        if (ask("Variable name", "", buf, sizeof buf) && buf[0]) {
            if (prj_add_var(&g_prj, buf) < 0) set_status("%s", "Too many variables."); else set_status("Variable %s created.", buf);
        }
        return;
    case PE_NEW_LIST:
        if (ask("List name", "", buf, sizeof buf) && buf[0]) {
            if (prj_add_list(&g_prj, buf) < 0) set_status("%s", "Too many lists."); else set_status("List %s created.", buf);
        }
        return;
    case PE_DEL_VAR:
    case PE_DEL_LIST: {
        int isvar = e->kind == PE_DEL_VAR;
        int n = isvar ? g_prj.nvars : g_prj.nlists;
        if (n == 0) { set_status("%s", "Nothing to delete."); return; }
        for (int i = 0; i < n; i++) project_copy_text(g_pk.items[i], isvar ? g_prj.vars[i].name : g_prj.lists[i].name);
        picker_open(isvar ? PK_DEL_VAR : PK_DEL_LIST, isvar ? "Delete which variable?" : "Delete which list?", 0, n);
        return; }
    default: break;
    }
    BlockKind kind = (BlockKind)e->kind;
    if (block_is_hat(kind)) {
        checkpoint();
        int s = prj_new_script(&g_prj, g_sprite, kind);
        if (s < 0) { undo_discard(&g_undo); set_status("%s", "Maximum number of scripts reached."); return; }
        g_script = s; g_sel = 0; g_scroll = 0;
        focus_reset();
        return;
    }
    if (block_is_reporter(kind)) { plug_reporter(kind, kind == BK_VAR ? g_prj.vars[e->param].name : NULL); return; }
    checkpoint();
    int at = prj_insert_block(&g_prj, g_sprite, g_script, g_sel, kind);
    if (at < 0) { undo_discard(&g_undo); set_status("%s", "Script is full."); return; }
    g_sel = -1;
    select_block(at);
}

static void plug_into_row(int row, int kind, const char *param)
{
    select_block(row);
    Script *sc = cur_script();
    int ns = block_nslots(sc->blocks[row].kind);
    if (ns == 0) { set_status("%s", "That block has no argument box."); return; }
    int want_bool = BLOCK_INFO[kind].shape == SH_BOOL;
    checkpoint();
    for (int pass = 0; pass < 2; pass++)
        for (int k = 0; k < ns; k++) {
            int is_bool = BLOCK_INFO[sc->blocks[row].kind].slots[k] == 'b';
            if (pass == 0 && is_bool != want_bool) continue;
            if (prj_plug(&g_prj, g_sprite, sc, &sc->blocks[row], k, (BlockKind)kind, param) == 0) {
                g_foc.depth = 0;
                g_foc.slot = k;
                if (block_nslots(kind) > 0) { g_foc.path[g_foc.depth++] = k; g_foc.slot = 0; }
                set_status("%s", "Plugged in. ^ goes back up.");
                return;
            }
        }
    undo_discard(&g_undo);
    set_status("%s", "No free slot accepts that block.");
}

static void handle_touch(int x, int y);

static void drag_begin(int x, int y)
{
    memset(&g_drag, 0, sizeof g_drag);
    if (g_mode == MODE_SCRIPTS && g_pk.action == PK_NONE && !g_recording && !g_play && g_sprite != STAGE_IDX) {
        PalEntry pe[PAL_MAX];
        int n = palette_entries(g_cat, pe);
        if (hit(x, y, PAL_X, PAL_Y, PAL_W, PAL_ROWS * PAL_ROW)) {
            int i = g_pal_scroll + (y - PAL_Y) / PAL_ROW;
            if (i < n && pe[i].kind >= 0) {
                g_drag.src = 1; g_drag.pe = pe[i];
                palette_label(&pe[i], g_drag.label, sizeof g_drag.label);
                g_drag.color = RGB(palette_color(&pe[i]));
            }
        } else if (hit(x, y, SCR_X, SCR_Y, SCRBTN_X - SCR_X, SCR_ROWS * SCR_ROW)) {
            const Script *sc = cur_script();
            int b = g_scroll + (y - SCR_Y) / SCR_ROW;
            if (b >= 1 && b < sc->nblocks) {
                int sh = BLOCK_INFO[sc->blocks[b].kind].shape;
                if (sh != SH_END && sh != SH_ELSE && sh != SH_HAT) {
                    g_drag.src = 2; g_drag.block = b;
                    prj_format_block(sc, &sc->blocks[b], g_drag.label, sizeof g_drag.label);
                    g_drag.color = RGB(category_color(BLOCK_INFO[sc->blocks[b].kind].category));
                }
            }
        }
    }
    if (!g_drag.src) { handle_touch(x, y); return; }
    g_drag.sx = g_drag.x = x;
    g_drag.sy = g_drag.y = y;
}

static void drag_move(int x, int y)
{
    if (!g_drag.src) return;
    g_drag.x = x; g_drag.y = y;
    if (!g_drag.active && (x - g_drag.sx) * (x - g_drag.sx) + (y - g_drag.sy) * (y - g_drag.sy) > DRAG_THRESHOLD * DRAG_THRESHOLD) g_drag.active = 1;
    if (g_drag.active && x >= SCR_X) {
        static int tick;
        if (++tick % 6 == 0) {
            if (y < SCR_Y + 8 && g_scroll > 0) g_scroll--;
            else if (y > SCR_Y + SCR_ROWS * SCR_ROW - 8 && g_scroll + SCR_ROWS < cur_script()->nblocks) g_scroll++;
        }
    }
}

static void drag_end(void)
{
    if (!g_drag.src) return;
    Drag d = g_drag;
    memset(&g_drag, 0, sizeof g_drag);
    if (!d.active) { handle_touch(d.sx, d.sy); return; }
    int in_script = d.x >= SCR_X - 4 && d.y >= SCR_Y - 4 && d.y < SCR_Y + SCR_ROWS * SCR_ROW + 4;
    if (d.src == 2) {
        if (hit(d.x, d.y, PAL_X, PAL_Y, PAL_W, PAL_ROWS * PAL_ROW)) {
            checkpoint();
            if (prj_delete_block(&g_prj, g_sprite, g_script, d.block) < 0) { undo_discard(&g_undo); set_status("%s", "Can't delete that block."); }
            else { focus_reset(); set_status("%s", "Block deleted."); }
            clamp_state();
        } else if (in_script) {
            checkpoint();
            int r = prj_move_block(&g_prj, g_sprite, g_script, d.block, gap_after(script_gap(d.y)));
            if (r < 0) { undo_discard(&g_undo); set_status("%s", "Can't drop a block inside itself."); }
            else { g_sel = -1; select_block(r); }
        }
        return;
    }
    int kind = d.pe.kind;
    if (block_is_reporter(kind)) {
        const char *param = kind == BK_VAR ? g_prj.vars[d.pe.param].name : NULL;
        for (int i = 0; i < MAX_ARGS; i++)
            if (hit(d.x, d.y, ARG_X + i * ARG_STEP, ARG_Y, ARG_W, ARG_H)) {
                Block *node = focus_node();
                if (!node || i >= block_nslots(node->kind)) return;
                g_foc.slot = i;
                plug_reporter(kind, param);
                return;
            }
        if (in_script) {
            int row = g_scroll + (d.y - SCR_Y) / SCR_ROW;
            if (row >= 0 && row < cur_script()->nblocks) plug_into_row(row, kind, param);
        }
        return;
    }
    if (block_is_hat(kind)) { if (in_script) add_from_palette(&d.pe); return; }
    if (!in_script) return;
    checkpoint();
    int at = prj_insert_block(&g_prj, g_sprite, g_script, gap_after(script_gap(d.y)), (BlockKind)kind);
    if (at < 0) { undo_discard(&g_undo); set_status("%s", "Script is full."); return; }
    g_sel = -1;
    select_block(at);
}

static void select_script(int delta)
{
    int n = g_script + delta;
    if (n < 0 || n >= cur()->nscripts) return;
    g_script = n; g_sel = 0; g_scroll = 0;
    focus_reset();
}

static void touch_scripts(int x, int y)
{
    for (int c = 0; c < CAT_COUNT; c++)
        if (hit(x, y, 2 + c * CAT_STEP, CAT_Y, CAT_W, CAT_H)) { g_cat = c; g_pal_scroll = 0; return; }

    PalEntry pe[PAL_MAX];
    int n = palette_entries(g_cat, pe);
    if (hit(x, y, PAL_X, PAL_Y, PAL_W, PAL_ROWS * PAL_ROW)) {
        int i = g_pal_scroll + (y - PAL_Y) / PAL_ROW;
        if (i < n) add_from_palette(&pe[i]);
        return;
    }
    if (hit(x, y, PAL_X, PALBTN_Y, 58, PALBTN_H)) { g_pal_scroll -= PAL_ROWS - 1; if (g_pal_scroll < 0) g_pal_scroll = 0; return; }
    if (hit(x, y, PAL_X + 62, PALBTN_Y, 58, PALBTN_H)) {
        if (g_pal_scroll + PAL_ROWS < n) g_pal_scroll += PAL_ROWS - 1;
        return;
    }
    if (hit(x, y, PAL_X, SCRNAV_Y, 17, SCRNAV_H)) { select_script(-1); return; }
    if (hit(x, y, PAL_X + 19, SCRNAV_Y, 17, SCRNAV_H)) { select_script(+1); return; }
    if (hit(x, y, PAL_X + 70, SCRNAV_Y, 24, SCRNAV_H)) { script_jump(0); return; }
    if (hit(x, y, PAL_X + 96, SCRNAV_Y, 24, SCRNAV_H)) { script_jump(1); return; }

    if (hit(x, y, SCRBTN_X, SCR_Y, SCRBTN_W, SCRBTN_H)) { script_page(-1); return; }
    if (hit(x, y, SCRBTN_X, SCR_Y + SCRBTN_H + SCRBTN_GAP, SCRBTN_W, SCRBTN_H)) { script_page(+1); return; }
    if (hit(x, y, SCR_X, SCR_Y, SCRBTN_X - SCR_X, SCR_ROWS * SCR_ROW)) {
        int b = g_scroll + (y - SCR_Y) / SCR_ROW;
        if (b < cur_script()->nblocks) select_block(b);
        return;
    }
    if (hit(x, y, SCR_X, ARG_Y, ARG_UP_W, ARG_H)) { focus_up(); return; }
    for (int i = 0; i < MAX_ARGS; i++)
        if (hit(x, y, ARG_X + i * ARG_STEP, ARG_Y, ARG_W, ARG_H)) {
            Block *node = focus_node();
            if (!node || i >= block_nslots(node->kind)) return;
            if (i != g_foc.slot) g_foc.slot = i; else edit_focused();
            return;
        }
}

static void bs_toggle_move(void)
{
    if (g_bs) { g_bs = BS_OFF; return; }
    if (g_sprite == STAGE_IDX) { set_status("%s", "Pick a sprite (name) to move it on the stage."); return; }
    g_bs = BS_MOVE;
    set_status("%s", "Drag on the stage to move the sprite. D-pad up / B = back.");
}

static void bs_touch(int x, int y, int pressed)
{
    float sx = (float)x / PAD_S - STAGE_W / 2.0f, sy = STAGE_H / 2.0f - (float)y / PAD_S;
    if (g_bs == BS_PICK) {
        if (!pressed) return;
        if (hit(x, y, 2, BS_BTN_Y, 36, 16)) { g_bs = BS_OFF; Block *n = focus_node(); if (n) open_arg_menu(focus_slot_char(n, g_foc.slot)); return; }
        if (hit(x, y, 40, BS_BTN_Y, 48, 16)) { g_bs = BS_OFF; set_status("%s", "Cancelled."); return; }
        int idx = rt_pixel_at(&g_rt, &g_prj, sx, sy);
        Block *n = focus_node();
        if (idx <= 0) { set_status("%s", "Nothing there (white). Tap a coloured pixel, or use List."); return; }
        if (!n || g_foc.slot >= block_nslots(n->kind)) { g_bs = BS_OFF; return; }
        checkpoint();
        project_copy_text(n->a[g_foc.slot].text, PALETTE_NAMES[idx]);
        set_status("Picked %s.", PALETTE_NAMES[idx]);
        g_bs = BS_OFF;
        return;
    }
    if (g_bs == BS_MOVE) {
        if (hit(x, y, 2, BS_BTN_Y, 44, 16)) { if (pressed) g_bs = BS_OFF; return; }
        if (g_sprite == STAGE_IDX) return;
        float hx = STAGE_W / 2.0f, hy = STAGE_H / 2.0f;
        g_prj.sprites[g_sprite].x = (int)lroundf(sx < -hx ? -hx : (sx > hx ? hx : sx));
        g_prj.sprites[g_sprite].y = (int)lroundf(sy < -hy ? -hy : (sy > hy ? hy : sy));
    }
}

static void costume_nav(int d)
{
    Sprite *sp = cur();
    int n = sp->cur_costume + d;
    if (n >= 0 && n < sp->ncostumes) sp->cur_costume = n;
}

static void touch_costumes(int x, int y)
{
    Sprite *sp = cur();
    Costume *c = &sp->costumes[sp->cur_costume];
    for (int i = 0; i < PAL_N; i++)
        if (hit(x, y, 172 + (i / 8) * 20, 36 + (i % 8) * 20, 18, 18)) { g_color = i; return; }
    for (int i = 0; i < 6; i++)
        if (hit(x, y, 214 + (i % 2) * 52, 36 + (i / 2) * 22, 50, 20)) {
            char buf[TEXT_LEN];
            switch (i) {
            case 0: g_tool = 0; break;
            case 1: g_tool = 1; break;
            case 2: costume_flip_h(c); break;
            case 3: costume_clear(c); break;
            case 4:
                if (prj_add_costume(&g_prj, g_sprite) < 0) set_status("%s", "Maximum number of costumes reached.");
                else set_status("%s", "New costume = copy of the previous one.");
                break;
            case 5:
                if (ask("Costume name", c->name, buf, sizeof buf) && buf[0]) {
                    if (prj_rename_costume(&g_prj, g_sprite, sp->cur_costume, buf) < 0) set_status("%s", "Name already used.");
                }
                break;
            }
            return;
        }
    if (hit(x, y, 214, 102, 50, 20)) costume_nav(-1);
    else if (hit(x, y, 266, 102, 50, 20)) costume_nav(+1);
}

static void paint_canvas(int x, int y, int pressed)
{
    int cx = (x - CV_X) / CV_CELL, cy = (y - CV_Y) / CV_CELL;
    if (x < CV_X || y < CV_Y || cx >= COSTUME_W || cy >= COSTUME_H) return;
    Costume *c = &cur()->costumes[cur()->cur_costume];
    if (g_tool == 0) c->px[cy * COSTUME_W + cx] = (uint8_t)g_color;
    else if (pressed) costume_fill(c, cx, cy, (uint8_t)g_color);
}

static void rec_finish(void)
{
    mic_stop();
    g_recording = 0;
    if (g_rec.n < REC_RATE / 20) { set_status("%s", "Too short: nothing recorded."); return; }
    int i = prj_add_recording(&g_prj, g_sprite, g_rec.buf, g_rec.n, REC_RATE);
    if (i < 0) { set_status("%s", "Maximum number of sounds reached."); return; }
    g_snd = i;
    char msg[64];
    snprintf(msg, sizeof msg, "Recorded %.1f s. Use Trim / Normalize.", (float)g_rec.n / REC_RATE);
    set_status("%s", msg);
}

static void rec_toggle(void)
{
    if (g_recording) { rec_finish(); return; }
    if (!g_mic_ok) { set_status("%s", "Microphone not available."); return; }
    if (cur()->nsounds >= MAX_SOUNDS) { set_status("%s", "Maximum number of sounds reached."); return; }
    if (mic_start(0) != 0) { set_status("%s", "Could not start the microphone."); return; }
    g_recording = 1;
    set_status("%s", "Recording... tap Stop when done.");
}

static void touch_sounds(int x, int y)
{
    Sprite *sp = cur();
    if (hit(x, y, 2, SN_REC_Y, 146, 22)) { rec_toggle(); return; }
    if (g_recording) return;
    if (hit(x, y, 156, SN_REC_Y, 160, 22)) {
        for (int i = 0; i < SND_PRESET_COUNT; i++) project_copy_text(g_pk.items[i], SND_PRESET_NAMES[i]);
        picker_open(PK_FX, "Add a sound effect", 0, SND_PRESET_COUNT);
        return;
    }
    for (int i = 0; i < sp->nsounds; i++)
        if (hit(x, y, 2, SN_LIST_Y + i * SN_ROW, 148, 18)) { g_snd = i; return; }
    if (hit(x, y, 2, SN_BTN_Y, 46, 18)) {
        int i = prj_add_sound(&g_prj, g_sprite);
        if (i < 0) set_status("%s", "Maximum number of sounds reached."); else g_snd = i;
        return;
    }
    if (g_snd < 0 || g_snd >= sp->nsounds) return;
    Sound *s = &sp->sounds[g_snd];
    if (hit(x, y, 52, SN_BTN_Y, 46, 18)) { audio_play(s, 100); return; }
    if (hit(x, y, 102, SN_BTN_Y, 46, 18)) {
        char buf[TEXT_LEN];
        if (ask("Sound name", s->name, buf, sizeof buf) && buf[0]) {
            if (prj_rename_sound(&g_prj, g_sprite, g_snd, buf) < 0) set_status("%s", "Name already used.");
        }
        return;
    }
    if (snd_is_recorded(s)) {
        for (int k = 0; k < 3; k++)
            if (hit(x, y, 156, 36 + k * 28, 160, 24)) {
                int rc = k == 0 ? snd_trim(s) : (k == 1 ? snd_normalize(s) : snd_reverse(s));
                set_status("%s", rc == 0 ? (k == 0 ? "Trimmed." : (k == 1 ? "Normalized." : "Reversed.")) : "Nothing to do (silent?).");
                return;
            }
        int yy = 36 + 3 * 28;
        if (hit(x, y, 262, yy, 26, 24) || hit(x, y, 290, yy, 26, 24)) {
            s->vol += hit(x, y, 290, yy, 26, 24) ? 10 : -10;
            snd_clamp(s);
            if (s->vol == 0 && s->npcm) s->vol = 0;
        }
        return;
    }
    for (int k = 0; k < 4; k++) {
        float yy = 36 + k * 28;
        int dec = hit(x, y, 262, (int)yy, 26, 24), inc = hit(x, y, 290, (int)yy, 26, 24);
        int lab = hit(x, y, 156, (int)yy, 102, 24);
        if (!dec && !inc && !lab) continue;
        int dir = inc ? +1 : -1;
        switch (k) {
        case 0: if (dec || inc) s->wave += dir; else s->wave = (s->wave + 1) % WAVE_COUNT; break;
        case 1:
            if (lab) { int v; if (ask_number("Frequency (Hz)", s->freq, &v)) s->freq = v; }
            else { int f = (int)lroundf((float)s->freq * (inc ? 1.0595f : 1.0f / 1.0595f)); s->freq = (f == s->freq) ? s->freq + dir : f; }
            break;
        case 2:
            if (lab) { int v; if (ask_number("Duration (ms)", s->ms, &v)) s->ms = v; }
            else s->ms += dir * 50;
            break;
        default:
            if (lab) { int v; if (ask_number("Volume (0-100)", s->vol, &v)) s->vol = v; }
            else s->vol += dir * 10;
            break;
        }
        snd_clamp(s);
        return;
    }
}

static void sanitize(char *s)
{
    for (; *s; s++)
        if (!((*s >= '0' && *s <= '9') || (*s >= 'a' && *s <= 'z') || (*s >= 'A' && *s <= 'Z') ||
              *s == '-' || *s == '_' || *s == ' '))
            *s = '_';
}

static void save_settings(void)
{
    mkdir("sdmc:/3ds", 0777);
    mkdir(SAVE_DIR, 0777);
    FILE *f = fopen(SAVE_DIR "/settings.txt", "w");
    if (!f) return;
    fprintf(f, "run_screen=%s\n", g_run_bottom ? "bottom" : "top");
    fclose(f);
}

static void load_settings(void)
{
    FILE *f = fopen(SAVE_DIR "/settings.txt", "r");
    if (!f) return;
    char line[64];
    while (fgets(line, sizeof line, f)) if (!strncmp(line, "run_screen=", 11)) g_run_bottom = !strncmp(line + 11, "bottom", 6);
    fclose(f);
}

static void save_project(void)
{
    char buf[TEXT_LEN], init[TEXT_LEN];
    snprintf(init, sizeof init, "%s", g_name);
    if (!ask("File name (without .sb3)", init, buf, sizeof buf) || !buf[0]) return;
    sanitize(buf);
    snprintf(g_name, sizeof g_name, "%s", buf);

    mkdir("sdmc:/3ds", 0777);
    mkdir(SAVE_DIR, 0777);
    mkdir(IMPORT_DIR, 0777);
    char path[128];
    snprintf(path, sizeof path, SAVE_DIR "/%s.sb3", g_name);
    if (sb3_write_project(&g_prj, path) == 0) set_status("Saved %s", path + 5);
    else set_status("%s", "ERROR: could not write the file.");
}

static void start_play(void)
{
    g_bs = BS_OFF;
    if (g_recording) rec_finish();
    picker_close();
    if (g_sprite == STAGE_IDX) { select_sprite(0); g_mode = MODE_SCRIPTS; }
    rt_green_flag(&g_rt, &g_prj);
    g_play = 1;
    g_monitoring = (mic_start(1) == 0);
    set_status("%s", g_monitoring ? "Playing (mic on): D-pad/A = keys, B = stop." : "Playing: D-pad/A = keys, B = stop.");
}

static void stop_play(void)
{
    rt_stop(&g_rt);
    if (g_monitoring) mic_stop();
    g_monitoring = 0;
    g_play = 0;
    audio_stop_all();
    set_status("%s", "Stopped.");
}

static void do_delete(void)
{
    if (g_mode == MODE_ABOUT) return;
    Sprite *sp = cur();
    switch (g_mode) {
    case MODE_SCRIPTS: {
        Block *node = focus_node();
        checkpoint();
        if (node && g_foc.slot < block_nslots(node->kind) && node->a[g_foc.slot].expr >= 0) {
            prj_unplug(cur_script(), node, g_foc.slot);
            break;
        }
        if (g_foc.depth > 0) {
            int slot = g_foc.path[g_foc.depth - 1];
            focus_up();
            Block *parent = focus_node();
            if (parent) prj_unplug(cur_script(), parent, slot);
            break;
        }
        if (g_sel == 0) {
            if (prj_delete_script(&g_prj, g_sprite, g_script) == 0) { g_sel = 0; g_scroll = 0; focus_reset(); }
            else { undo_discard(&g_undo); set_status("%s", "Can't delete the only script."); }
        } else if (prj_delete_block(&g_prj, g_sprite, g_script, g_sel) < 0) {
            undo_discard(&g_undo);
            set_status("%s", "Select the C block itself (if / forever...) to delete it.");
        } else focus_reset();
        break; }
    case MODE_COSTUMES:
        if (prj_delete_costume(&g_prj, g_sprite, sp->cur_costume) < 0) set_status("%s", "A sprite needs at least one costume.");
        break;
    default:
        if (g_snd >= 0 && prj_delete_sound(&g_prj, g_sprite, g_snd) == 0 && g_snd >= sp->nsounds) g_snd = sp->nsounds - 1;
        break;
    }
    clamp_state();
}

static void do_undo(int redo)
{
    if (g_mode != MODE_SCRIPTS) { set_status("%s", "Undo / redo work on scripts (Scripts tab)."); return; }
    int sp = redo ? undo_redo(&g_undo, &g_prj) : undo_undo(&g_undo, &g_prj);
    if (sp < 0) { set_status("%s", redo ? "Nothing to redo." : "Nothing to undo."); return; }
    if (sp != g_sprite) select_sprite(sp);
    focus_reset();
    clamp_state();
    set_status("%s", redo ? "Redone." : "Undone.");
}

static void do_duplicate(void)
{
    if (g_mode == MODE_ABOUT) return;
    switch (g_mode) {
    case MODE_SCRIPTS: {
        if (g_sprite == STAGE_IDX) return;
        checkpoint();
        if (g_sel == 0) {
            int n = prj_duplicate_script(&g_prj, g_sprite, g_script);
            if (n < 0) { undo_discard(&g_undo); set_status("%s", "Maximum number of scripts reached."); return; }
            g_script = n; g_sel = 0; g_scroll = 0;
            focus_reset();
            set_status("%s", "Script duplicated.");
        } else {
            int n = prj_duplicate_block(&g_prj, g_sprite, g_script, g_sel);
            if (n == -2) { undo_discard(&g_undo); set_status("%s", "Too many reporters in this script to copy it."); return; }
            if (n < 0) { undo_discard(&g_undo); set_status("%s", "Select a block (not its end / else marker) with room left in the script."); return; }
            g_sel = -1;
            select_block(n);
            set_status("%s", "Block duplicated.");
        }
        break; }
    case MODE_COSTUMES:
        if (prj_add_costume(&g_prj, g_sprite) < 0) set_status("%s", "Maximum number of costumes reached.");
        else set_status("%s", "Costume duplicated.");
        break;
    default: {
        int i = g_snd >= 0 ? prj_duplicate_sound(&g_prj, g_sprite, g_snd) : -1;
        if (i < 0) set_status("%s", g_snd < 0 ? "Select a sound first." : "Maximum number of sounds reached.");
        else { g_snd = i; set_status("%s", "Sound duplicated."); }
        break; }
    }
}

static void about_scroll(int d)
{
    int max = ABOUT_N - ABOUT_ROWS;
    g_about_scroll += d;
    if (g_about_scroll > max) g_about_scroll = max;
    if (g_about_scroll < 0) g_about_scroll = 0;
}

static void touch_about(int x, int y)
{
    if (hit(x, y, 294, 20, 24, 40)) about_scroll(-5);
    else if (hit(x, y, 294, 162, 24, 40)) about_scroll(+5);
}

static void touch_picker(int x, int y)
{
    if (hit(x, y, 2, PK_NAV_Y, 100, 18)) { if (g_pk.page > 0) g_pk.page--; return; }
    if (hit(x, y, 110, PK_NAV_Y, 100, 18)) { picker_close(); return; }
    if (hit(x, y, 218, PK_NAV_Y, 100, 18)) { if ((g_pk.page + 1) * PK_PER_PAGE < g_pk.n) g_pk.page++; return; }
    for (int i = 0; i < PK_PER_PAGE; i++) {
        int col = i / PK_ROWS, row = i % PK_ROWS, idx = g_pk.page * PK_PER_PAGE + i;
        if (idx < g_pk.n && hit(x, y, 2 + col * PK_COLSTEP, PK_Y + row * PK_ROW, PK_COLW, PK_ROW - 2)) { picker_choose(idx); return; }
    }
}

static void handle_touch(int x, int y)
{
    if (g_play) return;
    if (y < TAB_H) {
        for (int m = 0; m < MODE_COUNT; m++) if (hit(x, y, 1 + m * 70, 0, 68, TAB_H)) {
            if (m == MODE_SCRIPTS && g_sprite == STAGE_IDX) set_status("%s", "The Stage has no scripts: pick a sprite (name) to edit scripts.");
            else g_mode = m;
        }
        if (g_mode == MODE_SOUNDS && g_snd < 0 && cur()->nsounds > 0) g_snd = 0;
        picker_close();
        return;
    }
    if (g_mode != MODE_ABOUT && hit(x, y, 0, SPR_Y, 320, SPR_H)) {
        picker_close();
        if (g_recording) return;
        if (hit(x, y, 160, SPR_Y, 34, SPR_H)) {
            g_run_bottom = !g_run_bottom;
            save_settings();
            set_status("%s", g_run_bottom ? "Projects run on the BOTTOM screen (touch = stage)." : "Projects run on the TOP screen (bottom = touch pad).");
        } else if (hit(x, y, 0, SPR_Y, 158, SPR_H)) {
            for (int i = 0; i < g_prj.nsprites; i++) {
                char tmp[48];
                snprintf(tmp, sizeof tmp, "%d %.20s", i + 1, g_prj.sprites[i].name);
                project_copy_text(g_pk.items[i], tmp);
            }
            project_copy_text(g_pk.items[g_prj.nsprites], "Stage (backdrops)");
            g_pk.action = PK_SPRITE_LIST; g_pk.n = g_prj.nsprites + 1; g_pk.page = 0; g_pk.slot = 0;
            snprintf(g_pk.title, sizeof g_pk.title, "%s", "Go to sprite or Stage");
        } else if (hit(x, y, 196, SPR_Y, 22, SPR_H)) sprite_step(-1);
        else if (hit(x, y, 220, SPR_Y, 22, SPR_H)) sprite_step(+1);
        else if (hit(x, y, 244, SPR_Y, 22, SPR_H)) {
            int i = prj_add_sprite(&g_prj);
            if (i < 0) set_status("%s", "Maximum number of sprites reached."); else select_sprite(i);
        } else if (hit(x, y, 268, SPR_Y, 22, SPR_H)) {
            if (g_sprite == STAGE_IDX) set_status("%s", "The Stage can't be deleted (use Delete in Costumes for a backdrop).");
            else if (prj_delete_sprite(&g_prj, g_sprite) == 0) { undo_clear(&g_undo); select_sprite(g_sprite < g_prj.nsprites ? g_sprite : g_prj.nsprites - 1); }
            else set_status("%s", "A project needs at least one sprite.");
        } else if (hit(x, y, 292, SPR_Y, 26, SPR_H)) {
            if (g_sprite == STAGE_IDX) set_status("%s", "Stage: draw backdrops in Costumes; the selected one is shown.");
            else open_sprite_menu();
        }
        return;
    }
    if (hit(x, y, 0, BTN_Y, 320, BTN_H)) {
        picker_close();
        switch (x / BTN_STEP) {
        case 0: start_play(); break;
        case 1: stop_play(); break;
        case 2: save_project(); break;
        case 3: if (!g_recording) do_delete(); break;
        case 4: if (!g_recording) do_undo(0); break;
        case 5: if (!g_recording) do_undo(1); break;
        default: if (!g_recording) do_duplicate(); break;
        }
        return;
    }
    if (g_pk.action != PK_NONE) { touch_picker(x, y); return; }
    switch (g_mode) {
    case MODE_SCRIPTS:  touch_scripts(x, y);  break;
    case MODE_COSTUMES: touch_costumes(x, y); break;
    case MODE_ABOUT:    touch_about(x, y);    break;
    default:            touch_sounds(x, y);   break;
    }
}

static void play_pointer(int x, int y, int down, int pressed)
{
    float sx = (float)x / PAD_S - STAGE_W / 2.0f, sy = STAGE_H / 2.0f - (float)y / PAD_S;
    rt_pointer(&g_rt, sx, sy, down);
    if (pressed) rt_click(&g_rt, &g_prj, sx, sy);
}

static void play_audio_events(void)
{
    SoundEvt ev;
    while (rt_pop_sound(&g_rt, &ev)) {
        if (ev.sound == SND_STOP) audio_stop_all();
        else if (ev.sound == SND_TONE) audio_tone(ev.freq, ev.ms, ev.wave, ev.vol);
        else if (ev.sound >= 0 && ev.sound < g_prj.sprites[ev.sprite].nsounds) audio_play(&g_prj.sprites[ev.sprite].sounds[ev.sound], ev.vol);
    }
}

static void play_ask(void)
{
    const char *prompt = rt_ask_pending(&g_rt);
    if (!prompt) return;
    char buf[TEXT_LEN];
    if (!ask(prompt, "", buf, sizeof buf)) buf[0] = 0;
    rt_answer(&g_rt, buf);
}

int main(void)
{
    gfxInitDefault();
    {
        bool is_new = false;
        if (R_SUCCEEDED(APT_CheckNew3DS(&is_new)) && is_new) { osSetSpeedupEnable(true); g_new3ds = 1; }
    }
    C3D_Init(C3D_DEFAULT_CMDBUF_SIZE);
    C2D_Init(C2D_DEFAULT_MAX_OBJECTS * 4);
    C2D_Prepare();
    C3D_RenderTarget *top = C2D_CreateScreenTarget(GFX_TOP, GFX_LEFT);
    C3D_RenderTarget *bot = C2D_CreateScreenTarget(GFX_BOTTOM, GFX_LEFT);
    g_text = C2D_TextBufNew(4096);
    audio_init();
    mic_init();
    load_settings();
    if (!g_audio_ok) audio_explain();
    mkdir("sdmc:/3ds", 0777);
    mkdir(SAVE_DIR, 0777);
    mkdir(IMPORT_DIR, 0777);

    prj_init(&g_prj);
    rt_reset(&g_rt, &g_prj);

    int frame_no = 0;
    while (aptMainLoop()) {
        hidScanInput();
        u32 kd = hidKeysDown(), kh = hidKeysHeld();
        if (kd & KEY_SELECT) break;

        touchPosition tp;
        hidTouchRead(&tp);
        if (g_play) {
            if (kh & KEY_TOUCH) play_pointer(tp.px, tp.py, 1, (kd & KEY_TOUCH) != 0);
            else g_rt.mouse_down = 0;
        } else if (g_bs && g_pk.action == PK_NONE) {
            if (kh & KEY_TOUCH) bs_touch(tp.px, tp.py, (kd & KEY_TOUCH) != 0);
        } else {
            if (kd & KEY_TOUCH) drag_begin(tp.px, tp.py);
            else if (kh & KEY_TOUCH) drag_move(tp.px, tp.py);
            if (g_drag.src && !(kh & KEY_TOUCH)) drag_end();
            if (g_mode == MODE_COSTUMES && (kh & KEY_TOUCH)) paint_canvas(tp.px, tp.py, kd & KEY_TOUCH);
        }

        if (g_play) {

            u32 k = kd | (((frame_no % 4) == 0) ? kh : 0);
            static const struct { u32 bit; const char *name; } map[] = {
                { KEY_DUP, "up arrow" }, { KEY_DDOWN, "down arrow" }, { KEY_DLEFT, "left arrow" }, { KEY_DRIGHT, "right arrow" },
                { KEY_A, "space" }, { KEY_X, "x" }, { KEY_Y, "y" }, { KEY_L, "l" }, { KEY_R, "r" },
            };
            for (unsigned i = 0; i < sizeof map / sizeof map[0]; i++) {
                rt_set_key(&g_rt, map[i].name, (kh & map[i].bit) != 0);
                if (k & map[i].bit) rt_key(&g_rt, &g_prj, map[i].name);
            }
            if (g_monitoring) { mic_poll(); rt_set_loudness(&g_rt, g_rec.level); }

            circlePosition cp;
            hidCircleRead(&cp);
            rt_set_pico(&g_rt, 50.f + cp.dx * 50.f / 156.f, 50.f + cp.dy * 50.f / 156.f,
                        (kh & KEY_TOUCH) ? tp.px * 100.f / 320.f : g_rt.pico_b,
                        (kh & KEY_TOUCH) ? 100.f - tp.py * 100.f / 240.f : g_rt.pico_c, (kh & KEY_A) != 0);
            if (kd & KEY_B) stop_play();
        } else {
            if (g_mode == MODE_ABOUT) {
                if (kd & KEY_DUP) about_scroll(-1);
                if (kd & KEY_DDOWN) about_scroll(+1);
            } else if (g_pk.action == PK_NONE && !g_recording && (kd & KEY_DUP)) bs_toggle_move();
            if ((kd & KEY_DLEFT) && !g_recording && g_pk.action == PK_NONE) g_light = !g_light;
            if (g_mode == MODE_SCRIPTS && g_pk.action == PK_NONE && !g_bs) {
                Sprite *sp = cur();
                if (kd & KEY_DDOWN) select_block(g_sel + 1);
                if (kd & KEY_DRIGHT) focus_move(+1);
                if (kd & KEY_A) edit_focused();
                (void)sp;
            }
            if (kd & KEY_L) sprite_step(-1);
            if (kd & KEY_R) sprite_step(+1);
            if ((kd & KEY_X) && !g_recording && !g_bs) do_delete();
            if (kd & KEY_Y) start_play();
            if (kd & KEY_B) { if (g_bs) g_bs = BS_OFF; else if (g_pk.action != PK_NONE) picker_close(); else stop_play(); }
            if (kd & KEY_START) save_project();
            if (g_recording) { mic_poll(); if (g_rec.full) rec_finish(); }
        }
        clamp_state();

        if (g_play) {
            rt_tick(&g_rt, &g_prj, 1.0f / 30.0f);
            play_audio_events();
            play_ask();
        } else rt_reset(&g_rt, &g_prj);
        frame_no++;

        C3D_FrameBegin(C3D_FRAME_SYNCDRAW);
        C2D_TextBufClear(g_text);
        C2D_TargetClear(top, RGB(0x1B1B20));
        C2D_TargetClear(bot, RGB(0x2B2B33));
        C2D_SceneBegin(top);
        draw_top();
        C2D_SceneBegin(bot);
        draw_bottom();
        C3D_FrameEnd(0);
    }

    if (g_recording) mic_stop();
    stop_play();
    audio_exit();
    mic_exit();
    prj_clear(&g_prj);
    C2D_TextBufDelete(g_text);
    C2D_Fini();
    C3D_Fini();
    gfxExit();
    return 0;
}
