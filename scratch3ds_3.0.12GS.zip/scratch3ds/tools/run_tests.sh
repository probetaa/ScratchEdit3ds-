#!/bin/bash
set -eo pipefail
cd "$(dirname "$0")"
CC="gcc -std=gnu11 -Wall -Wextra -fsanitize=address,undefined"
T=$(mktemp -d)
SRC=../source
LIB="$SRC/editor.c $SRC/runtime.c $SRC/assets.c $SRC/importer.c $SRC/templates.c $SRC/svg.c"

echo "== 32-bit safety (the 3DS has a 32-bit long) =="
if grep -nE '[0-9]L? *<< *(3[2-9]|[4-6][0-9])' $SRC/*.c $SRC/*.h; then echo "shift wider than 32 bits"; exit 1; fi

echo "== editor / assets / interpreter =="
$CC -I$SRC test_editor.c $LIB -lm -o $T/test_editor
$T/test_editor

echo "== .sb writer + validator =="
$CC -I$SRC test_writer.c $SRC/sb_writer.c $SRC/sb3_writer.c $LIB -lm -o $T/test_writer
$T/test_writer $T/sample.sb $T/all_blocks.sb
python3 -I sbdump.py $T/sample.sb | tail -n 8
python3 -I sbdump.py $T/all_blocks.sb --coverage | tail -n 4
echo "== .sb3 =="
python3 -I sb3check.py $T/sample.sb3
python3 -I sb3check.py $T/all_blocks.sb3 --coverage

echo "== .sb3 reader (round trip, damaged files, deflate) =="
$CC -I$SRC test_reader.c $SRC/sb3_reader.c $SRC/sb3_writer.c $LIB -lm -o $T/test_reader
mkdir -p $T/rd
python3 -I -c "
import sys, zipfile
src = zipfile.ZipFile(sys.argv[1]); out = zipfile.ZipFile(sys.argv[2], 'w', zipfile.ZIP_DEFLATED)
for n in src.namelist(): out.writestr(n, src.read(n))
out.close()" $T/all_blocks.sb3 $T/rd/deflated.sb3
python3 -I -c "
import sys, zipfile
src = zipfile.ZipFile(sys.argv[1]); out = zipfile.ZipFile(sys.argv[2], 'w', zipfile.ZIP_DEFLATED)
for n in src.namelist():
    d = src.read(n)
    if n == 'project.json': d = d.replace(b'motion_movesteps', b'zzz_unknownblock').replace(b'looks_say\"', b'zzz_other\"')
    out.writestr(n, d)
out.close()" $T/all_blocks.sb3 $T/rd/unknown.sb3
python3 -I make_svg_project.py $T/rd/real.sb3
$T/test_reader $T/rd $T/all_blocks.sb3 $T/rd/deflated.sb3 $T/rd/unknown.sb3 $T/rd/real.sb3

echo "== templates, clones, undo =="
$CC -I$SRC test_templates.c $SRC/sb3_writer.c $LIB -lm -o $T/test_templates
mkdir -p $T/tpl
$T/test_templates $T/tpl
for f in $T/tpl/*.sb3; do python3 -I sb3check.py $f; done

echo "== importer (PNG/BMP/PPM/WAV + sprite.txt) =="
python3 -I make_fixtures.py $T/fx
$CC -I$SRC test_import.c $SRC/sb_writer.c $SRC/sb3_writer.c $LIB -lm -o $T/test_import
$T/test_import $T/fx | tail -n 2
python3 -I sb3check.py $T/fx/imported.sb3

echo "== UI (main.c with fake libctru/citro2d) =="
SB3CHECK="$(pwd)/sb3check.py"
FIXGEN="$(pwd)/make_fixtures.py"
export SB3CHECK FIXGEN
$CC -Istubs -I$SRC test_ui.c $SRC/sb3_writer.c $SRC/sb3_reader.c $LIB -lm -o $T/test_ui
$T/test_ui | tail -n 6

rm -rf "$T"
echo "ALL TESTS PASSED"
