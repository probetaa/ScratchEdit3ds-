#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "assets.h"
#include "editor.h"
#include "sb3_writer.h"
#include "templates.h"

static Project A, B;

static void dump(const Project *p, char *out, size_t n)
{
    size_t o = 0;
    out[0] = 0;
    for (int s = 0; s <= p->nsprites; s++) {
        int si = s == p->nsprites ? STAGE_IDX : s;
        const Sprite *sp = &p->sprites[si];
        o += (size_t)snprintf(out + o, n - o, "[%s %d %d %d %d %d c%d/%d s%d]\n", sp->name, sp->x, sp->y, sp->direction, sp->size, sp->visible, sp->cur_costume, sp->ncostumes, sp->nsounds);
        for (int c = 0; c < sp->ncostumes; c++) {
            unsigned sum = 0;
            for (int i = 0; i < COSTUME_W * COSTUME_H; i++) sum = sum * 31 + sp->costumes[c].px[i];
            o += (size_t)snprintf(out + o, n - o, " costume %s %u\n", sp->costumes[c].name, sum);
        }
        for (int i = 0; i < sp->nscripts && si != STAGE_IDX; i++) {
            const Script *sc = &sp->scripts[i];
            for (int b = 0; b < sc->nblocks; b++) {
                char t[256];
                prj_format_block(sc, &sc->blocks[b], t, sizeof t);
                o += (size_t)snprintf(out + o, n - o, "  %*s%s\n", prj_indent(sc, b) * 2, "", t);
            }
        }
    }
    for (int v = 0; v < p->nvars; v++) o += (size_t)snprintf(out + o, n - o, "var %s=%s\n", p->vars[v].name, p->vars[v].init);
    for (int l = 0; l < p->nlists; l++) o += (size_t)snprintf(out + o, n - o, "list %s\n", p->lists[l].name);
}

static char D1[200000], D2[200000];

int main(int argc, char **argv)
{
    const char *dir = argc > 1 ? argv[1] : ".";
    char path[300], err[128];
    int skipped = -1;

    for (int t = 0; t < tpl_count(); t++) {
        assert(tpl_build(&A, t) == 0);
        snprintf(path, sizeof path, "%s/rt%d.sb3", dir, t);
        assert(sb3_write_project(&A, path) == 0);
        memset(&B, 0, sizeof B);
        int rc = sb3_read_project(path, &B, &skipped, err, sizeof err);
        if (rc != 0) { printf("template %d read failed: %s\n", t, err); return 1; }
        assert(skipped == 0);
        dump(&A, D1, sizeof D1);
        dump(&B, D2, sizeof D2);
        if (strcmp(D1, D2)) {
            printf("template %d (%s) differs after a round trip:\n", t, tpl_name(t));
            FILE *f = fopen("/tmp/rt_a.txt", "w"); fputs(D1, f); fclose(f);
            f = fopen("/tmp/rt_b.txt", "w"); fputs(D2, f); fclose(f);
            return 1;
        }
        char path2[300];
        snprintf(path2, sizeof path2, "%s/rt%d_b.sb3", dir, t);
        assert(sb3_write_project(&B, path2) == 0);
        printf("template %d %s: round trip identical\n", t, tpl_name(t));
        prj_clear(&A);
        prj_clear(&B);
    }

    {
        assert(tpl_build(&A, 2) == 0);
        snprintf(path, sizeof path, "%s/fuzz.sb3", dir);
        assert(sb3_write_project(&A, path) == 0);
        FILE *f = fopen(path, "rb");
        fseek(f, 0, SEEK_END);
        long n = ftell(f);
        fseek(f, 0, SEEK_SET);
        unsigned char *orig = malloc((size_t)n), *buf = malloc((size_t)n);
        assert(fread(orig, 1, (size_t)n, f) == (size_t)n);
        fclose(f);
        unsigned seed = 12345;
        char bad[300];
        snprintf(bad, sizeof bad, "%s/bad.sb3", dir);
        int ok = 0;
        for (int it = 0; it < 300; it++) {
            memcpy(buf, orig, (size_t)n);
            long len = n;
            seed = seed * 1103515245u + 12345u;
            if (it % 3 == 0) len = (long)((seed >> 8) % (unsigned)n);
            else for (int k = 0; k < 1 + it % 8; k++) { seed = seed * 1103515245u + 12345u; buf[(seed >> 8) % (unsigned)n] ^= (unsigned char)(seed >> 3) | 1; }
            f = fopen(bad, "wb"); fwrite(buf, 1, (size_t)len, f); fclose(f);
            memset(&B, 0, sizeof B);
            if (sb3_read_project(bad, &B, &skipped, err, sizeof err) == 0) { ok++; prj_clear(&B); }
        }
        printf("fuzz: 300 damaged files handled (%d still readable)\n", ok);
        free(orig); free(buf);
        prj_clear(&A);
    }

    if (argc > 3) {
        static Project C;
        memset(&B, 0, sizeof B); memset(&C, 0, sizeof C);
        assert(sb3_read_project(argv[2], &B, &skipped, err, sizeof err) == 0);
        int rc = sb3_read_project(argv[3], &C, &skipped, err, sizeof err);
        if (rc != 0) { printf("deflated zip read failed: %s\n", err); return 1; }
        dump(&B, D1, sizeof D1);
        dump(&C, D2, sizeof D2);
        assert(strcmp(D1, D2) == 0);
        puts("deflate-compressed zip reads the same");
        prj_clear(&B); prj_clear(&C);
    }

    if (argc > 5) {
        static Project W;
        assert(sb3_read_project(argv[5], &W, &skipped, err, sizeof err) == 0 && skipped == 0);
        assert(W.nsprites == 2 && W.sprites[0].size == 104 && W.sprites[1].size == 250);
        int cat = 0, big = 0, stage = 0;
        for (int i = 0; i < COSTUME_W * COSTUME_H; i++) {
            cat += (W.sprites[0].costumes[0].px[i] & 0x8000) != 0;
            big += (W.sprites[1].costumes[0].px[i] & 0x8000) != 0;
            stage += (W.sprites[STAGE_IDX].costumes[0].px[i] & 0x8000) != 0;
        }
        assert(cat > 4000 && cat < 8000);
        assert(big > 2300 && big < 3400);
        assert(stage > 3200 && stage < 4400);
        assert(W.sprites[0].nsounds == 1 && strcmp(W.sprites[0].sounds[0].name, "pop") == 0 && W.sprites[0].sounds[0].npcm > 5000);
        int peak = 0;
        for (int i = 0; i < W.sprites[0].sounds[0].npcm; i++) if (abs(W.sprites[0].sounds[0].pcm[i]) > peak) peak = abs(W.sprites[0].sounds[0].pcm[i]);
        assert(peak > 9000 && peak < 15000);
        prj_clear(&W);
        puts("SVG and big PNG costumes read with shapes and sizes");
    }

    if (argc > 4) {
        static Project U;
        memset(&U, 0, sizeof U);
        assert(sb3_read_project(argv[4], &U, &skipped, err, sizeof err) == 0);
        assert(skipped > 0 && sb3_report_count() > 0);
        int found = 0;
        for (int i = 0; i < sb3_report_count(); i++) {
            printf("  report: %s\n", sb3_report_line(i));
            if (strstr(sb3_report_line(i), "zzz_unknownblock")) found = 1;
        }
        assert(found && strstr(sb3_report_line(0), "block(s) not supported"));
        prj_clear(&U);
        static Project V;
        memset(&V, 0, sizeof V);
        assert(sb3_read_project(argv[2], &V, &skipped, err, sizeof err) == 0 && skipped == 0 && sb3_report_count() == 0);
        prj_clear(&V);
        puts("import report lists what was skipped");
    }

    if (argc > 2) {
        int used[BK_COUNT] = { 0 };
        memset(&B, 0, sizeof B);
        int rc = sb3_read_project(argv[2], &B, &skipped, err, sizeof err);
        if (rc != 0) { printf("all_blocks read failed: %s\n", err); return 1; }
        for (int s = 0; s < B.nsprites; s++)
            for (int i = 0; i < B.sprites[s].nscripts; i++) {
                const Script *sc = &B.sprites[s].scripts[i];
                for (int b = 0; b < sc->nblocks; b++) used[sc->blocks[b].kind] = 1;
                for (int e = 0; e < MAX_EXPR; e++) if (sc->ex_used[e]) used[sc->ex[e].kind] = 1;
            }
        int nm;
        const Sb3Map *m = sb3_maps(&nm);
        int missing = 0;
        for (int i = 0; i < nm; i++) {
            int k = m[i].kind;
            if (k == BK_LOUD || k == BK_FOREVER_IF || used[k]) continue;
            printf("not read back: %s\n", BLOCK_INFO[k].label);
            missing++;
        }
        if (!used[BK_HAT_DEFINE] || !used[BK_CALL] || !used[BK_PARAM] || !used[BK_PARAMB]) { puts("custom blocks not read back"); return 1; }
        printf("all_blocks: read back with %d skipped, %d kinds missing\n", skipped, missing);
        if (missing) return 1;
        static Project C;
        memset(&C, 0, sizeof C);
        char again[300];
        snprintf(again, sizeof again, "%s/again.sb3", dir);
        assert(sb3_write_project(&B, again) == 0);
        assert(sb3_read_project(again, &C, &skipped, err, sizeof err) == 0 && skipped == 0);
        dump(&B, D1, sizeof D1);
        dump(&C, D2, sizeof D2);
        if (strcmp(D1, D2)) {
            FILE *f = fopen("/tmp/rt_a.txt", "w"); fputs(D1, f); fclose(f);
            f = fopen("/tmp/rt_b.txt", "w"); fputs(D2, f); fclose(f);
            puts("second round trip differs");
            return 1;
        }
        const Sprite *cu = &C.sprites[2];
        assert(!strcmp(cu->name, "Custom") && cu->scripts[1].blocks[0].kind == BK_HAT_DEFINE);
        printf("custom blocks survive a round trip: %s\n", cu->scripts[1].blocks[0].label);
        prj_clear(&C);
    }
    puts("all reader tests passed");
    return 0;
}
