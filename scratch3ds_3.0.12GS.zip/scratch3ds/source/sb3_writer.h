#ifndef SB3_WRITER_H
#define SB3_WRITER_H

#include <stddef.h>
#include "project.h"

int sb3_write_project(const Project *p, const char *path);

typedef struct { int kind; const char *op; const char *spec; const char *fields; const char *xmenu; } Sb3Map;
const Sb3Map *sb3_maps(int *n);

int sb3_read_project(const char *path, Project *out, int *skipped, char *err, size_t errn);
int sb3_report_count(void);
const char *sb3_report_line(int i);

void sb3_md5_hex(const void *data, size_t n, char out[33]);
unsigned sb3_crc32(const void *data, size_t n);

#endif
