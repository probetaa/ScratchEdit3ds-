
#ifndef ASSETS_H
#define ASSETS_H

#include "project.h"

#define PAL_N 16
extern const uint32_t PALETTE_RGB[PAL_N];

void costume_clear(Costume *c);
void costume_make_default(Costume *c, int variant);
void costume_fill(Costume *c, int x, int y, uint8_t color);
void costume_flip_h(Costume *c);
uint32_t costume_argb(uint8_t idx);

extern const char *const PALETTE_NAMES[PAL_N];
int      pal_find(const char *name);
uint32_t pen_rgb(float hue, float shade);
float    pen_hue_of(uint32_t rgb);

void        snd_default(Sound *s);
void        snd_free(Sound *s);
int         snd_is_recorded(const Sound *s);
int         snd_rate(const Sound *s);
int         snd_duration_ms(const Sound *s);
int         snd_set_pcm(Sound *s, const int16_t *pcm, int n, int rate);
const char *snd_wave_name(int wave);
void        snd_clamp(Sound *s);

int         snd_render(const Sound *s, int16_t *out, int max);

int         snd_trim(Sound *s);
int         snd_normalize(Sound *s);
int         snd_reverse(Sound *s);

#define SND_PRESET_COUNT 10
extern const char *const SND_PRESET_NAMES[SND_PRESET_COUNT];
int         snd_make_preset(Sound *s, int preset);

typedef struct { int16_t *buf; int n, max; uint32_t pos; int full, monitor; float level; } Recorder;
void rec_begin(Recorder *r, int16_t *buf, int max, int monitor);
int  rec_consume(Recorder *r, const uint8_t *ring, uint32_t ring_bytes, uint32_t write_off);

#endif
