#pragma once
#include <stdint.h>
#include <stdbool.h>
#include <stddef.h>
typedef uint32_t u32; typedef uint16_t u16; typedef uint8_t u8; typedef int16_t s16;
typedef struct { u16 px, py; } touchPosition;
typedef struct { s16 dx, dy; } circlePosition;
#define KEY_A 1u
#define KEY_B 2u
#define KEY_SELECT 4u
#define KEY_START 8u
#define KEY_DRIGHT 16u
#define KEY_DLEFT 32u
#define KEY_DUP 64u
#define KEY_DDOWN 128u
#define KEY_R 256u
#define KEY_L 512u
#define KEY_X 1024u
#define KEY_Y 2048u
#define KEY_TOUCH 4096u
#define GFX_TOP 0
#define GFX_BOTTOM 1
#define GFX_LEFT 0
void gfxInitDefault(void); void gfxExit(void);
bool aptMainLoop(void); void hidScanInput(void);
u32 hidKeysDown(void); u32 hidKeysHeld(void); void hidTouchRead(touchPosition*); void hidCircleRead(circlePosition*);
typedef struct { int x; } SwkbdState;
typedef enum { SWKBD_BUTTON_LEFT, SWKBD_BUTTON_MIDDLE, SWKBD_BUTTON_RIGHT, SWKBD_BUTTON_NONE } SwkbdButton;
typedef enum { SWKBD_TYPE_NORMAL, SWKBD_TYPE_NUMPAD } SwkbdType;
void swkbdInit(SwkbdState*, SwkbdType, int, int);
void swkbdSetHintText(SwkbdState*, const char*);
void swkbdSetInitialText(SwkbdState*, const char*);
void swkbdSetButton(SwkbdState*, SwkbdButton, const char*, bool);
void swkbdSetNumpadKeys(SwkbdState*, int, int);
SwkbdButton swkbdInputText(SwkbdState*, char*, size_t);
typedef int Result;
#define R_FAILED(r) ((r) < 0)
#define R_SUCCEEDED(r) ((r) >= 0)
Result APT_CheckNew3DS(bool *out); void osSetSpeedupEnable(bool enable);
Result ndspInit(void); void ndspExit(void);
#define NDSP_OUTPUT_MONO 0
#define NDSP_OUTPUT_STEREO 1
#define NDSP_INTERP_LINEAR 1
#define NDSP_FORMAT_MONO_PCM16 5
void ndspSetOutputMode(int); void ndspChnReset(int); void ndspChnSetInterp(int, int);
void ndspChnSetRate(int, float); void ndspChnSetFormat(int, u16); void ndspChnSetMix(int, float *);
typedef struct { void *data_vaddr; u32 nsamples; u8 status; } ndspWaveBuf;
void ndspChnWaveBufAdd(int, ndspWaveBuf *); void ndspChnWaveBufClear(int);
void *linearAlloc(size_t); void linearFree(void *); Result DSP_FlushDataCache(const void *, u32);

typedef enum { MICU_ENCODING_PCM8, MICU_ENCODING_PCM16, MICU_ENCODING_PCM8_SIGNED, MICU_ENCODING_PCM16_SIGNED } MICU_Encoding;
typedef enum { MICU_SAMPLE_RATE_32730, MICU_SAMPLE_RATE_16360, MICU_SAMPLE_RATE_10910, MICU_SAMPLE_RATE_8180 } MICU_SampleRate;
Result micInit(u8 *buffer, u32 bufferSize); void micExit(void);
u32 micGetSampleDataSize(void); u32 micGetLastSampleOffset(void);
Result MICU_StartSampling(MICU_Encoding, MICU_SampleRate, u32 offset, u32 size, bool loop);
Result MICU_StopSampling(void); Result MICU_SetPower(bool power);
typedef u32 Handle;
#define SELECT_NONE 0

Result svcWaitSynchronization(Handle, long long); Result svcCloseHandle(Handle);
