#include "assets.h"

#include <math.h>
#include <stdlib.h>
#include <string.h>

const uint32_t PALETTE_RGB[PAL_N] = {
    0x000000,
    0x1A1A1A,
    0xFFFFFF,
    0xE03C31,
    0xF5A623,
    0xF7DC3A,
    0x4CC24C,
    0x1E7A3A,
    0x3AD0E0,
    0x3B7DD8,
    0x1F3F8F,
    0x8A55D7,
    0xF06EB5,
    0x8B5A2B,
    0x808080,
    0xC8C8C8,
};

void costume_clear(Costume *c)
{
    memset(c->px, 0, sizeof c->px);
}

void costume_make_default(Costume *c, int variant)
{
    static const uint8_t body[4]    = { 4, 6, 9, 3 };
    static const uint8_t outline[4] = { 13, 7, 10, 1 };
    int v = ((variant % 4) + 4) % 4;
    costume_clear(c);
    for (int y = 0; y < COSTUME_H; y++)
        for (int x = 0; x < COSTUME_W; x++) {
            float dx = x - (COSTUME_W - 1) / 2.0f, dy = y - (COSTUME_H - 1) / 2.0f;
            float d;
            switch (v) {
            case 0:  d = sqrtf(dx * dx + dy * dy); break;
            case 1:  d = fmaxf(fabsf(dx), fabsf(dy)) * 1.05f; break;
            case 2:  d = (fabsf(dx) + fabsf(dy)) * 0.78f; break;
            default: {
                float t = (dy + 15.5f) / 31.0f;
                float half = t * 15.5f;
                d = (dy < -15.5f || dy > 15.5f || fabsf(dx) > half) ? 99.f
                    : fmaxf(fabsf(dx) / (half > 1 ? half : 1) * 14.f, fabsf(dy) * 0.9f);
                break; }
            }
            if (d <= 13.5f)      c->px[y * COSTUME_W + x] = body[v];
            else if (d <= 15.5f) c->px[y * COSTUME_W + x] = outline[v];
        }
}

typedef struct { int8_t x, y; } Pt;

void costume_fill(Costume *c, int x, int y, uint8_t color)
{
    if (x < 0 || y < 0 || x >= COSTUME_W || y >= COSTUME_H) return;
    uint8_t target = c->px[y * COSTUME_W + x];
    if (target == color) return;

    static Pt stack[COSTUME_W * COSTUME_H * 4 + 8];
    int sp = 0;
    stack[sp++] = (Pt){ (int8_t)x, (int8_t)y };
    while (sp > 0) {
        Pt p = stack[--sp];
        if (p.x < 0 || p.y < 0 || p.x >= COSTUME_W || p.y >= COSTUME_H) continue;
        if (c->px[p.y * COSTUME_W + p.x] != target) continue;
        c->px[p.y * COSTUME_W + p.x] = color;
        if (sp + 4 > (int)(sizeof stack / sizeof stack[0])) continue;
        stack[sp++] = (Pt){ (int8_t)(p.x + 1), p.y };
        stack[sp++] = (Pt){ (int8_t)(p.x - 1), p.y };
        stack[sp++] = (Pt){ p.x, (int8_t)(p.y + 1) };
        stack[sp++] = (Pt){ p.x, (int8_t)(p.y - 1) };
    }
}

void costume_flip_h(Costume *c)
{
    for (int y = 0; y < COSTUME_H; y++)
        for (int x = 0; x < COSTUME_W / 2; x++) {
            uint8_t *a = &c->px[y * COSTUME_W + x];
            uint8_t *b = &c->px[y * COSTUME_W + (COSTUME_W - 1 - x)];
            uint8_t t = *a; *a = *b; *b = t;
        }
}

uint32_t costume_argb(uint8_t idx)
{
    if (idx == 0 || idx >= PAL_N) return 0;
    return 0xFF000000u | PALETTE_RGB[idx];
}

const char *const PALETTE_NAMES[PAL_N] = {
    "none", "black", "white", "red", "orange", "yellow", "green", "dark green",
    "cyan", "blue", "navy", "purple", "pink", "brown", "gray", "light gray",
};

int pal_find(const char *name)
{
    for (int i = 1; i < PAL_N; i++) if (strcmp(PALETTE_NAMES[i], name) == 0) return i;
    return 3;
}

static void hsv_to_rgb(float h, float s, float v, float *r, float *g, float *b)
{
    h = fmodf(h, 360.f); if (h < 0) h += 360.f;
    float c = v * s, hp = h / 60.f;
    float x = c * (1.f - fabsf(fmodf(hp, 2.f) - 1.f));
    float r1 = 0, g1 = 0, b1 = 0;
    if (hp < 1) { r1 = c; g1 = x; } else if (hp < 2) { r1 = x; g1 = c; }
    else if (hp < 3) { g1 = c; b1 = x; } else if (hp < 4) { g1 = x; b1 = c; }
    else if (hp < 5) { r1 = x; b1 = c; } else { r1 = c; b1 = x; }
    float m = v - c;
    *r = r1 + m; *g = g1 + m; *b = b1 + m;
}

uint32_t pen_rgb(float hue, float shade)
{
    float r, g, b;
    hsv_to_rgb(hue * 1.8f, 1.f, 1.f, &r, &g, &b);
    if (shade < 0) shade = 0;
    if (shade > 100) shade = 100;
    if (shade < 50) { float k = shade / 50.f; r *= k; g *= k; b *= k; }
    else { float k = (shade - 50.f) / 50.f; r += (1 - r) * k; g += (1 - g) * k; b += (1 - b) * k; }
    return ((uint32_t)(r * 255.f + 0.5f) << 16) | ((uint32_t)(g * 255.f + 0.5f) << 8) | (uint32_t)(b * 255.f + 0.5f);
}

float pen_hue_of(uint32_t rgb)
{
    float r = ((rgb >> 16) & 255) / 255.f, g = ((rgb >> 8) & 255) / 255.f, b = (rgb & 255) / 255.f;
    float mx = fmaxf(r, fmaxf(g, b)), mn = fminf(r, fminf(g, b)), d = mx - mn, h = 0;
    if (d > 1e-6f) {
        if (mx == r) h = fmodf((g - b) / d, 6.f);
        else if (mx == g) h = (b - r) / d + 2.f;
        else h = (r - g) / d + 4.f;
        h *= 60.f; if (h < 0) h += 360.f;
    }
    return h / 1.8f;
}

void snd_default(Sound *s)
{
    memset(s, 0, sizeof *s);
    strcpy(s->name, "beep1");
    s->wave = WAVE_SINE;
    s->freq = 440;
    s->ms   = 300;
    s->vol  = 80;
}

void snd_free(Sound *s)
{
    free(s->pcm);
    s->pcm = NULL;
    s->npcm = 0;
    s->rate = 0;
}

int snd_is_recorded(const Sound *s) { return s->pcm != NULL && s->npcm > 0; }
int snd_rate(const Sound *s) { return snd_is_recorded(s) ? s->rate : SND_RATE; }

int snd_duration_ms(const Sound *s)
{
    if (snd_is_recorded(s)) return (int)((int64_t)s->npcm * 1000 / (s->rate > 0 ? s->rate : REC_RATE));
    Sound c = *s;
    snd_clamp(&c);
    return c.ms;
}

int snd_set_pcm(Sound *s, const int16_t *pcm, int n, int rate)
{
    if (n <= 0 || n > REC_MAX_SAMPLES || rate <= 0) return -1;
    int16_t *copy = malloc((size_t)n * sizeof(int16_t));
    if (!copy) return -1;
    memcpy(copy, pcm, (size_t)n * sizeof(int16_t));
    free(s->pcm);
    s->pcm = copy; s->npcm = n; s->rate = rate;
    if (s->vol <= 0) s->vol = 100;
    return 0;
}

const char *snd_wave_name(int wave)
{
    static const char *n[WAVE_COUNT] = { "sine", "square", "saw", "noise" };
    return (wave >= 0 && wave < WAVE_COUNT) ? n[wave] : "?";
}

void snd_clamp(Sound *s)
{
    if (s->wave < 0) s->wave = WAVE_COUNT - 1;
    if (s->wave >= WAVE_COUNT) s->wave = 0;
    if (s->freq < 40) s->freq = 40;
    if (s->freq > 4000) s->freq = 4000;
    if (s->ms < 50) s->ms = 50;
    if (s->ms > SND_MAX_MS) s->ms = SND_MAX_MS;
    if (s->vol < 0) s->vol = 0;
    if (s->vol > 100) s->vol = 100;
}

int snd_render(const Sound *s, int16_t *out, int max)
{
    if (snd_is_recorded(s)) {
        int vol = s->vol < 0 ? 0 : (s->vol > 100 ? 100 : s->vol);
        int n = s->npcm < max ? s->npcm : max;
        for (int i = 0; i < n; i++) out[i] = (int16_t)((int)s->pcm[i] * vol / 100);
        return n;
    }
    Sound c = *s;
    snd_clamp(&c);
    int n = SND_RATE * c.ms / 1000;
    if (n > max) n = max;
    const float amp = 32767.0f * 0.7f * (float)c.vol / 100.0f;
    const int fade_in = SND_RATE / 1000 * 2, fade_out = SND_RATE / 1000 * 12;
    uint32_t seed = 0x1234567u;
    float phase = 0.f;
    const float inc = (float)c.freq / (float)SND_RATE;
    for (int i = 0; i < n; i++) {
        float v;
        switch (c.wave) {
        case WAVE_SQUARE: v = phase < 0.5f ? 1.f : -1.f; break;
        case WAVE_SAW:    v = 2.f * phase - 1.f; break;
        case WAVE_NOISE:
            seed = seed * 1664525u + 1013904223u;
            v = ((int32_t)(seed >> 8) / 8388608.0f) - 1.0f;
            break;
        default:          v = sinf(6.2831853f * phase); break;
        }
        phase += inc;
        if (phase >= 1.f) phase -= 1.f;
        float env = 1.f;
        if (i < fade_in) env = (float)i / (float)fade_in;
        if (n - i < fade_out) env = (float)(n - i) / (float)fade_out;
        out[i] = (int16_t)(v * amp * env);
    }
    return n;
}

int snd_trim(Sound *s)
{
    if (!snd_is_recorded(s)) return -1;
    int peak = 0;
    for (int i = 0; i < s->npcm; i++) if (abs(s->pcm[i]) > peak) peak = abs(s->pcm[i]);
    if (peak < 200) return -1;
    int thr = peak / 12, a = 0, b = s->npcm - 1;
    while (a < b && abs(s->pcm[a]) < thr) a++;
    while (b > a && abs(s->pcm[b]) < thr) b--;
    int pad = s->rate / 100;
    a = a > pad ? a - pad : 0;
    b = b + pad < s->npcm - 1 ? b + pad : s->npcm - 1;
    int n = b - a + 1;
    if (n == s->npcm) return 0;
    memmove(s->pcm, s->pcm + a, (size_t)n * sizeof(int16_t));
    s->npcm = n;
    return 0;
}

int snd_normalize(Sound *s)
{
    if (!snd_is_recorded(s)) return -1;
    int peak = 0;
    for (int i = 0; i < s->npcm; i++) if (abs(s->pcm[i]) > peak) peak = abs(s->pcm[i]);
    if (peak < 50) return -1;
    float k = 31000.0f / (float)peak;
    for (int i = 0; i < s->npcm; i++) s->pcm[i] = (int16_t)(s->pcm[i] * k);
    return 0;
}

int snd_reverse(Sound *s)
{
    if (!snd_is_recorded(s)) return -1;
    for (int i = 0, j = s->npcm - 1; i < j; i++, j--) { int16_t t = s->pcm[i]; s->pcm[i] = s->pcm[j]; s->pcm[j] = t; }
    return 0;
}

void rec_begin(Recorder *r, int16_t *buf, int max, int monitor)
{
    memset(r, 0, sizeof *r);
    r->buf = buf;
    r->max = max;
    r->monitor = monitor;
}

int rec_consume(Recorder *r, const uint8_t *ring, uint32_t ring_bytes, uint32_t write_off)
{
    if (ring_bytes < 2) return 0;
    ring_bytes &= ~1u;
    write_off &= ~1u;
    if (write_off >= ring_bytes) write_off = 0;
    int consumed = 0, peak = 0;
    uint32_t limit = ring_bytes / 2;
    while (r->pos != write_off && (uint32_t)consumed < limit) {
        int16_t v = (int16_t)(ring[r->pos] | (ring[r->pos + 1] << 8));
        r->pos += 2;
        if (r->pos >= ring_bytes) r->pos = 0;
        consumed++;
        if (abs(v) > peak) peak = abs(v);
        if (!r->monitor) {
            if (r->n < r->max) r->buf[r->n++] = v;
            else r->full = 1;
        }
    }
    if (consumed) {
        int lv = peak * 100 / 16384;
        r->level = (float)(lv > 100 ? 100 : lv);
    }
    return consumed;
}

const char *const SND_PRESET_NAMES[SND_PRESET_COUNT] = {
    "laser", "jump", "coin", "power-up", "explosion", "hit", "blip", "siren", "fall", "click",
};

#define FX_RATE 11025
#define FX_MAX  (FX_RATE * 8 / 10)

typedef struct { int16_t *out; int pos; uint32_t rng; float phase, noise; } FxGen;

static void fx_seg(FxGen *g, float f0, float f1, int ms, int wave, float amp, float decay)
{
    int n = ms * FX_RATE / 1000;
    for (int i = 0; i < n && g->pos < FX_MAX; i++, g->pos++) {
        float t = (float)i / (float)n;
        float f = f0 + (f1 - f0) * t;
        float prev = g->phase;
        g->phase += f / FX_RATE;
        if (g->phase >= 1.f) g->phase -= floorf(g->phase);
        float v;
        switch (wave) {
        case 0:  v = sinf(6.2831853f * g->phase); break;
        case 1:  v = g->phase < 0.5f ? 1.f : -1.f; break;
        case 2:  v = 2.f * g->phase - 1.f; break;
        default:
            if (g->phase < prev || i == 0) { g->rng = g->rng * 1664525u + 1013904223u; g->noise = (float)((g->rng >> 16) & 0xFFFF) / 32767.5f - 1.f; }
            v = g->noise;
            break;
        }
        float env = powf(1.f - t, decay);
        float a = i < 40 ? (float)i / 40.f : 1.f;
        g->out[g->pos] = (int16_t)(v * amp * env * a * 30000.f);
    }
}

int snd_make_preset(Sound *s, int preset)
{
    if (preset < 0 || preset >= SND_PRESET_COUNT) return -1;
    int16_t *buf = calloc(FX_MAX, sizeof *buf);
    if (!buf) return -1;
    FxGen g = { buf, 0, 12345u + (uint32_t)preset * 7919u, 0.f, 0.f };
    switch (preset) {
    case 0: fx_seg(&g, 1800, 200, 260, 1, 0.5f, 1.2f); break;
    case 1: fx_seg(&g, 220, 700, 220, 1, 0.5f, 0.6f); break;
    case 2: fx_seg(&g, 988, 988, 70, 1, 0.45f, 0.2f); fx_seg(&g, 1319, 1319, 300, 1, 0.45f, 1.5f); break;
    case 3: {
        static const float n[6] = { 262, 330, 392, 523, 659, 784 };
        for (int i = 0; i < 6; i++) fx_seg(&g, n[i], n[i], 60, 1, 0.4f, 0.3f);
        break; }
    case 4: fx_seg(&g, 3500, 250, 700, 3, 0.8f, 1.6f); break;
    case 5: fx_seg(&g, 3000, 900, 70, 3, 0.7f, 1.0f); fx_seg(&g, 200, 70, 140, 0, 0.8f, 1.2f); break;
    case 6: fx_seg(&g, 880, 880, 80, 0, 0.6f, 0.8f); break;
    case 7: fx_seg(&g, 600, 950, 180, 0, 0.5f, 0.0f); fx_seg(&g, 950, 600, 180, 0, 0.5f, 0.0f);
            fx_seg(&g, 600, 950, 180, 0, 0.5f, 0.0f); fx_seg(&g, 950, 600, 180, 0, 0.5f, 0.6f); break;
    case 8: fx_seg(&g, 900, 90, 600, 0, 0.6f, 0.8f); break;
    default: fx_seg(&g, 6000, 6000, 18, 3, 0.7f, 2.0f); break;
    }
    int r = snd_set_pcm(s, buf, g.pos, FX_RATE);
    free(buf);
    if (r != 0) return -1;
    s->vol = 100;
    return 0;
}

