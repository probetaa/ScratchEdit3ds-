
#include <assert.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "editor.h"
#include "runtime.h"
#include "sb3_writer.h"
#include "templates.h"

static Project P;
static Runtime RT;

static void run(int frames) { for (int i = 0; i < frames; i++) rt_tick(&RT, &P, 1.f / 30.f); }

static void check_shape(void)
{
    for (int s = 0; s < P.nsprites; s++)
        for (int i = 0; i < P.sprites[s].nscripts; i++) {
            const Script *sc = &P.sprites[s].scripts[i];
            assert(sc->nblocks >= 1 && block_is_hat(sc->blocks[0].kind));
            int depth = 0;
            for (int b = 1; b < sc->nblocks; b++) {
                int sh = BLOCK_INFO[sc->blocks[b].kind].shape;
                assert(sh != SH_HAT && sh != SH_REP && sh != SH_BOOL);
                if (sh == SH_C || sh == SH_CELSE) { assert(prj_match_end(sc, b) > b); depth++; }
                if (sh == SH_END) depth--;
                assert(depth >= 0);
            }
            assert(depth == 0);
        }
}

int main(int argc, char **argv)
{
    const char *dir = argc > 1 ? argv[1] : ".";
    assert(tpl_count() >= 5);
    for (int t = 0; t < tpl_count(); t++) {
        assert(tpl_build(&P, t) == 0);
        printf("template %d: %s (%d sprites, %d vars)\n", t, tpl_name(t), P.nsprites, P.nvars);
        check_shape();
        rt_reset(&RT, &P);
        rt_green_flag(&RT, &P);
        run(300);
        for (int s = 0; s < P.nsprites; s++) assert(fabsf(RT.spr[s].x) < 600 && fabsf(RT.spr[s].y) < 600);
        char path[512];
        snprintf(path, sizeof path, "%s/tpl%d.sb3", dir, t);
        assert(sb3_write_project(&P, path) == 0);
    }

    tpl_build(&P, 1);
    rt_green_flag(&RT, &P); run(2);
    int apple = 1;
    RT.spr[apple].x = RT.spr[0].x; RT.spr[apple].y = RT.spr[0].y + 20;
    run(3);
    assert(RT.var[0].n >= 1.f);
    int sounds = 0; SoundEvt ev; while (rt_pop_sound(&RT, &ev)) sounds++;
    assert(sounds >= 1);
    rt_key(&RT, &P, "left arrow"); rt_set_key(&RT, "left arrow", 1);
    float x0 = RT.spr[0].x; run(3); assert(RT.spr[0].x < x0);
    rt_set_key(&RT, "left arrow", 0);

    tpl_build(&P, 2);
    rt_green_flag(&RT, &P); run(5);
    RT.spr[1].x = RT.spr[0].x; RT.spr[1].y = RT.spr[0].y + 25; RT.spr[1].dir = 135;
    run(3);
    assert(RT.var[0].n >= 1.f);
    run(900);
    assert(fabsf(RT.spr[1].x) <= STAGE_W / 2 && fabsf(RT.spr[1].y) <= STAGE_H / 2);

    tpl_build(&P, 3);
    rt_green_flag(&RT, &P); run(3);
    assert(rt_nclones(&RT) == 0 && !RT.spr[1].visible);
    rt_key(&RT, &P, "space"); run(3);
    assert(rt_nclones(&RT) == 1);
    int cl = MAX_SPRITES;
    assert(RT.spr[cl].alive && RT.spr[cl].is_clone && RT.spr[cl].visible && RT.spr[cl].def == 1);
    float y1 = RT.spr[cl].y; run(3); assert(RT.spr[cl].y > y1);
    run(60);
    assert(rt_nclones(&RT) == 0);

    RT.spr[2].x = 0; RT.spr[2].y = 0;
    rt_key(&RT, &P, "space"); RT.spr[0].x = 0; run(1);
    for (int i = 0; i < 40 && RT.var[0].n < 1.f; i++) { RT.spr[2].x = RT.spr[MAX_SPRITES].x; RT.spr[2].y = RT.spr[MAX_SPRITES].y; run(1); }
    assert(RT.var[0].n >= 1.f);

    tpl_build(&P, 4);
    rt_green_flag(&RT, &P); run(3);
    rt_pointer(&RT, 40, 30, 1); run(3); rt_pointer(&RT, 80, 60, 1); run(3);
    assert(RT.pen_count > 0);
    int n0 = RT.pen_count;
    rt_pointer(&RT, -80, -60, 0); run(5);
    assert(RT.pen_count == n0 || RT.pen_count == n0 + 1);
    rt_key(&RT, &P, "space"); run(2);
    assert(RT.pen_count == 0);

    tpl_build(&P, 5);
    rt_green_flag(&RT, &P); run(2);
    rt_key(&RT, &P, "left arrow"); run(2);
    int tones = 0; while (rt_pop_sound(&RT, &ev)) if (ev.sound == SND_TONE) tones++;
    assert(tones == 1);

    puts("all template tests passed");
    prj_clear(&P);
    return 0;
}
