#ifndef ASSETS_H
#define ASSETS_H

#include "project.h"

#define PAL_N 16
extern const uint32_t PALETTE_RGB[PAL_N];

static inline Px px_make(uint32_t rgb)
{
    return (Px)(0x8000u | (((rgb >> 19) & 31u) << 10) | (((rgb >> 11) & 31u) << 5) | ((rgb >> 3) & 31u));
}
static inline uint32_t px_rgb(Px p)
{
    uint32_t r = (p >> 10) & 31u, g = (p >> 5) & 31u, b = p & 31u;
    return ((r << 3 | r >> 2) << 16) | ((g << 3 | g >> 2) << 8) | (b << 3 | b >> 2);
}
static inline Px px_pal(int i) { return i > 0 && i < PAL_N ? px_make(PALETTE_RGB[i]) : (Px)0; }

void costume_clear(Costume *c);
void costume_make_default(Costume *c, int variant);
void costume_fill(Costume *c, int x, int y, Px color);
void costume_flip_h(Costume *c);
uint32_t costume_argb(Px p);
int  px_pal_index(Px p);

void costume_plot(Costume *c, int x, int y, Px color, int size);
void costume_line(Costume *c, int x0, int y0, int x1, int y1, Px color, int size);
void costume_rect(Costume *c, int x0, int y0, int x1, int y1, Px color, int size, int filled);
void costume_oval(Costume *c, int x0, int y0, int x1, int y1, Px color, int size, int filled);
Px   costume_get(const Costume *c, int x, int y);
void costume_grab(const Costume *c, int x0, int y0, int x1, int y1, Px *out);
void costume_clear_rect(Costume *c, int x0, int y0, int x1, int y1);
void costume_blit(Costume *c, const Px *src, int sw, int sh, int dx, int dy);

extern const char *const PALETTE_NAMES[PAL_N];
int      pal_find(const char *name);
uint32_t pen_rgb(float hue, float shade);
float    pen_hue_of(uint32_t rgb);

void        snd_default(Sound *s);
void        snd_free(Sound *s);
int         snd_is_recorded(const Sound *s);
int         snd_rate(const Sound *s);
int         snd_duration_ms(const Sound *s);
int         snd_set_pcm(Sound *s, const int16_t *pcm, int n, int rate);
const char *snd_wave_name(int wave);
void        snd_clamp(Sound *s);

int         snd_render(const Sound *s, int16_t *out, int max);

int         snd_trim(Sound *s);
int         snd_normalize(Sound *s);
int         snd_reverse(Sound *s);

#define SND_PRESET_COUNT 10
extern const char *const SND_PRESET_NAMES[SND_PRESET_COUNT];
int         snd_make_preset(Sound *s, int preset);

typedef struct { int16_t *buf; int n, max; uint32_t pos; int full, monitor; float level; } Recorder;
void rec_begin(Recorder *r, int16_t *buf, int max, int monitor);
int  rec_consume(Recorder *r, const uint8_t *ring, uint32_t ring_bytes, uint32_t write_off);

#endif
