
#include "sb_writer.h"
#include "assets.h"
#include "editor.h"

#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

enum {
    C_NIL = 1, C_TRUE = 2, C_FALSE = 3, C_INT32 = 4, C_INT16 = 5, C_FLOAT = 8,
    C_STRING = 9, C_SYMBOL = 10, C_BYTEARRAY = 11, C_SOUNDBUFFER = 12,
    C_ARRAY = 20, C_ORDCOLL = 21, C_DICT = 24,
    C_COLOR = 30, C_POINT = 32, C_RECT = 33, C_FORM = 34,
    C_REF = 99,
    C_SAMPLEDSOUND = 109, C_LISTMORPH = 175, C_SPRITE = 124, C_STAGE = 125, C_IMAGEMEDIA = 162, C_SOUNDMEDIA = 164,
};

#define VER_STAGE      5
#define VER_SPRITE     3
#define VER_IMAGEMEDIA 3
#define VER_SOUNDMEDIA 2
#define VER_SAMPLEDSOUND 1
#define VER_LISTMORPH  1

#ifndef SB_WRITE_LIST_MORPHS
#define SB_WRITE_LIST_MORPHS 1
#endif

typedef struct { uint8_t *d; size_t n, cap; int err; } Buf;

static void buf_put(Buf *b, const void *src, size_t len)
{
    if (b->err) return;
    if (b->n + len > b->cap) {
        size_t nc = b->cap ? b->cap : 256;
        while (nc < b->n + len) nc *= 2;
        uint8_t *nd = realloc(b->d, nc);
        if (!nd) { b->err = 1; return; }
        b->d = nd; b->cap = nc;
    }
    memcpy(b->d + b->n, src, len);
    b->n += len;
}
static void buf_u8(Buf *b, unsigned v)  { uint8_t x = (uint8_t)v; buf_put(b, &x, 1); }
static void buf_u16(Buf *b, unsigned v) { buf_u8(b, v >> 8); buf_u8(b, v); }
static void buf_u24(Buf *b, unsigned v) { buf_u8(b, v >> 16); buf_u8(b, v >> 8); buf_u8(b, v); }
static void buf_u32(Buf *b, uint32_t v) { buf_u8(b, v >> 24); buf_u8(b, v >> 16); buf_u8(b, v >> 8); buf_u8(b, v); }

typedef enum { F_NIL, F_TRUE, F_FALSE, F_INT, F_FLOAT, F_REF } FKind;
typedef struct { FKind k; int32_t i; double f; } Field;

typedef enum { O_BYTES, O_LIST, O_DICT, O_POINT, O_RECT, O_COLOR, O_USER } OKind;
typedef struct {
    OKind    kind;
    int      cls, version;
    int      nf;
    Field   *f;
    uint8_t *bytes;
    uint32_t blen;
    uint32_t rgb;
} Obj;

typedef struct { Obj *o; int n, cap; int err; } Table;

static Field F_nil(void)          { Field x = { F_NIL, 0, 0 }; return x; }
static Field F_bool(int v)        { Field x = { v ? F_TRUE : F_FALSE, 0, 0 }; return x; }
static Field F_int(int32_t v)     { Field x = { F_INT, v, 0 }; return x; }
static Field F_flt(double v)      { Field x = { F_FLOAT, 0, v }; return x; }
static Field F_ref(int idx)       { Field x = { F_REF, idx, 0 }; return x; }

static int t_add(Table *t, OKind kind, int cls, int version, int nf)
{
    if (t->err) return 0;
    if (t->n == t->cap) {
        int nc = t->cap ? t->cap * 2 : 64;
        Obj *no = realloc(t->o, nc * sizeof(Obj));
        if (!no) { t->err = 1; return 0; }
        t->o = no; t->cap = nc;
    }
    Obj *o = &t->o[t->n++];
    memset(o, 0, sizeof *o);
    o->kind = kind; o->cls = cls; o->version = version; o->nf = nf;
    if (nf > 0) {
        o->f = calloc(nf, sizeof(Field));
        if (!o->f) { t->err = 1; return 0; }
        for (int i = 0; i < nf; i++) o->f[i] = F_nil();
    }
    return t->n;
}
#define OBJ(t, idx) (&(t)->o[(idx) - 1])

#define SETF(t, idx, slot, val) do { Field _v = (val); OBJ(t, idx)->f[slot] = _v; } while (0)

static int t_bytes(Table *t, int cls, const void *src, uint32_t len)
{
    int idx = t_add(t, O_BYTES, cls, 0, 0);
    if (!idx) return 0;
    Obj *o = OBJ(t, idx);
    o->bytes = malloc(len ? len : 1);
    if (!o->bytes) { t->err = 1; return 0; }
    memcpy(o->bytes, src, len);
    o->blen = len;
    return idx;
}
static int t_str(Table *t, const char *s)  { return t_bytes(t, C_STRING, s, (uint32_t)strlen(s)); }
static int t_sym(Table *t, const char *s)  { return t_bytes(t, C_SYMBOL, s, (uint32_t)strlen(s)); }
static int t_list(Table *t, int cls, int n){ return t_add(t, O_LIST, cls, 0, n); }
static int t_dict(Table *t, int pairs)     { return t_add(t, O_DICT, C_DICT, 0, pairs * 2); }
static int t_point(Table *t, double x, double y)
{
    int idx = t_add(t, O_POINT, C_POINT, 0, 2);
    if (!idx) return 0;
    OBJ(t, idx)->f[0] = F_flt(x); OBJ(t, idx)->f[1] = F_flt(y);
    return idx;
}
static int t_rect(Table *t, int x0, int y0, int x1, int y1)
{
    int idx = t_add(t, O_RECT, C_RECT, 0, 4);
    if (!idx) return 0;
    Obj *o = OBJ(t, idx);
    o->f[0] = F_int(x0); o->f[1] = F_int(y0); o->f[2] = F_int(x1); o->f[3] = F_int(y1);
    return idx;
}
static int t_color(Table *t, uint32_t rgb)
{
    int idx = t_add(t, O_COLOR, C_COLOR, 0, 0);
    if (idx) OBJ(t, idx)->rgb = rgb;
    return idx;
}
static int t_user(Table *t, int cls, int ver, int nf) { return t_add(t, O_USER, cls, ver, nf); }

static void t_free(Table *t)
{
    for (int i = 0; i < t->n; i++) { free(t->o[i].f); free(t->o[i].bytes); }
    free(t->o);
    memset(t, 0, sizeof *t);
}

static void put_field(Buf *b, const Field *f)
{
    switch (f->k) {
    case F_NIL:   buf_u8(b, C_NIL);   break;
    case F_TRUE:  buf_u8(b, C_TRUE);  break;
    case F_FALSE: buf_u8(b, C_FALSE); break;
    case F_INT:
        if (f->i >= -32768 && f->i <= 32767) { buf_u8(b, C_INT16); buf_u16(b, (uint16_t)f->i); }
        else                                  { buf_u8(b, C_INT32); buf_u32(b, (uint32_t)f->i); }
        break;
    case F_FLOAT: {
        uint64_t bits; memcpy(&bits, &f->f, 8);
        buf_u8(b, C_FLOAT);
        buf_u32(b, (uint32_t)(bits >> 32)); buf_u32(b, (uint32_t)bits);
        break; }
    case F_REF:   buf_u8(b, C_REF); buf_u24(b, (unsigned)f->i); break;
    }
}

static unsigned to10(unsigned v8) { return (v8 << 2) | (v8 >> 6); }

static void put_object(Buf *b, const Obj *o)
{
    buf_u8(b, o->cls);
    switch (o->kind) {
    case O_BYTES:
        buf_u32(b, o->cls == C_SOUNDBUFFER ? o->blen / 2 : o->blen);
        buf_put(b, o->bytes, o->blen);
        break;
    case O_LIST:
        buf_u32(b, o->nf);
        for (int i = 0; i < o->nf; i++) put_field(b, &o->f[i]);
        break;
    case O_DICT:
        buf_u32(b, o->nf / 2);
        for (int i = 0; i < o->nf; i++) put_field(b, &o->f[i]);
        break;
    case O_POINT: case O_RECT:
        for (int i = 0; i < o->nf; i++) put_field(b, &o->f[i]);
        break;
    case O_COLOR: {
        uint32_t r = to10((o->rgb >> 16) & 255), g = to10((o->rgb >> 8) & 255), bl = to10(o->rgb & 255);
        buf_u32(b, (r << 20) | (g << 10) | bl);
        break; }
    case O_USER:
        buf_u8(b, o->version);
        buf_u8(b, o->nf);
        for (int i = 0; i < o->nf; i++) put_field(b, &o->f[i]);
        break;
    }
}

static void put_table(Buf *b, const Table *t)
{
    buf_put(b, "ObjS\x01Stch\x01", 10);
    buf_u32(b, (uint32_t)t->n);
    for (int i = 0; i < t->n; i++) put_object(b, &t->o[i]);
}

static void enc_int(Buf *b, uint32_t v)
{
    if (v <= 223)       buf_u8(b, v);
    else if (v <= 7935) { buf_u8(b, v / 256 + 224); buf_u8(b, v % 256); }
    else                { buf_u8(b, 255); buf_u32(b, v); }
}

static void compress_words(Buf *out, const uint32_t *w, uint32_t n)
{
    enc_int(out, n);
    uint32_t i = 0;
    while (i < n) {
        uint32_t run = 1;
        while (i + run < n && w[i + run] == w[i]) run++;
        if (run >= 3) {
            enc_int(out, (run << 2) | 2);
            buf_u32(out, w[i]);
            i += run;
        } else {
            uint32_t j = i;
            while (j < n) {
                uint32_t r = 1;
                while (j + r < n && w[j + r] == w[j]) r++;
                if (r >= 3) break;
                j += r;
            }
            uint32_t len = j - i;
            enc_int(out, (len << 2) | 3);
            for (uint32_t k = 0; k < len; k++) buf_u32(out, w[i + k]);
            i = j;
        }
    }
}

static int t_form(Table *t, int w, int h, const uint32_t *argb)
{
    Buf c = {0};
    compress_words(&c, argb, (uint32_t)(w * h));
    if (c.err) { t->err = 1; free(c.d); return 0; }
    int bits = t_bytes(t, C_BYTEARRAY, c.d, (uint32_t)c.n);
    free(c.d);
    int idx = t_add(t, O_USER, C_FORM, 0, 5);
    if (!idx || !bits) return 0;

    Obj *o = OBJ(t, idx);
    o->kind = O_POINT;
    o->f[0] = F_int(w);
    o->f[1] = F_int(h);
    o->f[2] = F_int(32);
    o->f[3] = F_nil();
    o->f[4] = F_ref(bits);
    return idx;
}

static uint32_t *make_backdrop(int w, int h)
{
    uint32_t *px = malloc((size_t)w * h * 4);
    if (!px) return NULL;
    for (size_t i = 0; i < (size_t)w * h; i++) px[i] = 0xFFFFFFFFu;
    return px;
}

static int parse_number(const char *s, double *out)
{
    while (*s == ' ') s++;
    if (!*s) return 0;
    char *end;
    double d = strtod(s, &end);
    while (*end == ' ') end++;
    if (*end || end == s || d != d) return 0;
    *out = d;
    return 1;
}

static int build_tuple(Table *t, const Script *sc, const Block *b, int body1, int body2, int depth);

static Field build_arg(Table *t, const Script *sc, char slot, const Arg *a, int depth)
{
    if (a->expr >= 0) {
        if (a->expr < MAX_EXPR && sc->ex_used[a->expr] && depth < MAX_EXPR + 2)
            return F_ref(build_tuple(t, sc, &sc->ex[a->expr], 0, 0, depth + 1));
        return F_int(0);
    }
    double d;
    switch (slot) {
    case 'b': return F_bool(0);
    case 'x': return F_ref(t_color(t, PALETTE_RGB[pal_find(a->text)]));
    case 'n':
        if (!a->text[0]) return F_int(0);
        if (parse_number(a->text, &d)) {
            if (d == floor(d) && fabs(d) < 2e9) return F_int((int32_t)d);
            return F_flt(d);
        }
        return F_ref(t_str(t, a->text));
    default:  return F_ref(t_str(t, a->text));
    }
}

static int build_tuple(Table *t, const Script *sc, const Block *b, int body1, int body2, int depth)
{
    const BlockInfo *bi = &BLOCK_INFO[b->kind];
    int ns = block_nslots(b->kind);
    int special = (b->kind == BK_HAT_FLAG || b->kind == BK_HAT_CLICK);
    int nargs = special ? 1 : ns;
    int nbody = bi->shape == SH_C ? 1 : (bi->shape == SH_CELSE ? 2 : 0);
    int tup = t_list(t, C_ARRAY, 1 + nargs + nbody);
    if (!tup) return 0;
    SETF(t, tup, 0, F_ref(t_sym(t, bi->selector)));
    for (int k = 0; k < nargs; k++) {
        if (special) SETF(t, tup, 1, F_ref(t_str(t, b->kind == BK_HAT_FLAG ? "Scratch-StartClicked" : "Scratch-MouseClickEvent")));
        else         SETF(t, tup, 1 + k, build_arg(t, sc, bi->slots[k], &b->a[k], depth));
    }
    if (nbody >= 1) SETF(t, tup, 1 + nargs, F_ref(body1));
    if (nbody >= 2) SETF(t, tup, 2 + nargs, F_ref(body2));
    return tup;
}

static int build_seq(Table *t, const Script *sc, int *pos)
{
    int refs[MAX_BLOCKS], n = 0;
    while (*pos < sc->nblocks && n < MAX_BLOCKS) {
        const Block *b = &sc->blocks[*pos];
        int shape = BLOCK_INFO[b->kind].shape;
        if (shape == SH_END || shape == SH_ELSE) break;
        (*pos)++;
        int body1 = 0, body2 = 0;
        if (shape == SH_C || shape == SH_CELSE) {
            body1 = build_seq(t, sc, pos);
            if (shape == SH_CELSE) {
                if (*pos < sc->nblocks && sc->blocks[*pos].kind == BK_ELSE) { (*pos)++; body2 = build_seq(t, sc, pos); }
                else body2 = t_list(t, C_ARRAY, 0);
            }
            if (*pos < sc->nblocks && sc->blocks[*pos].kind == BK_END) (*pos)++;
        }
        refs[n++] = build_tuple(t, sc, b, body1, body2, 0);
    }
    int arr = t_list(t, C_ARRAY, n);
    if (!arr) return 0;
    for (int i = 0; i < n; i++) SETF(t, arr, i, F_ref(refs[i]));
    return arr;
}

static int build_script(Table *t, const Script *s)
{
    int pair = t_list(t, C_ARRAY, 2);
    int pt   = t_point(t, s->x, s->y);
    int pos  = 0;
    int body = build_seq(t, s, &pos);
    if (!pair) return 0;
    SETF(t, pair, 0, F_ref(pt));
    SETF(t, pair, 1, F_ref(body));
    return pair;
}

static int build_media(Table *t, const char *name, int w, int h, const uint32_t *px)
{
    int form = t_form(t, w, h, px);
    int med  = t_user(t, C_IMAGEMEDIA, VER_IMAGEMEDIA, 6);
    int nm   = t_str(t, name);
    int rc   = t_point(t, w / 2.0, h / 2.0);
    if (!form || !med) return 0;
    Obj *m = OBJ(t, med);
    m->f[0] = F_ref(nm);
    m->f[1] = F_ref(form);
    m->f[2] = F_ref(rc);
    m->f[3] = F_nil();
    m->f[4] = F_nil();
    m->f[5] = F_nil();
    return med;
}

static int build_costume_media(Table *t, const Costume *c)
{
    const int W = COSTUME_W * COSTUME_SB_SCALE, H = COSTUME_H * COSTUME_SB_SCALE;
    uint32_t *px = malloc((size_t)W * H * 4);
    if (!px) { t->err = 1; return 0; }
    for (int y = 0; y < H; y++)
        for (int x = 0; x < W; x++)
            px[y * W + x] = costume_argb(c->px[(y / COSTUME_SB_SCALE) * COSTUME_W + (x / COSTUME_SB_SCALE)]);
    int med = build_media(t, c->name, W, H, px);
    free(px);
    return med;
}

static int build_sound_media(Table *t, const Sound *snd)
{
    int16_t *pcm = malloc(SND_BUF_MAX * sizeof(int16_t));
    uint8_t *be  = malloc(SND_BUF_MAX * 2);
    if (!pcm || !be) { free(pcm); free(be); t->err = 1; return 0; }
    int n = snd_render(snd, pcm, SND_BUF_MAX);
    int rate = snd_rate(snd);
    for (int i = 0; i < n; i++) { be[2 * i] = (uint8_t)((uint16_t)pcm[i] >> 8); be[2 * i + 1] = (uint8_t)pcm[i]; }
    int buf = t_bytes(t, C_SOUNDBUFFER, be, (uint32_t)n * 2);
    free(pcm); free(be);

    int env = t_list(t, C_ARRAY, 0);
    int ss  = t_user(t, C_SAMPLEDSOUND, VER_SAMPLEDSOUND, 8);
    int nm  = t_str(t, snd->name);
    int med = t_user(t, C_SOUNDMEDIA, VER_SOUNDMEDIA, 7);
    if (t->err || !buf || !ss || !med) return 0;

    SETF(t, ss, 0, F_ref(env));
    SETF(t, ss, 1, F_int(32768));
    SETF(t, ss, 2, F_int(0));
    SETF(t, ss, 3, F_ref(buf));
    SETF(t, ss, 4, F_int(rate));
    SETF(t, ss, 5, F_int(n));
    SETF(t, ss, 6, F_int((int32_t)((int64_t)rate * 32768 / 22050)));
    SETF(t, ss, 7, F_int(0));

    SETF(t, med, 0, F_ref(nm));
    SETF(t, med, 1, F_ref(ss));
    SETF(t, med, 2, F_int(100));
    SETF(t, med, 3, F_int(50));
    SETF(t, med, 4, F_nil());
    SETF(t, med, 5, F_nil());
    SETF(t, med, 6, F_nil());
    return med;
}

static int build_sprite(Table *t, const Project *p, int si, int sprite, int stage)
{
    const Sprite *s = &p->sprites[si];
    const int CW = COSTUME_W * COSTUME_SB_SCALE, CH = COSTUME_H * COSTUME_SB_SCALE;

    int media = t_list(t, C_ARRAY, s->ncostumes + s->nsounds);
    int cur = 0;
    for (int c = 0; c < s->ncostumes; c++) {
        int m = build_costume_media(t, &s->costumes[c]);
        if (!m) return -1;
        SETF(t, media, c, F_ref(m));
        if (c == s->cur_costume) cur = m;
    }
    for (int k = 0; k < s->nsounds; k++) {
        int m = build_sound_media(t, &s->sounds[k]);
        if (!m) return -1;
        SETF(t, media, s->ncostumes + k, F_ref(m));
    }
    if (t->err) return -1;

    int cx = STAGE_W / 2 + s->x, cy = STAGE_H / 2 - s->y;
    int bw = CW * (s->size > 0 ? s->size : 100) / 100, bh = CH * (s->size > 0 ? s->size : 100) / 100;
    SETF(t, sprite, 0, F_ref(t_rect(t, cx - bw / 2, cy - bh / 2, cx + bw / 2, cy + bh / 2)));
    SETF(t, sprite, 1, F_ref(stage));
    SETF(t, sprite, 2, F_ref(t_list(t, C_ARRAY, 0)));
    SETF(t, sprite, 3, F_ref(t_color(t, 0xFFFFFF)));
    SETF(t, sprite, 4, F_int(0));
    SETF(t, sprite, 5, F_nil());

    SETF(t, sprite, 6, F_ref(t_str(t, s->name)));
    SETF(t, sprite, 7, F_ref(t_dict(t, 0)));
    int bin = t_list(t, C_ARRAY, s->nscripts);
    for (int i = 0; i < s->nscripts; i++) {
        int sc = build_script(t, &s->scripts[i]);
        SETF(t, bin, i, F_ref(sc));
    }
    SETF(t, sprite, 8, F_ref(bin));
    SETF(t, sprite, 9, F_bool(0));
    SETF(t, sprite, 10, F_ref(media));
    SETF(t, sprite, 11, F_ref(cur));

    SETF(t, sprite, 12, F_int(s->visible ? 100 : 0));
    { double sc = s->size > 0 ? s->size / 100.0 : 1.0; SETF(t, sprite, 13, F_ref(t_point(t, sc, sc))); }
    SETF(t, sprite, 14, F_flt((double)(s->direction - 90)));
    SETF(t, sprite, 15, F_int(1));
    SETF(t, sprite, 16, F_flt(100.0));
    SETF(t, sprite, 17, F_int(60));
    SETF(t, sprite, 18, F_bool(0));
    SETF(t, sprite, 19, F_nil());
    SETF(t, sprite, 20, F_ref(t_dict(t, 0)));
    return t->err ? -1 : 0;
}

static int build_vars(Table *t, const Project *p)
{
    int d = t_dict(t, p->nvars);
    if (!d) return 0;
    for (int i = 0; i < p->nvars; i++) {
        int k = t_str(t, p->vars[i].name);
        double v;
        Field val;
        if (parse_number(p->vars[i].init, &v)) val = (v == floor(v) && fabs(v) < 2e9) ? F_int((int32_t)v) : F_flt(v);
        else val = F_ref(t_str(t, p->vars[i].init));
        SETF(t, d, 2 * i, F_ref(k));
        SETF(t, d, 2 * i + 1, val);
    }
    return d;
}

static int build_lists(Table *t, const Project *p, int stage)
{
    int d = t_dict(t, p->nlists);
    if (!d) return 0;
    for (int i = 0; i < p->nlists; i++) {
        int k = t_str(t, p->lists[i].name);
        SETF(t, d, 2 * i, F_ref(k));
#if SB_WRITE_LIST_MORPHS

        int lm = t_user(t, C_LISTMORPH, VER_LISTMORPH, 9);
        if (!lm) return 0;
        SETF(t, lm, 0, F_ref(t_rect(t, 0, 0, 100, 120)));
        SETF(t, lm, 1, F_nil());
        SETF(t, lm, 2, F_ref(t_list(t, C_ARRAY, 0)));
        SETF(t, lm, 3, F_ref(t_color(t, 0xFFFFFF)));
        SETF(t, lm, 4, F_int(0));
        SETF(t, lm, 5, F_nil());
        SETF(t, lm, 6, F_ref(t_str(t, p->lists[i].name)));
        SETF(t, lm, 7, F_ref(t_list(t, C_ORDCOLL, 0)));
        SETF(t, lm, 8, F_ref(stage));
        SETF(t, d, 2 * i + 1, F_ref(lm));
#else
        (void)stage;
        SETF(t, d, 2 * i + 1, F_nil());
#endif
    }
    return d;
}

static int build_contents(Table *t, const Project *p)
{

    int stage = t_user(t, C_STAGE, VER_STAGE, 21);
    int spr[MAX_SPRITES];
    for (int i = 0; i < p->nsprites; i++) spr[i] = t_user(t, C_SPRITE, VER_SPRITE, 21);

    uint32_t *bpx = make_backdrop(STAGE_W, STAGE_H);
    if (!bpx) return -1;
    int bg = build_media(t, "backdrop1", STAGE_W, STAGE_H, bpx);
    free(bpx);
    if (t->err || !stage || !bg) return -1;

    SETF(t, stage, 0, F_ref(t_rect(t, 0, 0, STAGE_W, STAGE_H)));
    SETF(t, stage, 1, F_nil());
    int ssub = t_list(t, C_ARRAY, p->nsprites);
    for (int i = 0; i < p->nsprites; i++) SETF(t, ssub, i, F_ref(spr[i]));
    SETF(t, stage, 2, F_ref(ssub));
    SETF(t, stage, 3, F_ref(t_color(t, 0xFFFFFF)));
    SETF(t, stage, 4, F_int(0));
    SETF(t, stage, 5, F_nil());

    SETF(t, stage, 6, F_ref(t_str(t, "Stage")));
    SETF(t, stage, 7, F_ref(build_vars(t, p)));
    SETF(t, stage, 8, F_ref(t_list(t, C_ARRAY, 0)));
    SETF(t, stage, 9, F_bool(0));
    int smedia = t_list(t, C_ARRAY, 1);
    SETF(t, smedia, 0, F_ref(bg));
    SETF(t, stage, 10, F_ref(smedia));
    SETF(t, stage, 11, F_ref(bg));

    SETF(t, stage, 12, F_flt(1.0));
    SETF(t, stage, 13, F_flt(0.0));
    SETF(t, stage, 14, F_flt(0.0));
    SETF(t, stage, 15, F_nil());
    int sprs = t_list(t, C_ORDCOLL, p->nsprites);
    for (int i = 0; i < p->nsprites; i++) SETF(t, sprs, i, F_ref(spr[i]));
    SETF(t, stage, 16, F_ref(sprs));
    SETF(t, stage, 17, F_flt(100.0));
    SETF(t, stage, 18, F_int(60));
    SETF(t, stage, 19, F_nil());
    SETF(t, stage, 20, F_ref(build_lists(t, p, stage)));

    for (int i = 0; i < p->nsprites; i++)
        if (build_sprite(t, p, i, spr[i], stage) != 0) return -1;
    return t->err ? -1 : 0;
}

static int build_info(Table *t, const char *author)
{
    int d = t_dict(t, 3);
    if (!d) return -1;
    int k0 = t_str(t, "author"),   v0 = t_str(t, author);
    int k1 = t_str(t, "comment"),  v1 = t_str(t, "Made with ScratchEdit3DS");
    int k2 = t_str(t, "scratch-version"), v2 = t_str(t, "1.4 of 30-Jun-09");
    Obj *o = OBJ(t, d);
    o->f[0] = F_ref(k0); o->f[1] = F_ref(v0);
    o->f[2] = F_ref(k1); o->f[3] = F_ref(v1);
    o->f[4] = F_ref(k2); o->f[5] = F_ref(v2);
    return t->err ? -1 : 0;
}

int sb_write_project(const Project *p, const char *path, const char *author)
{
    Table info = {0}, cont = {0};
    Buf ib = {0}, cb = {0};
    int rc = -1;

    if (build_info(&info, author ? author : "3DS") != 0) goto done;
    if (build_contents(&cont, p) != 0) goto done;

    put_table(&ib, &info);
    put_table(&cb, &cont);
    if (ib.err || cb.err) goto done;

    FILE *f = fopen(path, "wb");
    if (!f) goto done;
    uint8_t len[4] = { ib.n >> 24, ib.n >> 16, ib.n >> 8, ib.n };
    int ok = fwrite("ScratchV02", 1, 10, f) == 10
          && fwrite(len, 1, 4, f) == 4
          && fwrite(ib.d, 1, ib.n, f) == ib.n
          && fwrite(cb.d, 1, cb.n, f) == cb.n;
    ok = (fclose(f) == 0) && ok;
    rc = ok ? 0 : -1;

done:
    free(ib.d); free(cb.d);
    t_free(&info); t_free(&cont);
    return rc;
}
