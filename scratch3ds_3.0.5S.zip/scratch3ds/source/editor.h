
#ifndef EDITOR_H
#define EDITOR_H

#include "project.h"

void prj_init(Project *p);
void prj_clear(Project *p);

int  prj_add_sprite(Project *p);
int  prj_delete_sprite(Project *p, int sp);
int  prj_duplicate_sprite(Project *p, int sp);
int  prj_move_sprite(Project *p, int sp, int delta);
int  prj_add_imported(Project *p, Sprite *s);
void prj_rename_sprite(Project *p, int sp, const char *name);

int  prj_add_costume(Project *p, int sp);
int  prj_delete_costume(Project *p, int sp, int c);
int  prj_find_costume(const Sprite *s, const char *name);
int  prj_rename_costume(Project *p, int sp, int c, const char *name);

int  prj_add_sound(Project *p, int sp);
int  prj_add_recording(Project *p, int sp, const int16_t *pcm, int n, int rate);
int  prj_add_effect(Project *p, int sp, int preset);
int  prj_duplicate_sound(Project *p, int sp, int snd);
int  prj_delete_sound(Project *p, int sp, int snd);
int  prj_find_sound(const Sprite *s, const char *name);
int  prj_rename_sound(Project *p, int sp, int snd, const char *name);

int  prj_add_var(Project *p, const char *name);
int  prj_delete_var(Project *p, int i);
int  prj_find_var(const Project *p, const char *name);
int  prj_add_list(Project *p, const char *name);
int  prj_delete_list(Project *p, int i);
int  prj_find_list(const Project *p, const char *name);

int  prj_new_script(Project *p, int sp, BlockKind hat);
int  prj_delete_script(Project *p, int sp, int s);

int  prj_insert_block(Project *p, int sp, int s, int after, BlockKind k);

int  prj_delete_block(Project *p, int sp, int s, int b);

int  prj_move_block(Project *p, int sp, int s, int from, int after);
int  prj_match_end(const Script *s, int head);
int  prj_match_else(const Script *s, int head);
int  prj_indent(const Script *s, int b);

Block *prj_node(Script *s, int blk, const int *path, int depth);

int  prj_plug(Project *p, int sp, Script *s, Block *node, int slot, BlockKind kind, const char *param);
int  prj_unplug(Script *s, Block *node, int slot);
void prj_fill_defaults(const Project *p, int sp, Block *b);

void prj_format_block(const Script *s, const Block *b, char *out, int outlen);
void prj_format_arg(const Script *s, const Arg *a, char slot, char *out, int outlen);

#define MENU_MAX 48
int  prj_menu_items(const Project *p, int sp, char slot, char out[][TEXT_LEN], int max);
int  slot_is_text(char slot);
int  slot_is_menu(char slot);

void prj_rename_refs(Project *p, int scope, const char *slots, const char *oldv, const char *newv);

extern const char *const KEY_NAMES[KEY_NAME_COUNT];
int  key_index(const char *name);

#define UNDO_DEPTH 20
typedef struct { int sp; int nscripts; Script *sc; } UndoSnap;
typedef struct {
    UndoSnap undo[UNDO_DEPTH]; int nundo;
    UndoSnap redo[UNDO_DEPTH]; int nredo;
} UndoStack;
void undo_clear(UndoStack *u);

void undo_checkpoint(UndoStack *u, const Project *p, int sp);
void undo_discard(UndoStack *u);

int  undo_undo(UndoStack *u, Project *p);
int  undo_redo(UndoStack *u, Project *p);

int  prj_duplicate_script(Project *p, int sp, int s);

int  prj_duplicate_block(Project *p, int sp, int s, int b);

#endif
