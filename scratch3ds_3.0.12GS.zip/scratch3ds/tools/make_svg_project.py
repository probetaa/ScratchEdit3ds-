import hashlib
import json
import struct
import sys
import zipfile
import zlib

SVG = b"""<svg version="1.1" width="96" height="100" viewBox="-1 -1 96 100" xmlns="http://www.w3.org/2000/svg">
<g transform="translate(0.5,0.5)"><g>
<path d="M47.5 3 C70 3 90 20 90 45 C90 75 70 95 47.5 95 C25 95 5 75 5 45 C5 20 25 3 47.5 3 Z" fill="#ffab19" stroke="#cf8b17" stroke-width="3" stroke-linecap="round"/>
<circle cx="33" cy="38" r="8" fill="#fff" stroke="#000" stroke-width="2"/>
<ellipse cx="62" cy="38" rx="8" ry="10" fill="#fff" style="stroke:#000;stroke-width:2"/>
<path d="M30 65 q17.5 20 35 0" fill="none" stroke="#7a2500" stroke-width="4" stroke-linecap="round"/>
<polygon points="10,10 30,5 25,25" fill="rgb(80,160,255)" fill-opacity="0.6"/>
<path d="M60 70 a15 10 0 1 0 20 0 z" fill="#2a2" fill-rule="evenodd"/>
</g></g></svg>"""


def png(w, h, fn):
    raw = b""
    for y in range(h):
        raw += b"\0" + b"".join(bytes(fn(x, y)) for x in range(w))

    def chunk(t, d):
        c = struct.pack(">I", len(d)) + t + d
        return c + struct.pack(">I", zlib.crc32(t + d) & 0xFFFFFFFF)

    return b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", struct.pack(">IIBBBBB", w, h, 8, 6, 0, 0, 0)) + chunk(b"IDAT", zlib.compress(raw)) + chunk(b"IEND", b"")


big = png(480, 360, lambda x, y: (x * 255 // 480, y * 255 // 360, 128, 255 if (x - 240) ** 2 + (y - 180) ** 2 < 150 ** 2 else 0))


STEP = [7, 8, 9, 10, 11, 12, 13, 14, 16, 17, 19, 21, 23, 25, 28, 31, 34, 37, 41, 45, 50, 55, 60, 66, 73, 80, 88, 97, 107, 118, 130, 143,
        157, 173, 190, 209, 230, 253, 279, 307, 337, 371, 408, 449, 494, 544, 598, 658, 724, 796, 876, 963, 1060, 1166, 1282, 1411, 1552,
        1707, 1878, 2066, 2272, 2499, 2749, 3024, 3327, 3660, 4026, 4428, 4871, 5358, 5894, 6484, 7132, 7845, 8630, 9493, 10442, 11487,
        12635, 13899, 15289, 16818, 18500, 20350, 22385, 24623, 27086, 29794, 32767]
IDX = [-1, -1, -1, -1, 2, 4, 6, 8, -1, -1, -1, -1, 2, 4, 6, 8]


def ima_wav(samples, rate):
    block_samples = 505
    block_align = 256
    out = b""
    pred, idx = 0, 0
    for start in range(0, len(samples), block_samples):
        blk = samples[start:start + block_samples]
        blk = blk + [blk[-1]] * (block_samples - len(blk))
        pred, idx = blk[0], idx
        data = struct.pack("<hBB", pred, idx, 0)
        nibs = []
        for v in blk[1:]:
            step = STEP[idx]
            diff = v - pred
            nib = 0
            if diff < 0:
                nib = 8
                diff = -diff
            t = step
            if diff >= t:
                nib |= 4
                diff -= t
            t >>= 1
            if diff >= t:
                nib |= 2
                diff -= t
            t >>= 1
            if diff >= t:
                nib |= 1
            d = step >> 3
            if nib & 1:
                d += step >> 2
            if nib & 2:
                d += step >> 1
            if nib & 4:
                d += step
            pred = max(-32768, min(32767, pred - d if nib & 8 else pred + d))
            idx = max(0, min(88, idx + IDX[nib]))
            nibs.append(nib)
        for i in range(0, len(nibs), 2):
            data += bytes([nibs[i] | (nibs[i + 1] << 4)])
        out += data.ljust(block_align, b"\0")
    fmt = struct.pack("<HHIIHHHH", 0x11, 1, rate, rate * block_align // block_samples, block_align, 4, 2, block_samples)
    body = b"WAVE" + b"fmt " + struct.pack("<I", len(fmt)) + fmt + b"data" + struct.pack("<I", len(out)) + out
    return b"RIFF" + struct.pack("<I", len(body)) + body


import math
tone = [int(12000 * math.sin(2 * math.pi * 440 * i / 22050)) for i in range(11025)]
ADPCM = ima_wav(tone, 22050)


def md5(b):
    return hashlib.md5(b).hexdigest()


def costume(name, data, ext, rc, res=None):
    d = {"assetId": md5(data), "name": name, "md5ext": md5(data) + "." + ext, "dataFormat": ext, "rotationCenterX": rc[0], "rotationCenterY": rc[1]}
    if res:
        d["bitmapResolution"] = res
    return d


def target(name, stage, cost, layer, **kw):
    t = {"isStage": stage, "name": name, "variables": {}, "lists": {}, "broadcasts": {}, "blocks": {}, "comments": {}, "currentCostume": 0,
         "costumes": [cost], "sounds": [], "volume": 100, "layerOrder": layer}
    t.update(kw)
    return t


sprite = dict(visible=True, x=0, y=0, size=100, direction=90, draggable=False, rotationStyle="all around")
proj = {"targets": [
    target("Stage", True, costume("bg", big, "png", (240, 180), 1), 0),
    target("Cat", False, costume("cat", SVG, "svg", (48, 50)), 1, **sprite, sounds=[{"assetId": md5(ADPCM), "name": "pop", "dataFormat": "wav", "format": "adpcm", "rate": 22050, "sampleCount": 11025, "md5ext": md5(ADPCM) + ".wav"}]),
    target("Big", False, costume("big", big, "png", (240, 180), 1), 2, **dict(sprite, x=50, y=50, size=50)),
], "monitors": [], "extensions": [], "meta": {"semver": "3.0.0", "vm": "0.2.0", "agent": "test"}}
with zipfile.ZipFile(sys.argv[1], "w", zipfile.ZIP_DEFLATED) as z:
    z.writestr("project.json", json.dumps(proj))
    z.writestr(md5(SVG) + ".svg", SVG)
    z.writestr(md5(big) + ".png", big)
    z.writestr(md5(ADPCM) + ".wav", ADPCM)
