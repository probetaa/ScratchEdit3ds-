#ifndef TEMPLATES_H
#define TEMPLATES_H

#include "project.h"

int         tpl_count(void);
const char *tpl_name(int i);
const char *tpl_info(int i);
int         tpl_build(Project *p, int i);

#endif
