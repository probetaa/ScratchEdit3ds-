# ScratchEdit3DS — version history

Version codes: **BR** beta release (debugged major release, emulator-tested) · **BE** beta (debugged minor release, emulator-tested, not on real hardware) · **NS** not stable (newest build, not tested on real hardware) · **S** stable (recommended) · **GS** GitHub sandbox build (the one published on GitHub).


## v3.0.12GS

- Added: debug mode. Hold L and R and press Y to turn it on or off. A panel on the top screen shows version, FPS and frame time, mode, sprites, clones, running scripts, stamps, pen segments, drawn rectangles (out of 6500), free linear memory and the last status message. While it is on, every status message and a summary line every 4 seconds are appended to sd:/3ds/scratch-editor/debug.log
- Fixed: the costume editor kept the last edit of the previous project, and Undo in Costumes brought back the old sprite 1 picture. The costume editor state (undo, selection, view) is now reset when a project is replaced, a sprite is selected, moved or deleted, and when a costume is switched, added or deleted
- Changed: this build is the stable line of 3.0.12 (was 3.0.12NS)

## v3.0.12NS

- Fixed: after opening another project (or a template, or leaving Play), the costume editor kept the last edit of the previous project, and Undo in Costumes brought back the old sprite 1 picture. The costume editor state (undo, selection, view) is now reset when a project is replaced, a sprite is selected, moved or deleted, and when a costume is switched, added or deleted

## v3.0.11NS

- Fixed: graphic effects now show on the stage and on stamps. Before, only ghost was drawn; color, fisheye, whirl, pixelate, mosaic and brightness were stored but ignored. Effect names are matched without regard to case, and stamps keep the sprite's effects
- Changed: costumes are 96×96 pixels in 15-bit colour (they were 32×32 with 16 colours); opening a project scales sprites to fit, keeps their size and rotation centre, and backdrops fill the stage
- Added: drawing tools: RGB colour, eyedropper, line, rectangle and ellipse (solid or outline), select / copy / cut / paste / delete, bigger brushes, zoom
- Added: SVG costumes are read and rasterized when opening an .sb3 (before, they were skipped and sprites came out empty)
- Added: IMA ADPCM .wav sounds are decoded when opening an .sb3 (not yet covered by an automated test)
- Changed: a saved backdrop is written as an SVG made of merged rectangles; costumes as 96×96 PNG
- Changed: the draw budget limits how many rectangles are drawn per frame; very detailed sprites may be shown with lower detail

## v3.0.10NS

- Fixed: costumes came back completely black when opening a saved .sb3 (and when importing sprite images) on the console: the palette matching used a 40-bit shift that overflows the 3DS 32-bit long; it now uses 32-bit integers, and the tests check that no source file shifts by 32 bits or more

## v3.0.9NS

- Added: block search ("Find" button under the palette): type part of a name and the palette lists matching blocks from every category; tapping a category clears it
- Added: import report: after opening a project, a list shows how many blocks, inputs, scripts, costumes, sounds, variables or sprites were skipped, and the names of the unsupported blocks
- Added: autosave: every 3 minutes (if you did something) and when you exit with SELECT, the project is written to autosave.sb3; the app tells you at start if one exists, and you can recover it from Spr > Open project
- Added: script list: tap the "S1/N" box to jump to any script of the sprite
- Changed: 24 scripts per sprite (was 12); the project in memory is larger (about 2.4 MB)

## v3.0.8NS

- Added: Make a Block (custom blocks) in the new "More" category: "+ Make a Block" creates a `define` script with up to 3 inputs (text/number or boolean); the block and its inputs then appear in the palette, calls can be nested and recursive
- Added: custom blocks are written to .sb3 as real Scratch 3 custom blocks (checked by running them in scratch-vm) and read back when a project is opened or played
- Changed: 12 scripts per sprite (was 8); script runs can nest up to 12 custom block calls; the project in memory is larger (about 1.2 MB instead of 0.6 MB)
- Not included: editing an existing custom block, "run without screen refresh", custom blocks in the old .sb format (skipped there)

## v3.0.7NS

- Added: Spr menu > "Open project (.sb3)..." loads a saved .sb3 so it can be edited again, and "Play project (.sb3)..." runs one without replacing the project being edited (B returns to it)
- Added: the reader understands every block the editor can write; unsupported blocks, SVG costumes that are not plain rectangles, non-WAV sounds and anything that does not fit are skipped and counted in the status line
- Changed: "Import ALL" moved to the second page of the Spr menu

## v3.0.6NS

- Added the Scratch 2 blocks: `switch backdrop to`, `next backdrop`, `backdrop #`, `backdrop name`, the hat `when backdrop switches to`, `set rotation style`, `stop other scripts in sprite`, `current (year/month/date/day of week/hour/minute/second)`, `days since 2000` and `username` (empty on 3DS)
- Rotation style is stored and exported to .sb3, but sprites are not drawn rotated on screen yet
- Not added: video sensing, "Make a Block" and cloud variables

## v3.0.5S

- Removed: camera support (the Camera button in Costumes and the `cam:u` permission)

## v3.0.4NS

- Changed: when the camera can't start, the status line now names the step that failed and its error code (e.g. `Camera failed: Activate 0xE0E...`), to find out why it fails on real hardware

## v3.0.3NS

- Fixed: a sprite could be sent off the stage without limit (e.g. `forever move 10`), and its pen trail with it, which broke the drawing of the whole screen. Like Scratch, at least a few pixels of the sprite now always stay on the stage

## v3.0.2NS

- Added: ^ / v buttons beside the script to slide the view page by page in long scripts (the selected block does not change)
- Added: D-pad left switches the interface between dark and light theme (outside a run)
- Removed: the `light` PicoBoard channel and its D-pad toggle; D-pad right now wraps through a block's arguments

## v3.0.1NS

- Added: `pen down?` block (Pen category), usable inside `if`; it only works inside ScratchEdit3DS and is empty (false) when opened in Scratch 3

## v3.0.0BR

- Added: PicoBoard sensor blocks (Circle Pad, touch, microphone, A button, light via D-pad left)
- Added: Colour sensors work, with an eyedropper
- Added: D-pad up: stage on the bottom screen, move sprites
- Added: New 3DS: faster CPU switched on automatically
- Added: Blocks drawn as puzzle pieces
- Added: Top / End buttons to jump around long scripts
- Added: This About tab and the version history
- Fixed: go to / point towards mouse-pointer do nothing when the screen is not touched
- Fixed: pen down draws a dot, like Scratch
- Fixed: the direction line is no longer drawn while a project runs

## v2.0.0NS

- Added: Drag and drop of blocks with the stylus
- Added: Undo / redo and duplicate
- Added: Clones, 6 starter templates
- Added: Camera costumes, preset sound effects
- Added: Keyboard and numeric keypad input

## v1.0.0NS

- Added: First version: block editor with the Scratch 1.x blocks, saved as .sb3 (and .sb)
- Added: Several sprites and a Stage with backdrops
- Added: Pixel costume editor, sound editor, microphone
- Added: Run the project on either screen

Known issues: camera, microphone and sound are
