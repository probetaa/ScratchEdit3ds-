

const fs=require('fs');const VM=require('scratch-vm');const S=require('scratch-storage').ScratchStorage;
(async()=>{const vm=new VM();vm.attachStorage(new S());
vm.runtime.on('PROJECT_RUN_START',()=>{});
await vm.loadProject(fs.readFileSync(process.argv[2]));
vm.start();
vm.greenFlag();
await new Promise(r=>setTimeout(r,1500));
console.log('threads',vm.runtime.threads.length);
for(const t of vm.runtime.targets) if(!t.isStage) console.log(t.getName(),'x',Math.round(t.x),'y',Math.round(t.y),'dir',t.direction,'size',t.size,'visible',t.visible);
console.log(JSON.stringify(vm.runtime.targets[1].variables? Object.values(vm.runtime.targets[0].variables).map(v=>[v.name,v.value]):0));
process.exit(0)})();
