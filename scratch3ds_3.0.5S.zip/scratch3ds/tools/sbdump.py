#!/usr/bin/env python3
"""sbdump.py - structural reader/validator for Scratch 1.x (.sb) files.

Usage:  python3 sbdump.py FILE.sb [--objects]

It checks the header, both object tables, that every reference is in range,
that the whole file is consumed, and that the root of the contents table is a
ScratchStageMorph. It then prints the scripts of every sprite.

Run it on a file saved by *real* Scratch 1.4 as well: the "class/version/
fields" lines let you compare against what sb_writer.c emits and fix the
VER_* constants if they differ.
"""
import os
import re
import struct
import sys

USER_NAMES = {
    100: "Morph", 109: "SampledSound", 124: "ScratchSpriteMorph", 125: "ScratchStageMorph",
    155: "WatcherMorph", 162: "ImageMedia", 164: "SoundMedia", 175: "ScratchListMorph",
}
FIXED_NAMES = {
    9: "String", 10: "Symbol", 11: "ByteArray", 12: "SoundBuffer", 13: "Bitmap",
    14: "UTF8", 20: "Array", 21: "OrderedCollection", 22: "Set", 23: "IdentitySet",
    24: "Dictionary", 25: "IdentityDictionary", 30: "Color", 31: "TranslucentColor",
    32: "Point", 33: "Rectangle", 34: "Form", 35: "ColorForm",
}

class Ref:
    def __init__(self, idx):
        self.idx = idx

    def __repr__(self):
        return f"#{self.idx}"

class Reader:
    def __init__(self, data, pos=0):
        self.d, self.p = data, pos

    def take(self, n):
        if self.p + n > len(self.d):
            raise ValueError(f"unexpected end of data at {self.p}")
        b = self.d[self.p:self.p + n]
        self.p += n
        return b

    def u8(self):  return self.take(1)[0]
    def u16(self): return struct.unpack(">H", self.take(2))[0]
    def u24(self): return int.from_bytes(self.take(3), "big")
    def u32(self): return struct.unpack(">I", self.take(4))[0]

    def field(self):
        c = self.u8()
        if c == 1: return None
        if c == 2: return True
        if c == 3: return False
        if c == 4: return struct.unpack(">i", self.take(4))[0]
        if c == 5: return struct.unpack(">h", self.take(2))[0]
        if c in (6, 7):
            n = self.u16()
            v = int.from_bytes(self.take(n), "little")
            return v if c == 6 else -v
        if c == 8: return struct.unpack(">d", self.take(8))[0]
        if c == 99: return Ref(self.u24())
        raise ValueError(f"bad field class id {c} at {self.p - 1}")

    def fields(self, n):
        return [self.field() for _ in range(n)]

def read_table(r):
    if r.take(10) != b"ObjS\x01Stch\x01":
        raise ValueError("bad object-table header")
    n = r.u32()
    objs = []
    for i in range(n):
        c = r.u8()
        o = {"cls": c, "ver": None}
        if c in (9, 10, 11, 14):
            ln = r.u32(); o["val"] = r.take(ln)
        elif c == 12:
            ln = r.u32(); o["val"] = r.take(ln * 2)
        elif c == 13:
            ln = r.u32(); o["val"] = r.take(ln * 4)
        elif c in (20, 21, 22, 23):
            o["val"] = r.fields(r.u32())
        elif c in (24, 25):
            ln = r.u32(); o["val"] = r.fields(ln * 2)
        elif c == 30:
            o["val"] = r.u32()
        elif c == 31:
            o["val"] = (r.u32(), r.u8())
        elif c == 32:
            o["val"] = r.fields(2)
        elif c == 33:
            o["val"] = r.fields(4)
        elif c == 34:
            o["val"] = r.fields(5)
        elif c == 35:
            o["val"] = r.fields(6)
        elif c >= 100:
            o["ver"] = r.u8(); ln = r.u8(); o["val"] = r.fields(ln)
        else:
            raise ValueError(f"unknown class id {c} (object {i + 1})")
        objs.append(o)

    for i, o in enumerate(objs, 1):
        vals = o["val"] if isinstance(o["val"], list) else []
        for v in vals:
            if isinstance(v, Ref) and not (1 <= v.idx <= n):
                raise ValueError(f"object {i}: reference {v} out of range (n={n})")
    return objs

def dec_int(b, p):
    v = b[p]
    if v <= 223:
        return v, p + 1
    if v <= 254:
        return (v - 224) * 256 + b[p + 1], p + 2
    return int.from_bytes(b[p + 1:p + 5], "big"), p + 5

def decompress_bitmap(b):
    """Squeak Bitmap compression: size, then runs coded as (n<<2)|type."""
    n, p = dec_int(b, 0)
    words = []
    while len(words) < n:
        code, p = dec_int(b, p)
        run, kind = code >> 2, code & 3
        if kind == 0:
            words += [0] * run
        elif kind == 1:
            words += [int.from_bytes(bytes([b[p]]) * 4, "big")] * run; p += 1
        elif kind == 2:
            words += [int.from_bytes(b[p:p + 4], "big")] * run; p += 4
        else:
            for _ in range(run):
                words.append(int.from_bytes(b[p:p + 4], "big")); p += 4
    if len(words) != n or p != len(b):
        raise ValueError("bitmap data inconsistent")
    return words

def name(o):
    c = o["cls"]
    return FIXED_NAMES.get(c) or USER_NAMES.get(c) or f"class{c}"

def text(o):
    return o["val"].decode("latin-1")

def resolve(objs, v, depth=0):
    """Readable tree of a value (used for scripts)."""
    if isinstance(v, Ref):
        o = objs[v.idx - 1]
        c = o["cls"]
        if c in (9, 10):
            return text(o) if c == 9 else "#" + text(o)
        if c in (20, 21):
            return [resolve(objs, x, depth + 1) for x in o["val"]] if depth < 64 else "..."
        if c == 32:
            return ("Point",) + tuple(resolve(objs, x) for x in o["val"])
        return f"<{name(o)} #{v.idx}>"
    return v

def load_block_table():
    """Reads the block table (selector, slots, shape) out of source/project.h so the
    scripts in a file can be checked against what the editor believes a block is."""
    path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "source", "project.h")
    if not os.path.exists(path):
        return None
    text = open(path).read()
    pat = re.compile(r'X\((BK_\w+),\s*"((?:[^"\\]|\\.)*)",\s*"((?:[^"\\]|\\.)*)",\s*"([a-z]*)",'
                     r'\s*"((?:[^"\\]|\\.)*)",\s*(SH_\w+),\s*(CAT_\w+)\)')
    table = {}
    for m in pat.finditer(text):
        sel = m.group(3).encode().decode("unicode_escape")
        if sel:
            table.setdefault(sel, []).append((m.group(4), m.group(6), m.group(1)))
    return table

class BadBlock(Exception):
    pass

SEEN = set()

def check_block(t, table, counter):
    if not isinstance(t, list) or not t or not (isinstance(t[0], str) and t[0].startswith("#")):
        raise BadBlock(f"not a block: {t!r}")
    sel = t[0][1:]
    cands = table.get(sel)
    if not cands:
        raise BadBlock(f"unknown selector {sel!r}")
    errors = []
    for slots, shape, name in cands:
        nbody = 1 if shape == "SH_C" else 2 if shape == "SH_CELSE" else 0
        nargs = 1 if (sel == "EventHatMorph" and slots == "") else len(slots)
        if len(t) != 1 + nargs + nbody:
            errors.append(f"{name}: expected {1 + nargs + nbody} fields, got {len(t)}")
            continue
        try:
            for i in range(nargs):
                a = t[1 + i]
                if isinstance(a, list):
                    check_block(a, table, counter)
                elif slots and slots[i] == "b" and a is not False:
                    raise BadBlock("empty boolean slot must be false")
            for body in t[1 + nargs:]:
                if not isinstance(body, list):
                    raise BadBlock("C block body is not an Array")
                for sub in body:
                    check_block(sub, table, counter)
        except BadBlock as e:
            errors.append(f"{name}: {e}")
            continue
        counter[0] += 1
        SEEN.add(sel)
        return
    raise BadBlock(f"{sel}: " + "; ".join(errors))

def main():
    if len(sys.argv) < 2:
        print(__doc__); return 2
    data = open(sys.argv[1], "rb").read()
    show_objects = "--objects" in sys.argv
    if data[:10] not in (b"ScratchV02", b"ScratchV01"):
        print("not a Scratch 1.x file, header =", data[:10]); return 1
    print("header      :", data[:10].decode())
    info_size = struct.unpack(">I", data[10:14])[0]
    info = read_table(Reader(data[14:14 + info_size]))
    print(f"info table  : {len(info)} objects, {info_size} bytes")
    d = info[0]
    if d["cls"] == 24:
        kv = d["val"]
        for i in range(0, len(kv), 2):
            k = text(info[kv[i].idx - 1])
            vo = info[kv[i + 1].idx - 1]
            print(f"   {k:16}", text(vo) if vo["cls"] == 9 else f"<{name(vo)}>")
    r = Reader(data, 14 + info_size)
    objs = read_table(r)
    print(f"contents    : {len(objs)} objects")
    if r.p != len(data):
        print(f"ERROR: {len(data) - r.p} trailing bytes"); return 1
    if objs[0]["cls"] != 125:
        print("ERROR: root is not ScratchStageMorph, it is", name(objs[0])); return 1
    print("root        : ScratchStageMorph  OK, file fully consumed")
    for i, o in enumerate(objs, 1):
        if o["cls"] == 34:
            w, h, depth, _, bits = o["val"]
            words = decompress_bitmap(objs[bits.idx - 1]["val"])
            ok = len(words) == w * h and depth == 32
            print(f"form #{i}: {w}x{h} depth {depth}, bitmap {'OK' if ok else 'SIZE MISMATCH'}")
            if not ok:
                return 1

    print("\nuser-class objects (compare with a real Scratch 1.4 file):")
    seen = set()
    for o in objs:
        if o["ver"] is not None and (o["cls"], o["ver"], len(o["val"])) not in seen:
            seen.add((o["cls"], o["ver"], len(o["val"])))
            print(f"   class {o['cls']:3} {name(o):20} version {o['ver']}  fields {len(o['val'])}")

    stage = objs[0]["val"]
    table = load_block_table()
    counter = [0]
    if table is None:
        print("(source/project.h not found: block selectors are not cross-checked)")
    vars_o = objs[stage[7].idx - 1]
    if vars_o["cls"] == 24 and vars_o["val"]:
        kv = vars_o["val"]
        print("\nvariables:", {text(objs[kv[i].idx - 1]): resolve(objs, kv[i + 1]) for i in range(0, len(kv), 2)})
    lists_o = objs[stage[20].idx - 1]
    if lists_o["cls"] == 24 and lists_o["val"]:
        kv = lists_o["val"]
        print("lists    :", [text(objs[kv[i].idx - 1]) for i in range(0, len(kv), 2)])
    sprites = objs[stage[16].idx - 1]["val"]
    print(f"\n{len(sprites)} sprite(s)")
    for s in sprites:
        so = objs[s.idx - 1]["val"]
        print(f"\nsprite '{text(objs[so[6].idx - 1])}'  visibility={so[12]}  direction={so[14] + 90 if so[14] is not None else '?'}")
        cur = so[11].idx
        for m in objs[so[10].idx - 1]["val"]:
            mo = objs[m.idx - 1]
            mv = mo["val"]
            nm = text(objs[mv[0].idx - 1])
            if mo["cls"] == 162:
                form = objs[mv[1].idx - 1]["val"]
                mark = "  <- current" if m.idx == cur else ""
                print(f"  costume '{nm}' {form[0]}x{form[1]}{mark}")
            elif mo["cls"] == 164:
                ss = objs[mv[1].idx - 1]["val"]
                buf = objs[ss[3].idx - 1]
                n_samples = len(buf["val"]) // 2
                ok = buf["cls"] == 12 and n_samples == ss[5]
                print(f"  sound   '{nm}' {n_samples} samples @ {ss[4]} Hz ({n_samples / ss[4]:.2f}s) {'OK' if ok else 'SIZE MISMATCH'}")
                if not ok:
                    return 1
            else:
                print("  media of unexpected class", mo["cls"])
                return 1
        for sc in objs[so[8].idx - 1]["val"]:
            pair = objs[sc.idx - 1]["val"]
            script = resolve(objs, pair[1])
            print("  script at", resolve(objs, pair[0]))
            print("   ", script)
            if table is not None:
                try:
                    for blk in script:
                        check_block(blk, table, counter)
                except BadBlock as e:
                    print("ERROR: bad block:", e)
                    return 1
    if table is not None:
        print(f"\n{counter[0]} blocks (including nested reporters) validated against source/project.h")
    if table is not None and "--coverage" in sys.argv:
        missing = sorted(set(table) - SEEN)
        print(f"selector coverage: {len(SEEN)}/{len(table)}")
        if missing:
            print("ERROR: selectors never written:", missing)
            return 1
    if show_objects:
        print()
        for i, o in enumerate(objs, 1):
            print(i, name(o), o["ver"], o["val"] if len(str(o["val"])) < 100 else "...")
    return 0

if __name__ == "__main__":
    sys.exit(main())
