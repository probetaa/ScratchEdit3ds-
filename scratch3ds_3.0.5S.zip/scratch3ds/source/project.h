
#ifndef PROJECT_H
#define PROJECT_H

#include <stdint.h>

#define MAX_SPRITES   12
#define STAGE_IDX     MAX_SPRITES
#define MAX_SCRIPTS   8
#define MAX_BLOCKS    40
#define MAX_EXPR      16
#define MAX_ARGS      3
#define TEXT_LEN      28
#define MAX_COSTUMES  6
#define MAX_SOUNDS    6
#define MAX_VARS      10
#define MAX_LISTS     4
#define LIST_ITEMS    40
#define KEY_NAME_COUNT 41
#define MAX_DEPTH     8

#define COSTUME_W     32
#define COSTUME_H     32
#define COSTUME_SB_SCALE 2
#define STAGE_W       480
#define STAGE_H       360

#define SND_RATE      11025
#define SND_MAX_MS    2000
#define SND_MAX_SAMPLES (SND_RATE * SND_MAX_MS / 1000)
#define REC_RATE      10910
#define REC_MAX_SECS  4
#define REC_MAX_SAMPLES (REC_RATE * REC_MAX_SECS)
#define SND_BUF_MAX   (REC_MAX_SAMPLES > SND_MAX_SAMPLES ? REC_MAX_SAMPLES : SND_MAX_SAMPLES)

typedef enum {
    CAT_MOTION = 0, CAT_LOOKS, CAT_SOUND, CAT_PEN, CAT_CONTROL,
    CAT_SENSING, CAT_OPERATORS, CAT_VARIABLES, CAT_LISTS,
    CAT_COUNT,
    CAT_NONE = CAT_COUNT
} BlockCategory;

typedef enum { SH_CMD = 0, SH_HAT, SH_C, SH_CELSE, SH_REP, SH_BOOL, SH_END, SH_ELSE } BlockShape;

#define BLOCK_LIST(X) \
  \
X(BK_MOVE,         "move %1 steps",              "forward:",           "n",   "10",              SH_CMD,  CAT_MOTION) \
X(BK_TURN_R,       "turn right %1 degrees",      "turnRight:",         "n",   "15",              SH_CMD,  CAT_MOTION) \
X(BK_TURN_L,       "turn left %1 degrees",       "turnLeft:",          "n",   "15",              SH_CMD,  CAT_MOTION) \
X(BK_POINT_DIR,    "point in direction %1",      "heading:",           "n",   "90",              SH_CMD,  CAT_MOTION) \
X(BK_POINT_TOWARDS,"point towards %1",           "pointTowards:",      "p",   "mouse-pointer",   SH_CMD,  CAT_MOTION) \
X(BK_GOTO_XY,      "go to x:%1 y:%2",            "gotoX:y:",           "nn",  "0|0",             SH_CMD,  CAT_MOTION) \
X(BK_GOTO_SPRITE,  "go to %1",                   "gotoSpriteOrMouse:", "p",   "mouse-pointer",   SH_CMD,  CAT_MOTION) \
X(BK_GLIDE,        "glide %1 secs to x:%2 y:%3", "glideSecs:toX:y:elapsed:from:", "nnn", "1|0|0", SH_CMD,  CAT_MOTION) \
X(BK_CHANGE_X,     "change x by %1",             "changeXposBy:",      "n",   "10",              SH_CMD,  CAT_MOTION) \
X(BK_SET_X,        "set x to %1",                "xpos:",              "n",   "0",               SH_CMD,  CAT_MOTION) \
X(BK_CHANGE_Y,     "change y by %1",             "changeYposBy:",      "n",   "10",              SH_CMD,  CAT_MOTION) \
X(BK_SET_Y,        "set y to %1",                "ypos:",              "n",   "0",               SH_CMD,  CAT_MOTION) \
X(BK_BOUNCE,       "if on edge, bounce",         "bounceOffEdge",      "",    "",                SH_CMD,  CAT_MOTION) \
X(BK_XPOS,         "x position",                 "xpos",               "",    "",                SH_REP,  CAT_MOTION) \
X(BK_YPOS,         "y position",                 "ypos",               "",    "",                SH_REP,  CAT_MOTION) \
X(BK_DIRECTION,    "direction",                  "heading",            "",    "",                SH_REP,  CAT_MOTION) \
  \
X(BK_SWITCH_COSTUME,"switch to costume %1",      "lookLike:",          "c",   "",                SH_CMD,  CAT_LOOKS) \
X(BK_NEXT_COSTUME, "next costume",               "nextCostume",        "",    "",                SH_CMD,  CAT_LOOKS) \
X(BK_COSTUME_NUM,  "costume #",                  "costumeIndex",       "",    "",                SH_REP,  CAT_LOOKS) \
X(BK_SAY_FOR,      "say %1 for %2 secs",         "say:duration:elapsed:from:", "sn", "Hello!|2", SH_CMD,  CAT_LOOKS) \
X(BK_SAY,          "say %1",                     "say:",               "s",   "Hello!",          SH_CMD,  CAT_LOOKS) \
X(BK_THINK_FOR,    "think %1 for %2 secs",       "think:duration:elapsed:from:", "sn", "Hmm...|2", SH_CMD, CAT_LOOKS) \
X(BK_THINK,        "think %1",                   "think:",             "s",   "Hmm...",          SH_CMD,  CAT_LOOKS) \
X(BK_CHANGE_EFFECT,"change %1 effect by %2",     "changeGraphicEffect:by:", "en", "ghost|25",    SH_CMD,  CAT_LOOKS) \
X(BK_SET_EFFECT,   "set %1 effect to %2",        "setGraphicEffect:to:", "en", "ghost|0",        SH_CMD,  CAT_LOOKS) \
X(BK_CLEAR_EFFECTS,"clear graphic effects",      "filterReset",        "",    "",                SH_CMD,  CAT_LOOKS) \
X(BK_CHANGE_SIZE,  "change size by %1",          "changeSizeBy:",      "n",   "10",              SH_CMD,  CAT_LOOKS) \
X(BK_SET_SIZE,     "set size to %1 %",           "setSizeTo:",         "n",   "100",             SH_CMD,  CAT_LOOKS) \
X(BK_SIZE,         "size",                       "scale",              "",    "",                SH_REP,  CAT_LOOKS) \
X(BK_SHOW,         "show",                       "show",               "",    "",                SH_CMD,  CAT_LOOKS) \
X(BK_HIDE,         "hide",                       "hide",               "",    "",                SH_CMD,  CAT_LOOKS) \
X(BK_FRONT,        "go to front",                "comeToFront",        "",    "",                SH_CMD,  CAT_LOOKS) \
X(BK_BACK,         "go back %1 layers",          "goBackByLayers:",    "n",   "1",               SH_CMD,  CAT_LOOKS) \
  \
X(BK_PLAY_SOUND,   "play sound %1",              "playSound:",         "o",   "",                SH_CMD,  CAT_SOUND) \
X(BK_PLAY_SOUND_WAIT,"play sound %1 until done", "doPlaySoundAndWait", "o",   "",                SH_CMD,  CAT_SOUND) \
X(BK_STOP_SOUNDS,  "stop all sounds",            "stopAllSounds",      "",    "",                SH_CMD,  CAT_SOUND) \
X(BK_DRUM,         "play drum %1 for %2 beats",  "drum:duration:elapsed:from:", "nn", "48|0.2",  SH_CMD,  CAT_SOUND) \
X(BK_REST,         "rest for %1 beats",          "rest:elapsed:from:", "n",   "0.2",             SH_CMD,  CAT_SOUND) \
X(BK_NOTE,         "play note %1 for %2 beats",  "noteOn:duration:elapsed:from:", "nn", "60|0.5", SH_CMD,  CAT_SOUND) \
X(BK_INSTRUMENT,   "set instrument to %1",       "instrument:",        "n",   "1",               SH_CMD,  CAT_SOUND) \
X(BK_CHANGE_VOLUME,"change volume by %1",        "changeVolumeBy:",    "n",   "-10",             SH_CMD,  CAT_SOUND) \
X(BK_SET_VOLUME,   "set volume to %1 %",         "setVolumeTo:",       "n",   "100",             SH_CMD,  CAT_SOUND) \
X(BK_VOLUME,       "volume",                     "volume",             "",    "",                SH_REP,  CAT_SOUND) \
X(BK_CHANGE_TEMPO, "change tempo by %1",         "changeTempoBy:",     "n",   "20",              SH_CMD,  CAT_SOUND) \
X(BK_SET_TEMPO,    "set tempo to %1 bpm",        "setTempoTo:",        "n",   "60",              SH_CMD,  CAT_SOUND) \
X(BK_TEMPO,        "tempo",                      "tempo",              "",    "",                SH_REP,  CAT_SOUND) \
  \
X(BK_PEN_CLEAR,    "clear",                      "clearPenTrails",     "",    "",                SH_CMD,  CAT_PEN) \
X(BK_PEN_DOWN,     "pen down",                   "putPenDown",         "",    "",                SH_CMD,  CAT_PEN) \
X(BK_PEN_UP,       "pen up",                     "putPenUp",           "",    "",                SH_CMD,  CAT_PEN) \
X(BK_PEN_IS_DOWN,  "pen down?",                  "penDown?",           "",    "",                SH_BOOL, CAT_PEN) \
X(BK_PEN_COLOR,    "set pen color to %1",        "penColor:",          "x",   "red",             SH_CMD,  CAT_PEN) \
X(BK_PEN_HUE_CHANGE,"change pen hue by %1",      "changePenHueBy:",    "n",   "10",              SH_CMD,  CAT_PEN) \
X(BK_PEN_HUE_SET,  "set pen hue to %1",          "setPenHueTo:",       "n",   "0",               SH_CMD,  CAT_PEN) \
X(BK_PEN_SHADE_CHANGE,"change pen shade by %1",  "changePenShadeBy:",  "n",   "10",              SH_CMD,  CAT_PEN) \
X(BK_PEN_SHADE_SET,"set pen shade to %1",        "setPenShadeTo:",     "n",   "50",              SH_CMD,  CAT_PEN) \
X(BK_PEN_SIZE_CHANGE,"change pen size by %1",    "changePenSizeBy:",   "n",   "1",               SH_CMD,  CAT_PEN) \
X(BK_PEN_SIZE_SET, "set pen size to %1",         "penSize:",           "n",   "1",               SH_CMD,  CAT_PEN) \
X(BK_STAMP,        "stamp",                      "stampCostume",       "",    "",                SH_CMD,  CAT_PEN) \
  \
X(BK_HAT_FLAG,     "when flag clicked",          "EventHatMorph",      "",    "",                SH_HAT,  CAT_CONTROL) \
X(BK_HAT_KEY,      "when %1 key pressed",        "KeyEventHatMorph",   "k",   "space",           SH_HAT,  CAT_CONTROL) \
X(BK_HAT_CLICK,    "when this sprite clicked",   "EventHatMorph",      "",    "",                SH_HAT,  CAT_CONTROL) \
X(BK_HAT_RECV,     "when I receive %1",          "EventHatMorph",      "m",   "message1",        SH_HAT,  CAT_CONTROL) \
X(BK_HAT_SENSOR,   "when %1 > %2",               "whenSensorGreaterThan", "in", "loudness|30",    SH_HAT,  CAT_CONTROL) \
X(BK_HAT_CLONE,    "when I start as a clone",    "whenCloned",         "",    "",                SH_HAT,  CAT_CONTROL) \
X(BK_WAIT,         "wait %1 secs",               "wait:elapsed:from:", "n",   "1",               SH_CMD,  CAT_CONTROL) \
X(BK_FOREVER,      "forever",                    "doForever",          "",    "",                SH_C,    CAT_CONTROL) \
X(BK_REPEAT,       "repeat %1",                  "doRepeat",           "n",   "10",              SH_C,    CAT_CONTROL) \
X(BK_BROADCAST,    "broadcast %1",               "broadcast:",         "m",   "message1",        SH_CMD,  CAT_CONTROL) \
X(BK_BROADCAST_WAIT,"broadcast %1 and wait",     "doBroadcastAndWait", "m",   "message1",        SH_CMD,  CAT_CONTROL) \
X(BK_FOREVER_IF,   "forever if %1",              "doForeverIf",        "b",   "",                SH_C,    CAT_CONTROL) \
X(BK_IF,           "if %1",                      "doIf",               "b",   "",                SH_C,    CAT_CONTROL) \
X(BK_IF_ELSE,      "if %1",                      "doIfElse",           "b",   "",                SH_CELSE,CAT_CONTROL) \
X(BK_WAIT_UNTIL,   "wait until %1",              "doWaitUntil",        "b",   "",                SH_CMD,  CAT_CONTROL) \
X(BK_UNTIL,        "repeat until %1",            "doUntil",            "b",   "",                SH_C,    CAT_CONTROL) \
X(BK_STOP_ALL,     "stop all",                   "stopAll",            "",    "",                SH_CMD,  CAT_CONTROL) \
X(BK_STOP_SCRIPT,  "stop script",                "doReturn",           "",    "",                SH_CMD,  CAT_CONTROL) \
X(BK_CLONE,        "create clone of %1",         "createCloneOf",      "y",   "myself",          SH_CMD,  CAT_CONTROL) \
X(BK_CLONE_DEL,    "delete this clone",          "deleteClone",        "",    "",                SH_CMD,  CAT_CONTROL) \
  \
X(BK_TOUCHING,     "touching %1 ?",              "touching:",          "t",   "mouse-pointer",   SH_BOOL, CAT_SENSING) \
X(BK_TOUCHING_COLOR,"touching color %1 ?",       "touchingColor:",     "x",   "red",             SH_BOOL, CAT_SENSING) \
X(BK_COLOR_SEES,   "color %1 is touching %2 ?",  "color:sees:",        "xx",  "red|blue",        SH_BOOL, CAT_SENSING) \
X(BK_ASK,          "ask %1 and wait",            "doAsk",              "s",   "What's your name?", SH_CMD, CAT_SENSING) \
X(BK_ANSWER,       "answer",                     "answer",             "",    "",                SH_REP,  CAT_SENSING) \
X(BK_MOUSE_X,      "mouse x",                    "mouseX",             "",    "",                SH_REP,  CAT_SENSING) \
X(BK_MOUSE_Y,      "mouse y",                    "mouseY",             "",    "",                SH_REP,  CAT_SENSING) \
X(BK_MOUSE_DOWN,   "mouse down?",                "mousePressed",       "",    "",                SH_BOOL, CAT_SENSING) \
X(BK_KEY_PRESSED,  "key %1 pressed?",            "keyPressed:",        "k",   "space",           SH_BOOL, CAT_SENSING) \
X(BK_DISTANCE,     "distance to %1",             "distanceTo:",        "p",   "mouse-pointer",   SH_REP,  CAT_SENSING) \
X(BK_TIMER,        "timer",                      "timer",              "",    "",                SH_REP,  CAT_SENSING) \
X(BK_TIMER_RESET,  "reset timer",                "timerReset",         "",    "",                SH_CMD,  CAT_SENSING) \
X(BK_ATTR_OF,      "%1 of %2",                   "getAttribute:of:",   "aq",  "x position|",     SH_REP,  CAT_SENSING) \
X(BK_LOUDNESS,     "loudness",                   "soundLevel",         "",    "",                SH_REP,  CAT_SENSING) \
X(BK_LOUD,         "loud?",                      "isLoud",             "",    "",                SH_BOOL, CAT_SENSING) \
X(BK_SENSOR_VALUE, "%1 sensor value",           "sensor:",            "z",   "slider",          SH_REP,  CAT_SENSING) \
X(BK_SENSOR_BTN,   "sensor %1 ?",               "sensorPressed:",     "u",   "button pressed",  SH_BOOL, CAT_SENSING) \
  \
X(BK_ADD,          "%1 + %2",                    "+",                  "nn",  "0|0",             SH_REP,  CAT_OPERATORS) \
X(BK_SUB,          "%1 - %2",                    "-",                  "nn",  "0|0",             SH_REP,  CAT_OPERATORS) \
X(BK_MUL,          "%1 * %2",                    "*",                  "nn",  "1|1",             SH_REP,  CAT_OPERATORS) \
X(BK_DIV,          "%1 / %2",                    "/",                  "nn",  "1|1",             SH_REP,  CAT_OPERATORS) \
X(BK_MOD,          "%1 mod %2",                  "\\\\",               "nn",  "10|3",            SH_REP,  CAT_OPERATORS) \
X(BK_ROUND,        "round %1",                   "rounded",            "n",   "0.5",             SH_REP,  CAT_OPERATORS) \
X(BK_FUNC,         "%1 of %2",                   "computeFunction:of:", "fn", "sqrt|10",         SH_REP,  CAT_OPERATORS) \
X(BK_RANDOM,       "pick random %1 to %2",       "randomFrom:to:",     "nn",  "1|10",            SH_REP,  CAT_OPERATORS) \
X(BK_LT,           "%1 < %2",                    "<",                  "nn",  "0|0",             SH_BOOL, CAT_OPERATORS) \
X(BK_EQ,           "%1 = %2",                    "=",                  "ss",  "0|0",             SH_BOOL, CAT_OPERATORS) \
X(BK_GT,           "%1 > %2",                    ">",                  "nn",  "0|0",             SH_BOOL, CAT_OPERATORS) \
X(BK_AND,          "%1 and %2",                  "&",                  "bb",  "",                SH_BOOL, CAT_OPERATORS) \
X(BK_OR,           "%1 or %2",                   "|",                  "bb",  "",                SH_BOOL, CAT_OPERATORS) \
X(BK_NOT,          "not %1",                     "not",                "b",   "",                SH_BOOL, CAT_OPERATORS) \
X(BK_JOIN,         "join %1 %2",                 "concatenate:with:",  "ss",  "hello |world",    SH_REP,  CAT_OPERATORS) \
X(BK_LETTER,       "letter %1 of %2",            "letter:of:",         "ns",  "1|world",         SH_REP,  CAT_OPERATORS) \
X(BK_LENGTH,       "length of %1",               "stringLength:",      "s",   "world",           SH_REP,  CAT_OPERATORS) \
  \
X(BK_VAR,          "%1",                         "readVariable",       "v",   "",                SH_REP,  CAT_VARIABLES) \
X(BK_SET_VAR,      "set %1 to %2",               "setVar:to:",         "vs",  "|0",              SH_CMD,  CAT_VARIABLES) \
X(BK_CHANGE_VAR,   "change %1 by %2",            "changeVar:by:",      "vn",  "|1",              SH_CMD,  CAT_VARIABLES) \
X(BK_SHOW_VAR,     "show variable %1",           "showVariable:",      "v",   "",                SH_CMD,  CAT_VARIABLES) \
X(BK_HIDE_VAR,     "hide variable %1",           "hideVariable:",      "v",   "",                SH_CMD,  CAT_VARIABLES) \
  \
X(BK_LIST_ADD,     "add %1 to %2",               "append:toList:",     "sl",  "thing|",          SH_CMD,  CAT_LISTS) \
X(BK_LIST_DELETE,  "delete %1 of %2",            "deleteLine:ofList:", "nl",  "1|",              SH_CMD,  CAT_LISTS) \
X(BK_LIST_INSERT,  "insert %1 at %2 of %3",      "insert:at:ofList:",  "snl", "thing|1|",        SH_CMD,  CAT_LISTS) \
X(BK_LIST_REPLACE, "replace item %1 of %2 with %3", "setLine:ofList:to:", "nls", "1||thing",     SH_CMD,  CAT_LISTS) \
X(BK_LIST_ITEM,    "item %1 of %2",              "getLine:ofList:",    "nl",  "1|",              SH_REP,  CAT_LISTS) \
X(BK_LIST_LEN,     "length of list %1",          "lineCountOfList:",   "l",   "",                SH_REP,  CAT_LISTS) \
  \
X(BK_ELSE,         "else",                       "",                   "",    "",                SH_ELSE, CAT_NONE) \
X(BK_END,          "end",                        "",                   "",    "",                SH_END,  CAT_NONE)

#define X_ENUM(e, l, s, sl, d, sh, c) e,
typedef enum { BLOCK_LIST(X_ENUM) BK_COUNT } BlockKind;
#undef X_ENUM

typedef struct {
    int16_t expr;
    char    text[TEXT_LEN];
} Arg;

typedef struct {
    int16_t kind;
    Arg     a[MAX_ARGS];
} Block;

typedef struct {
    int   x, y;
    int   nblocks;
    Block blocks[MAX_BLOCKS];
    uint8_t ex_used[MAX_EXPR];
    Block ex[MAX_EXPR];
} Script;

typedef struct {
    char    name[TEXT_LEN];
    uint8_t px[COSTUME_W * COSTUME_H];
} Costume;

typedef enum { WAVE_SINE = 0, WAVE_SQUARE, WAVE_SAW, WAVE_NOISE, WAVE_COUNT } Wave;

typedef struct {
    char name[TEXT_LEN];
    int  wave;
    int  freq;
    int  ms;
    int  vol;
    int16_t *pcm;
    int  npcm;
    int  rate;
} Sound;

typedef struct {
    char    name[TEXT_LEN];
    int     x, y;
    int     direction;
    int     visible;
    int     size;
    int     cur_costume;
    int     ncostumes;
    Costume costumes[MAX_COSTUMES];
    int     nsounds;
    Sound   sounds[MAX_SOUNDS];
    int     nscripts;
    Script  scripts[MAX_SCRIPTS];
} Sprite;

typedef struct { char name[TEXT_LEN]; char init[TEXT_LEN]; } Var;
typedef struct { char name[TEXT_LEN]; } ListDef;

typedef struct {
    int     nsprites;
    Sprite  sprites[MAX_SPRITES + 1];
    int     nvars;
    Var     vars[MAX_VARS];
    int     nlists;
    ListDef lists[MAX_LISTS];
} Project;

typedef struct {
    const char *label;
    const char *selector;
    const char *slots;
    const char *defaults;
    uint8_t     shape;
    uint8_t     category;
} BlockInfo;

#define X_INFO(e, l, s, sl, d, sh, c) { l, s, sl, d, sh, c },
static const BlockInfo BLOCK_INFO[BK_COUNT] = { BLOCK_LIST(X_INFO) };
#undef X_INFO

#define COL_MOTION    0x4A6CD4
#define COL_LOOKS     0x8A55D7
#define COL_SOUND     0xCF4ADB
#define COL_PEN       0x0E9A6C
#define COL_CONTROL   0xE6A81C
#define COL_SENSING   0x2CA5E2
#define COL_OPERATORS 0x5CB712
#define COL_VARIABLES 0xEE7D16
#define COL_LISTS     0xD94D11

static inline uint32_t category_color(int cat)
{
    static const uint32_t c[CAT_COUNT] = { COL_MOTION, COL_LOOKS, COL_SOUND, COL_PEN, COL_CONTROL,
                                           COL_SENSING, COL_OPERATORS, COL_VARIABLES, COL_LISTS };
    return (cat >= 0 && cat < CAT_COUNT) ? c[cat] : 0x888888;
}

static inline int block_nslots(int kind)
{
    int n = 0;
    while (BLOCK_INFO[kind].slots[n]) n++;
    return n;
}
static inline int block_is_c(int kind) { return BLOCK_INFO[kind].shape == SH_C || BLOCK_INFO[kind].shape == SH_CELSE; }
static inline int block_is_hat(int kind) { return BLOCK_INFO[kind].shape == SH_HAT; }
static inline int block_is_reporter(int kind) { return BLOCK_INFO[kind].shape == SH_REP || BLOCK_INFO[kind].shape == SH_BOOL; }

static inline void project_copy_text(char *dst, const char *src)
{
    int i = 0;
    for (; i < TEXT_LEN - 1 && src[i]; i++) dst[i] = src[i];
    dst[i] = 0;
}

static inline Block block_default(int kind)
{
    Block b;
    b.kind = (int16_t)kind;
    for (int i = 0; i < MAX_ARGS; i++) { b.a[i].expr = -1; b.a[i].text[0] = 0; }
    const char *d = BLOCK_INFO[kind].defaults;
    for (int i = 0; i < MAX_ARGS && *d; i++) {
        int n = 0;
        while (*d && *d != '|') { if (n < TEXT_LEN - 1) b.a[i].text[n++] = *d; d++; }
        b.a[i].text[n] = 0;
        if (*d == '|') d++;
    }
    return b;
}

#endif
