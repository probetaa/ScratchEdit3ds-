#include "sb3_writer.h"
#include "assets.h"
#include "editor.h"
#include "importer.h"
#include "svg.h"

#include <ctype.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_JSON   (8u * 1024u * 1024u)
#define MAX_ASSET  (4u * 1024u * 1024u)
#define MAX_FILE   (24u * 1024u * 1024u)
#define MAX_ZIP_ENTRIES 4096
#define ID_LEN     48

static void seterr(char *err, size_t n, const char *msg) { if (err && n) snprintf(err, n, "%s", msg); }
static void copy_text(char *dst, const char *src, int n)
{
    int i = 0;
    for (; i < n - 1 && src[i]; i++) dst[i] = src[i];
    dst[i] = 0;
}

typedef struct { char name[96]; int method; uint32_t csize, usize, off; } ZipEnt;
typedef struct { const unsigned char *d; size_t n; ZipEnt *e; int ne; } ZipR;

static unsigned u16(const unsigned char *p) { return p[0] | (unsigned)p[1] << 8; }
static unsigned u32(const unsigned char *p) { return p[0] | (unsigned)p[1] << 8 | (unsigned)p[2] << 16 | (unsigned)p[3] << 24; }

static int zip_open(ZipR *z, const unsigned char *d, size_t n, char *err, size_t errn)
{
    memset(z, 0, sizeof *z);
    z->d = d; z->n = n;
    if (n < 22) { seterr(err, errn, "Not a .sb3 file."); return -1; }
    size_t i = n - 22, lim = n > 65557 ? n - 65557 : 0;
    for (;; i--) {
        if (u32(d + i) == 0x06054b50u) break;
        if (i == lim) { seterr(err, errn, "Not a .sb3 file (no ZIP index)."); return -1; }
    }
    unsigned cnt = u16(d + i + 10);
    size_t cdoff = u32(d + i + 16);
    if (cnt > MAX_ZIP_ENTRIES || cdoff >= n) { seterr(err, errn, "Unsupported ZIP file."); return -1; }
    z->e = calloc(cnt ? cnt : 1, sizeof *z->e);
    if (!z->e) { seterr(err, errn, "Out of memory."); return -1; }
    size_t p = cdoff;
    for (unsigned k = 0; k < cnt; k++) {
        if (p + 46 > n || u32(d + p) != 0x02014b50u) break;
        ZipEnt *e = &z->e[z->ne];
        unsigned nl = u16(d + p + 28), xl = u16(d + p + 30), cl = u16(d + p + 32);
        if (p + 46 + nl > n) break;
        e->method = (int)u16(d + p + 10);
        e->csize = u32(d + p + 20); e->usize = u32(d + p + 24); e->off = u32(d + p + 42);
        copy_text(e->name, "", 96);
        size_t m = nl < 95 ? nl : 95;
        memcpy(e->name, d + p + 46, m); e->name[m] = 0;
        if (e->csize == 0xFFFFFFFFu || e->usize == 0xFFFFFFFFu) { seterr(err, errn, "ZIP64 files are not supported."); return -1; }
        z->ne++;
        p += 46 + nl + xl + cl;
    }
    return 0;
}

static const ZipEnt *zip_find(const ZipR *z, const char *name)
{
    for (int i = 0; i < z->ne; i++) if (strcmp(z->e[i].name, name) == 0) return &z->e[i];
    return NULL;
}

static unsigned char *zip_extract(const ZipR *z, const ZipEnt *e, unsigned cap, size_t *len)
{
    if (e->usize > cap || (size_t)e->off + 30 > z->n || u32(z->d + e->off) != 0x04034b50u) return NULL;
    size_t data = (size_t)e->off + 30 + u16(z->d + e->off + 26) + u16(z->d + e->off + 28);
    if (data + e->csize > z->n) return NULL;
    unsigned char *out = malloc(e->usize ? e->usize + 1 : 1);
    if (!out) return NULL;
    if (e->method == 0) {
        if (e->csize != e->usize) { free(out); return NULL; }
        memcpy(out, z->d + data, e->usize);
        *len = e->usize;
    } else if (e->method == 8) {
        size_t got = 0;
        if (inflate_raw(z->d + data, e->csize, out, e->usize, &got) != 0 || got != e->usize) { free(out); return NULL; }
        *len = got;
    } else { free(out); return NULL; }
    out[*len] = 0;
    return out;
}

enum { J_OBJ = 'o', J_ARR = 'a', J_STR = 's', J_NUM = 'n', J_TRUE = 't', J_FALSE = 'f', J_NULL = 'z' };
typedef struct { uint8_t t; int ks, kl, a, b, child, next; } JN;
typedef struct { const char *s; size_t n; JN *nd; int cnt, cap, err; } Json;

static int jnew(Json *j, int t)
{
    if (j->cnt == j->cap) {
        int nc = j->cap ? j->cap * 2 : 1024;
        JN *nn = realloc(j->nd, (size_t)nc * sizeof *nn);
        if (!nn) { j->err = 1; return -1; }
        j->nd = nn; j->cap = nc;
    }
    JN *x = &j->nd[j->cnt];
    memset(x, 0, sizeof *x);
    x->t = (uint8_t)t; x->child = -1; x->next = -1; x->ks = -1;
    return j->cnt++;
}

static void jws(const Json *j, size_t *p) { while (*p < j->n && (j->s[*p] == ' ' || j->s[*p] == '\n' || j->s[*p] == '\r' || j->s[*p] == '\t')) (*p)++; }

static int jstring_span(Json *j, size_t *p, int *start, int *len)
{
    if (*p >= j->n || j->s[*p] != '"') return -1;
    size_t q = ++(*p);
    while (q < j->n && j->s[q] != '"') { if (j->s[q] == '\\') q++; q++; }
    if (q >= j->n) return -1;
    *start = (int)*p; *len = (int)(q - *p);
    *p = q + 1;
    return 0;
}

static int jvalue(Json *j, size_t *p, int depth)
{
    if (depth > 40 || j->err) return -1;
    jws(j, p);
    if (*p >= j->n) return -1;
    char c = j->s[*p];
    if (c == '{' || c == '[') {
        int self = jnew(j, c == '{' ? J_OBJ : J_ARR);
        if (self < 0) return -1;
        char close = c == '{' ? '}' : ']';
        (*p)++;
        jws(j, p);
        int last = -1;
        if (*p < j->n && j->s[*p] == close) { (*p)++; return self; }
        for (;;) {
            jws(j, p);
            int ks = -1, kl = 0;
            if (c == '{') {
                if (jstring_span(j, p, &ks, &kl) != 0) return -1;
                jws(j, p);
                if (*p >= j->n || j->s[*p] != ':') return -1;
                (*p)++;
            }
            int v = jvalue(j, p, depth + 1);
            if (v < 0) return -1;
            if (c == '{') { j->nd[v].ks = ks; j->nd[v].kl = kl; }
            if (last < 0) j->nd[self].child = v; else j->nd[last].next = v;
            last = v;
            jws(j, p);
            if (*p >= j->n) return -1;
            if (j->s[*p] == ',') { (*p)++; continue; }
            if (j->s[*p] == close) { (*p)++; return self; }
            return -1;
        }
    }
    if (c == '"') {
        int st, ln;
        if (jstring_span(j, p, &st, &ln) != 0) return -1;
        int v = jnew(j, J_STR);
        if (v < 0) return -1;
        j->nd[v].a = st; j->nd[v].b = ln;
        return v;
    }
    size_t st = *p;
    if (!strncmp(j->s + *p, "true", 4) && *p + 4 <= j->n) { *p += 4; int v = jnew(j, J_TRUE); return v; }
    if (!strncmp(j->s + *p, "false", 5) && *p + 5 <= j->n) { *p += 5; int v = jnew(j, J_FALSE); return v; }
    if (!strncmp(j->s + *p, "null", 4) && *p + 4 <= j->n) { *p += 4; int v = jnew(j, J_NULL); return v; }
    while (*p < j->n && (isdigit((unsigned char)j->s[*p]) || strchr("+-.eE", j->s[*p]))) (*p)++;
    if (*p == st) return -1;
    int v = jnew(j, J_NUM);
    if (v < 0) return -1;
    j->nd[v].a = (int)st; j->nd[v].b = (int)(*p - st);
    return v;
}

static void unescape(const char *s, int len, char *out, int n)
{
    int o = 0;
    for (int i = 0; i < len && o < n - 1; i++) {
        unsigned char c = (unsigned char)s[i];
        if (c != '\\' || i + 1 >= len) { out[o++] = (char)c; continue; }
        c = (unsigned char)s[++i];
        switch (c) {
        case 'n': out[o++] = ' '; break;
        case 't': out[o++] = ' '; break;
        case 'r': break;
        case 'b': case 'f': break;
        case 'u': {
            unsigned cp = 0;
            int k = 0;
            for (; k < 4 && i + 1 + k < len; k++) {
                char h = s[i + 1 + k];
                cp = cp * 16 + (unsigned)(isdigit((unsigned char)h) ? h - '0' : (tolower((unsigned char)h) - 'a' + 10));
            }
            i += k;
            if (cp < 0x80) out[o++] = (char)cp;
            else if (cp < 0x800 && o + 2 < n) { out[o++] = (char)(0xC0 | (cp >> 6)); out[o++] = (char)(0x80 | (cp & 63)); }
            else if (o + 3 < n) { out[o++] = (char)(0xE0 | (cp >> 12)); out[o++] = (char)(0x80 | ((cp >> 6) & 63)); out[o++] = (char)(0x80 | (cp & 63)); }
            break; }
        default: out[o++] = (char)c; break;
        }
    }
    out[o] = 0;
}

static void jtext(const Json *j, int node, char *out, int n)
{
    out[0] = 0;
    if (node < 0) return;
    const JN *x = &j->nd[node];
    if (x->t == J_STR) unescape(j->s + x->a, x->b, out, n);
    else if (x->t == J_NUM) { int l = x->b < n - 1 ? x->b : n - 1; memcpy(out, j->s + x->a, (size_t)l); out[l] = 0; }
    else if (x->t == J_TRUE) copy_text(out, "true", n);
    else if (x->t == J_FALSE) copy_text(out, "false", n);
}

static double jnum(const Json *j, int node)
{
    char t[40];
    if (node < 0) return 0;
    jtext(j, node, t, sizeof t);
    return strtod(t, NULL);
}

static int jget(const Json *j, int obj, const char *key)
{
    if (obj < 0 || j->nd[obj].t != J_OBJ) return -1;
    size_t kl = strlen(key);
    for (int c = j->nd[obj].child; c >= 0; c = j->nd[c].next)
        if ((size_t)j->nd[c].kl == kl && !memcmp(j->s + j->nd[c].ks, key, kl)) return c;
    return -1;
}

static int jat(const Json *j, int arr, int i)
{
    if (arr < 0 || j->nd[arr].t != J_ARR) return -1;
    int c = j->nd[arr].child;
    while (c >= 0 && i-- > 0) c = j->nd[c].next;
    return c;
}

static int jis(const Json *j, int node, int t) { return node >= 0 && j->nd[node].t == t; }
static int jlen(const Json *j, int arr)
{
    int n = 0;
    if (arr < 0) return 0;
    for (int c = j->nd[arr].child; c >= 0; c = j->nd[c].next) n++;
    return n;
}

typedef struct { char key[ID_LEN]; int node; } BEnt;

enum { S_BLOCK, S_INPUT, S_SCRIPT, S_STAGE, S_COSTUME, S_SOUND, S_VAR, S_SPRITE, S_COUNT };
#define MAX_OPS 8
#define OP_LEN 44
#define REP_LEN 48

typedef struct {
    const Json *j;
    Project *p;
    int spi;
    int cur_np;
    char cur_pn[MAX_ARGS][TEXT_LEN];
    char cur_pt[MAX_ARGS];
    BEnt *tab; int tcap;
    Block *tb; int ntb, captb;
    int skipped;
    int cat[S_COUNT];
    char ops[MAX_OPS][OP_LEN]; int nops;
} R;

static char g_rep[S_COUNT + MAX_OPS][REP_LEN];
static int g_nrep;

static void skip(R *r, int c) { r->skipped++; r->cat[c]++; }

static void note_op(R *r, int bn)
{
    char op[OP_LEN];
    jtext(r->j, jget(r->j, bn, "opcode"), op, sizeof op);
    if (!op[0]) return;
    for (int i = 0; i < r->nops; i++) if (!strcmp(r->ops[i], op)) return;
    if (r->nops < MAX_OPS) { memcpy(r->ops[r->nops], op, sizeof op); r->nops++; }
}

static void build_report(R *r)
{
    static const char *const fmt[S_COUNT] = {
        "block(s) not supported", "input(s) not supported", "script(s) skipped (limit/hat)",
        "Stage script(s) skipped", "costume(s) skipped", "sound(s) skipped (not WAV)",
        "variable/list(s) over limit", "sprite(s) over limit"
    };
    g_nrep = 0;
    for (int c = 0; c < S_COUNT; c++) if (r->cat[c]) snprintf(g_rep[g_nrep++], REP_LEN, "%d %s", r->cat[c], fmt[c]);
    for (int i = 0; i < r->nops; i++) snprintf(g_rep[g_nrep++], REP_LEN, "- %s", r->ops[i]);
}

int sb3_report_count(void) { return g_nrep; }
const char *sb3_report_line(int i) { return i >= 0 && i < g_nrep ? g_rep[i] : ""; }

static unsigned hash_str(const char *s)
{
    unsigned h = 2166136261u;
    while (*s) { h ^= (unsigned char)*s++; h *= 16777619u; }
    return h;
}

static int tab_build(R *r, int blocks)
{
    free(r->tab); r->tab = NULL; r->tcap = 0;
    int n = jlen(r->j, blocks);
    if (n == 0) return 0;
    r->tcap = n * 2 + 1;
    r->tab = calloc((size_t)r->tcap, sizeof *r->tab);
    if (!r->tab) return -1;
    for (int c = r->j->nd[blocks].child; c >= 0; c = r->j->nd[c].next) {
        char k[ID_LEN];
        unescape(r->j->s + r->j->nd[c].ks, r->j->nd[c].kl, k, ID_LEN);
        unsigned h = hash_str(k) % (unsigned)r->tcap;
        while (r->tab[h].key[0]) h = (h + 1) % (unsigned)r->tcap;
        copy_text(r->tab[h].key, k, ID_LEN);
        r->tab[h].node = c;
    }
    return 0;
}

static int blk_find(R *r, const char *id)
{
    if (!r->tab || !id[0]) return -1;
    unsigned h = hash_str(id) % (unsigned)r->tcap;
    for (int i = 0; i < r->tcap && r->tab[h].key[0]; i++, h = (h + 1) % (unsigned)r->tcap)
        if (!strcmp(r->tab[h].key, id)) return r->tab[h].node;
    return -1;
}

static int blk_find_node(R *r, int idnode)
{
    if (!jis(r->j, idnode, J_STR)) return -1;
    char id[ID_LEN];
    jtext(r->j, idnode, id, sizeof id);
    return blk_find(r, id);
}

static void inv_xform(char x, char *v)
{
    if (x == 'T') {
        if (!strcmp(v, "_mouse_")) strcpy(v, "mouse-pointer");
        else if (!strcmp(v, "_myself_")) strcpy(v, "myself");
        else if (!strcmp(v, "_edge_")) strcpy(v, "edge");
    } else if (x == 'O') {
        if (!strcmp(v, "_stage_")) v[0] = 0;
    } else if (x == 'K') {
        if (!strcmp(v, "any")) strcpy(v, "any key");
    } else if (x == 'U') {
        for (char *c = v; *c; c++) *c = (char)tolower((unsigned char)*c);
    } else if (x == 'D') {
        for (char *c = v; *c; c++) *c = (char)tolower((unsigned char)*c);
        if (!strcmp(v, "dayofweek")) strcpy(v, "day of week");
    }
}

static int nearest_pal(unsigned rgb)
{
    int r = (int)(rgb >> 16) & 255, g = (int)(rgb >> 8) & 255, b = (int)rgb & 255, best = 1;
    int32_t bd = INT32_MAX;
    for (int i = 1; i < PAL_N; i++) {
        int pr = (PALETTE_RGB[i] >> 16) & 255, pg = (PALETTE_RGB[i] >> 8) & 255, pb = PALETTE_RGB[i] & 255;
        int32_t d = 2 * (r - pr) * (r - pr) + 4 * (g - pg) * (g - pg) + 3 * (b - pb) * (b - pb);
        if (d < bd) { bd = d; best = i; }
    }
    return best;
}

static int add_var(R *r, const char *name)
{
    if (!name[0]) return -1;
    int i = prj_add_var(r->p, name);
    return i;
}

static int add_list(R *r, const char *name)
{
    if (!name[0]) return -1;
    return prj_add_list(r->p, name);
}

static const Sb3Map *MAPT; static int NMAP;

static int fields_value(R *r, int bn, const char *fname, char *out, int n)
{
    out[0] = 0;
    int f = jget(r->j, jget(r->j, bn, "fields"), fname);
    if (f < 0) return 0;
    jtext(r->j, jat(r->j, f, 0), out, n);
    return 1;
}

static int fixed_fields_match(R *r, const Sb3Map *m, int bn)
{
    if (!m->fields) return 1;
    const char *s = m->fields;
    char key[48], val[64];
    const char *q = strchr(s, '"');
    if (!q) return 1;
    const char *e = strchr(q + 1, '"');
    if (!e) return 1;
    snprintf(key, sizeof key, "%.*s", (int)(e - q - 1), q + 1);
    const char *v = strstr(e, "[\"");
    if (!v) return 1;
    const char *ve = strchr(v + 2, '"');
    if (!ve) return 1;
    snprintf(val, sizeof val, "%.*s", (int)(ve - v - 2), v + 2);
    char got[64];
    fields_value(r, bn, key, got, sizeof got);
    return !strcmp(got, val);
}

static int xmenu_match(R *r, const Sb3Map *m, int bn)
{
    if (!m->xmenu) return 1;
    char t[200], *parts[4];
    snprintf(t, sizeof t, "%s", m->xmenu);
    char *s = t;
    for (int i = 0; i < 4; i++) { parts[i] = s; char *bar = strchr(s, '|'); if (bar) { *bar = 0; s = bar + 1; } }
    int in = jget(r->j, jget(r->j, bn, "inputs"), parts[0]);
    int sh = blk_find_node(r, jat(r->j, in, 1));
    if (sh < 0) return 0;
    char got[64];
    fields_value(r, sh, parts[2], got, sizeof got);
    return !strcmp(got, parts[3]);
}

static const Sb3Map *find_map(R *r, int bn)
{
    char op[64];
    jtext(r->j, jget(r->j, bn, "opcode"), op, sizeof op);
    for (int i = 0; i < NMAP; i++) {
        const Sb3Map *m = &MAPT[i];
        if (m->kind == BK_LOUD || m->kind == BK_VAR || strcmp(m->op, op)) continue;
        if (fixed_fields_match(r, m, bn) && xmenu_match(r, m, bn)) return m;
    }
    return NULL;
}

static int pool_new(Script *sc)
{
    for (int i = 0; i < MAX_EXPR; i++) if (!sc->ex_used[i]) { sc->ex_used[i] = 1; return i; }
    return -1;
}

static int conv_reporter(R *r, Script *sc, int bn, int depth);

static void prim_to_text(R *r, int prim, char slot, char *out, int n)
{
    out[0] = 0;
    if (!jis(r->j, prim, J_ARR)) return;
    int t = (int)jnum(r->j, jat(r->j, prim, 0));
    char v[TEXT_LEN * 2];
    jtext(r->j, jat(r->j, prim, 1), v, sizeof v);
    if (t == 9) { snprintf(out, (size_t)n, "%s", PALETTE_NAMES[nearest_pal((unsigned)strtoul(v[0] == '#' ? v + 1 : v, NULL, 16))]); return; }
    if (slot == 'x' && t != 9) { copy_text(out, PALETTE_NAMES[1], n); return; }
    copy_text(out, v, n);
}

static int reporter_from(R *r, Script *sc, int v, int depth)
{
    if (v < 0) return -1;
    if (jis(r->j, v, J_STR)) {
        int bn = blk_find_node(r, v);
        return bn < 0 ? -1 : conv_reporter(r, sc, bn, depth + 1);
    }
    if (jis(r->j, v, J_ARR) && (int)jnum(r->j, jat(r->j, v, 0)) == 12) {
        char name[TEXT_LEN];
        jtext(r->j, jat(r->j, v, 1), name, sizeof name);
        if (add_var(r, name) < 0) return -1;
        int e = pool_new(sc);
        if (e < 0) return -1;
        sc->ex[e] = block_default(BK_VAR);
        copy_text(sc->ex[e].a[0].text, name, TEXT_LEN);
        return e;
    }
    return -1;
}

static void plug_reporter(R *r, Script *sc, Arg *a, char slot, int ex)
{
    if (ex < 0) return;
    if (slot == 'b' && BLOCK_INFO[sc->ex[ex].kind].shape != SH_BOOL) { sc->ex_used[ex] = 0; skip(r, S_INPUT); return; }
    a->expr = (int16_t)ex;
}

static void read_value(R *r, Script *sc, Arg *a, char slot, int in, int depth)
{
    char val[TEXT_LEN * 2];
    if (in < 0) return;
    int t0 = (int)jnum(r->j, jat(r->j, in, 0));
    int v1 = jat(r->j, in, 1), v2 = jat(r->j, in, 2);
    int ex = -1;
    if (t0 == 3 || t0 == 2) {
        ex = reporter_from(r, sc, v1, depth);
        if (ex < 0) skip(r, S_INPUT);
    }
    if (t0 == 3) { prim_to_text(r, v2, slot, val, sizeof val); copy_text(a->text, val, TEXT_LEN); }
    else if (jis(r->j, v1, J_ARR)) { prim_to_text(r, v1, slot, val, sizeof val); copy_text(a->text, val, TEXT_LEN); }
    else if (jis(r->j, v1, J_STR)) {
        int sh = blk_find_node(r, v1);
        if (sh >= 0) {
            int fl = jget(r->j, sh, "fields");
            if (fl >= 0 && r->j->nd[fl].child >= 0) { jtext(r->j, jat(r->j, r->j->nd[fl].child, 0), val, sizeof val); copy_text(a->text, val, TEXT_LEN); }
        }
    }
    if (ex >= 0) plug_reporter(r, sc, a, slot, ex);
}

static void read_bool(R *r, Script *sc, Arg *a, char slot, int in, int depth)
{
    if (in < 0) return;
    int ex = reporter_from(r, sc, jat(r->j, in, 1), depth);
    if (ex >= 0) plug_reporter(r, sc, a, slot, ex); else skip(r, S_INPUT);
}

static void fill_args(R *r, Script *sc, int bn, const Sb3Map *m, Block *dst, int depth)
{
    const char *sp = m->spec;
    int k = 0;
    int inputs = jget(r->j, bn, "inputs");
    while (*sp && k < MAX_ARGS) {
        while (*sp == ' ') sp++;
        if (!*sp) break;
        char tok[160];
        int n = 0;
        while (sp[n] && sp[n] != ' ' && n < (int)sizeof tok - 1) { tok[n] = sp[n]; n++; }
        tok[n] = 0;
        sp += n;
        char type = tok[0], xf = tok[1] != ':' ? tok[1] : 0;
        char *name = strchr(tok, ':') + 1, *rest = strchr(name, ':');
        char field[64] = "";
        if (rest) {
            *rest++ = 0;
            char *f = strchr(rest, ':');
            if (f) snprintf(field, sizeof field, "%s", f + 1);
        }
        char slot = BLOCK_INFO[dst->kind].slots[k];
        Arg *a = &dst->a[k];
        char val[TEXT_LEN * 2];
        int in = jget(r->j, inputs, name);
        switch (type) {
        case 'n': case 's': case 'c':
            read_value(r, sc, a, slot, in, depth);
            break;
        case 'b':
            read_bool(r, sc, a, slot, in, depth);
            break;
        case 'm': {
            if (in < 0) break;
            int t0 = (int)jnum(r->j, jat(r->j, in, 0));
            int v1 = jat(r->j, in, 1), v2 = jat(r->j, in, 2);
            int shadow = t0 == 3 ? v2 : v1;
            if (t0 == 3) plug_reporter(r, sc, a, slot, reporter_from(r, sc, v1, depth));
            int sb = blk_find_node(r, shadow);
            if (sb >= 0) {
                fields_value(r, sb, field, val, sizeof val);
                inv_xform(xf, val);
                copy_text(a->text, val, TEXT_LEN);
            } else if (jis(r->j, shadow, J_ARR)) { prim_to_text(r, shadow, slot, val, sizeof val); copy_text(a->text, val, TEXT_LEN); }
            break; }
        case 'e': {
            if (in < 0) break;
            int t0 = (int)jnum(r->j, jat(r->j, in, 0));
            int v1 = jat(r->j, in, 1), v2 = jat(r->j, in, 2);
            int prim = t0 == 3 ? v2 : v1;
            if (t0 == 3) plug_reporter(r, sc, a, slot, reporter_from(r, sc, v1, depth));
            if (jis(r->j, prim, J_ARR)) { jtext(r->j, jat(r->j, prim, 1), val, sizeof val); copy_text(a->text, val, TEXT_LEN); }
            break; }
        case 'f':
            if (fields_value(r, bn, name, val, sizeof val)) { inv_xform(xf, val); copy_text(a->text, val, TEXT_LEN); }
            break;
        case 'v':
            if (fields_value(r, bn, name, val, sizeof val)) { copy_text(a->text, val, TEXT_LEN); add_var(r, a->text); }
            break;
        case 'l':
            if (fields_value(r, bn, name, val, sizeof val)) { copy_text(a->text, val, TEXT_LEN); add_list(r, a->text); }
            break;
        case 'E':
            if (fields_value(r, bn, name, val, sizeof val)) copy_text(a->text, val, TEXT_LEN);
            break;
        default: break;
        }
        k++;
    }
}

static int op_is(R *r, int bn, const char *op)
{
    char t[64];
    jtext(r->j, jget(r->j, bn, "opcode"), t, sizeof t);
    return !strcmp(t, op);
}

static int parse_str_array(const char *s, char out[][ID_LEN], int max)
{
    int n = 0;
    while (*s && *s != '[') s++;
    if (*s) s++;
    while (*s && n < max) {
        while (*s && *s != '"' && *s != ']') s++;
        if (*s != '"') break;
        s++;
        int o = 0;
        while (*s && *s != '"') {
            if (*s == '\\' && s[1]) s++;
            if (o < ID_LEN - 1) out[n][o++] = *s;
            s++;
        }
        out[n][o] = 0;
        if (*s == '"') s++;
        n++;
    }
    return n;
}

static int proc_sig(R *r, int bn, char *name, int *np, char *types, char ids[][ID_LEN], char names[][ID_LEN])
{
    int proto = bn;
    if (op_is(r, bn, "procedures_definition")) proto = blk_find_node(r, jat(r->j, jget(r->j, jget(r->j, bn, "inputs"), "custom_block"), 1));
    int mut = jget(r->j, proto, "mutation");
    if (mut < 0) return -1;
    char code[160], tok[80];
    jtext(r->j, jget(r->j, mut, "proccode"), code, sizeof code);
    name[0] = 0;
    *np = 0;
    const char *p = code;
    while (*p) {
        while (*p == ' ') p++;
        int l = 0;
        while (p[l] && p[l] != ' ' && l < (int)sizeof tok - 1) { tok[l] = p[l]; l++; }
        tok[l] = 0;
        p += l;
        if (!l) break;
        if (!strcmp(tok, "%s") || !strcmp(tok, "%b")) {
            if (*np >= MAX_ARGS) return -1;
            types[*np] = tok[1] == 'b' ? 'b' : 's';
            (*np)++;
        } else {
            size_t nl = strlen(name);
            if (nl + strlen(tok) + 2 < TEXT_LEN) { if (nl) name[nl++] = ' '; strcpy(name + nl, tok); }
        }
    }
    if (!name[0]) return -1;
    char buf[400];
    jtext(r->j, jget(r->j, mut, "argumentids"), buf, sizeof buf);
    if (ids) parse_str_array(buf, ids, MAX_ARGS);
    if (names) {
        jtext(r->j, jget(r->j, mut, "argumentnames"), buf, sizeof buf);
        parse_str_array(buf, names, MAX_ARGS);
    }
    return 0;
}

static int conv_param(R *r, Script *sc, int bn)
{
    int boolean = op_is(r, bn, "argument_reporter_boolean");
    char nm[ID_LEN];
    fields_value(r, bn, "VALUE", nm, sizeof nm);
    int idx = -1;
    for (int i = 0; i < r->cur_np; i++) if (!strcmp(r->cur_pn[i], nm)) idx = i;
    if (idx < 0) return -1;
    int e = pool_new(sc);
    if (e < 0) return -1;
    sc->ex[e] = block_default(boolean ? BK_PARAMB : BK_PARAM);
    sc->ex[e].aux = (int8_t)idx;
    copy_text(sc->ex[e].label, nm, TEXT_LEN);
    return e;
}

static int conv_reporter(R *r, Script *sc, int bn, int depth)
{
    if (op_is(r, bn, "argument_reporter_string_number") || op_is(r, bn, "argument_reporter_boolean")) return conv_param(r, sc, bn);
    if (depth > MAX_DEPTH + 2) return -1;
    const Sb3Map *m = find_map(r, bn);
    if (!m || !block_is_reporter(m->kind)) { if (!m) note_op(r, bn); return -1; }
    int e = pool_new(sc);
    if (e < 0) return -1;
    sc->ex[e] = block_default(m->kind);
    fill_args(r, sc, bn, m, &sc->ex[e], depth);
    return e;
}

static int tb_push(R *r, Block b)
{
    if (r->ntb == r->captb) {
        int nc = r->captb ? r->captb * 2 : 256;
        Block *nb = realloc(r->tb, (size_t)nc * sizeof *nb);
        if (!nb) return -1;
        r->tb = nb; r->captb = nc;
    }
    r->tb[r->ntb++] = b;
    return 0;
}

static int next_of(R *r, int bn)
{
    return blk_find_node(r, jget(r->j, bn, "next"));
}

static int substack(R *r, int bn, const char *name)
{
    int in = jget(r->j, jget(r->j, bn, "inputs"), name);
    return blk_find_node(r, jat(r->j, in, 1));
}

static void conv_stack(R *r, Script *sc, int bn, int cdepth)
{
    int guard = 0;
    while (bn >= 0 && guard++ < 5000 && r->ntb < 4000) {
        if (op_is(r, bn, "procedures_call")) {
            char name[TEXT_LEN], types[MAX_ARGS] = { 0 }, ids[MAX_ARGS][ID_LEN];
            int np = 0;
            memset(ids, 0, sizeof ids);
            if (proc_sig(r, bn, name, &np, types, ids, NULL) == 0) {
                Block b = block_default(BK_CALL);
                copy_text(b.label, name, TEXT_LEN);
                b.np = (uint8_t)np;
                for (int k = 0; k < np; k++) {
                    b.pt[k] = types[k];
                    int in = jget(r->j, jget(r->j, bn, "inputs"), ids[k]);
                    if (types[k] == 'b') read_bool(r, sc, &b.a[k], 'b', in, 0); else read_value(r, sc, &b.a[k], 's', in, 0);
                }
                tb_push(r, b);
            } else skip(r, S_BLOCK);
            bn = next_of(r, bn);
            continue;
        }
        const Sb3Map *m = find_map(r, bn);
        if (!m || block_is_hat(m->kind) || block_is_reporter(m->kind) || (block_is_c(m->kind) && cdepth >= MAX_DEPTH - 1)) {
            if (!m) note_op(r, bn);
            skip(r, S_BLOCK);
            bn = next_of(r, bn);
            continue;
        }
        Block b = block_default(m->kind);
        fill_args(r, sc, bn, m, &b, 0);
        prj_fill_defaults(r->p, r->spi, &b);
        tb_push(r, b);
        if (block_is_c(m->kind)) {
            conv_stack(r, sc, substack(r, bn, "SUBSTACK"), cdepth + 1);
            if (BLOCK_INFO[m->kind].shape == SH_CELSE) {
                tb_push(r, block_default(BK_ELSE));
                conv_stack(r, sc, substack(r, bn, "SUBSTACK2"), cdepth + 1);
            }
            tb_push(r, block_default(BK_END));
        }
        bn = next_of(r, bn);
    }
}

static void close_script(R *r, Script *sc)
{
    int cut = r->ntb;
    for (;;) {
        int open = 0, kinds[MAX_DEPTH * 4], seen_else[MAX_DEPTH * 4];
        int bad = 0;
        for (int i = 0; i < cut; i++) {
            int sh = BLOCK_INFO[r->tb[i].kind].shape;
            if (sh == SH_C || sh == SH_CELSE) { if (open >= MAX_DEPTH * 4) { bad = 1; break; } kinds[open] = sh; seen_else[open] = 0; open++; }
            else if (sh == SH_ELSE && open) seen_else[open - 1] = 1;
            else if (sh == SH_END && open) open--;
        }
        int extra = 0;
        if (!bad) for (int i = 0; i < open; i++) extra += 1 + (kinds[i] == SH_CELSE && !seen_else[i]);
        if (!bad && cut + extra <= MAX_BLOCKS - 1) {
            int n = 0;
            sc->blocks[n++] = sc->blocks[0];
            for (int i = 0; i < cut; i++) sc->blocks[n++] = r->tb[i];
            for (int i = open - 1; i >= 0; i--) {
                if (kinds[i] == SH_CELSE && !seen_else[i]) sc->blocks[n++] = block_default(BK_ELSE);
                sc->blocks[n++] = block_default(BK_END);
            }
            sc->nblocks = n;
            if (cut < r->ntb) { r->skipped += r->ntb - cut; r->cat[S_BLOCK] += r->ntb - cut; }
            return;
        }
        cut--;
        if (cut < 0) { sc->nblocks = 1; return; }
    }
}

static void conv_scripts(R *r, int target, Sprite *sp, int spi, int is_stage)
{
    r->spi = spi;
    int blocks = jget(r->j, target, "blocks");
    if (blocks < 0 || tab_build(r, blocks) != 0) return;
    for (int c = r->j->nd[blocks].child; c >= 0; c = r->j->nd[c].next) {
        int bn = c;
        if (!jis(r->j, bn, J_OBJ)) continue;
        if (!jis(r->j, jget(r->j, bn, "topLevel"), J_TRUE)) continue;
        if (is_stage) { skip(r, S_STAGE); continue; }
        if (op_is(r, bn, "procedures_definition")) {
            char name[TEXT_LEN], types[MAX_ARGS] = { 0 }, names[MAX_ARGS][ID_LEN];
            int np = 0;
            memset(names, 0, sizeof names);
            if (sp->nscripts >= MAX_SCRIPTS || proc_sig(r, bn, name, &np, types, NULL, names) != 0) { skip(r, S_SCRIPT); continue; }
            Script *sc = &sp->scripts[sp->nscripts];
            memset(sc, 0, sizeof *sc);
            sc->x = (int)(jnum(r->j, jget(r->j, bn, "x")) / 2);
            sc->y = (int)(jnum(r->j, jget(r->j, bn, "y")) / 2);
            sc->blocks[0] = block_default(BK_HAT_DEFINE);
            copy_text(sc->blocks[0].label, name, TEXT_LEN);
            sc->blocks[0].np = (uint8_t)np;
            r->cur_np = np;
            for (int k = 0; k < np; k++) {
                sc->blocks[0].pt[k] = types[k];
                copy_text(sc->blocks[0].a[k].text, names[k], TEXT_LEN);
                copy_text(r->cur_pn[k], names[k], TEXT_LEN);
            }
            r->ntb = 0;
            conv_stack(r, sc, next_of(r, bn), 0);
            close_script(r, sc);
            sp->nscripts++;
            r->cur_np = 0;
            continue;
        }
        const Sb3Map *m = find_map(r, bn);
        if (!m || !block_is_hat(m->kind) || sp->nscripts >= MAX_SCRIPTS) { if (!m) note_op(r, bn); skip(r, S_SCRIPT); continue; }
        Script *sc = &sp->scripts[sp->nscripts];
        memset(sc, 0, sizeof *sc);
        sc->x = (int)(jnum(r->j, jget(r->j, bn, "x")) / 2);
        sc->y = (int)(jnum(r->j, jget(r->j, bn, "y")) / 2);
        sc->blocks[0] = block_default(m->kind);
        fill_args(r, sc, bn, m, &sc->blocks[0], 0);
        prj_fill_defaults(r->p, spi, &sc->blocks[0]);
        r->ntb = 0;
        conv_stack(r, sc, next_of(r, bn), 0);
        close_script(r, sc);
        sp->nscripts++;
    }
}

static int file_write(const char *path, const unsigned char *d, size_t n)
{
    FILE *f = fopen(path, "wb");
    if (!f) return -1;
    int rc = fwrite(d, 1, n, f) == n ? 0 : -1;
    if (fclose(f) != 0) rc = -1;
    return rc;
}

static int ext_is(const char *name, const char *ext)
{
    size_t l = strlen(name), e = strlen(ext);
    return l > e && !strcmp(name + l - e, ext);
}

static int png_dims(const unsigned char *d, size_t n, int *w, int *h)
{
    if (n < 24 || memcmp(d, "\x89PNG", 4) != 0) return -1;
    *w = (int)((unsigned)d[16] << 24 | (unsigned)d[17] << 16 | (unsigned)d[18] << 8 | d[19]);
    *h = (int)((unsigned)d[20] << 24 | (unsigned)d[21] << 16 | (unsigned)d[22] << 8 | d[23]);
    return *w > 0 && *h > 0 ? 0 : -1;
}

static void load_costumes(R *r, const ZipR *z, int target, Sprite *sp, const char *tmp, int is_stage)
{
    sp->ncostumes = 0;
    int arr = jget(r->j, target, "costumes");
    double mx = 0;
    int cnt = 0;
    double uw[MAX_COSTUMES], uh[MAX_COSTUMES];
    for (int c = arr >= 0 ? r->j->nd[arr].child : -1; c >= 0 && cnt < MAX_COSTUMES; c = r->j->nd[c].next, cnt++) {
        char file[96];
        jtext(r->j, jget(r->j, c, "md5ext"), file, sizeof file);
        uw[cnt] = uh[cnt] = 0;
        const ZipEnt *e = file[0] ? zip_find(z, file) : NULL;
        size_t len = 0;
        unsigned char *d = e ? zip_extract(z, e, MAX_ASSET, &len) : NULL;
        if (d) {
            if (ext_is(file, ".svg")) { double w, h; if (svg_size((const char *)d, len, &w, &h) == 0) { uw[cnt] = w; uh[cnt] = h; } }
            else { int w, h; if (png_dims(d, len, &w, &h) == 0) {
                double res = jnum(r->j, jget(r->j, c, "bitmapResolution"));
                if (res < 1) res = 1;
                uw[cnt] = w / res; uh[cnt] = h / res;
            } }
        }
        free(d);
        double m = uw[cnt] > uh[cnt] ? uw[cnt] : uh[cnt];
        if (m > mx) mx = m;
    }
    if (mx < 1) mx = COSTUME_W;
    if (mx > 4096) mx = 4096;
    double scale = is_stage ? 0 : (double)COSTUME_W / mx;
    if (!is_stage) {
        double f = mx / COSTUME_W;
        long ns = (long)(sp->size * f + 0.5);
        if (ns < 5) ns = 5;
        if (ns > 500) ns = 500;
        sp->size = (int)ns;
    }
    int k = 0;
    for (int c = arr >= 0 ? r->j->nd[arr].child : -1; c >= 0; c = r->j->nd[c].next, k++) {
        if (sp->ncostumes >= MAX_COSTUMES) { skip(r, S_COSTUME); continue; }
        Costume *co = &sp->costumes[sp->ncostumes];
        memset(co, 0, sizeof *co);
        jtext(r->j, jget(r->j, c, "name"), co->name, TEXT_LEN);
        if (!co->name[0]) snprintf(co->name, TEXT_LEN, "costume%d", sp->ncostumes + 1);
        char file[96];
        jtext(r->j, jget(r->j, c, "md5ext"), file, sizeof file);
        const ZipEnt *e = file[0] ? zip_find(z, file) : NULL;
        size_t len = 0;
        unsigned char *d = e ? zip_extract(z, e, MAX_ASSET, &len) : NULL;
        int done = 0;
        int dw = COSTUME_W, dh = COSTUME_H, ox = 0, oy = 0;
        double bw = k < MAX_COSTUMES ? uw[k] : 0, bh = k < MAX_COSTUMES ? uh[k] : 0;
        if (!is_stage && bw > 0 && bh > 0) {
            dw = (int)(bw * scale + 0.5); dh = (int)(bh * scale + 0.5);
            if (dw < 1) dw = 1;
            if (dh < 1) dh = 1;
            if (dw > COSTUME_W) dw = COSTUME_W;
            if (dh > COSTUME_H) dh = COSTUME_H;
            ox = (COSTUME_W - dw) / 2; oy = (COSTUME_H - dh) / 2;
            double rcx = jnum(r->j, jget(r->j, c, "rotationCenterX")), rcy = jnum(r->j, jget(r->j, c, "rotationCenterY"));
            if (jis(r->j, jget(r->j, c, "rotationCenterX"), J_NUM)) {
                double res = ext_is(file, ".svg") ? 1 : jnum(r->j, jget(r->j, c, "bitmapResolution"));
                if (res < 1) res = 1;
                int tx = (int)(COSTUME_W / 2.0 - rcx / res * scale + 0.5), ty = (int)(COSTUME_H / 2.0 - rcy / res * scale + 0.5);
                if (tx >= 0 && ty >= 0 && tx + dw <= COSTUME_W && ty + dh <= COSTUME_H) { ox = tx; oy = ty; }
            }
        }
        if (d && ext_is(file, ".svg")) {
            int pw = dw * 3, ph = dh * 3;
            unsigned char *rgba = svg_render((const char *)d, len, pw, ph);
            if (rgba) { img_to_costume_ex(rgba, pw, ph, co, dw, dh, ox, oy); free(rgba); done = 1; }
        } else if (d && file_write(tmp, d, len) == 0) {
            int w, h;
            unsigned char *rgba = NULL;
            char err[64];
            if (img_decode(tmp, &w, &h, &rgba, err, sizeof err) == 0) { img_to_costume_ex(rgba, w, h, co, dw, dh, ox, oy); free(rgba); done = 1; }
            remove(tmp);
        }
        free(d);
        if (!done) { costume_clear(co); skip(r, S_COSTUME); }
        sp->ncostumes++;
    }
    if (sp->ncostumes == 0) {
        sp->ncostumes = 1;
        snprintf(sp->costumes[0].name, TEXT_LEN, "%s", is_stage ? "backdrop1" : "costume1");
        if (is_stage) for (int i = 0; i < COSTUME_W * COSTUME_H; i++) sp->costumes[0].px[i] = px_make(0xFFFFFF);
    }
    int cur = (int)jnum(r->j, jget(r->j, target, "currentCostume"));
    sp->cur_costume = cur >= 0 && cur < sp->ncostumes ? cur : 0;
}

static void load_sounds(R *r, const ZipR *z, int target, Project *p, int spi, const char *tmp)
{
    int arr = jget(r->j, target, "sounds");
    for (int c = arr >= 0 ? r->j->nd[arr].child : -1; c >= 0; c = r->j->nd[c].next) {
        char file[96], name[TEXT_LEN];
        jtext(r->j, jget(r->j, c, "md5ext"), file, sizeof file);
        jtext(r->j, jget(r->j, c, "name"), name, sizeof name);
        const ZipEnt *e = file[0] && ext_is(file, ".wav") ? zip_find(z, file) : NULL;
        size_t len = 0;
        unsigned char *d = e ? zip_extract(z, e, MAX_ASSET, &len) : NULL;
        int ok = 0;
        if (d && file_write(tmp, d, len) == 0) {
            int16_t *pcm = NULL;
            int n = 0, rate = 0;
            char err[64];
            if (wav_load(tmp, &pcm, &n, &rate, err, sizeof err) == 0) {
                int i = prj_add_recording(p, spi, pcm, n, rate);
                free(pcm);
                if (i >= 0) {
                    Sound *s = &p->sprites[spi].sounds[i];
                    if (name[0]) copy_text(s->name, name, TEXT_LEN);
                    ok = 1;
                }
            }
            remove(tmp);
        }
        free(d);
        if (!ok) skip(r, S_SOUND);
    }
}

static void reset_sprite(Project *p, int spi)
{
    Sprite *s = &p->sprites[spi];
    for (int k = 0; k < MAX_SOUNDS; k++) snd_free(&s->sounds[k]);
    s->nsounds = 0;
    s->nscripts = 0;
    s->ncostumes = 0;
    memset(s->scripts, 0, sizeof s->scripts);
}

static void load_vars(R *r, int target, int is_stage)
{
    (void)is_stage;
    int vars = jget(r->j, target, "variables");
    for (int c = vars >= 0 ? r->j->nd[vars].child : -1; c >= 0; c = r->j->nd[c].next) {
        char name[TEXT_LEN], init[TEXT_LEN];
        jtext(r->j, jat(r->j, c, 0), name, sizeof name);
        jtext(r->j, jat(r->j, c, 1), init, sizeof init);
        int i = add_var(r, name);
        if (i >= 0 && !r->p->vars[i].init[0]) copy_text(r->p->vars[i].init, init, TEXT_LEN);
        else if (i < 0) skip(r, S_VAR);
    }
    int lists = jget(r->j, target, "lists");
    for (int c = lists >= 0 ? r->j->nd[lists].child : -1; c >= 0; c = r->j->nd[c].next) {
        char name[TEXT_LEN];
        jtext(r->j, jat(r->j, c, 0), name, sizeof name);
        if (add_list(r, name) < 0) skip(r, S_VAR);
    }
}

int sb3_read_project(const char *path, Project *out, int *skipped, char *err, size_t errn)
{
    int rc = -1;
    unsigned char *file = NULL, *jbuf = NULL;
    Project *np = NULL;
    ZipR z = { 0 };
    Json j = { 0 };
    R r;
    memset(&r, 0, sizeof r);
    char tmp[300];
    if (skipped) *skipped = 0;
    g_nrep = 0;
    snprintf(tmp, sizeof tmp, "%s.tmp", path);

    FILE *f = fopen(path, "rb");
    if (!f) { seterr(err, errn, "Can't open the file."); return -1; }
    fseek(f, 0, SEEK_END);
    long sz = ftell(f);
    fseek(f, 0, SEEK_SET);
    if (sz <= 0 || (unsigned long)sz > MAX_FILE) { fclose(f); seterr(err, errn, sz <= 0 ? "Empty file." : "File too large (24 MB max)."); return -1; }
    file = malloc((size_t)sz);
    if (!file || fread(file, 1, (size_t)sz, f) != (size_t)sz) { fclose(f); seterr(err, errn, "Read error."); goto done; }
    fclose(f);

    if (zip_open(&z, file, (size_t)sz, err, errn) != 0) goto done;
    const ZipEnt *pj = zip_find(&z, "project.json");
    if (!pj) { seterr(err, errn, "Not a Scratch 3 project (no project.json). .sb files are not supported."); goto done; }
    size_t jlen_ = 0;
    jbuf = zip_extract(&z, pj, MAX_JSON, &jlen_);
    if (!jbuf) { seterr(err, errn, "project.json is too big or damaged."); goto done; }
    j.s = (const char *)jbuf; j.n = jlen_;
    size_t pos = 0;
    int root = jvalue(&j, &pos, 0);
    int targets = jget(&j, root, "targets");
    if (root < 0 || targets < 0 || j.err) { seterr(err, errn, "project.json is damaged."); goto done; }

    MAPT = sb3_maps(&NMAP);
    np = calloc(1, sizeof *np);
    if (!np) { seterr(err, errn, "Out of memory."); goto done; }
    prj_init(np);
    np->nvars = 0; np->nlists = 0;
    memset(np->vars, 0, sizeof np->vars);
    memset(np->lists, 0, sizeof np->lists);
    r.j = &j; r.p = np;

    int order[MAX_SPRITES + 1], nord = 0, lay[MAX_SPRITES + 1], stage = -1;
    for (int t = j.nd[targets].child; t >= 0; t = j.nd[t].next) {
        if (jis(&j, jget(&j, t, "isStage"), J_TRUE)) { if (stage < 0) stage = t; continue; }
        if (nord >= MAX_SPRITES) { r.skipped++; r.cat[S_SPRITE]++; continue; }
        int l = (int)jnum(&j, jget(&j, t, "layerOrder"));
        int k = nord++;
        while (k > 0 && lay[k - 1] > l) { order[k] = order[k - 1]; lay[k] = lay[k - 1]; k--; }
        order[k] = t; lay[k] = l;
    }
    if (nord == 0 && stage < 0) { seterr(err, errn, "The project has no sprites."); goto done; }
    if (stage >= 0) load_vars(&r, stage, 1);

    int nsp = nord > 0 ? nord : 1;
    for (int s = 1; s < nsp; s++) if (prj_add_sprite(np) < 0) break;
    for (int s = 0; s < np->nsprites; s++) reset_sprite(np, s);
    reset_sprite(np, STAGE_IDX);

    for (int s = 0; s < nord && s < np->nsprites; s++) {
        int t = order[s];
        Sprite *sp = &np->sprites[s];
        char name[TEXT_LEN];
        jtext(&j, jget(&j, t, "name"), name, sizeof name);
        if (name[0]) copy_text(sp->name, name, TEXT_LEN);
        sp->x = (int)jnum(&j, jget(&j, t, "x"));
        sp->y = (int)jnum(&j, jget(&j, t, "y"));
        sp->direction = (int)jnum(&j, jget(&j, t, "direction"));
        sp->size = (int)jnum(&j, jget(&j, t, "size"));
        if (sp->size < 5) sp->size = 100;
        if (sp->size > 500) sp->size = 500;
        sp->visible = !jis(&j, jget(&j, t, "visible"), J_FALSE);
        load_vars(&r, t, 0);
        load_costumes(&r, &z, t, sp, tmp, 0);
        load_sounds(&r, &z, t, np, s, tmp);
        conv_scripts(&r, t, sp, s, 0);
        if (sp->nscripts == 0) prj_new_script(np, s, BK_HAT_FLAG);
    }
    if (nord == 0) { prj_new_script(np, 0, BK_HAT_FLAG); load_costumes(&r, &z, -1, &np->sprites[0], tmp, 0); }
    if (stage >= 0) {
        Sprite *st = &np->sprites[STAGE_IDX];
        strcpy(st->name, "Stage");
        st->size = 100; st->visible = 1; st->direction = 90;
        load_costumes(&r, &z, stage, st, tmp, 1);
        load_sounds(&r, &z, stage, np, STAGE_IDX, tmp);
        conv_scripts(&r, stage, st, STAGE_IDX, 1);
    } else {
        Sprite *st = &np->sprites[STAGE_IDX];
        strcpy(st->name, "Stage");
        st->size = 100; st->visible = 1; st->direction = 90;
        st->ncostumes = 1;
        strcpy(st->costumes[0].name, "backdrop1");
        memset(st->costumes[0].px, 2, sizeof st->costumes[0].px);
    }

    prj_clear(out);
    *out = *np;
    free(np);
    np = NULL;
    if (skipped) *skipped = r.skipped;
    build_report(&r);
    rc = 0;
done:
    if (np) prj_clear(np);
    free(np);
    free(r.tab); free(r.tb);
    free(j.nd);
    free(jbuf);
    free(z.e);
    free(file);
    return rc;
}
