
#include <assert.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <unistd.h>
#include "3ds.h"
#include "citro2d.h"

static char kb_reply[64] = "Reply";
static SwkbdButton kb_button = SWKBD_BUTTON_RIGHT;
static int kb_numpad_calls;
static int  objs;
void gfxInitDefault(void) {} void gfxExit(void) {}
bool aptMainLoop(void) { return false; } void hidScanInput(void) {}
u32 hidKeysDown(void) { return 0; } u32 hidKeysHeld(void) { return 0; } void hidTouchRead(touchPosition *t) { (void)t; }
void hidCircleRead(circlePosition *c) { c->dx = 0; c->dy = 0; }
void swkbdInit(SwkbdState *s, SwkbdType t, int a, int b) { (void)s; (void)a; (void)b; if (t == SWKBD_TYPE_NUMPAD) kb_numpad_calls++; }
void swkbdSetNumpadKeys(SwkbdState *s, int l, int r) { (void)s; (void)l; (void)r; }
void swkbdSetHintText(SwkbdState *s, const char *h) { (void)s; (void)h; }
void swkbdSetInitialText(SwkbdState *s, const char *h) { (void)s; (void)h; }
void swkbdSetButton(SwkbdState *s, SwkbdButton b, const char *t, bool c) { (void)s; (void)b; (void)t; (void)c; }
SwkbdButton swkbdInputText(SwkbdState *s, char *out, size_t n) { (void)s; if (kb_button == SWKBD_BUTTON_RIGHT) snprintf(out, n, "%s", kb_reply); return kb_button; }
Result APT_CheckNew3DS(bool *out) { *out = true; return 0; }
void osSetSpeedupEnable(bool enable) { (void)enable; }
Result ndspInit(void) { return -1; }
void ndspExit(void) {} void ndspSetOutputMode(int m) { (void)m; } void ndspChnReset(int c) { (void)c; }
void ndspChnSetInterp(int c, int i) { (void)c; (void)i; } void ndspChnSetRate(int c, float r) { (void)c; (void)r; }
void ndspChnSetFormat(int c, u16 f) { (void)c; (void)f; } void ndspChnSetMix(int c, float *m) { (void)c; (void)m; }
void ndspChnWaveBufAdd(int c, ndspWaveBuf *w) { (void)c; (void)w; } void ndspChnWaveBufClear(int c) { (void)c; }
void *linearAlloc(size_t n) { return malloc(n); } void linearFree(void *p) { free(p); }
Result DSP_FlushDataCache(const void *p, u32 n) { (void)p; (void)n; return 0; }
void C3D_Init(size_t n) { (void)n; } void C3D_Fini(void) {} void C2D_Init(size_t n) { (void)n; } void C2D_Fini(void) {}
void C2D_Prepare(void) {}
C3D_RenderTarget *C2D_CreateScreenTarget(int a, int b) { (void)a; (void)b; return NULL; }
C2D_TextBuf C2D_TextBufNew(size_t n) { (void)n; return NULL; } void C2D_TextBufDelete(C2D_TextBuf b) { (void)b; }
void C2D_TextBufClear(C2D_TextBuf b) { (void)b; }
const char *C2D_TextParse(C2D_Text *t, C2D_TextBuf b, const char *s) { (void)t; (void)b; return s; }
void C2D_TextOptimize(const C2D_Text *t) { (void)t; }
void C2D_DrawText(const C2D_Text *t, u32 f, float x, float y, float z, float sx, float sy, ...) { (void)t; (void)f; (void)x; (void)y; (void)z; (void)sx; (void)sy; objs++; }
bool C3D_FrameBegin(u8 f) { (void)f; return true; } void C3D_FrameEnd(u8 f) { (void)f; }
void C2D_TargetClear(C3D_RenderTarget *t, u32 c) { (void)t; (void)c; } void C2D_SceneBegin(C3D_RenderTarget *t) { (void)t; }
bool C2D_DrawRectSolid(float x, float y, float z, float w, float h, u32 c) { (void)x; (void)y; (void)z; (void)w; (void)h; (void)c; objs++; return true; }
bool C2D_DrawCircleSolid(float x, float y, float z, float r, u32 c) { (void)x; (void)y; (void)z; (void)r; (void)c; objs++; return true; }
bool C2D_DrawCircle(float x, float y, float z, float r, u32 a, u32 b, u32 c, u32 d) { (void)x; (void)y; (void)z; (void)r; (void)a; (void)b; (void)c; (void)d; objs++; return true; }
bool C2D_DrawLine(float x0, float y0, u32 c0, float x1, float y1, u32 c1, float t, float z) { (void)x0; (void)y0; (void)c0; (void)x1; (void)y1; (void)c1; (void)t; (void)z; objs++; return true; }

static u8 *fake_mic_buf; static u32 fake_mic_size, fake_mic_wr; static int fake_mic_on, fake_mic_amp, fake_mic_calls_start, fake_mic_calls_stop;
static long fake_mic_t;
Result micInit(u8 *b, u32 n) { fake_mic_buf = b; fake_mic_size = n; return 0; }
void micExit(void) {}
u32 micGetSampleDataSize(void) { return fake_mic_size - 4; }
Result MICU_StartSampling(MICU_Encoding e, MICU_SampleRate r, u32 off, u32 size, bool loop)
{
    assert(e == MICU_ENCODING_PCM16_SIGNED && r == MICU_SAMPLE_RATE_10910 && off == 0 && size == fake_mic_size - 4 && loop);
    fake_mic_on = 1; fake_mic_calls_start++;
    return 0;
}
Result MICU_StopSampling(void) { fake_mic_on = 0; fake_mic_calls_stop++; return 0; }
Result MICU_SetPower(bool p) { (void)p; return 0; }
u32 micGetLastSampleOffset(void)
{
    if (!fake_mic_on) return fake_mic_wr;
    for (int i = 0; i < 364; i++) {
        int16_t v = (int16_t)(sinf((float)fake_mic_t++ * 0.3f) * (float)fake_mic_amp);
        fake_mic_buf[fake_mic_wr] = (uint8_t)(v & 255); fake_mic_buf[fake_mic_wr + 1] = (uint8_t)((v >> 8) & 255);
        fake_mic_wr = (fake_mic_wr + 2) % (fake_mic_size - 4);
    }
    return fake_mic_wr;
}

#define main app_main
#include "../source/main.c"
#undef main

static void touch(int x, int y) { handle_touch(x, y); }

static int frame_objects(void)
{
    objs = 0;
    draw_top();
    int top = objs;
    objs = 0;
    draw_bottom();
    printf("   mode %d%s: top %d, bottom %d draw calls\n", g_mode, g_play ? " (playing)" : "", top, objs);
    assert(top + objs < C2D_DEFAULT_MAX_OBJECTS * 4);
    return top + objs;
}

static void pick(int idx) { touch(2 + (idx / PK_ROWS % 2) * PK_COLSTEP + 5, PK_Y + (idx % PK_ROWS) * PK_ROW + 5 - 0); }
static void tap_tab(int m)      { touch(1 + m * 70 + 5, 5); }
static void tap_cat(int cat)    { touch(2 + cat * CAT_STEP + 5, CAT_Y + 3); }
static void tap_arg(int i)      { touch(ARG_X + i * ARG_STEP + 5, ARG_Y + 5); }
static void tap_up(void)        { touch(SCR_X + 4, ARG_Y + 5); }
static void tap_row(int row)    { touch(SCR_X + 20, SCR_Y + row * SCR_ROW + 5); }
static void tap_btn(int i)      { touch(i * BTN_STEP + 10, BTN_Y + 5); }
static void tap_delete(void)    { tap_btn(3); }

static void tap_palette(int kind, int param)
{
    int cat = kind < 0 ? (kind == PE_NEW_VAR || kind == PE_DEL_VAR ? CAT_VARIABLES : CAT_LISTS) : BLOCK_INFO[kind].category;
    tap_cat(cat);
    assert(g_cat == cat && g_pal_scroll == 0);
    PalEntry pe[PAL_MAX];
    int n = palette_entries(cat, pe), row = -1;
    for (int i = 0; i < n; i++) if (pe[i].kind == kind && (kind != BK_VAR || pe[i].param == param)) row = i;
    assert(row >= 0);
    while (row >= g_pal_scroll + PAL_ROWS) { int before = g_pal_scroll; touch(PAL_X + 70, PALBTN_Y + 3); assert(g_pal_scroll > before); }
    touch(PAL_X + 30, PAL_Y + (row - g_pal_scroll) * PAL_ROW + 5);
}

static void rec_frames(int n)
{
    for (int i = 0; i < n; i++) {
        mic_poll();
        if (g_recording && g_rec.full) rec_finish();
    }
}

int main(void)
{
    char tmpl[] = "/tmp/uitestXXXXXX";
    assert(mkdtemp(tmpl));
    assert(chdir(tmpl) == 0);
    mkdir("sdmc:", 0777);

    mic_init();
    assert(g_mic_ok && g_micsize == MIC_BUF_BYTES - 4);
    prj_init(&g_prj);
    rt_reset(&g_rt, &g_prj);

    touch(255, 24);
    assert(g_prj.nsprites == 2 && g_sprite == 1);
    touch(207, 24);
    assert(g_sprite == 0);
    touch(231, 24);
    assert(g_sprite == 1);
    touch(207, 24); touch(279, 24);
    assert(g_prj.nsprites == 1 && g_sprite == 0);
    strcpy(kb_reply, "Hero");
    touch(305, 24);
    assert(g_pk.action == PK_SPRITE_MENU && g_pk.n == SM_COUNT);
    frame_objects();
    pick(SM_RENAME);
    assert(strcmp(cur()->name, "Hero") == 0 && g_pk.action == PK_SPRITE_MENU);
    strcpy(kb_reply, "-60");
    pick(SM_X); assert(cur()->x == -60 && strcmp(g_pk.items[SM_X], "x: -60") == 0);
    strcpy(kb_reply, "999");
    pick(SM_Y); assert(cur()->y == STAGE_H / 2);
    strcpy(kb_reply, "270");
    pick(SM_DIR); assert(cur()->direction == -90);
    strcpy(kb_reply, "1000");
    pick(SM_SIZE); assert(cur()->size == 500 && strcmp(g_pk.items[SM_SIZE], "Size: 500%") == 0);
    strcpy(kb_reply, "200");
    pick(SM_SIZE); assert(cur()->size == 200);
    pick(SM_VISIBLE); assert(cur()->visible == 0 && strcmp(g_pk.items[SM_VISIBLE], "Visible: no") == 0);
    pick(SM_VISIBLE); assert(cur()->visible == 1);
    {
        rt_reset(&g_rt, &g_prj);
        assert(g_rt.spr[0].size == 200.f && g_rt.spr[0].x == -60.f && g_rt.spr[0].dir == -90.f);
    }
    pick(SM_DUPLICATE);
    assert(g_prj.nsprites == 2 && g_sprite == 1 && strcmp(cur()->name, "Hero2") == 0 && cur()->size == 200 && g_pk.action == PK_NONE);
    touch(305, 24); pick(SM_BACK);
    assert(g_sprite == 0 && strcmp(cur()->name, "Hero2") == 0 && strcmp(g_prj.sprites[1].name, "Hero") == 0);
    pick(SM_FRONT); pick(SM_FRONT);
    assert(g_sprite == 1 && strcmp(cur()->name, "Hero2") == 0);
    touch(300, PK_NAV_Y + 5); touch(110, PK_NAV_Y + 5);
    assert(g_pk.action == PK_NONE);
    touch(60, 24);
    assert(g_pk.action == PK_SPRITE_LIST && g_pk.n == 3 && strcmp(g_pk.items[0], "1 Hero") == 0 && strcmp(g_pk.items[2], "Stage (backdrops)") == 0);
    pick(0);
    assert(g_sprite == 0 && g_pk.action == PK_NONE);
    select_sprite(1);
    touch(279, 24);
    assert(g_prj.nsprites == 1 && g_sprite == 0);
    cur()->x = 0; cur()->y = 0; cur()->direction = 90; cur()->size = 100;

    {
        assert(g_run_bottom == 0);
        touch(170, 24);
        assert(g_run_bottom == 1 && strstr(g_status, "BOTTOM"));
        FILE *f = fopen("sdmc:/3ds/scratch-editor/settings.txt", "r");
        char ln[64] = ""; assert(f && fgets(ln, sizeof ln, f) && strstr(ln, "run_screen=bottom")); fclose(f);
        g_run_bottom = 0; load_settings(); assert(g_run_bottom == 1);
        g_mode = MODE_COSTUMES;
        start_play();
        assert(g_play);
        printf("   run on the bottom screen:\n");
        frame_objects();
        objs = 0; draw_top_run_info(); assert(objs > 3);
        play_pointer(0, 0, 1, 1);
        assert(fabsf(g_rt.mouse_x + 240.f) < 1.f && fabsf(g_rt.mouse_y - 180.f) < 1.f && g_rt.mouse_down);
        stop_play();
        touch(170, 24);
        assert(g_run_bottom == 0 && strstr(g_status, "TOP"));
        g_run_bottom = 0; load_settings(); assert(g_run_bottom == 0);
        g_mode = MODE_SCRIPTS;
        printf("   run on the top screen again:\n");
        start_play(); frame_objects(); stop_play();
    }

    {
        assert(g_prj.sprites[STAGE_IDX].ncostumes == 1 && strcmp(g_prj.sprites[STAGE_IDX].costumes[0].name, "backdrop1") == 0);
        touch(60, 24); pick(g_prj.nsprites);
        assert(g_sprite == STAGE_IDX && g_mode == MODE_COSTUMES && cur()->ncostumes == 1);
        frame_objects();
        tap_tab(MODE_SCRIPTS);
        assert(g_mode == MODE_COSTUMES && strstr(g_status, "no scripts"));
        touch(180, 36 + 6 * 20 + 5 - 40);
        paint_canvas(CV_X + 2, CV_Y + 2, 1);
        Costume *bd = &cur()->costumes[0];
        assert(bd->px[0] == g_color);
        touch(218, 36 + 2 * 22 + 3);
        assert(cur()->ncostumes == 2 && strcmp(cur()->costumes[1].name, "backdrop2") == 0);
        touch(228, 110);
        assert(cur()->cur_costume == 0);
        touch(60, 24); pick(0);
        assert(g_sprite == 0);
        select_sprite(STAGE_IDX);
        sprite_step(+1); assert(g_sprite == 0);
        select_sprite(STAGE_IDX);
        sprite_step(-1); assert(g_sprite == g_prj.nsprites - 1);
        select_sprite(STAGE_IDX);
        touch(279, 24); assert(g_sprite == STAGE_IDX && strstr(g_status, "can't be deleted"));
        touch(305, 24); assert(g_pk.action == PK_NONE);
        g_mode = MODE_SOUNDS;
        touch(10, SN_BTN_Y + 8);
        assert(cur()->nsounds == 1);
        g_mode = MODE_COSTUMES;
        start_play();
        assert(g_play && g_sprite == 0 && g_mode == MODE_SCRIPTS);
        frame_objects();
        stop_play();
        {
            mkdir("sdmc:/3ds", 0777); mkdir("sdmc:/3ds/scratch-editor", 0777);
            assert(sb3_write_project(&g_prj, "sdmc:/3ds/scratch-editor/backdrops.sb3") == 0);
            if (getenv("SB3CHECK")) {
                char cmd[400];
                snprintf(cmd, sizeof cmd, "python3 -I '%s' sdmc:/3ds/scratch-editor/backdrops.sb3", getenv("SB3CHECK"));
                assert(system(cmd) == 0);
            }
        }
        cur()->nsounds = 0;
        for (int k = 0; k < MAX_SOUNDS; k++) snd_free(&g_prj.sprites[STAGE_IDX].sounds[k]);
        select_sprite(0);
        g_mode = MODE_SCRIPTS;
    }

    mkdir("sdmc:/3ds", 0777); mkdir("sdmc:/3ds/scratch-editor", 0777); mkdir(IMPORT_DIR, 0777);
    touch(305, 24); pick(SM_IMPORT);
    assert(g_pk.action == PK_NONE && strstr(g_status, "Nothing in"));
    {
        const char *gen = getenv("FIXGEN");
        if (gen) {
            char cmd[512];
            snprintf(cmd, sizeof cmd, "python3 -I '%s' '%s'", gen, IMPORT_DIR);
            assert(system(cmd) == 0);
            touch(305, 24); pick(SM_IMPORT);
            assert(g_pk.action == PK_IMPORT && g_pk.n == 4 && strcmp(g_pk.items[2], "[+] Hero") == 0);
            frame_objects();
            pick(2);
            assert(g_prj.nsprites == 2 && g_sprite == 1 && strcmp(cur()->name, "Knight") == 0 && cur()->ncostumes == 4 && cur()->nsounds == 2);
            assert(cur()->x == 120 && cur()->size == 150 && cur()->visible == 0 && cur()->cur_costume == 1 && strstr(g_status, "skipped"));
            rt_reset(&g_rt, &g_prj);
            frame_objects();
            touch(305, 24); pick(SM_IMPORT_ALL);
            assert(g_prj.nsprites == 2 + 3 && strstr(g_status, "Imported 3") && strstr(g_status, "failed"));
            assert(strcmp(g_prj.sprites[2].name, "coin") == 0 && strcmp(g_prj.sprites[3].name, "Knight2") == 0 && strcmp(g_prj.sprites[4].name, "Mixed") == 0);
            printf("   after import all: %d sprites (Empty has no images and is reported)\n", g_prj.nsprites);
        }
    }
    while (g_prj.nsprites > 1) prj_delete_sprite(&g_prj, g_prj.nsprites - 1);
    select_sprite(0);
    touch(279, 24);
    assert(g_prj.nsprites == 1 && g_sprite == 0);
    touch(279, 24);
    assert(g_prj.nsprites == 1);

    assert(g_mode == MODE_SCRIPTS && g_cat == CAT_MOTION);
    tap_palette(BK_MOVE, 0);
    assert(cur_script()->nblocks == 2 && cur_script()->blocks[1].kind == BK_MOVE && g_sel == 1);
    strcpy(kb_reply, "25");
    tap_arg(0);
    assert(strcmp(cur_script()->blocks[1].a[0].text, "25") == 0);
    tap_cat(CAT_CONTROL);
    assert(g_cat == CAT_CONTROL);
    tap_palette(BK_FOREVER, 0);
    assert(cur_script()->blocks[2].kind == BK_FOREVER && cur_script()->blocks[3].kind == BK_END);
    tap_palette(BK_TURN_R, 0);
    assert(cur_script()->blocks[3].kind == BK_TURN_R && cur_script()->blocks[4].kind == BK_END && g_sel == 3);
    assert(prj_indent(cur_script(), 3) == 1);
    tap_palette(BK_IF_ELSE, 0);
    assert(cur_script()->nblocks == 8);
    tap_row(0);
    assert(g_sel == 0);
    tap_palette(BK_HAT_KEY, 0);
    assert(cur()->nscripts == 2 && g_script == 1 && g_sel == 0);
    strcpy(kb_reply, "x");
    touch(PAL_X + 5, SCRNAV_Y + 5);
    assert(g_script == 0);
    touch(PAL_X + 25, SCRNAV_Y + 5);
    assert(g_script == 1);

    for (int i = 0; i < 12; i++) prj_insert_block(&g_prj, g_sprite, g_script, 0, BK_MOVE);
    touch(PAL_X + 108, SCRNAV_Y + 5);
    assert(g_sel == cur_script()->nblocks - 1 && g_scroll > 0);
    touch(PAL_X + 80, SCRNAV_Y + 5);
    assert(g_sel == 0 && g_scroll == 0);

    {
        int n = cur_script()->nblocks, max = n - SCR_ROWS;
        assert(max > 0);
        touch(SCRBTN_X + 5, SCR_Y + SCRBTN_H + SCRBTN_GAP + 5);
        assert(g_scroll == SCR_ROWS - 1 && g_sel == 0);
        for (int i = 0; i < 10; i++) touch(SCRBTN_X + 5, SCR_Y + SCRBTN_H + SCRBTN_GAP + 5);
        assert(g_scroll == max && g_sel == 0);
        touch(SCRBTN_X + 5, SCR_Y + 5);
        assert(g_scroll == (max - (SCR_ROWS - 1) > 0 ? max - (SCR_ROWS - 1) : 0) && g_sel == 0);
        for (int i = 0; i < 10; i++) touch(SCRBTN_X + 5, SCR_Y + 5);
        assert(g_scroll == 0);
        frame_objects();
    }
    tap_arg(0);
    assert(g_pk.action == PK_ARG && g_pk.n == KEY_NAME_COUNT);
    frame_objects();
    touch(110, PK_NAV_Y + 5);
    assert(g_pk.action == PK_NONE && strcmp(cur_script()->blocks[0].a[0].text, "space") == 0);
    tap_arg(0);
    touch(218 + 5, PK_NAV_Y + 5);
    assert(g_pk.page == 1);
    touch(2 + 5, PK_NAV_Y + 5);
    assert(g_pk.page == 0);
    touch(2 + PK_COLSTEP + 5, PK_Y + 0 * PK_ROW + 5);
    assert(g_pk.action == PK_NONE && strcmp(cur_script()->blocks[0].a[0].text, KEY_NAMES[PK_ROWS]) == 0);
    select_script(-1);

    select_block(1);
    assert(g_foc.depth == 0 && g_foc.slot == 0);
    tap_palette(BK_ADD, 0);
    assert(cur_script()->blocks[1].a[0].expr >= 0 && g_foc.depth == 1 && g_foc.slot == 0);
    strcpy(kb_reply, "7");
    tap_arg(1);
    assert(g_foc.slot == 1);
    tap_arg(1);
    {
        char lab[96];
        prj_format_block(cur_script(), &cur_script()->blocks[1], lab, sizeof lab);
        assert(strcmp(lab, "move (0 + 7) steps") == 0);
    }
    tap_arg(0);
    tap_palette(BK_XPOS, 0);
    assert(g_foc.depth == 1);
    {
        char lab[96];
        prj_format_block(cur_script(), &cur_script()->blocks[1], lab, sizeof lab);
        assert(strcmp(lab, "move ((x position) + 7) steps") == 0);
    }
    tap_up();
    assert(g_foc.depth == 0 && g_foc.slot == 0);
    tap_arg(0);
    assert(g_foc.depth == 1);
    tap_delete();
    assert(g_foc.depth == 1 && cur_script()->blocks[1].a[0].expr >= 0);
    tap_delete();
    assert(g_foc.depth == 0 && cur_script()->blocks[1].a[0].expr == -1);
    for (int i = 0; i < MAX_EXPR; i++) assert(!cur_script()->ex_used[i]);
    tap_palette(BK_LT, 0);
    assert(g_foc.depth == 1);
    tap_up();
    tap_delete();
    assert(cur_script()->blocks[1].a[0].expr == -1);
    { int ie = 0; while (cur_script()->blocks[ie].kind != BK_IF_ELSE) ie++; select_block(ie); }
    tap_palette(BK_ADD, 0);
    assert(strstr(g_status, "boolean") && cur_script()->blocks[g_sel].a[0].expr == -1);
    tap_palette(BK_TOUCHING, 0);
    assert(cur_script()->blocks[g_sel].a[0].expr >= 0 && g_foc.depth == 1);
    tap_arg(0);
    tap_arg(0);
    assert(g_pk.action == PK_ARG && strcmp(g_pk.items[0], "mouse-pointer") == 0 && strcmp(g_pk.items[1], "edge") == 0);
    touch(2 + 5, PK_Y + 1 * PK_ROW + 5);
    {
        char lab[96];
        prj_format_block(cur_script(), &cur_script()->blocks[g_sel], lab, sizeof lab);
        assert(strcmp(lab, "if <touching edge ?>") == 0);
    }
    tap_up();
    tap_arg(0);
    assert(g_foc.depth == 1);
    tap_up();

    strcpy(kb_reply, "score");
    tap_palette(PE_NEW_VAR, 0);
    assert(g_prj.nvars == 1 && strcmp(g_prj.vars[0].name, "score") == 0);
    strcpy(kb_reply, "items");
    tap_palette(PE_NEW_LIST, 0);
    assert(g_prj.nlists == 1);
    select_block(1);
    tap_palette(BK_VAR, 0);
    {
        char lab[96];
        prj_format_block(cur_script(), &cur_script()->blocks[1], lab, sizeof lab);
        assert(strcmp(lab, "move (score) steps") == 0);
    }
    tap_up();
    tap_delete();
    tap_palette(BK_SET_VAR, 0);
    assert(cur_script()->blocks[g_sel].kind == BK_SET_VAR && strcmp(cur_script()->blocks[g_sel].a[0].text, "score") == 0);
    tap_palette(BK_LIST_ADD, 0);
    assert(strcmp(cur_script()->blocks[g_sel].a[1].text, "items") == 0);
    strcpy(kb_reply, "second");
    tap_palette(PE_NEW_VAR, 0);
    assert(g_prj.nvars == 2);
    tap_arg(0);
    tap_row(g_sel - g_scroll);
    tap_palette(BK_SET_VAR, 0);
    tap_arg(0);
    tap_arg(0);
    assert(g_pk.action == PK_ARG && g_pk.n == 2 && strcmp(g_pk.items[1], "second") == 0);
    touch(2 + 5, PK_Y + 1 * PK_ROW + 5);
    assert(strcmp(cur_script()->blocks[g_sel].a[0].text, "second") == 0);
    tap_palette(PE_DEL_VAR, 0);
    assert(g_pk.action == PK_DEL_VAR && g_pk.n == 2);
    touch(2 + 5, PK_Y + 5);
    assert(g_prj.nvars == 1 && strcmp(g_prj.vars[0].name, "second") == 0);
    tap_palette(PE_DEL_LIST, 0);
    touch(2 + 5, PK_Y + 5);
    assert(g_prj.nlists == 0);
    tap_palette(PE_DEL_LIST, 0);
    assert(g_pk.action == PK_NONE && strstr(g_status, "Nothing"));

    int added = 0;
    for (int k = 0; k < BK_COUNT; k++) {
        if (BLOCK_INFO[k].category >= CAT_COUNT) continue;
        prj_clear(&g_prj); prj_init(&g_prj);
        prj_add_var(&g_prj, "v"); prj_add_list(&g_prj, "L");
        select_sprite(0);
        g_cat = 0;
        if (k == BK_VAR) { tap_palette(BK_SAY, 0); tap_palette(BK_VAR, 0); assert(cur_script()->blocks[g_sel].a[0].expr >= 0); added++; continue; }
        int hat = block_is_hat(k), rep = block_is_reporter(k);
        if (rep) tap_palette(BK_SAY, 0);
        int nscripts = cur()->nscripts, nblocks = cur_script()->nblocks;
        tap_palette(k, 0);
        if (hat) assert(cur()->nscripts == nscripts + 1 && cur_script()->blocks[0].kind == k);
        else if (rep) { Block *p = &cur_script()->blocks[g_sel]; assert(p->a[0].expr >= 0 || g_foc.depth == 1); }
        else assert(cur_script()->nblocks > nblocks && cur_script()->blocks[g_sel].kind == k);
        frame_objects();
        added++;
    }
    printf("%d palette blocks added through the touch UI\n", added);
    assert(added >= 100);
    prj_clear(&g_prj); prj_init(&g_prj); select_sprite(0);

    tap_cat(CAT_OPERATORS);
    {
        PalEntry pe[PAL_MAX];
        assert(palette_entries(CAT_OPERATORS, pe) > PAL_ROWS);
    }
    touch(PAL_X + 70, PALBTN_Y + 3);
    assert(g_pal_scroll == PAL_ROWS - 1);
    touch(PAL_X + 10, PALBTN_Y + 3);
    assert(g_pal_scroll == 0);
    touch(PAL_X + 10, PALBTN_Y + 3);
    assert(g_pal_scroll == 0);

    prj_add_costume(&g_prj, 0);
    tap_palette(BK_SWITCH_COSTUME, 0);
    assert(strcmp(cur_script()->blocks[g_sel].a[0].text, "costume2") == 0);
    tap_arg(0);
    assert(g_pk.action == PK_ARG && g_pk.n == 2);
    touch(2 + 5, PK_Y + 5);
    assert(strcmp(cur_script()->blocks[g_sel].a[0].text, "costume1") == 0);

    tap_tab(MODE_COSTUMES);
    assert(g_mode == MODE_COSTUMES);
    touch(180, 36 + 3 * 20 + 5);
    assert(g_color == 3);
    Costume *c = &cur()->costumes[cur()->cur_costume];
    assert(c->px[0] == 0);
    paint_canvas(CV_X + 2, CV_Y + 2, 1);
    assert(c->px[0] == 3);
    touch(180, 36 + 0 * 20 + 5);
    paint_canvas(CV_X + 2, CV_Y + 2, 1);
    assert(c->px[0] == 0);
    touch(180 + 20, 36 + 2 * 20 + 5);
    assert(g_color == 10);
    touch(270, 40);
    assert(g_tool == 1);
    paint_canvas(CV_X + 16 * CV_CELL + 2, CV_Y + 16 * CV_CELL + 2, 1);
    assert(c->px[16 * COSTUME_W + 16] == 10 && c->px[0] == 0);
    c->px[0] = 7;
    touch(218, 36 + 1 * 22 + 3);
    assert(c->px[COSTUME_W - 1] == 7 && c->px[0] == 0);
    touch(218, 36 + 2 * 22 + 3);
    assert(cur()->ncostumes == 3 && cur()->cur_costume == 2);
    strcpy(kb_reply, "run1");
    touch(270, 36 + 2 * 22 + 3);
    assert(strcmp(cur()->costumes[2].name, "run1") == 0);
    strcpy(kb_reply, "costume1");
    touch(270, 36 + 2 * 22 + 3);
    assert(strcmp(cur()->costumes[2].name, "run1") == 0 && strstr(g_status, "already"));
    touch(228, 110);
    assert(cur()->cur_costume == 1);
    touch(280, 110);
    assert(cur()->cur_costume == 2);
    tap_delete();
    assert(cur()->ncostumes == 2);
    tap_delete(); tap_delete();
    assert(cur()->ncostumes == 1);

    tap_tab(MODE_SOUNDS);
    assert(g_mode == MODE_SOUNDS && g_snd == -1);
    touch(10, SN_BTN_Y + 8);
    assert(cur()->nsounds == 1 && g_snd == 0);
    int f0 = cur()->sounds[0].freq;
    touch(300, 36 + 1 * 28 + 5);
    assert(cur()->sounds[0].freq > f0 && cur()->sounds[0].freq < f0 * 11 / 10);
    touch(274, 36 + 1 * 28 + 5);
    assert(cur()->sounds[0].freq == f0);
    touch(300, 36 + 0 * 28 + 5);
    assert(cur()->sounds[0].wave == WAVE_SQUARE);
    strcpy(kb_reply, "500");
    touch(170, 36 + 2 * 28 + 5);
    assert(cur()->sounds[0].ms == 500);
    strcpy(kb_reply, "9999");
    touch(170, 36 + 3 * 28 + 5);
    assert(cur()->sounds[0].vol == 100);
    touch(60, SN_BTN_Y + 8);
    assert(strstr(g_status, "No sound"));
    strcpy(kb_reply, "ding");
    touch(110, SN_BTN_Y + 8);
    assert(strcmp(cur()->sounds[0].name, "ding") == 0);

    int starts = fake_mic_calls_start;
    fake_mic_amp = 0;
    touch(30, SN_REC_Y + 8);
    assert(g_recording == 1 && fake_mic_on && fake_mic_calls_start == starts + 1);
    frame_objects();
    rec_frames(10);
    fake_mic_amp = 9000;
    rec_frames(30);
    fake_mic_amp = 0;
    rec_frames(10);
    assert(g_rec.level == 0.f && g_rec.n > 18000);
    touch(160, 36 + 28);
    tap_delete();
    assert(g_recording == 1 && cur()->nsounds == 1);
    frame_objects();
    touch(30, SN_REC_Y + 8);
    assert(g_recording == 0 && !fake_mic_on && cur()->nsounds == 2 && g_snd == 1);
    Sound *rs = &cur()->sounds[1];
    assert(snd_is_recorded(rs) && rs->rate == REC_RATE && rs->npcm > 18000 && strcmp(rs->name, "recording2") == 0);
    {
        int peak = 0;
        for (int i = 0; i < rs->npcm; i++) if (abs(rs->pcm[i]) > peak) peak = abs(rs->pcm[i]);
        assert(peak > 8000 && peak <= 9001);
    }
    int before = rs->npcm;
    touch(200, 36 + 0 * 28 + 5);
    assert(rs->npcm < before && rs->npcm > 8000 && strstr(g_status, "Trimmed"));
    touch(200, 36 + 1 * 28 + 5);
    {
        int peak = 0;
        for (int i = 0; i < rs->npcm; i++) if (abs(rs->pcm[i]) > peak) peak = abs(rs->pcm[i]);
        assert(peak > 30000);
    }
    int16_t first = rs->pcm[100];
    touch(200, 36 + 2 * 28 + 5);
    assert(rs->pcm[rs->npcm - 1 - 100] == first);
    touch(300, 36 + 3 * 28 + 5);
    assert(rs->vol == 100);
    touch(274, 36 + 3 * 28 + 5);
    assert(rs->vol == 90);
    frame_objects();
    touch(110, SN_BTN_Y + 8);
    strcpy(kb_reply, "ding");
    touch(110, SN_BTN_Y + 8);
    assert(strcmp(rs->name, "recording2") == 0 && strstr(g_status, "already"));
    strcpy(kb_reply, "voice");
    touch(110, SN_BTN_Y + 8);
    assert(strcmp(rs->name, "voice") == 0);
    touch(10, 36 + 19 * 0 + 5);
    assert(g_snd == 0);
    frame_objects();

    fake_mic_amp = 3000;
    touch(30, SN_REC_Y + 8);
    assert(g_recording);
    rec_frames(REC_MAX_SECS * 30 + 40);
    assert(!g_recording && cur()->nsounds == 3 && cur()->sounds[2].npcm == REC_MAX_SAMPLES);
    while (cur()->nsounds < MAX_SOUNDS) prj_add_sound(&g_prj, 0);
    touch(30, SN_REC_Y + 8);
    assert(!g_recording && strstr(g_status, "Maximum"));
    prj_delete_sound(&g_prj, 0, cur()->nsounds - 1);
    g_snd = 0;

    touch(30, SN_REC_Y + 8);
    assert(g_recording);
    rec_frames(1);
    touch(30, SN_REC_Y + 8);
    assert(!g_recording && strstr(g_status, "Too short"));
    g_mic_ok = 0;
    touch(30, SN_REC_Y + 8);
    assert(!g_recording && strstr(g_status, "not available"));
    g_mic_ok = 1;
    tap_delete();
    assert(g_snd >= 0);

    tap_tab(MODE_SCRIPTS);
    tap_palette(BK_PLAY_SOUND, 0);
    Block *pb = &cur_script()->blocks[g_sel];
    assert(pb->kind == BK_PLAY_SOUND && prj_find_sound(cur(), pb->a[0].text) >= 0);
    tap_arg(0);
    assert(g_pk.action == PK_ARG && g_pk.n == cur()->nsounds);
    touch(2 + 5, PK_Y + 5);

    prj_clear(&g_prj); prj_init(&g_prj); select_sprite(0);
    prj_add_var(&g_prj, "n");
    {
        int s = 0, a = prj_insert_block(&g_prj, s, 0, 0, BK_ASK);
        strcpy(g_prj.sprites[0].scripts[0].blocks[a].a[0].text, "Name?");
        int w = prj_insert_block(&g_prj, s, 0, a, BK_SET_VAR);
        Script *sc = &g_prj.sprites[0].scripts[0];
        prj_plug(&g_prj, s, sc, &sc->blocks[w], 1, BK_ANSWER, NULL);
        int l = prj_insert_block(&g_prj, s, 0, w, BK_SET_VAR);
        prj_plug(&g_prj, s, sc, &sc->blocks[l], 1, BK_LOUDNESS, NULL);
        strcpy(sc->blocks[l].a[0].text, "n");
        int f = prj_insert_block(&g_prj, s, 0, l, BK_FOREVER);
        int m = prj_insert_block(&g_prj, s, 0, f, BK_IF);
        prj_plug(&g_prj, s, sc, &sc->blocks[m], 0, BK_TOUCHING, NULL);
        strcpy(prj_node(sc, m, (int[]){ 0 }, 1)->a[0].text, "mouse-pointer");
        prj_insert_block(&g_prj, s, 0, m, BK_TURN_R);
        int pdn = prj_insert_block(&g_prj, s, 0, prj_match_end(sc, m), BK_PEN_DOWN);
        prj_insert_block(&g_prj, s, 0, pdn, BK_CHANGE_X);
    }
    strcpy(kb_reply, "mygame");
    tap_btn(2);
    assert(strstr(g_status, "Saved"));
    assert(access("sdmc:/3ds/scratch-editor/mygame.sb3", R_OK) == 0);
    fake_mic_amp = 8000;
    starts = fake_mic_calls_start;
    touch(30, BTN_Y + 5);
    assert(g_play == 1 && g_monitoring && fake_mic_calls_start == starts + 1);
    touch(10, 10);
    assert(g_mode == MODE_SCRIPTS);
    for (int i = 0; i < 3; i++) { mic_poll(); rt_set_loudness(&g_rt, g_rec.level); rt_tick(&g_rt, &g_prj, 1.f / 30.f); }
    assert(rt_ask_pending(&g_rt));
    strcpy(kb_reply, "Ana");
    play_ask();
    for (int i = 0; i < 5; i++) { mic_poll(); rt_set_loudness(&g_rt, g_rec.level); rt_tick(&g_rt, &g_prj, 1.f / 30.f); }
    {
        assert(g_rt.loudness > 40 && g_rt.loudness < 60);
        assert(g_rt.spr[0].x > 0);
    }
    play_pointer(160, 120, 1, 1);
    assert(fabsf(g_rt.mouse_x) < 2.f && fabsf(g_rt.mouse_y) < 2.f && g_rt.mouse_down);
    play_pointer(0, 0, 1, 0);
    assert(fabsf(g_rt.mouse_x + 240.f) < 1.f && fabsf(g_rt.mouse_y - 180.f) < 1.f);
    frame_objects();
    int stops = fake_mic_calls_stop;
    stop_play();
    assert(g_play == 0 && !g_monitoring && fake_mic_calls_stop == stops + 1);

    g_mic_ok = 0;
    start_play();
    assert(g_play == 1 && !g_monitoring);
    stop_play();
    g_mic_ok = 1;

    prj_clear(&g_prj); prj_init(&g_prj);
    while (prj_add_sprite(&g_prj) >= 0) {}
    static int16_t tone[REC_MAX_SAMPLES];
    for (int i = 0; i < REC_MAX_SAMPLES; i++) tone[i] = (int16_t)(sinf(i * 0.1f) * 12000);
    for (int s = 0; s < g_prj.nsprites; s++) {
        while (prj_add_costume(&g_prj, s) >= 0) {}
        while (prj_add_sound(&g_prj, s) >= 0) {}
        for (int k = 0; k < MAX_SOUNDS; k += 2) { prj_delete_sound(&g_prj, s, k); prj_add_recording(&g_prj, s, tone, REC_MAX_SAMPLES, REC_RATE); }
        for (int p = 0; p < COSTUME_W * COSTUME_H; p += 3) g_prj.sprites[s].costumes[0].px[p] = (uint8_t)(p % 15 + 1);
        g_prj.sprites[s].cur_costume = 0;
    }
    prj_add_var(&g_prj, "a");

    {
        Script *sc = &g_prj.sprites[0].scripts[0];
        (void)sc;
        int pd = prj_insert_block(&g_prj, 0, 0, 0, BK_PEN_DOWN);
        int f = prj_insert_block(&g_prj, 0, 0, pd, BK_FOREVER);
        int m = prj_insert_block(&g_prj, 0, 0, f, BK_MOVE);
        int tr = prj_insert_block(&g_prj, 0, 0, m, BK_TURN_R);
        int st = prj_insert_block(&g_prj, 0, 0, tr, BK_STAMP);
        int sv = prj_insert_block(&g_prj, 0, 0, st, BK_SHOW_VAR);
        (void)sv;
        strcpy(g_prj.sprites[0].scripts[0].blocks[m].a[0].text, "10");
        strcpy(g_prj.sprites[0].scripts[0].blocks[tr].a[0].text, "15");
    }
    select_sprite(0);
    rt_green_flag(&g_rt, &g_prj);
    g_play = 1;
    for (int i = 0; i < PEN_SEGS + 100; i++) rt_tick(&g_rt, &g_prj, 1.f / 30.f);
    assert(g_rt.pen_count == PEN_SEGS && g_rt.nstamps == MAX_STAMPS);
    puts("draw-call budget (full project, worst-case noisy costumes, 1024 pen segments, 4 stamps):");
    int worst = 0;
    for (int m = 0; m < 3; m++) { g_mode = m; int n = frame_objects(); if (n > worst) worst = n; }
    g_play = 0;
    g_mode = MODE_SCRIPTS;
    int n = frame_objects(); if (n > worst) worst = n;
    printf("worst frame: %d of %d\n", worst, C2D_DEFAULT_MAX_OBJECTS * 4);
    g_play = 1; frame_objects(); g_play = 0;
    g_run_bottom = 1; g_play = 1; { int w2 = frame_objects(); printf("worst frame running on the bottom screen: %d\n", w2); } g_play = 0; g_run_bottom = 0;
    g_mode = MODE_SOUNDS; g_snd = 1; frame_objects(); g_mode = MODE_SCRIPTS;

    assert(sb3_write_project(&g_prj, "sdmc:/3ds/scratch-editor/full.sb3") == 0);
    struct stat st;
    assert(stat("sdmc:/3ds/scratch-editor/full.sb3", &st) == 0);
    printf("full project .sb3: %ld bytes\n", (long)st.st_size);
    assert(st.st_size > 20000);
    const char *dump = getenv("SB3CHECK");
    if (dump) {
        char cmd[512];
        snprintf(cmd, sizeof cmd, "python3 -I '%s' sdmc:/3ds/scratch-editor/full.sb3 > /dev/null && python3 -I '%s' sdmc:/3ds/scratch-editor/mygame.sb3 > /dev/null", dump, dump);
        assert(system(cmd) == 0);
        puts("full project and mygame.sb3 validated by sb3check.py");
    }

    puts("drag & drop:");
    prj_clear(&g_prj); prj_init(&g_prj); rt_reset(&g_rt, &g_prj);
    g_mode = MODE_SCRIPTS; g_sprite = 0; g_script = 0; g_scroll = 0; g_sel = 0; g_pal_scroll = 0;
    {
        Script *q;
        #define DRAG(X0, Y0, X1, Y1) do { drag_begin(X0, Y0); drag_move((X0 + X1) / 2, (Y0 + Y1) / 2); drag_move(X1, Y1); frame_objects(); drag_end(); } while (0)
        tap_cat(CAT_MOTION);

        DRAG(PAL_X + 30, PAL_Y + 5, SCR_X + 30, SCR_Y + SCR_ROW + 2);
        q = &g_prj.sprites[0].scripts[0];
        assert(q->nblocks == 2 && q->blocks[1].kind == BK_MOVE && g_sel == 1);
        DRAG(PAL_X + 30, PAL_Y + PAL_ROW + 5, SCR_X + 30, SCR_Y + 2 * SCR_ROW + 2);
        assert(q->nblocks == 3 && q->blocks[2].kind != BK_MOVE);
        int second = q->blocks[2].kind;

        DRAG(SCR_X + 30, SCR_Y + 2 * SCR_ROW + 5, SCR_X + 30, SCR_Y + SCR_ROW - 3);
        assert(q->nblocks == 3 && q->blocks[1].kind == second && q->blocks[2].kind == BK_MOVE);

        DRAG(SCR_X + 30, SCR_Y + 2 * SCR_ROW + 5, PAL_X + 30, PAL_Y + 30);
        assert(q->nblocks == 2 && q->blocks[1].kind == second);

        g_sel = 0;
        drag_begin(SCR_X + 30, SCR_Y + SCR_ROW + 5); drag_end();
        assert(g_sel == 1);

        drag_begin(SCR_X + 30, SCR_Y + 5); drag_move(PAL_X + 30, PAL_Y + 5); drag_move(PAL_X + 30, PAL_Y + 8); drag_end();
        assert(q->nblocks == 2 && q->blocks[0].kind == BK_HAT_FLAG);

        tap_cat(CAT_OPERATORS);
        PalEntry pe[PAL_MAX]; int np = palette_entries(CAT_OPERATORS, pe), add = -1;
        for (int i = 0; i < np; i++) if (pe[i].kind == BK_ADD) add = i;
        assert(add >= 0 && add < PAL_ROWS);
        q->blocks[1].kind = BK_MOVE;
        DRAG(PAL_X + 30, PAL_Y + add * PAL_ROW + 5, SCR_X + 30, SCR_Y + SCR_ROW + 5);
        assert(q->blocks[1].a[0].expr >= 0);

        int ns = g_prj.sprites[0].nscripts;
        tap_cat(CAT_CONTROL);
        DRAG(PAL_X + 30, PAL_Y + 5, SCR_X + 30, SCR_Y + 3 * SCR_ROW);
        assert(g_prj.sprites[0].nscripts == ns + 1);
    }
    g_sel = 0; g_script = 0;
    puts("drag & drop ok");

    puts("undo, redo, duplicate:");
    prj_clear(&g_prj); prj_init(&g_prj); rt_reset(&g_rt, &g_prj); undo_clear(&g_undo);
    g_mode = MODE_SCRIPTS; g_sprite = 0; g_script = 0; g_sel = 0; g_scroll = 0; g_pal_scroll = 0; focus_reset();
    {
        Script *q = &g_prj.sprites[0].scripts[0];
        tap_btn(4); assert(q->nblocks == 1);
        tap_palette(BK_MOVE, 0);
        tap_palette(BK_TURN_R, 0);
        assert(q->nblocks == 3);
        tap_btn(4); assert(q->nblocks == 2 && q->blocks[1].kind == BK_MOVE);
        tap_btn(4); assert(q->nblocks == 1);
        tap_btn(5); assert(q->nblocks == 2);
        tap_btn(5); assert(q->nblocks == 3 && q->blocks[2].kind == BK_TURN_R);
        tap_btn(5); assert(q->nblocks == 3);
        tap_btn(4);
        select_block(1);
        tap_palette(BK_SAY, 0);
        tap_btn(5); assert(q->nblocks == 3 && q->blocks[2].kind == BK_SAY);

        select_block(2);
        strcpy(kb_reply, "Boo!");
        tap_arg(0);
        assert(!strcmp(q->blocks[2].a[0].text, "Boo!"));
        tap_btn(4); assert(strcmp(q->blocks[2].a[0].text, "Boo!") != 0);
        tap_btn(5); assert(!strcmp(q->blocks[2].a[0].text, "Boo!"));

        tap_cat(CAT_OPERATORS);
        tap_palette(BK_ADD, 0);
        select_block(1); tap_delete();
        assert(q->nblocks == 2);
        tap_btn(4); assert(q->nblocks == 3);
        tap_btn(4);
        assert(q->blocks[2].a[0].expr < 0 || q->blocks[2].kind != BK_ADD);

        tap_cat(CAT_CONTROL);
        tap_palette(BK_REPEAT, 0);
        int rp = g_sel;
        assert(q->blocks[rp].kind == BK_REPEAT);
        tap_palette(BK_STOP_SCRIPT, 0);
        int n0 = q->nblocks;
        select_block(rp);
        tap_btn(6);
        assert(q->nblocks == n0 + 3 && q->blocks[g_sel].kind == BK_REPEAT);
        tap_btn(4); assert(q->nblocks == n0);
        select_block(1);
        tap_btn(6); assert(q->nblocks == n0 + 1 && q->blocks[2].kind == q->blocks[1].kind);
        select_block(0);
        int ns = g_prj.sprites[0].nscripts;
        tap_btn(6);
        assert(g_prj.sprites[0].nscripts == ns + 1 && g_script == ns);
        assert(g_prj.sprites[0].scripts[ns].nblocks == g_prj.sprites[0].scripts[0].nblocks);
        tap_btn(4); assert(g_prj.sprites[0].nscripts == ns);

        assert(g_undo.nundo > 0);
        undo_clear(&g_undo);
        tap_btn(4); assert(g_undo.nredo == 0);

        tap_tab(MODE_COSTUMES); tap_btn(4);
        assert(strstr(g_status, "scripts"));
        tap_tab(MODE_SCRIPTS);
    }
    puts("undo / redo / duplicate ok");

    puts("effects, templates:");
    prj_clear(&g_prj); prj_init(&g_prj); rt_reset(&g_rt, &g_prj); undo_clear(&g_undo);
    g_sprite = 0; g_snd = -1;
    tap_tab(MODE_SOUNDS);
    {
        Sprite *sp = &g_prj.sprites[0];
        int before = sp->nsounds;
        touch(160, SN_REC_Y + 5);
        assert(g_pk.action == PK_FX && g_pk.n == SND_PRESET_COUNT);
        pick(2);
        assert(sp->nsounds == before + 1 && snd_is_recorded(&sp->sounds[before]) && g_snd == before);
        assert(!strncmp(sp->sounds[before].name, "coin", 4) && sp->sounds[before].npcm > 1000);
        for (int k = 0; k < SND_PRESET_COUNT; k++) {
            touch(160, SN_REC_Y + 5);
            if (sp->nsounds >= MAX_SOUNDS) break;
            pick(k);
        }
        assert(sp->nsounds <= MAX_SOUNDS);
        tap_btn(6);
        tap_btn(6); tap_btn(6);
        assert(sp->nsounds == MAX_SOUNDS);
        assert(sb3_write_project(&g_prj, "sdmc:/3ds/scratch-editor/fx.sb3") == 0);
    }
    tap_tab(MODE_SCRIPTS);
    {

        touch(292 + 5, SPR_Y + 5);
        assert(g_pk.action == PK_SPRITE_MENU);
        pick(SM_TEMPLATES);
        assert(g_pk.action == PK_TEMPLATE && g_pk.n == tpl_count());
        pick(3);
        assert(g_pk.action == PK_TEMPLATE_OK);
        pick(1);
        assert(g_prj.nsprites == 1);
        touch(292 + 5, SPR_Y + 5); pick(SM_TEMPLATES); pick(3); pick(0);
        assert(g_prj.nsprites == 3 && !strcmp(g_prj.sprites[0].name, "Cannon") && g_sprite == 0 && g_undo.nundo == 0);
        frame_objects();
        g_play = 1; rt_green_flag(&g_rt, &g_prj);
        rt_key(&g_rt, &g_prj, "space");
        for (int i = 0; i < 6; i++) rt_tick(&g_rt, &g_prj, 1.f / 30.f);
        assert(rt_nclones(&g_rt) == 1);
        frame_objects();
        g_play = 0; rt_stop(&g_rt);

        int calls = kb_numpad_calls;
        g_script = 0; select_block(0);
        tap_palette(BK_MOVE, 0);
        strcpy(kb_reply, "12");
        tap_arg(0); tap_arg(0);
        assert(kb_numpad_calls > calls);
        assert(!strcmp(g_prj.sprites[0].scripts[0].blocks[g_sel].a[0].text, "12"));
        kb_button = SWKBD_BUTTON_LEFT;
        int x_before = g_prj.sprites[0].x;
        touch(292 + 5, SPR_Y + 5); pick(SM_X);
        assert(g_prj.sprites[0].x == x_before);
        kb_button = SWKBD_BUTTON_RIGHT;
        strcpy(kb_reply, "Reply");
    }
    puts("effects, templates ok");

    {
        prj_clear(&g_prj); prj_init(&g_prj); rt_reset(&g_rt, &g_prj);
        g_mode = MODE_SCRIPTS; g_sprite = 0; g_script = 0; g_sel = 0; g_scroll = 0; g_pk.action = PK_NONE; g_play = 0;
        int red = pal_find("red");
        memset(g_prj.sprites[0].costumes[0].px, red, COSTUME_W * COSTUME_H);
        g_prj.sprites[0].x = 0; g_prj.sprites[0].y = 0;
        int sv = prj_insert_block(&g_prj, 0, 0, 0, BK_IF);
        assert(sv > 0);
        Script *sc = cur_script();
        assert(prj_plug(&g_prj, 0, sc, &sc->blocks[sv], 0, BK_TOUCHING_COLOR, NULL) == 0);
        select_block(sv);
        g_foc.depth = 1; g_foc.path[0] = 0; g_foc.slot = 0;
        edit_focused();
        assert(g_bs == BS_PICK && g_pk.action == PK_NONE);
        rt_reset(&g_rt, &g_prj);
        frame_objects();
        float px = (0 + STAGE_W / 2.0f) * PAD_S, py = (STAGE_H / 2.0f) * PAD_S;
        bs_touch((int)px, (int)py, 1);
        assert(g_bs == BS_OFF);
        assert(strcmp(prj_node(sc, sv, g_foc.path, g_foc.depth)->a[0].text, PALETTE_NAMES[red]) == 0);
        memset(g_prj.sprites[STAGE_IDX].costumes[0].px, 0, COSTUME_W * COSTUME_H);
        rt_reset(&g_rt, &g_prj);
        edit_focused();
        assert(g_bs == BS_PICK);
        bs_touch(5, 235, 1);
        assert(g_bs == BS_PICK && strstr(g_status, "Nothing there"));
        bs_touch(10, BS_BTN_Y + 5, 1);
        assert(g_bs == BS_OFF && g_pk.action == PK_ARG);
        picker_close();

        assert(!g_play);
        bs_toggle_move();
        assert(g_bs == BS_MOVE && !g_play);
        bs_touch(160 + 30, 120 - 15, 1);
        assert(g_prj.sprites[0].x == (int)lroundf(30 / PAD_S) && g_prj.sprites[0].y == (int)lroundf(15 / PAD_S));
        bs_touch(10, BS_BTN_Y + 5, 1);
        assert(g_bs == BS_OFF);
        bs_toggle_move(); bs_toggle_move();
        assert(g_bs == BS_OFF);
        select_sprite(STAGE_IDX);
        bs_toggle_move();
        assert(g_bs == BS_OFF);
        select_sprite(0);
    }
    puts("stage on the bottom screen ok");

    {
        prj_clear(&g_prj); prj_init(&g_prj); rt_reset(&g_rt, &g_prj);
        g_mode = MODE_SCRIPTS; g_sprite = 0; g_script = 0; g_sel = 0; g_scroll = 0; g_pk.action = PK_NONE; g_play = 0; g_bs = BS_OFF;
        tap_cat(CAT_PEN);
        PalEntry pe[PAL_MAX];
        int n = palette_entries(CAT_PEN, pe);
        for (int i = 0; i < n && i < PAL_ROWS; i++) {
            if (BLOCK_INFO[pe[i].kind].shape == SH_REP || BLOCK_INFO[pe[i].kind].shape == SH_BOOL) continue;
            int before = cur_script()->nblocks;
            touch(PAL_X + 30, PAL_Y + i * PAL_ROW + 5);
            assert(cur_script()->nblocks == before + 1);
            assert(cur_script()->blocks[g_sel].kind == pe[i].kind);
        }
        for (int i = 0; i < n; i++) printf("   pen palette row %d: %s\n", i, BLOCK_INFO[pe[i].kind].label);
    }
    puts("pen palette ok");

    {
        prj_clear(&g_prj); prj_init(&g_prj); rt_reset(&g_rt, &g_prj);
        g_mode = MODE_SCRIPTS; g_sprite = 0; g_script = 0; g_sel = 0; g_pk.action = PK_NONE; g_play = 0; g_bs = BS_OFF;
        tap_tab(MODE_ABOUT);
        assert(g_mode == MODE_ABOUT);
        int nsnd = cur()->nsounds, ncos = cur()->ncostumes, nsc = cur()->nscripts;
        tap_delete(); tap_btn(6);
        assert(cur()->nsounds == nsnd && cur()->ncostumes == ncos && cur()->nscripts == nsc);
        assert(g_about_scroll == 0);
        touch(300, 170);
        assert(g_about_scroll == 5);
        for (int i = 0; i < 40; i++) touch(300, 170);
        assert(g_about_scroll == ABOUT_N - ABOUT_ROWS);
        for (int i = 0; i < 40; i++) touch(300, 30);
        assert(g_about_scroll == 0);
        int has_hist = 0, has_ver = 0;
        for (int i = 0; i < ABOUT_N; i++) { if (strstr(ABOUT_LINES[i], "Scratch Everywhere")) has_hist = 1; if (strstr(ABOUT_LINES[i], APP_VERSION)) has_ver = 1; }
        assert(has_hist && has_ver);
        frame_objects();
        tap_tab(MODE_SCRIPTS);
        assert(g_mode == MODE_SCRIPTS);
    }

    {
        g_light = 0; assert(th_hex(0x2B2B33) == 0x2B2B33);
        g_light = 1;
        assert(th_hex(0x2B2B33) == 0xD4D4CC && th_hex(0xFFFFFF) == 0x000000);
        assert(th_hex(0x4C97FF) == 0x4C97FF);
        for (int m = 0; m < MODE_COUNT; m++) { tap_tab(m); frame_objects(); }
        tap_tab(MODE_SCRIPTS);
        g_light = 0;
    }

    {
        prj_clear(&g_prj); prj_init(&g_prj); rt_reset(&g_rt, &g_prj);
        g_mode = MODE_SCRIPTS; g_sprite = 0; g_script = 0; g_sel = 0; g_scroll = 0; g_pk.action = PK_NONE; g_play = 0; g_bs = BS_OFF;
        int h = prj_insert_block(&g_prj, 0, 0, 0, BK_HAT_FLAG);
        int a = prj_insert_block(&g_prj, 0, 0, h, BK_PEN_DOWN);
        int f = prj_insert_block(&g_prj, 0, 0, a, BK_FOREVER);
        int m = prj_insert_block(&g_prj, 0, 0, f, BK_MOVE);
        int t = prj_insert_block(&g_prj, 0, 0, m, BK_TURN_R);
        int st = prj_insert_block(&g_prj, 0, 0, t, BK_STAMP);
        (void)st;
        start_play();
        int worst = 0;
        for (int i = 0; i < 4000; i++) {
            rt_tick(&g_rt, &g_prj, 1.0f / 30.0f);
            if (i % 200 == 0) { int n = frame_objects(); if (n > worst) worst = n; }
        }
        printf("   pen stress: %d pen segments, %d stamps, worst frame %d draw calls\n", g_rt.pen_count, g_rt.nstamps, worst);
        stop_play();
    }
    puts("about tab ok");

    {
        prj_clear(&g_prj); prj_init(&g_prj); rt_reset(&g_rt, &g_prj);
        g_mode = MODE_SCRIPTS; g_sprite = 0; g_script = 0; g_sel = 0; g_scroll = 0; g_pk.action = PK_NONE; g_play = 0; g_bs = BS_OFF;
        srand(12345);
        for (int it = 0; it < 30000; it++) {
            int r = rand() % 100;
            if (r < 70) touch(rand() % 320, rand() % 240);
            else if (r < 78) { if (g_play) stop_play(); }
            else if (r < 84) bs_toggle_move();
            else if (r < 90) { if (g_bs) bs_touch(rand() % 320, rand() % 240, rand() & 1); }
            else if (r < 94) tap_tab(rand() % MODE_COUNT);
            else if (r < 97) sprite_step(rand() & 1 ? 1 : -1);
            else { strcpy(kb_reply, rand() & 1 ? "12" : "abc"); }
            if (g_play) { rt_tick(&g_rt, &g_prj, 1.f / 30.f); if (it % 7 == 0) stop_play(); }
            else rt_reset(&g_rt, &g_prj);
            clamp_state();
            assert(g_sprite == STAGE_IDX || (g_sprite >= 0 && g_sprite < g_prj.nsprites));
            if (g_sprite != STAGE_IDX) {
                assert(g_script >= 0 && g_script < cur()->nscripts);
                assert(g_sel >= 0 && g_sel < cur_script()->nblocks);
            }
            if (it % 500 == 0) frame_objects();
        }
    }
    puts("fuzz ok");

    mic_exit();
    prj_clear(&g_prj);
    puts("all UI tests passed");
    return 0;
}
