
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "assets.h"
#include "editor.h"
#include "importer.h"
#include "sb3_writer.h"

int main(int argc, char **argv)
{
    assert(argc > 1);
    const char *root = argv[1];
    ImportEntry e[IMP_MAX_ENTRIES];
    int n = imp_scan(root, e, IMP_MAX_ENTRIES);
    for (int i = 0; i < n; i++) printf("  entry %-8s %s\n", e[i].name, e[i].is_dir ? "(folder)" : "(image)");
    assert(n == 4);
    assert(strcmp(e[0].name, "coin") == 0 && !e[0].is_dir);
    assert(strcmp(e[1].name, "Empty") == 0 && strcmp(e[2].name, "Hero") == 0 && strcmp(e[3].name, "Mixed") == 0);
    assert(imp_scan("/nonexistent/dir", e, IMP_MAX_ENTRIES) == 0);
    n = imp_scan(root, e, IMP_MAX_ENTRIES);

    Project p; memset(&p, 0, sizeof p); prj_init(&p);
    char err[128];

    Sprite s;
    assert(imp_load_sprite(&e[2], &s, err, sizeof err) == 0);
    printf("  Hero: '%s' %d costumes, %d sounds, warning: %s\n", s.name, s.ncostumes, s.nsounds, err);
    assert(strcmp(s.name, "Knight") == 0 && s.x == 120 && s.y == -80 && s.direction == 0 && s.size == 150 && s.visible == 0);
    assert(s.ncostumes == 4 && s.nsounds == 2 && strstr(err, "1 file(s) skipped"));
    assert(strcmp(s.costumes[0].name, "a_walk") == 0 && strcmp(s.costumes[1].name, "b_walk") == 0);
    assert(s.cur_costume == 1);

    Costume *c0 = &s.costumes[0];
    assert(c0->px[16 * COSTUME_W + 16] != 0 && c0->px[2 * COSTUME_W + 2] == 0 && c0->px[0] == 0 && c0->px[COSTUME_W * 31 + 16] == 0);
    uint32_t red = costume_argb(c0->px[16 * COSTUME_W + 16]);
    assert(((red >> 16) & 255) > 150 && ((red >> 8) & 255) < 100 && (red & 255) < 100);
    uint32_t blue = costume_argb(s.costumes[1].px[16 * COSTUME_W + 16]);
    assert((blue & 255) > ((blue >> 16) & 255) + 60);
    assert(s.costumes[2].px[16 * COSTUME_W + 16] != 0);
    assert(s.costumes[3].px[0] == 0 && s.costumes[3].px[8] != 0);
    assert(snd_is_recorded(&s.sounds[0]) && strcmp(s.sounds[0].name, "hit") == 0 && s.sounds[0].rate == 8000);
    assert(s.sounds[0].npcm > 1900 && s.sounds[0].npcm <= 2000);
    assert(strcmp(s.sounds[1].name, "jump") == 0 && s.sounds[1].rate == SND_RATE && s.sounds[1].npcm > 5400 && s.sounds[1].npcm < 5600);
    int peak = 0;
    for (int i = 0; i < s.sounds[1].npcm; i++) if (abs(s.sounds[1].pcm[i]) > peak) peak = abs(s.sounds[1].pcm[i]);
    assert(peak > 9000 && peak < 13000);
    int h = prj_add_imported(&p, &s);
    assert(h == 1 && p.nsprites == 2 && strcmp(p.sprites[1].name, "Knight") == 0 && p.sprites[1].nscripts == 1 && s.nsounds == 0);

    Sprite m;
    assert(imp_load_sprite(&e[3], &m, err, sizeof err) == 0 && m.ncostumes == 3 && m.nsounds == 0 && err[0] == 0);
    assert(strcmp(m.name, "Mixed") == 0 && m.visible == 1 && m.size == 100 && m.direction == 90);
    assert(m.costumes[0].px[16 * COSTUME_W + 1] == 0);
    assert(m.costumes[0].px[7 * COSTUME_W + 16] != 0 && m.costumes[0].px[24 * COSTUME_W + 16] != 0);
    assert(m.costumes[0].px[7 * COSTUME_W + 16] != m.costumes[0].px[24 * COSTUME_W + 16]);
    assert(((costume_argb(m.costumes[0].px[7 * COSTUME_W + 16]) & 255) > 150));
    assert(m.costumes[2].px[16 * COSTUME_W + 16] != 0 && m.costumes[2].px[0] != 0);
    int mi = prj_add_imported(&p, &m);
    assert(mi == 2 && strcmp(p.sprites[2].name, "Mixed") == 0);

    Sprite coin;
    assert(imp_load_sprite(&e[0], &coin, err, sizeof err) == 0 && coin.ncostumes == 1 && strcmp(coin.name, "coin") == 0);
    assert(coin.costumes[0].px[16 * COSTUME_W + 16] != 0 && coin.costumes[0].px[0] == 0);
    Sprite none;
    assert(imp_load_sprite(&e[1], &none, err, sizeof err) == -1 && strstr(err, "no images"));
    assert(none.ncostumes == 0);

    Sprite again;
    assert(imp_load_sprite(&e[2], &again, err, sizeof err) == 0);
    int ai = prj_add_imported(&p, &again);
    assert(strcmp(p.sprites[ai].name, "Knight2") == 0);
    assert(p.sprites[ai].sounds[0].pcm && p.sprites[ai].sounds[0].pcm != p.sprites[1].sounds[0].pcm);

    int d = prj_duplicate_sprite(&p, 1);
    assert(d == p.nsprites - 1 && strcmp(p.sprites[d].name, "Knight3") == 0);
    assert(p.sprites[d].sounds[1].pcm != p.sprites[1].sounds[1].pcm && p.sprites[d].sounds[1].npcm == p.sprites[1].sounds[1].npcm);
    assert(memcmp(p.sprites[d].sounds[1].pcm, p.sprites[1].sounds[1].pcm, (size_t)p.sprites[d].sounds[1].npcm * 2) == 0);
    assert(p.sprites[d].x != p.sprites[1].x || p.sprites[d].y != p.sprites[1].y);
    prj_delete_sprite(&p, 1);
    assert(p.sprites[p.nsprites - 1].sounds[1].pcm && p.sprites[p.nsprites - 1].sounds[1].npcm > 5000);

    char first[TEXT_LEN]; strcpy(first, p.sprites[0].name);
    assert(prj_move_sprite(&p, 0, 1) == 1 && strcmp(p.sprites[1].name, first) == 0);
    assert(prj_move_sprite(&p, 1, -1) == 0 && strcmp(p.sprites[0].name, first) == 0);
    assert(prj_move_sprite(&p, 0, -1) == 0);
    assert(prj_move_sprite(&p, p.nsprites - 1, 1) == p.nsprites - 1);

    char out[256]; snprintf(out, sizeof out, "%s/imported.sb3", root);
    assert(sb3_write_project(&p, out) == 0);

    unsigned char junk[64], dst[64]; size_t ol;
    for (int i = 0; i < 64; i++) junk[i] = (unsigned char)(i * 37 + 11);
    assert(inflate_zlib(junk, sizeof junk, dst, sizeof dst, &ol) != 0);
    junk[0] = 0x78; junk[1] = 0x9c;
    inflate_zlib(junk, sizeof junk, dst, sizeof dst, &ol);

    int guard = 0;
    while (p.nsprites < MAX_SPRITES) { Sprite q; assert(imp_load_sprite(&e[0], &q, err, sizeof err) == 0); assert(prj_add_imported(&p, &q) >= 0); assert(++guard < 40); }
    Sprite q; assert(imp_load_sprite(&e[0], &q, err, sizeof err) == 0);
    assert(prj_add_imported(&p, &q) == -1 && prj_duplicate_sprite(&p, 0) == -1);

    prj_clear(&p);
    for (int k = 0; k < MAX_SOUNDS; k++) { snd_free(&again.sounds[k]); snd_free(&s.sounds[k]); snd_free(&m.sounds[k]); }
    puts("all import tests passed");
    return 0;
}
