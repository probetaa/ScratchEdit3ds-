# ScratchEdit3DS (prototipo)

Editor táctil para Nintendo 3DS (homebrew) con **varios sprites**, **editor de disfraces**
(pixel art), **editor de sonidos** y editor de bloques, que guarda proyectos en formato
**`.sb3`** (Scratch 3). No es un port del editor oficial de Scratch: el editor oficial
(Scratch 3) es JavaScript/HTML y no cabe en una 3DS, así que esto es un editor nuevo, escrito
en C con libctru + citro2d, que genera archivos `.sb3`.

> Proyecto no oficial; "Scratch" es una marca del MIT / Scratch Foundation.

## Estado: leer antes de usar

| Parte | Estado |
|---|---|
| Escritor `.sb3` (`source/sb3_writer.c`) | ZIP sin compresión con `project.json` + PNG/WAV nombrados por MD5, con MD5/CRC32/PNG implementados a mano. **Verificado con el motor real de Scratch 3**: el proyecto de ejemplo pasa `scratch-parser` (esquema oficial), se carga en `scratch-vm`, y al pulsar la bandera verde los sprites se mueven y las variables cambian como en el editor; los 114 opcodes de la tabla aparecen en `all_blocks.sb3` y `tools/sb3check.py` comprueba referencias, MD5 y alcanzabilidad. No lo he abierto en la interfaz web de Scratch. |
| Escritor `.sb` (Scratch 1.x, `sb_writer.c`) | Ya no lo usa el editor; se conserva con sus pruebas. Sin verificar contra Scratch 1.4. |
| Editor, intérprete, assets, grabadora, importador | Probados en PC (`tools/test_*.c`). |
| Interfaz (`source/main.c`) | La lógica táctil se probó en PC compilando `main.c` con librerías simuladas (`tools/test_ui.c`). **No compilada contra libctru/citro2d reales ni probada en una consola.** |
| Micrófono (`mic*` de libctru) | Escrito de memoria según la API; en las pruebas es un micrófono simulado. **Sin probar en hardware.** |
| Teclado numérico (`SWKBD_TYPE_NUMPAD`) | Llamadas según la API de libctru; en las pruebas es un teclado simulado. **Sin probar en la consola.** |
| Audio (`ndsp`) | Escrito según la API de libctru, sin probar. Necesita `sd:/3ds/dspfirm.cdc`, también en emuladores (carpeta `sdmc/3ds/` del emulador); si `ndspInit` falla, el editor lo dice en la línea de estado con el código de error. |

Diferencias al exportar a Scratch 3 (limitaciones del formato, no de la interfaz):
`forever if` se guarda como `forever { if }`; `loud?` como `loudness > 10`; las variables y listas
son globales (del Escenario) y las listas empiezan vacías; los disfraces se guardan como PNG de
64×64 (cada píxel del editor = 2×2); los tonos sintetizados se guardan como WAV. Los bloques de
lápiz y música usan las extensiones `pen` y `music` de Scratch 3, que se activan solas si hay
bloques de ese tipo. `touching color` / `color is touching` sí se simulan (ver abajo).

## Compilar

1. Instala devkitPro y las librerías: `sudo dkp-pacman -S 3ds-dev` (incluye citro2d/citro3d).
2. `export DEVKITPRO=/opt/devkitpro` y `export DEVKITARM=$DEVKITPRO/devkitARM`
3. `make` → genera `scratch3ds.3dsx`.
4. Copia `scratch3ds.3dsx` a `sd:/3ds/` y ábrelo desde el Homebrew Launcher.

**CIA (instalable con FBI)**: además de lo anterior necesitas `makerom` y `bannertool` en el PATH
(binarios de [3DSGuy/Project_CTR](https://github.com/3DSGuy/Project_CTR) y
[Epicpkmn11/bannertool](https://github.com/Epicpkmn11/bannertool)). Luego `make cia` genera `scratch3ds.cia`
(usa `resources/icon.png`, `banner.png`, `audio.wav` y `app.rsf`). Instálalo con FBI. El audio sigue necesitando
`sd:/3ds/dspfirm.cdc`. El `.rsf` y el `make cia` **no están probados**: si `makerom` protesta por alguna clave, es el `.rsf`.

Los proyectos se guardan en `sd:/3ds/scratch-editor/<nombre>.sb3` y se abren en Scratch 3 (scratch.mit.edu o el editor de escritorio: Archivo → Cargar desde tu computadora).

## Uso

La pantalla inferior tiene tres pestañas (**Scripts**, **Costumes**, **Sounds**), debajo el
selector de sprites y abajo los botones **Flag / Stop / Save / Del / Undo / Redo / Dup**. La superior muestra el
escenario (Scripts), el disfraz en grande (Costumes) o la forma de onda (Sounds).

**Sprites** (hasta 12): `<` `>` cambian de sprite, `+` crea uno nuevo, `-` borra el actual y tocar
el nombre abre la lista de sprites. El botón **`Spr`** abre el menú del sprite: renombrar,
duplicar (copia scripts, disfraces y grabaciones), mover en la lista / capa, editar `x`, `y`,
dirección, tamaño (%) y visibilidad (valores iniciales que se guardan en el `.sb3`), e importar.

**Fondos (Stage)**: toca el nombre del sprite y elige `Stage (backdrops)` al final de la lista. Con el
Escenario seleccionado, la pestaña **Costumes** edita los fondos (mismo lienzo, paleta, `New`, `Name`, `Flip`,
`Delete`; el fondo mostrado es el seleccionado) y **Sounds** sus sonidos. El primer fondo es blanco; lo
transparente se ve blanco. `<` `>` / L R vuelven a los sprites. El Escenario no tiene scripts: al pulsar
Flag desde el Escenario el editor pasa al primer sprite. En el `.sb3` cada fondo se guarda como SVG de 480×360.

**Importar sprites desde una carpeta** (por ejemplo la que crea un juego o una herramienta de PC):
deja carpetas en `sd:/3ds/scratch-editor/sprites/` (el editor la crea) y usa `Spr → Import sprite...`
(uno) o `Import ALL` (todos).

```
sprites/
  Hero/              una carpeta = un sprite llamado "Hero"
    sprite.txt       opcional: name=  x=  y=  direction=  size=  visible=  costume=  (líneas "clave=valor", # comentarios)
    walk1.png        imágenes .png / .bmp / .ppm -> disfraces, por orden alfabético (máx. 6)
    walk2.png
    jump.wav         .wav PCM 8/16 bit, mono o estéreo -> sonidos (máx. 6; se reducen a ≤ 11025 Hz y 4 s)
  coin.png           una imagen suelta = sprite de un disfraz
```

Las imágenes se ajustan a 32×32 (conservando la proporción) y a la paleta de 15 colores; alfa
< 128 es transparente, y en BMP/PPM el magenta `#FF00FF` también. No se admiten PNG entrelazados
ni BMP comprimidos. Los archivos que fallan se saltan y el editor avisa de cuántos. Los nombres
repetidos se numeran (`Hero`, `Hero2`...). `tools/make_fixtures.py DIR` genera una carpeta de ejemplo.

**Scripts**: 9 categorías (Motion, Looks, Sound, Pen, Control, Sensing, Operators, Variables,
Lists) con **123 bloques** (los 117 de Scratch 1.x, dos de la PicoBoard, tres de clones y `pen down?`, que no existen en Scratch). Toca un bloque de la paleta para añadirlo después del bloque
seleccionado (los sombreros crean un script nuevo; `forever`, `repeat`, `if`, `if else`... crean
su cuerpo con marcadores `end`/`else`). Los botones `^`/`v` desplazan la paleta.

*Argumentos:* la barra inferior del script muestra los 3 huecos del bloque seleccionado. Toca un
hueco para enfocarlo y otra vez para editarlo: teclado, o un menú (disfraz, sonido, tecla,
mensaje, variable, lista, efecto, color de lápiz, sprite...). Si tocas un bloque **reportero**
(redondo, `( )`) o **booleano** (`< >`) de la paleta mientras hay un hueco enfocado, se enchufa
en él y entras en ese reportero para rellenar sus propios huecos (`^` sube un nivel). `Delete`
quita el reportero enchufado. Los reporteros se anidan (hasta 16 por script).

*Variables y listas* (hasta 10 y 4): `Make a variable` / `Make a list` en su categoría, con
un reportero por variable y bloques `set/change/show/hide`, `add/delete/insert/replace`...

*Pantalla de ejecución*: el botón morado **`Run:T` / `Run:B`** de la barra de sprites elige dónde corre el
proyecto. `Run:T` (por defecto): el escenario en la pantalla de arriba y la inferior como panel táctil (ratón).
`Run:B`: el escenario ocupa la pantalla táctil (480×360 → 320×240, tocar = ratón) y la de arriba muestra
posiciones, variables, temporizador y respuesta. Se recuerda en `sd:/3ds/scratch-editor/settings.txt`.

*Ejecutar* (Flag/Y): la pantalla táctil se convierte en un panel que hace de ratón; la cruceta,
A, X, Y, L y R son teclas; B para. Funcionan los bloques de lápiz (rastro y sello), sensores
(ratón, tecla, temporizador, `ask`/`answer`, volumen del micrófono, `when loudness > n`),
operadores, listas y `broadcast and wait`.

**Costumes** (hasta 6 por sprite, 32×32 píxeles, paleta de 16 colores): toca un color y dibuja
en el lienzo con el lápiz (`Pen`) o rellena (`Fill`). El color `x` borra. `Flip` voltea, `Clear`
limpia, `New` crea un disfraz copiando el actual, `Name` lo renombra, `<` `>` cambian de disfraz.

**Sounds** (hasta 6 por sprite): tonos sintetizados (seno / cuadrada / sierra / ruido) con
frecuencia, duración y volumen, o **grabaciones con el micrófono**: `Rec (microphone)` empieza
y vuelve a tocarse para parar (máximo 4 s a 10910 Hz; se detiene sola al llenarse y descarta lo
más corto de 50 ms). Una grabación se puede recortar (`Trim silence`), normalizar, invertir y
ajustar de volumen; se guarda en el `.sb3` como WAV y se oye con `play sound`.

| Botón | Acción |
|---|---|
| L / R | Sprite anterior / siguiente |
| Cruceta ↑ ↓ | Mover la selección de bloque (pestaña Scripts) |
| Cruceta ← → | Mover el foco entre huecos |
| A | Editar el hueco enfocado |
| X | Borrar (bloque, reportero, script, disfraz o sonido según la pestaña) |
| (pantalla) Undo / Redo / Dup | Deshacer, rehacer, duplicar (ver abajo) |
| Y / B | Ejecutar (bandera verde) / parar |
| START | Guardar `.sb3` |
| SELECT | Salir |

Junto al script hay dos botones `^` y `v` que lo desplazan por páginas sin cambiar el bloque seleccionado (además de *Top* y *End*).

### Límites del escenario

Como en Scratch, un sprite nunca sale del todo del escenario: siempre queda dentro al menos una parte (hasta 15 px). Así un `forever move 10` se queda en el borde en vez de alejarse sin fin.

### Tema claro / oscuro

**D-pad izquierda** (fuera de una ejecución) cambia la interfaz entre tema oscuro y claro. El escenario, los disfraces y el lápiz conservan sus colores. Durante una ejecución, D-pad izquierda sigue siendo la flecha izquierda del proyecto. Dentro de un bloque, D-pad derecha pasa al siguiente argumento y, tras el último, vuelve al primero.

### Pestaña About e historial de versiones

La cuarta pestaña, **About**, muestra el nombre (ScratchEdit3DS), la versión, créditos, los controles y el aviso legal (el historial de versiones está en `CHANGELOG.md`). Los textos están en `source/about.h`; para publicar una versión nueva cambia `APP_VERSION` ahí (formato `3.0.0BR`: BR = beta release, BE = beta, NS = not stable, S = stable; ver `CHANGELOG.md`) y añade sus líneas. Sube/baja con `^` `v` o con el D-pad.

### Escenario abajo, gotero y mover sprites

- **D-pad arriba** (sin ejecutar nada): el escenario pasa a la pantalla táctil. **Arrastra** para colocar el sprite seleccionado; se guarda como su posición inicial. D-pad arriba, **B** o *Done* vuelven. (Por eso D-pad arriba ya no selecciona el bloque anterior: toca el bloque o usa D-pad abajo, *Top* y *End*.)
- En `touching color` y `color is touching`, tocar la casilla de color abre un **gotero**: el escenario aparece abajo y al tocar un píxel se elige su color (de la paleta). *List* abre el menú de colores de siempre y *Cancel* sale.

### Puntero y scripts largos

- `go to mouse-pointer`, `point towards mouse-pointer`, `touching mouse-pointer?` y `distance to mouse-pointer` solo actúan **mientras tocas la pantalla táctil**: si no hay un dedo, el bloque se omite (el sprite se queda donde está) en vez de ir a una esquina.
- Debajo de la paleta, junto a `<` `>` (script anterior/siguiente), los botones **Top** y **End** saltan al primer y al último bloque del script.

### Sensores estilo PicoBoard

`<canal> sensor value` y `sensor <…>?` (categoría Sensing) leen la consola mientras corre el proyecto:

| Canal | Qué lee |
|-------|---------|
| `slider` | Circle Pad horizontal (0–100, centro 50) |
| `resistance-A` | Circle Pad vertical (0–100, centro 50) |
| `resistance-B` / `resistance-C` | posición táctil X / Y (0–100) |
| `sound` | micrófono (igual que `loudness`) |
| `sensor button pressed?` | botón A |
| `sensor A/B/C connected?` | siempre verdadero (D, falso) |

No lo he probado en una 3DS real (`hidCircleRead` y el táctil solo en la simulación de PC).

### Arrastrar bloques (pantalla táctil)

En la pestaña de scripts puedes arrastrar con el lápiz/dedo:

- **Paleta → script**: suelta el bloque entre dos filas (aparece una línea blanca donde se insertará). Un bloque de evento (sombrero) suelto en la zona de scripts crea un script nuevo.
- **Reporteros/booleanos** (operadores, variables…): suéltalos sobre una casilla de argumento de la barra inferior o sobre una fila del script (entran en el primer hueco libre que los acepte).
- **Reordenar**: arrastra una fila del script a otro hueco. Un bloque en C (si, por siempre…) se mueve con todo su contenido; si lo sueltas dentro de sí mismo no pasa nada. Soltar justo debajo de la cabecera de un C lo mete dentro.
- **Borrar**: arrastra una fila hasta la paleta (se marca en rojo).
- Cerca del borde superior/inferior del script se desplaza solo. Un toque sin mover sigue funcionando como antes (seleccionar/añadir). Los sombreros no se arrastran.

> Probado solo con las pruebas de PC (pantalla simulada); no lo he ejecutado en una 3DS ni en emulador.

### Deshacer, rehacer y duplicar

- **Undo / Redo** (botones de abajo): deshacen y rehacen los cambios en los **scripts** del sprite (añadir, borrar,
  mover o duplicar bloques, enchufar reporteros, cambiar un valor, crear o borrar scripts). Hay 20 pasos. Una edición
  nueva borra el historial de "rehacer"; al borrar o reordenar sprites se borra todo el historial. No cubren
  disfraces, sonidos, variables ni listas.
- **Dup** (botón de abajo): en **Scripts** duplica el bloque seleccionado (con su cuerpo si es un bloque en C, y con los
  reporteros enchufados); con el **sombrero** seleccionado duplica el script entero. En **Costumes** y **Sounds**
  duplica el disfraz / sonido actual.

### Clones

En **Control**: `when I start as a clone`, `create clone of [myself / sprite]` y `delete this clone`. Un clon copia
la posición, dirección, tamaño, disfraz y efectos del original, ejecuta los scripts de su sprite, responde a
mensajes y teclas y puede tocar o ser tocado. Hay hasta **16 clones** a la vez; con **Stop** (o `stop all`) desaparecen.
Se exportan al `.sb3` como los bloques normales de Scratch 3 (`control_create_clone_of`...).

### Teclado

Tocar un hueco ya abría el teclado del sistema. Ahora los huecos **numéricos** y los valores del menú del sprite (`x`, `y`,
dirección, tamaño, frecuencia...) abren el **teclado numérico** (dígitos, `-` y `.`); en los huecos de bloque el botón
`Abc` abre el teclado completo (para escribir `last`, `all`...).

### Efectos de sonido

**Sounds → Sound effects...** añade uno de 10 efectos sintetizados como sonido normal (se exportan como WAV):
`laser`, `jump`, `coin`, `power-up`, `explosion`, `hit`, `blip`, `siren`, `fall`, `click`.

### Plantillas

`Spr → New from template...` (pide confirmación, **sustituye** el proyecto actual; guarda antes):
`Blank project`, `Catch the apples`, `Pong`, `Space shooter (clones)`, `Pen sketch` y `Music keys`. Son proyectos
normales con sprites, disfraces, sonidos y scripts que se pueden editar. Con las pruebas de PC se juegan en el
intérprete y los `.sb3` se validan con `scratch-parser`; cinco de las seis se cargaron en el motor real de Scratch (`scratch-vm`, sin pantalla: ahí no se pueden probar colisiones
ni rebotes) y en el del tirador se ejecutó `create clone of`; `Music keys` no se probó allí. `examples/templates/` trae los `.sb3` ya hechos.

## Límites del prototipo

- Máximo 12 sprites, 8 scripts por sprite, 40 bloques por script, 6 disfraces y 6 sonidos por sprite.
- El Escenario tiene fondos (hasta 6) y sonidos, pero no scripts; los fondos son de 32×32 píxeles estirados a 480×360 y los disfraces se guardan ampliados 2× (64×64).
- `touching color` / `color touching color` solo miran sprites y fondo (no el lápiz, los sellos ni la rotación); no se simula la rotación visual de sprites.
- Excluidos: los bloques de vídeo. Los bloques de la PicoBoard (`… sensor value`, `sensor …?`) se simulan con la consola (ver abajo) y **no existen en Scratch 3**: en el `.sb3` se exportan sin ellos (queda el valor por defecto); en el `.sb` de Scratch 1.x sí se guardan. Los clones no son de Scratch 1.x (se añadieron a petición).
- Guarda `.sb3` (Scratch 3); no abre archivos existentes, solo crea y guarda.

## Pruebas y verificación del formato (en PC)

```sh
cd tools
./run_tests.sh                                  # editor, assets, importador, escritores .sb/.sb3 y la interfaz con librerías simuladas
python3 sb3check.py ../examples/all_blocks.sb3 --coverage   # valida el .sb3: ZIP, MD5, referencias entre bloques, opcodes
# opcional, con el motor real de Scratch 3 (necesita npm i scratch-vm scratch-storage):
node sb3_vm_run.js ../examples/sample.sb3       # carga el proyecto, pulsa la bandera verde y muestra posiciones y variables
```

## Alternativa para jugar

Si lo que quieres es *jugar* proyectos de Scratch en la 3DS, existe
[Scratch Everywhere!](https://github.com/scratch-everywhere/scratch-everywhere) (runtime para `.sb3`). Se puede crear el proyecto en un PC con Scratch 3 y copiarlo a `3ds/scratch-everywhere`.

## Estructura

```
source/project.h      modelo de datos + tabla BLOCK_LIST (los 123 bloques)
source/assets.c/h     paleta, disfraces, síntesis de sonido, grabadora/recorte/normalizado (sin libctru)
source/importer.c/h   importa sprites de carpetas (PNG con inflate propio, BMP, PPM, WAV, sprite.txt)
source/editor.c/h     edición del proyecto: scripts, reporteros, variables, listas (sin libctru)
source/runtime.c/h    intérprete cooperativo multi-sprite con clones (sin libctru)
source/templates.c/h  plantillas de proyecto (se construyen con la misma API de edición)
source/sb3_writer.c/h serializador .sb3 (ZIP + project.json + PNG/WAV)
source/sb_writer.c/h  serializador .sb de Scratch 1.x (ya no se usa en el editor)
source/main.c         interfaz 3DS (citro2d, ndsp, micrófono)
tools/                sb3check.py, sb3_vm_run.js, sbdump.py, pruebas de PC, run_tests.sh, stubs/ (libctru/citro2d simuladas)
examples/             sample.sb3 (juego de atrapar la pelota), all_blocks.sb3 (un bloque de cada tipo) y los mismos en .sb
```
