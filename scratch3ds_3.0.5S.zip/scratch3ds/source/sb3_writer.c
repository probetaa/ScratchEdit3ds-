
#include "sb3_writer.h"

#include <math.h>
#include <stdarg.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "assets.h"
#include "editor.h"

typedef struct { char *p; size_t n, cap; int err; } Buf;

static void b_put(Buf *b, const void *s, size_t n)
{
    if (b->err) return;
    if (b->n + n + 1 > b->cap) {
        size_t nc = b->cap ? b->cap : 1024;
        while (nc < b->n + n + 1) nc *= 2;
        char *q = realloc(b->p, nc);
        if (!q) { b->err = 1; return; }
        b->p = q; b->cap = nc;
    }
    memcpy(b->p + b->n, s, n);
    b->n += n;
    b->p[b->n] = 0;
}
static void b_str(Buf *b, const char *s) { b_put(b, s, strlen(s)); }
static void b_fmt(Buf *b, const char *fmt, ...)
{
    char tmp[256];
    va_list ap;
    va_start(ap, fmt);
    int n = vsnprintf(tmp, sizeof tmp, fmt, ap);
    va_end(ap);
    if (n < 0) { b->err = 1; return; }
    if ((size_t)n < sizeof tmp) { b_put(b, tmp, (size_t)n); return; }
    char *big = malloc((size_t)n + 1);
    if (!big) { b->err = 1; return; }
    va_start(ap, fmt);
    vsnprintf(big, (size_t)n + 1, fmt, ap);
    va_end(ap);
    b_put(b, big, (size_t)n);
    free(big);
}
static void b_json(Buf *b, const char *s)
{
    b_put(b, "\"", 1);
    for (; *s; s++) {
        unsigned char c = (unsigned char)*s;
        if (c == '"') b_str(b, "\\\"");
        else if (c == '\\') b_str(b, "\\\\");
        else if (c < 32) b_fmt(b, "\\u%04x", c);
        else b_put(b, s, 1);
    }
    b_put(b, "\"", 1);
}
static void b_free(Buf *b) { free(b->p); memset(b, 0, sizeof *b); }

static uint32_t rol(uint32_t x, int c) { return (x << c) | (x >> (32 - c)); }

void sb3_md5_hex(const void *data, size_t len, char out[33])
{
    static const uint32_t K[64] = {
        0xd76aa478,0xe8c7b756,0x242070db,0xc1bdceee,0xf57c0faf,0x4787c62a,0xa8304613,0xfd469501,0x698098d8,0x8b44f7af,0xffff5bb1,0x895cd7be,0x6b901122,0xfd987193,0xa679438e,0x49b40821,
        0xf61e2562,0xc040b340,0x265e5a51,0xe9b6c7aa,0xd62f105d,0x02441453,0xd8a1e681,0xe7d3fbc8,0x21e1cde6,0xc33707d6,0xf4d50d87,0x455a14ed,0xa9e3e905,0xfcefa3f8,0x676f02d9,0x8d2a4c8a,
        0xfffa3942,0x8771f681,0x6d9d6122,0xfde5380c,0xa4beea44,0x4bdecfa9,0xf6bb4b60,0xbebfbc70,0x289b7ec6,0xeaa127fa,0xd4ef3085,0x04881d05,0xd9d4d039,0xe6db99e5,0x1fa27cf8,0xc4ac5665,
        0xf4292244,0x432aff97,0xab9423a7,0xfc93a039,0x655b59c3,0x8f0ccc92,0xffeff47d,0x85845dd1,0x6fa87e4f,0xfe2ce6e0,0xa3014314,0x4e0811a1,0xf7537e82,0xbd3af235,0x2ad7d2bb,0xeb86d391 };
    static const int S[64] = { 7,12,17,22,7,12,17,22,7,12,17,22,7,12,17,22, 5,9,14,20,5,9,14,20,5,9,14,20,5,9,14,20,
                               4,11,16,23,4,11,16,23,4,11,16,23,4,11,16,23, 6,10,15,21,6,10,15,21,6,10,15,21,6,10,15,21 };
    uint32_t a0 = 0x67452301, b0 = 0xefcdab89, c0 = 0x98badcfe, d0 = 0x10325476;
    size_t total = ((len + 8) / 64 + 1) * 64;
    unsigned char *m = calloc(total, 1);
    if (!m) { strcpy(out, "00000000000000000000000000000000"); return; }
    memcpy(m, data, len);
    m[len] = 0x80;
    uint64_t bits = (uint64_t)len * 8;
    for (int i = 0; i < 8; i++) m[total - 8 + (size_t)i] = (unsigned char)(bits >> (8 * i));
    for (size_t off = 0; off < total; off += 64) {
        uint32_t M[16];
        for (int i = 0; i < 16; i++) M[i] = m[off + 4 * i] | (uint32_t)m[off + 4 * i + 1] << 8 | (uint32_t)m[off + 4 * i + 2] << 16 | (uint32_t)m[off + 4 * i + 3] << 24;
        uint32_t A = a0, B = b0, C = c0, D = d0;
        for (int i = 0; i < 64; i++) {
            uint32_t F; int g;
            if (i < 16)      { F = (B & C) | (~B & D); g = i; }
            else if (i < 32) { F = (D & B) | (~D & C); g = (5 * i + 1) % 16; }
            else if (i < 48) { F = B ^ C ^ D;          g = (3 * i + 5) % 16; }
            else             { F = C ^ (B | ~D);       g = (7 * i) % 16; }
            F = F + A + K[i] + M[g];
            A = D; D = C; C = B; B = B + rol(F, S[i]);
        }
        a0 += A; b0 += B; c0 += C; d0 += D;
    }
    free(m);
    uint32_t r[4] = { a0, b0, c0, d0 };
    for (int i = 0; i < 4; i++) for (int j = 0; j < 4; j++) sprintf(out + i * 8 + j * 2, "%02x", (r[i] >> (8 * j)) & 255);
}

unsigned sb3_crc32(const void *data, size_t n)
{
    static uint32_t table[256];
    if (!table[1]) for (uint32_t i = 0; i < 256; i++) { uint32_t c = i; for (int k = 0; k < 8; k++) c = (c & 1) ? 0xEDB88320u ^ (c >> 1) : c >> 1; table[i] = c; }
    uint32_t c = 0xFFFFFFFFu;
    const unsigned char *p = data;
    for (size_t i = 0; i < n; i++) c = table[(c ^ p[i]) & 255] ^ (c >> 8);
    return c ^ 0xFFFFFFFFu;
}

typedef struct { char name[64]; uint32_t crc, size, off; } ZEntry;
typedef struct { Buf data; ZEntry e[640]; int n; } Zip;

static void le16w(Buf *b, unsigned v) { unsigned char c[2] = { (unsigned char)v, (unsigned char)(v >> 8) }; b_put(b, c, 2); }
static void le32w(Buf *b, uint32_t v) { le16w(b, v & 0xFFFF); le16w(b, v >> 16); }

static int zip_has(const Zip *z, const char *name) { for (int i = 0; i < z->n; i++) if (strcmp(z->e[i].name, name) == 0) return 1; return 0; }

static int zip_add(Zip *z, const char *name, const void *d, size_t n)
{
    if (zip_has(z, name)) return 0;
    if (z->n >= 640 || strlen(name) >= sizeof z->e[0].name) return -1;
    ZEntry *e = &z->e[z->n++];
    snprintf(e->name, sizeof e->name, "%s", name);
    e->crc = sb3_crc32(d, n); e->size = (uint32_t)n; e->off = (uint32_t)z->data.n;
    le32w(&z->data, 0x04034b50); le16w(&z->data, 20); le16w(&z->data, 0); le16w(&z->data, 0);
    le16w(&z->data, 0); le16w(&z->data, 0x5821);
    le32w(&z->data, e->crc); le32w(&z->data, e->size); le32w(&z->data, e->size);
    le16w(&z->data, (unsigned)strlen(name)); le16w(&z->data, 0);
    b_str(&z->data, name);
    b_put(&z->data, d, n);
    return z->data.err ? -1 : 0;
}

static void zip_finish(Zip *z)
{
    uint32_t cd = (uint32_t)z->data.n;
    for (int i = 0; i < z->n; i++) {
        const ZEntry *e = &z->e[i];
        le32w(&z->data, 0x02014b50); le16w(&z->data, 20); le16w(&z->data, 20); le16w(&z->data, 0); le16w(&z->data, 0);
        le16w(&z->data, 0); le16w(&z->data, 0x5821);
        le32w(&z->data, e->crc); le32w(&z->data, e->size); le32w(&z->data, e->size);
        le16w(&z->data, (unsigned)strlen(e->name)); le16w(&z->data, 0); le16w(&z->data, 0);
        le16w(&z->data, 0); le16w(&z->data, 0); le32w(&z->data, 0); le32w(&z->data, e->off);
        b_str(&z->data, e->name);
    }
    uint32_t cdsize = (uint32_t)z->data.n - cd;
    le32w(&z->data, 0x06054b50); le16w(&z->data, 0); le16w(&z->data, 0);
    le16w(&z->data, (unsigned)z->n); le16w(&z->data, (unsigned)z->n);
    le32w(&z->data, cdsize); le32w(&z->data, cd); le16w(&z->data, 0);
}

static void be32w(Buf *b, uint32_t v) { unsigned char c[4] = { (unsigned char)(v >> 24), (unsigned char)(v >> 16), (unsigned char)(v >> 8), (unsigned char)v }; b_put(b, c, 4); }

static void png_chunk(Buf *out, const char *type, const void *d, size_t n)
{
    unsigned char *tmp = malloc(n + 4);
    if (!tmp) { out->err = 1; return; }
    memcpy(tmp, type, 4);
    if (n) memcpy(tmp + 4, d, n);
    be32w(out, (uint32_t)n);
    b_put(out, tmp, n + 4);
    be32w(out, sb3_crc32(tmp, n + 4));
    free(tmp);
}

static void png_encode(Buf *out, int w, int h, const uint32_t *argb)
{
    static const unsigned char sig[8] = { 137, 80, 78, 71, 13, 10, 26, 10 };
    b_put(out, sig, 8);
    Buf hdr = { 0 };
    be32w(&hdr, (uint32_t)w); be32w(&hdr, (uint32_t)h);
    b_put(&hdr, "\x08\x06\x00\x00\x00", 5);
    png_chunk(out, "IHDR", hdr.p, hdr.n);
    b_free(&hdr);

    size_t rawn = (size_t)h * (1 + (size_t)w * 4);
    unsigned char *raw = malloc(rawn);
    if (!raw) { out->err = 1; return; }
    size_t o = 0;
    for (int y = 0; y < h; y++) {
        raw[o++] = 0;
        for (int x = 0; x < w; x++) {
            uint32_t c = argb[y * w + x];
            raw[o++] = (unsigned char)(c >> 16); raw[o++] = (unsigned char)(c >> 8); raw[o++] = (unsigned char)c; raw[o++] = (unsigned char)(c >> 24);
        }
    }
    Buf z = { 0 };
    b_put(&z, "\x78\x01", 2);
    for (size_t pos = 0; pos < rawn || pos == 0; ) {
        size_t n = rawn - pos > 65535 ? 65535 : rawn - pos;
        unsigned char h5[5] = { (unsigned char)(pos + n >= rawn), (unsigned char)n, (unsigned char)(n >> 8), (unsigned char)~n, (unsigned char)(~n >> 8) };
        b_put(&z, h5, 5);
        b_put(&z, raw + pos, n);
        pos += n;
        if (n == 0) break;
    }
    uint32_t a = 1, b = 0;
    for (size_t i = 0; i < rawn; i++) { a = (a + raw[i]) % 65521; b = (b + a) % 65521; }
    be32w(&z, (b << 16) | a);
    png_chunk(out, "IDAT", z.p, z.n);
    png_chunk(out, "IEND", NULL, 0);
    b_free(&z);
    free(raw);
}

static void wav_encode(Buf *out, const int16_t *pcm, int n, int rate, int vol)
{
    uint32_t bytes = (uint32_t)n * 2;
    b_str(out, "RIFF"); le32w(out, 36 + bytes); b_str(out, "WAVEfmt ");
    le32w(out, 16); le16w(out, 1); le16w(out, 1); le32w(out, (uint32_t)rate); le32w(out, (uint32_t)rate * 2); le16w(out, 2); le16w(out, 16);
    b_str(out, "data"); le32w(out, bytes);
    for (int i = 0; i < n; i++) le16w(out, (uint16_t)(int16_t)((int)pcm[i] * vol / 100));
}

typedef struct { int kind; const char *op; const char *spec; const char *fields; const char *xmenu; } Map;

static const Map MAPS[] = {
    { BK_MOVE, "motion_movesteps", "n:STEPS", 0, 0 },
    { BK_TURN_R, "motion_turnright", "n:DEGREES", 0, 0 },
    { BK_TURN_L, "motion_turnleft", "n:DEGREES", 0, 0 },
    { BK_POINT_DIR, "motion_pointindirection", "n:DIRECTION", 0, 0 },
    { BK_POINT_TOWARDS, "motion_pointtowards", "mT:TOWARDS:motion_pointtowards_menu:TOWARDS", 0, 0 },
    { BK_GOTO_XY, "motion_gotoxy", "n:X n:Y", 0, 0 },
    { BK_GOTO_SPRITE, "motion_goto", "mT:TO:motion_goto_menu:TO", 0, 0 },
    { BK_GLIDE, "motion_glidesecstoxy", "n:SECS n:X n:Y", 0, 0 },
    { BK_CHANGE_X, "motion_changexby", "n:DX", 0, 0 },
    { BK_SET_X, "motion_setx", "n:X", 0, 0 },
    { BK_CHANGE_Y, "motion_changeyby", "n:DY", 0, 0 },
    { BK_SET_Y, "motion_sety", "n:Y", 0, 0 },
    { BK_BOUNCE, "motion_ifonedgebounce", "", 0, 0 },
    { BK_XPOS, "motion_xposition", "", 0, 0 },
    { BK_YPOS, "motion_yposition", "", 0, 0 },
    { BK_DIRECTION, "motion_direction", "", 0, 0 },
    { BK_SWITCH_COSTUME, "looks_switchcostumeto", "m:COSTUME:looks_costume:COSTUME", 0, 0 },
    { BK_NEXT_COSTUME, "looks_nextcostume", "", 0, 0 },
    { BK_COSTUME_NUM, "looks_costumenumbername", "", "\"NUMBER_NAME\":[\"number\",null]", 0 },
    { BK_SAY_FOR, "looks_sayforsecs", "s:MESSAGE n:SECS", 0, 0 },
    { BK_SAY, "looks_say", "s:MESSAGE", 0, 0 },
    { BK_THINK_FOR, "looks_thinkforsecs", "s:MESSAGE n:SECS", 0, 0 },
    { BK_THINK, "looks_think", "s:MESSAGE", 0, 0 },
    { BK_CHANGE_EFFECT, "looks_changeeffectby", "fU:EFFECT n:CHANGE", 0, 0 },
    { BK_SET_EFFECT, "looks_seteffectto", "fU:EFFECT n:VALUE", 0, 0 },
    { BK_CLEAR_EFFECTS, "looks_cleargraphiceffects", "", 0, 0 },
    { BK_CHANGE_SIZE, "looks_changesizeby", "n:CHANGE", 0, 0 },
    { BK_SET_SIZE, "looks_setsizeto", "n:SIZE", 0, 0 },
    { BK_SIZE, "looks_size", "", 0, 0 },
    { BK_SHOW, "looks_show", "", 0, 0 },
    { BK_HIDE, "looks_hide", "", 0, 0 },
    { BK_FRONT, "looks_gotofrontback", "", "\"FRONT_BACK\":[\"front\",null]", 0 },
    { BK_BACK, "looks_goforwardbackwardlayers", "n:NUM", "\"FORWARD_BACKWARD\":[\"backward\",null]", 0 },
    { BK_PLAY_SOUND, "sound_play", "m:SOUND_MENU:sound_sounds_menu:SOUND_MENU", 0, 0 },
    { BK_PLAY_SOUND_WAIT, "sound_playuntildone", "m:SOUND_MENU:sound_sounds_menu:SOUND_MENU", 0, 0 },
    { BK_STOP_SOUNDS, "sound_stopallsounds", "", 0, 0 },
    { BK_DRUM, "music_playDrumForBeats", "m:DRUM:music_menu_DRUM:DRUM n:BEATS", 0, 0 },
    { BK_REST, "music_restForBeats", "n:BEATS", 0, 0 },
    { BK_NOTE, "music_playNoteForBeats", "n:NOTE n:BEATS", 0, 0 },
    { BK_INSTRUMENT, "music_setInstrument", "m:INSTRUMENT:music_menu_INSTRUMENT:INSTRUMENT", 0, 0 },
    { BK_CHANGE_VOLUME, "sound_changevolumeby", "n:VOLUME", 0, 0 },
    { BK_SET_VOLUME, "sound_setvolumeto", "n:VOLUME", 0, 0 },
    { BK_VOLUME, "sound_volume", "", 0, 0 },
    { BK_CHANGE_TEMPO, "music_changeTempo", "n:TEMPO", 0, 0 },
    { BK_SET_TEMPO, "music_setTempo", "n:TEMPO", 0, 0 },
    { BK_TEMPO, "music_getTempo", "", 0, 0 },
    { BK_PEN_CLEAR, "pen_clear", "", 0, 0 },
    { BK_PEN_DOWN, "pen_penDown", "", 0, 0 },
    { BK_PEN_UP, "pen_penUp", "", 0, 0 },
    { BK_PEN_COLOR, "pen_setPenColorToColor", "c:COLOR", 0, 0 },
    { BK_PEN_HUE_CHANGE, "pen_changePenColorParamBy", "n:VALUE", 0, "COLOR_PARAM|pen_menu_colorParam|colorParam|color" },
    { BK_PEN_HUE_SET, "pen_setPenColorParamTo", "n:VALUE", 0, "COLOR_PARAM|pen_menu_colorParam|colorParam|color" },
    { BK_PEN_SHADE_CHANGE, "pen_changePenColorParamBy", "n:VALUE", 0, "COLOR_PARAM|pen_menu_colorParam|colorParam|brightness" },
    { BK_PEN_SHADE_SET, "pen_setPenColorParamTo", "n:VALUE", 0, "COLOR_PARAM|pen_menu_colorParam|colorParam|brightness" },
    { BK_PEN_SIZE_CHANGE, "pen_changePenSizeBy", "n:SIZE", 0, 0 },
    { BK_PEN_SIZE_SET, "pen_setPenSizeTo", "n:SIZE", 0, 0 },
    { BK_STAMP, "pen_stamp", "", 0, 0 },
    { BK_HAT_FLAG, "event_whenflagclicked", "", 0, 0 },
    { BK_HAT_KEY, "event_whenkeypressed", "fK:KEY_OPTION", 0, 0 },
    { BK_HAT_CLICK, "event_whenthisspriteclicked", "", 0, 0 },
    { BK_HAT_RECV, "event_whenbroadcastreceived", "E:BROADCAST_OPTION", 0, 0 },
    { BK_HAT_SENSOR, "event_whengreaterthan", "fU:WHENGREATERTHANMENU n:VALUE", 0, 0 },
    { BK_WAIT, "control_wait", "n:DURATION", 0, 0 },
    { BK_FOREVER, "control_forever", "", 0, 0 },
    { BK_REPEAT, "control_repeat", "n:TIMES", 0, 0 },
    { BK_BROADCAST, "event_broadcast", "e:BROADCAST_INPUT", 0, 0 },
    { BK_BROADCAST_WAIT, "event_broadcastandwait", "e:BROADCAST_INPUT", 0, 0 },
    { BK_FOREVER_IF, "control_forever", "", 0, 0 },
    { BK_IF, "control_if", "b:CONDITION", 0, 0 },
    { BK_IF_ELSE, "control_if_else", "b:CONDITION", 0, 0 },
    { BK_WAIT_UNTIL, "control_wait_until", "b:CONDITION", 0, 0 },
    { BK_UNTIL, "control_repeat_until", "b:CONDITION", 0, 0 },
    { BK_STOP_ALL, "control_stop", "", "\"STOP_OPTION\":[\"all\",null]", 0 },
    { BK_STOP_SCRIPT, "control_stop", "", "\"STOP_OPTION\":[\"this script\",null]", 0 },
    { BK_HAT_CLONE, "control_start_as_clone", "", 0, 0 },
    { BK_CLONE, "control_create_clone_of", "mT:CLONE_OPTION:control_create_clone_of_menu:CLONE_OPTION", 0, 0 },
    { BK_CLONE_DEL, "control_delete_this_clone", "", 0, 0 },
    { BK_TOUCHING, "sensing_touchingobject", "mT:TOUCHINGOBJECTMENU:sensing_touchingobjectmenu:TOUCHINGOBJECTMENU", 0, 0 },
    { BK_TOUCHING_COLOR, "sensing_touchingcolor", "c:COLOR", 0, 0 },
    { BK_COLOR_SEES, "sensing_coloristouchingcolor", "c:COLOR c:COLOR2", 0, 0 },
    { BK_ASK, "sensing_askandwait", "s:QUESTION", 0, 0 },
    { BK_ANSWER, "sensing_answer", "", 0, 0 },
    { BK_MOUSE_X, "sensing_mousex", "", 0, 0 },
    { BK_MOUSE_Y, "sensing_mousey", "", 0, 0 },
    { BK_MOUSE_DOWN, "sensing_mousedown", "", 0, 0 },
    { BK_KEY_PRESSED, "sensing_keypressed", "mK:KEY_OPTION:sensing_keyoptions:KEY_OPTION", 0, 0 },
    { BK_DISTANCE, "sensing_distanceto", "mT:DISTANCETOMENU:sensing_distancetomenu:DISTANCETOMENU", 0, 0 },
    { BK_TIMER, "sensing_timer", "", 0, 0 },
    { BK_TIMER_RESET, "sensing_resettimer", "", 0, 0 },
    { BK_ATTR_OF, "sensing_of", "f:PROPERTY mO:OBJECT:sensing_of_object_menu:OBJECT", 0, 0 },
    { BK_LOUDNESS, "sensing_loudness", "", 0, 0 },
    { BK_LOUD, "operator_gt", "", 0, 0 },
    { BK_ADD, "operator_add", "n:NUM1 n:NUM2", 0, 0 },
    { BK_SUB, "operator_subtract", "n:NUM1 n:NUM2", 0, 0 },
    { BK_MUL, "operator_multiply", "n:NUM1 n:NUM2", 0, 0 },
    { BK_DIV, "operator_divide", "n:NUM1 n:NUM2", 0, 0 },
    { BK_MOD, "operator_mod", "n:NUM1 n:NUM2", 0, 0 },
    { BK_ROUND, "operator_round", "n:NUM", 0, 0 },
    { BK_FUNC, "operator_mathop", "f:OPERATOR n:NUM", 0, 0 },
    { BK_RANDOM, "operator_random", "n:FROM n:TO", 0, 0 },
    { BK_LT, "operator_lt", "s:OPERAND1 s:OPERAND2", 0, 0 },
    { BK_EQ, "operator_equals", "s:OPERAND1 s:OPERAND2", 0, 0 },
    { BK_GT, "operator_gt", "s:OPERAND1 s:OPERAND2", 0, 0 },
    { BK_AND, "operator_and", "b:OPERAND1 b:OPERAND2", 0, 0 },
    { BK_OR, "operator_or", "b:OPERAND1 b:OPERAND2", 0, 0 },
    { BK_NOT, "operator_not", "b:OPERAND", 0, 0 },
    { BK_JOIN, "operator_join", "s:STRING1 s:STRING2", 0, 0 },
    { BK_LETTER, "operator_letter_of", "n:LETTER s:STRING", 0, 0 },
    { BK_LENGTH, "operator_length", "s:STRING", 0, 0 },
    { BK_VAR, "data_variable", "", 0, 0 },
    { BK_SET_VAR, "data_setvariableto", "v:VARIABLE s:VALUE", 0, 0 },
    { BK_CHANGE_VAR, "data_changevariableby", "v:VARIABLE n:VALUE", 0, 0 },
    { BK_SHOW_VAR, "data_showvariable", "v:VARIABLE", 0, 0 },
    { BK_HIDE_VAR, "data_hidevariable", "v:VARIABLE", 0, 0 },
    { BK_LIST_ADD, "data_addtolist", "s:ITEM l:LIST", 0, 0 },
    { BK_LIST_DELETE, "data_deleteoflist", "n:INDEX l:LIST", 0, 0 },
    { BK_LIST_INSERT, "data_insertatlist", "s:ITEM n:INDEX l:LIST", 0, 0 },
    { BK_LIST_REPLACE, "data_replaceitemoflist", "n:INDEX l:LIST s:ITEM", 0, 0 },
    { BK_LIST_ITEM, "data_itemoflist", "n:INDEX l:LIST", 0, 0 },
    { BK_LIST_LEN, "data_lengthoflist", "l:LIST", 0, 0 },
};
#define NMAPS ((int)(sizeof MAPS / sizeof MAPS[0]))

static const Map *map_for(int kind)
{
    for (int i = 0; i < NMAPS; i++) if (MAPS[i].kind == kind) return &MAPS[i];
    return NULL;
}

#define MAX_MSGS 96
typedef struct {
    const Project *p;
    Buf   blocks;
    int   nextid;
    char  msgs[MAX_MSGS][TEXT_LEN];
    int   nmsgs;
    int   use_pen, use_music;
    int   err;
} Ctx;

static void idstr(char *out, int id) { sprintf(out, "b%d", id); }

static int find_var(const Project *p, const char *n) { for (int i = 0; i < p->nvars; i++) if (strcmp(p->vars[i].name, n) == 0) return i; return -1; }
static int find_list(const Project *p, const char *n) { for (int i = 0; i < p->nlists; i++) if (strcmp(p->lists[i].name, n) == 0) return i; return -1; }

static int msg_id(Ctx *c, const char *name)
{
    for (int i = 0; i < c->nmsgs; i++) if (strcmp(c->msgs[i], name) == 0) return i;
    if (c->nmsgs >= MAX_MSGS) return 0;
    snprintf(c->msgs[c->nmsgs], TEXT_LEN, "%s", name);
    return c->nmsgs++;
}

static int is_number(const char *s)
{
    while (*s == ' ') s++;
    if (!*s) return 0;
    char *end;
    double d = strtod(s, &end);
    while (*end == ' ') end++;
    return !*end && d == d;
}

static void prim(Buf *b, char slot, const char *text)
{
    if (slot == 'x') {
        uint32_t rgb = PALETTE_RGB[pal_find(text)];
        b_fmt(b, "[9,\"#%06x\"]", (unsigned)rgb);
    } else if (slot == 'n' && (is_number(text) || !text[0])) {
        b_str(b, "[4,"); b_json(b, text); b_put(b, "]", 1);
    } else {
        b_str(b, "[10,"); b_json(b, text); b_put(b, "]", 1);
    }
}

static void xform_value(char x, const char *in, char *out, size_t n)
{
    if (x == 'T') {
        if (!in[0] || !strcmp(in, "mouse-pointer")) snprintf(out, n, "_mouse_");
        else if (!strcmp(in, "myself")) snprintf(out, n, "_myself_");
        else if (!strcmp(in, "edge")) snprintf(out, n, "_edge_");
        else snprintf(out, n, "%s", in);
    } else if (x == 'O') {
        snprintf(out, n, "%s", in[0] ? in : "_stage_");
    } else if (x == 'U') {
        size_t i = 0;
        for (; in[i] && i + 1 < n; i++) out[i] = (char)((in[i] >= 'a' && in[i] <= 'z') ? in[i] - 32 : in[i]);
        out[i] = 0;
    } else snprintf(out, n, "%s", in);
}

static void add_entry_sep(Buf *b) { if (b->n) b_put(b, ",", 1); }

static void put_block(Ctx *c, int id, const char *op, const Buf *inputs, const Buf *fields, const char *mutation,
                      int parent, int next, int toplevel, int x, int y, int shadow)
{
    char ids[16];
    Buf *b = &c->blocks;
    add_entry_sep(b);
    idstr(ids, id);
    b_fmt(b, "\"%s\":{\"opcode\":\"%s\",\"next\":", ids, op);
    if (next) { idstr(ids, next); b_fmt(b, "\"%s\"", ids); } else b_str(b, "null");
    b_str(b, ",\"parent\":");
    if (parent) { idstr(ids, parent); b_fmt(b, "\"%s\"", ids); } else b_str(b, "null");
    b_str(b, ",\"inputs\":{");
    if (inputs && inputs->n) b_put(b, inputs->p, inputs->n);
    b_str(b, "},\"fields\":{");
    if (fields && fields->n) b_put(b, fields->p, fields->n);
    b_fmt(b, "},\"shadow\":%s,\"topLevel\":%s", shadow ? "true" : "false", toplevel ? "true" : "false");
    if (mutation) b_fmt(b, ",\"mutation\":%s", mutation);
    if (toplevel) b_fmt(b, ",\"x\":%d,\"y\":%d", x, y);
    b_put(b, "}", 1);
    if (!strncmp(op, "pen_", 4)) c->use_pen = 1;
    if (!strncmp(op, "music_", 6)) c->use_music = 1;
}

static int emit_seq(Ctx *c, const Script *sc, int *pos, int parent, int toplevel, int depth);
static int emit_reporter(Ctx *c, const Script *sc, int ex, int parent, int depth);

static int plugged_ref(Ctx *c, const Script *sc, const Arg *a, int parent, Buf *ref, int depth)
{
    if (a->expr < 0 || a->expr >= MAX_EXPR || !sc->ex_used[a->expr] || depth > MAX_EXPR + 2) return 0;
    const Block *r = &sc->ex[a->expr];
    if (r->kind == BK_VAR) {
        int v = find_var(c->p, r->a[0].text);
        if (v < 0) return 0;
        b_str(ref, "[12,"); b_json(ref, c->p->vars[v].name); b_fmt(ref, ",\"v%d\"]", v);
        return 1;
    }
    int id = emit_reporter(c, sc, a->expr, parent, depth + 1);
    if (!id) return 0;
    char ids[16];
    idstr(ids, id);
    b_fmt(ref, "\"%s\"", ids);
    return 1;
}

static void build_slots(Ctx *c, const Script *sc, const Block *b, int id, int body1, int body2, Buf *in, Buf *fl, int depth)
{
    const Map *m = map_for(b->kind);
    const BlockInfo *bi = &BLOCK_INFO[b->kind];
    char ids[16];
    if (!m) return;
    const char *sp = m->spec;
    int k = 0;
    while (*sp) {
        while (*sp == ' ') sp++;
        if (!*sp) break;
        char tok[160];
        int n = 0;
        while (sp[n] && sp[n] != ' ' && n < (int)sizeof tok - 1) { tok[n] = sp[n]; n++; }
        tok[n] = 0;
        sp += n;
        char type = tok[0], xf = tok[1] != ':' ? tok[1] : 0;
        char *name = strchr(tok, ':') + 1, *rest = strchr(name, ':');
        char shadowop[64] = "", field[64] = "";
        if (rest) {
            *rest++ = 0;
            char *f = strchr(rest, ':');
            if (f) { *f++ = 0; snprintf(shadowop, sizeof shadowop, "%s", rest); snprintf(field, sizeof field, "%s", f); }
        }
        if (k >= MAX_ARGS) break;
        const Arg *a = &b->a[k];
        char slot = bi->slots[k];
        Buf ref = { 0 };
        int has = plugged_ref(c, sc, a, id, &ref, depth);
        char val[TEXT_LEN * 2];
        switch (type) {
        case 'n': case 's': case 'c':
            add_entry_sep(in);
            b_json(in, name); b_put(in, ":", 1);
            if (has) { b_str(in, "[3,"); b_put(in, ref.p, ref.n); b_put(in, ",", 1); prim(in, slot, a->text); b_put(in, "]", 1); }
            else { b_str(in, "[1,"); prim(in, slot, a->text); b_put(in, "]", 1); }
            break;
        case 'b':
            if (has) { add_entry_sep(in); b_json(in, name); b_str(in, ":[2,"); b_put(in, ref.p, ref.n); b_put(in, "]", 1); }
            break;
        case 'm': {
            int sid = ++c->nextid;
            Buf sf = { 0 };
            xform_value(xf, a->text, val, sizeof val);
            b_json(&sf, field); b_str(&sf, ":["); b_json(&sf, val); b_str(&sf, ",null]");
            put_block(c, sid, shadowop, NULL, &sf, NULL, id, 0, 0, 0, 0, 1);
            b_free(&sf);
            idstr(ids, sid);
            add_entry_sep(in);
            b_json(in, name);
            if (has) { b_str(in, ":[3,"); b_put(in, ref.p, ref.n); b_fmt(in, ",\"%s\"]", ids); }
            else b_fmt(in, ":[1,\"%s\"]", ids);
            break; }
        case 'e': {
            add_entry_sep(in);
            b_json(in, name); b_str(in, ":[");
            Buf pr = { 0 };
            b_str(&pr, "[11,"); b_json(&pr, a->text); b_fmt(&pr, ",\"m%d\"]", msg_id(c, a->text));
            if (has) { b_str(in, "3,"); b_put(in, ref.p, ref.n); b_put(in, ",", 1); b_put(in, pr.p, pr.n); }
            else { b_str(in, "1,"); b_put(in, pr.p, pr.n); }
            b_put(in, "]", 1);
            b_free(&pr);
            break; }
        case 'f':
            xform_value(xf == 'U' ? 'U' : 0, a->text, val, sizeof val);
            if (xf == 'K' && !strcmp(a->text, "any key")) snprintf(val, sizeof val, "any");
            add_entry_sep(fl);
            b_json(fl, name); b_str(fl, ":["); b_json(fl, val); b_str(fl, ",null]");
            break;
        case 'v': {
            int v = find_var(c->p, a->text);
            add_entry_sep(fl);
            b_json(fl, name); b_str(fl, ":["); b_json(fl, a->text); b_fmt(fl, ",\"v%d\"]", v < 0 ? 0 : v);
            break; }
        case 'l': {
            int l = find_list(c->p, a->text);
            add_entry_sep(fl);
            b_json(fl, name); b_str(fl, ":["); b_json(fl, a->text); b_fmt(fl, ",\"l%d\"]", l < 0 ? 0 : l);
            break; }
        case 'E':
            add_entry_sep(fl);
            b_json(fl, name); b_str(fl, ":["); b_json(fl, a->text); b_fmt(fl, ",\"m%d\"]", msg_id(c, a->text));
            break;
        default: break;
        }
        b_free(&ref);
        k++;
    }
    if (m->fields) { add_entry_sep(fl); b_str(fl, m->fields); }
    if (m->xmenu) {
        char t[200], *parts[4];
        snprintf(t, sizeof t, "%s", m->xmenu);
        char *s = t;
        for (int i = 0; i < 4; i++) { parts[i] = s; char *bar = strchr(s, '|'); if (bar) { *bar = 0; s = bar + 1; } }
        int sid = ++c->nextid;
        Buf sf = { 0 };
        b_json(&sf, parts[2]); b_str(&sf, ":["); b_json(&sf, parts[3]); b_str(&sf, ",null]");
        put_block(c, sid, parts[1], NULL, &sf, NULL, id, 0, 0, 0, 0, 1);
        b_free(&sf);
        idstr(ids, sid);
        add_entry_sep(in);
        b_json(in, parts[0]); b_fmt(in, ":[1,\"%s\"]", ids);
    }
    if (body1) { idstr(ids, body1); add_entry_sep(in); b_fmt(in, "\"SUBSTACK\":[2,\"%s\"]", ids); }
    if (body2) { idstr(ids, body2); add_entry_sep(in); b_fmt(in, "\"SUBSTACK2\":[2,\"%s\"]", ids); }
}

static int emit_reporter(Ctx *c, const Script *sc, int ex, int parent, int depth)
{
    const Block *b = &sc->ex[ex];
    const Map *m = map_for(b->kind);
    if (!m || b->kind == BK_VAR) return 0;
    int id = ++c->nextid;
    Buf in = { 0 }, fl = { 0 };
    if (b->kind == BK_LOUD) {
        int lid = ++c->nextid;
        char ids[16];
        put_block(c, lid, "sensing_loudness", NULL, NULL, NULL, id, 0, 0, 0, 0, 0);
        idstr(ids, lid);
        b_fmt(&in, "\"OPERAND1\":[3,\"%s\",[4,\"0\"]],\"OPERAND2\":[1,[4,\"10\"]]", ids);
    } else build_slots(c, sc, b, id, 0, 0, &in, &fl, depth);
    put_block(c, id, m->op, &in, &fl, NULL, parent, 0, 0, 0, 0, 0);
    b_free(&in); b_free(&fl);
    return id;
}

typedef struct { int id, kind; Buf in, fl; const Block *b; } Pending;

static int emit_seq(Ctx *c, const Script *sc, int *pos, int parent, int toplevel, int depth)
{
    Pending q[MAX_BLOCKS];
    int n = 0, first = 0;
    int extra_if[MAX_BLOCKS];
    while (*pos < sc->nblocks && n < MAX_BLOCKS && depth < MAX_DEPTH + 2) {
        const Block *b = &sc->blocks[*pos];
        int shape = BLOCK_INFO[b->kind].shape;
        if (shape == SH_END || shape == SH_ELSE) break;
        (*pos)++;
        Pending *p = &q[n];
        memset(p, 0, sizeof *p);
        p->id = ++c->nextid; p->kind = b->kind; p->b = b;
        extra_if[n] = 0;
        int body1 = 0, body2 = 0, bodyparent = p->id;
        if (b->kind == BK_FOREVER_IF) { extra_if[n] = ++c->nextid; bodyparent = extra_if[n]; }
        if (shape == SH_C || shape == SH_CELSE) {
            body1 = emit_seq(c, sc, pos, bodyparent, 0, depth + 1);
            if (shape == SH_CELSE) {
                if (*pos < sc->nblocks && sc->blocks[*pos].kind == BK_ELSE) { (*pos)++; body2 = emit_seq(c, sc, pos, p->id, 0, depth + 1); }
            }
            if (*pos < sc->nblocks && sc->blocks[*pos].kind == BK_END) (*pos)++;
        }
        if (b->kind == BK_FOREVER_IF) {
            Buf cond = { 0 };
            Buf ref = { 0 };
            if (plugged_ref(c, sc, &b->a[0], extra_if[n], &ref, depth)) { b_str(&cond, "\"CONDITION\":[2,"); b_put(&cond, ref.p, ref.n); b_put(&cond, "]", 1); }
            if (body1) { char ids[16]; idstr(ids, body1); if (cond.n) b_put(&cond, ",", 1); b_fmt(&cond, "\"SUBSTACK\":[2,\"%s\"]", ids); }
            put_block(c, extra_if[n], "control_if", &cond, NULL, NULL, p->id, 0, 0, 0, 0, 0);
            Buf fin = { 0 };
            char ids[16];
            idstr(ids, extra_if[n]);
            b_fmt(&fin, "\"SUBSTACK\":[2,\"%s\"]", ids);
            b_free(&cond); b_free(&ref);
            p->in = fin;
        } else if (b->kind == BK_STOP_ALL || b->kind == BK_STOP_SCRIPT) {
            build_slots(c, sc, b, p->id, 0, 0, &p->in, &p->fl, depth);
        } else {
            build_slots(c, sc, b, p->id, body1, body2, &p->in, &p->fl, depth);
        }
        n++;
    }
    for (int i = 0; i < n; i++) {
        const Map *m = map_for(q[i].kind);
        int hasnext_false = (q[i].kind == BK_STOP_ALL || q[i].kind == BK_STOP_SCRIPT);
        const char *mut = hasnext_false ? "{\"tagName\":\"mutation\",\"children\":[],\"hasnext\":\"false\"}" : NULL;
        put_block(c, q[i].id, m ? m->op : "control_wait", &q[i].in, &q[i].fl, mut,
                  i == 0 ? parent : q[i - 1].id, i + 1 < n ? q[i + 1].id : 0, toplevel && i == 0, toplevel ? sc->x * 2 : 0, toplevel ? sc->y * 2 : 0, 0);
        b_free(&q[i].in); b_free(&q[i].fl);
    }
    first = n ? q[0].id : 0;
    return first;
}

static void json_value(Buf *b, const char *text)
{
    if (is_number(text)) { double d = strtod(text, NULL); if (d == floor(d) && fabs(d) < 1e15) b_fmt(b, "%.0f", d); else b_fmt(b, "%.10g", d); }
    else b_json(b, text);
}

static void add_costume_json(Buf *j, Zip *z, const Costume *cs, int first)
{
    const int W = COSTUME_W * COSTUME_SB_SCALE, H = COSTUME_H * COSTUME_SB_SCALE;
    uint32_t *px = malloc((size_t)W * H * 4);
    Buf png = { 0 };
    if (!px) { j->err = 1; return; }
    for (int y = 0; y < H; y++)
        for (int x = 0; x < W; x++)
            px[y * W + x] = costume_argb(cs->px[(y / COSTUME_SB_SCALE) * COSTUME_W + (x / COSTUME_SB_SCALE)]);
    png_encode(&png, W, H, px);
    free(px);
    char md5[33], file[48];
    sb3_md5_hex(png.p, png.n, md5);
    snprintf(file, sizeof file, "%s.png", md5);
    if (zip_add(z, file, png.p, png.n) != 0) j->err = 1;
    if (!first) b_put(j, ",", 1);
    b_fmt(j, "{\"assetId\":\"%s\",\"name\":", md5);
    b_json(j, cs->name);
    b_fmt(j, ",\"bitmapResolution\":1,\"md5ext\":\"%s\",\"dataFormat\":\"png\",\"rotationCenterX\":%d,\"rotationCenterY\":%d}", file, W / 2, H / 2);
    b_free(&png);
}

static void add_backdrop_json(Buf *j, Zip *z, const Costume *cs, int first)
{
    Buf svg = { 0 };
    const double cw = (double)STAGE_W / COSTUME_W, ch = (double)STAGE_H / COSTUME_H;
    b_fmt(&svg, "<svg version=\"1.1\" width=\"%d\" height=\"%d\" viewBox=\"0 0 %d %d\" shape-rendering=\"crispEdges\" xmlns=\"http://www.w3.org/2000/svg\" xmlns:xlink=\"http://www.w3.org/1999/xlink\">", STAGE_W, STAGE_H, STAGE_W, STAGE_H);
    b_fmt(&svg, "<rect width=\"%d\" height=\"%d\" fill=\"#ffffff\"/>", STAGE_W, STAGE_H);
    for (int r = 0; r < COSTUME_H; r++) {
        int x = 0;
        while (x < COSTUME_W) {
            uint8_t v = cs->px[r * COSTUME_W + x];
            int e = x + 1;
            while (e < COSTUME_W && cs->px[r * COSTUME_W + e] == v) e++;
            if (v) b_fmt(&svg, "<rect x=\"%g\" y=\"%g\" width=\"%g\" height=\"%g\" fill=\"#%06x\"/>", x * cw, r * ch, (e - x) * cw, ch + 0.01, (unsigned)PALETTE_RGB[v]);
            x = e;
        }
    }
    b_str(&svg, "</svg>");
    char md5[33], file[48];
    sb3_md5_hex(svg.p, svg.n, md5);
    snprintf(file, sizeof file, "%s.svg", md5);
    if (svg.err || zip_add(z, file, svg.p, svg.n) != 0) j->err = 1;
    if (!first) b_put(j, ",", 1);
    b_fmt(j, "{\"assetId\":\"%s\",\"name\":", md5);
    b_json(j, cs->name);
    b_fmt(j, ",\"md5ext\":\"%s\",\"dataFormat\":\"svg\",\"rotationCenterX\":%d,\"rotationCenterY\":%d}", file, STAGE_W / 2, STAGE_H / 2);
    b_free(&svg);
}

static void add_sound_json(Buf *j, Zip *z, const Sound *s, int first)
{
    int16_t *pcm = malloc(SND_BUF_MAX * sizeof(int16_t));
    if (!pcm) { j->err = 1; return; }
    int n = snd_render(s, pcm, SND_BUF_MAX), rate = snd_rate(s);
    if (n < 1) { n = 1; pcm[0] = 0; }
    Buf wav = { 0 };
    wav_encode(&wav, pcm, n, rate, s->vol > 0 ? (s->vol > 100 ? 100 : s->vol) : 100);
    free(pcm);
    char md5[33], file[48];
    sb3_md5_hex(wav.p, wav.n, md5);
    snprintf(file, sizeof file, "%s.wav", md5);
    if (zip_add(z, file, wav.p, wav.n) != 0) j->err = 1;
    if (!first) b_put(j, ",", 1);
    b_fmt(j, "{\"assetId\":\"%s\",\"name\":", md5);
    b_json(j, s->name);
    b_fmt(j, ",\"dataFormat\":\"wav\",\"format\":\"\",\"rate\":%d,\"sampleCount\":%d,\"md5ext\":\"%s\"}", rate, n, file);
    b_free(&wav);
}

static void scan_messages(Ctx *c)
{
    for (int s = 0; s < c->p->nsprites; s++)
        for (int i = 0; i < c->p->sprites[s].nscripts; i++) {
            const Script *sc = &c->p->sprites[s].scripts[i];
            for (int b = 0; b < sc->nblocks; b++) {
                const Block *bl = &sc->blocks[b];
                if (bl->kind == BK_HAT_RECV || bl->kind == BK_BROADCAST || bl->kind == BK_BROADCAST_WAIT) msg_id(c, bl->a[0].text);
            }
        }
}

int sb3_write_project(const Project *p, const char *path)
{
    Ctx *c = calloc(1, sizeof *c);
    Zip *z = calloc(1, sizeof *z);
    Buf j = { 0 };
    int rc = -1;
    if (!c || !z) goto done;
    c->p = p;
    scan_messages(c);

    const Sprite *stg = &p->sprites[STAGE_IDX];

    b_str(&j, "{\"targets\":[{\"isStage\":true,\"name\":\"Stage\",\"variables\":{");
    for (int i = 0; i < p->nvars; i++) {
        if (i) b_put(&j, ",", 1);
        b_fmt(&j, "\"v%d\":[", i); b_json(&j, p->vars[i].name); b_put(&j, ",", 1); json_value(&j, p->vars[i].init); b_put(&j, "]", 1);
    }
    b_str(&j, "},\"lists\":{");
    for (int i = 0; i < p->nlists; i++) {
        if (i) b_put(&j, ",", 1);
        b_fmt(&j, "\"l%d\":[", i); b_json(&j, p->lists[i].name); b_str(&j, ",[]]");
    }
    b_str(&j, "},\"broadcasts\":{");
    int sprites_json_start = (int)j.n;
    (void)sprites_json_start;

    Buf sprites = { 0 };
    for (int s = 0; s < p->nsprites; s++) {
        const Sprite *sp = &p->sprites[s];
        b_free(&c->blocks);
        memset(&c->blocks, 0, sizeof c->blocks);
        for (int i = 0; i < sp->nscripts; i++) {
            int pos = 0;
            emit_seq(c, &sp->scripts[i], &pos, 0, 1, 0);
        }
        b_str(&sprites, ",{\"isStage\":false,\"name\":"); b_json(&sprites, sp->name);
        b_str(&sprites, ",\"variables\":{},\"lists\":{},\"broadcasts\":{},\"blocks\":{");
        if (c->blocks.n) b_put(&sprites, c->blocks.p, c->blocks.n);
        b_fmt(&sprites, "},\"comments\":{},\"currentCostume\":%d,\"costumes\":[", sp->cur_costume);
        for (int k = 0; k < sp->ncostumes; k++) add_costume_json(&sprites, z, &sp->costumes[k], k == 0);
        b_str(&sprites, "],\"sounds\":[");
        for (int k = 0; k < sp->nsounds; k++) add_sound_json(&sprites, z, &sp->sounds[k], k == 0);
        b_fmt(&sprites, "],\"volume\":100,\"layerOrder\":%d,\"visible\":%s,\"x\":%d,\"y\":%d,\"size\":%d,\"direction\":%d,\"draggable\":false,\"rotationStyle\":\"all around\"}",
              s + 1, sp->visible ? "true" : "false", sp->x, sp->y, sp->size > 0 ? sp->size : 100, sp->direction);
    }
    for (int i = 0; i < c->nmsgs; i++) {
        if (i) b_put(&j, ",", 1);
        b_fmt(&j, "\"m%d\":", i); b_json(&j, c->msgs[i]);
    }
    b_fmt(&j, "},\"blocks\":{},\"comments\":{},\"currentCostume\":%d,\"costumes\":[", stg->ncostumes > 0 ? stg->cur_costume : 0);
    for (int k = 0; k < stg->ncostumes; k++) add_backdrop_json(&j, z, &stg->costumes[k], k == 0);
    if (stg->ncostumes == 0) {
        Costume white; memset(&white, 2, sizeof white); strcpy(white.name, "backdrop1");
        add_backdrop_json(&j, z, &white, 1);
    }
    b_str(&j, "],\"sounds\":[");
    for (int k = 0; k < stg->nsounds; k++) add_sound_json(&j, z, &stg->sounds[k], k == 0);
    b_str(&j, "],\"volume\":100,\"layerOrder\":0,\"tempo\":60,\"videoTransparency\":50,\"videoState\":\"off\",\"textToSpeechLanguage\":null}");
    b_put(&j, sprites.p ? sprites.p : "", sprites.n);
    b_free(&sprites);
    b_str(&j, "],\"monitors\":[],\"extensions\":[");
    if (c->use_pen) b_str(&j, "\"pen\"");
    if (c->use_music) b_str(&j, c->use_pen ? ",\"music\"" : "\"music\"");
    b_str(&j, "],\"meta\":{\"semver\":\"3.0.0\",\"vm\":\"0.2.0\",\"agent\":\"ScratchEdit3DS\"}}");
    if (j.err || c->blocks.err) goto done;

    Zip *zf = calloc(1, sizeof *zf);
    if (!zf) goto done;
    if (zip_add(zf, "project.json", j.p, j.n) != 0) { free(zf->data.p); free(zf); goto done; }
    for (int i = 0; i < z->n; i++) {
        const ZEntry *e = &z->e[i];
        if (zip_add(zf, e->name, z->data.p + e->off + 30 + strlen(e->name), e->size) != 0) { free(zf->data.p); free(zf); goto done; }
    }
    zip_finish(zf);
    if (!zf->data.err) {
        FILE *f = fopen(path, "wb");
        if (f) {
            rc = fwrite(zf->data.p, 1, zf->data.n, f) == zf->data.n ? 0 : -1;
            if (fclose(f) != 0) rc = -1;
        }
    }
    free(zf->data.p); free(zf);
done:
    b_free(&j);
    if (c) b_free(&c->blocks);
    if (z) free(z->data.p);
    free(z); free(c);
    return rc;
}
