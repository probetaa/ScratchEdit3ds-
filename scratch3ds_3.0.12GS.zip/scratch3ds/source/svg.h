#ifndef SVG_H
#define SVG_H

#include <stddef.h>

int svg_size(const char *svg, size_t len, double *w, double *h);
unsigned char *svg_render(const char *svg, size_t len, int pw, int ph);

#endif
