#include "editor.h"
#include "assets.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static void copy_str(char *dst, const char *src, int n)
{
    int i = 0;
    for (; i < n - 1 && src[i]; i++) dst[i] = src[i];
    dst[i] = 0;
}

static int sprite_ok(const Project *p, int sp) { return sp >= 0 && sp < p->nsprites; }

static int slot_ok(const Project *p, int sp) { return sprite_ok(p, sp) || sp == STAGE_IDX; }

static char slot_char(int kind, int k)
{
    return (k >= 0 && k < block_nslots(kind)) ? BLOCK_INFO[kind].slots[k] : 0;
}

const char *const KEY_NAMES[KEY_NAME_COUNT] = {
    "space", "up arrow", "down arrow", "left arrow", "right arrow",
    "a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m",
    "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z",
    "0", "1", "2", "3", "4", "5", "6", "7", "8", "9",
};

int key_index(const char *name)
{
    for (int i = 0; i < KEY_NAME_COUNT; i++) if (strcmp(KEY_NAMES[i], name) == 0) return i;
    return -1;
}

typedef void (*ArgFn)(Arg *a, char slot, void *ctx);

static void walk_block(Block *b, ArgFn fn, void *ctx)
{
    int ns = block_nslots(b->kind);
    for (int k = 0; k < ns && k < MAX_ARGS; k++)
        if (b->a[k].expr < 0) fn(&b->a[k], BLOCK_INFO[b->kind].slots[k], ctx);
}

static void walk_script(Script *sc, ArgFn fn, void *ctx)
{
    for (int i = 0; i < sc->nblocks; i++) walk_block(&sc->blocks[i], fn, ctx);
    for (int i = 0; i < MAX_EXPR; i++) if (sc->ex_used[i]) walk_block(&sc->ex[i], fn, ctx);
}

typedef struct { const char *slots, *oldv, *newv; } RenameCtx;

static void rename_cb(Arg *a, char slot, void *ctx)
{
    RenameCtx *r = ctx;
    if (strchr(r->slots, slot) && strcmp(a->text, r->oldv) == 0) copy_str(a->text, r->newv, TEXT_LEN);
}

void prj_rename_refs(Project *p, int scope, const char *slots, const char *oldv, const char *newv)
{
    RenameCtx r = { slots, oldv, newv };
    for (int s = 0; s < p->nsprites; s++) {
        if (scope >= 0 && s != scope) continue;
        for (int i = 0; i < p->sprites[s].nscripts; i++) walk_script(&p->sprites[s].scripts[i], rename_cb, &r);
    }
}

typedef int (*TakenFn)(const Sprite *, const char *);
static int costume_taken(const Sprite *s, const char *n) { return prj_find_costume(s, n) >= 0; }
static int sound_taken(const Sprite *s, const char *n)   { return prj_find_sound(s, n) >= 0; }
static void unique_name(char *out, const Sprite *s, const char *base, int start, TakenFn taken)
{
    char cand[TEXT_LEN] = "";
    for (int n = start; n < start + 100; n++) {
        snprintf(cand, TEXT_LEN, "%s%d", base, n);
        if (!taken(s, cand)) break;
    }
    copy_str(out, cand, TEXT_LEN);
}

static int sprite_name_taken(const Project *p, const char *n, int except)
{
    for (int i = 0; i < p->nsprites; i++)
        if (i != except && strcmp(p->sprites[i].name, n) == 0) return 1;
    return 0;
}

static void sprite_setup(Project *p, int sp, int variant)
{
    Sprite *s = &p->sprites[sp];
    memset(s, 0, sizeof *s);
    for (int n = 1; n < 100; n++) {
        snprintf(s->name, TEXT_LEN, "Sprite%d", n);
        if (!sprite_name_taken(p, s->name, sp)) break;
    }
    s->x = (variant % 3 - 1) * 90;
    s->y = ((variant / 3) % 2) ? -60 : 40;
    s->direction = 90;
    s->visible = 1;
    s->size = 100;
    s->ncostumes = 1;
    strcpy(s->costumes[0].name, "costume1");
    costume_make_default(&s->costumes[0], variant);
    s->cur_costume = 0;
    prj_new_script(p, sp, BK_HAT_FLAG);
}

void prj_clear(Project *p)
{
    for (int s = 0; s <= MAX_SPRITES; s++)
        for (int k = 0; k < MAX_SOUNDS; k++) snd_free(&p->sprites[s].sounds[k]);
    memset(p, 0, sizeof *p);
}

void prj_init(Project *p)
{
    prj_clear(p);
    p->nsprites = 1;
    sprite_setup(p, 0, 0);
    p->sprites[0].x = 0; p->sprites[0].y = 0;
    Sprite *st = &p->sprites[STAGE_IDX];
    strcpy(st->name, "Stage");
    st->ncostumes = 1;
    strcpy(st->costumes[0].name, "backdrop1");
    memset(st->costumes[0].px, 2, sizeof st->costumes[0].px);
    st->size = 100; st->visible = 1; st->direction = 90;
}

static void unique_sprite_name(const Project *p, char *name, int except)
{
    char base[TEXT_LEN];
    copy_str(base, name, TEXT_LEN);
    for (int k = 2; k < 1000 && sprite_name_taken(p, name, except); k++) {
        char suf[8];
        snprintf(suf, sizeof suf, "%d", k);
        snprintf(name, TEXT_LEN, "%.*s%s", (int)(TEXT_LEN - 1 - strlen(suf)), base, suf);
    }
}

int prj_add_imported(Project *p, Sprite *s)
{
    if (p->nsprites >= MAX_SPRITES || s->ncostumes < 1) return -1;
    int i = p->nsprites++;
    p->sprites[i] = *s;
    Sprite *d = &p->sprites[i];
    memset(s->sounds, 0, sizeof s->sounds);
    s->nsounds = 0;
    if (!d->name[0]) copy_str(d->name, "sprite", TEXT_LEN);
    unique_sprite_name(p, d->name, i);
    if (d->size <= 0) d->size = 100;
    if (d->cur_costume < 0 || d->cur_costume >= d->ncostumes) d->cur_costume = 0;
    if (d->nscripts == 0) prj_new_script(p, i, BK_HAT_FLAG);
    return i;
}

int prj_duplicate_sprite(Project *p, int sp)
{
    if (!sprite_ok(p, sp) || p->nsprites >= MAX_SPRITES) return -1;
    int i = p->nsprites++;
    p->sprites[i] = p->sprites[sp];
    Sprite *d = &p->sprites[i];
    for (int k = 0; k < MAX_SOUNDS; k++) {
        Sound *s = &d->sounds[k];
        if (k < d->nsounds && s->pcm) {
            int16_t *copy = malloc((size_t)s->npcm * sizeof(int16_t));
            if (copy) memcpy(copy, s->pcm, (size_t)s->npcm * sizeof(int16_t));
            s->pcm = copy;
            if (!copy) s->npcm = 0;
        } else s->pcm = NULL;
    }
    unique_sprite_name(p, d->name, i);
    if (d->x < STAGE_W / 2 - 30) d->x += 20; else d->x -= 20;
    if (d->y > -STAGE_H / 2 + 30) d->y -= 20; else d->y += 20;
    return i;
}

int prj_move_sprite(Project *p, int sp, int delta)
{
    if (!sprite_ok(p, sp)) return -1;
    int to = sp + delta;
    if (to < 0 || to >= p->nsprites) return sp;
    Sprite tmp = p->sprites[sp];
    p->sprites[sp] = p->sprites[to];
    p->sprites[to] = tmp;
    return to;
}

int prj_add_sprite(Project *p)
{
    if (p->nsprites >= MAX_SPRITES) return -1;
    int i = p->nsprites++;
    sprite_setup(p, i, i);
    return i;
}

int prj_delete_sprite(Project *p, int sp)
{
    if (!sprite_ok(p, sp) || p->nsprites <= 1) return -1;
    char gone[TEXT_LEN];
    copy_str(gone, p->sprites[sp].name, TEXT_LEN);
    for (int k = 0; k < MAX_SOUNDS; k++) snd_free(&p->sprites[sp].sounds[k]);
    for (int i = sp; i < p->nsprites - 1; i++) p->sprites[i] = p->sprites[i + 1];
    memset(&p->sprites[p->nsprites - 1], 0, sizeof(Sprite));
    p->nsprites--;

    prj_rename_refs(p, -1, "tp", gone, "mouse-pointer");
    prj_rename_refs(p, -1, "q", gone, p->sprites[0].name);
    prj_rename_refs(p, -1, "y", gone, "myself");
    return 0;
}

void prj_rename_sprite(Project *p, int sp, const char *name)
{
    if (!sprite_ok(p, sp) || !name[0]) return;
    char tmp[TEXT_LEN], old[TEXT_LEN];
    copy_str(tmp, name, TEXT_LEN);
    copy_str(old, p->sprites[sp].name, TEXT_LEN);
    for (int i = 0; i < p->nsprites; i++)
        if (i != sp && strcmp(p->sprites[i].name, tmp) == 0) {
            size_t l = strlen(tmp);
            if (l > TEXT_LEN - 3) tmp[TEXT_LEN - 3] = 0;
            strcat(tmp, "2");
            break;
        }
    copy_str(p->sprites[sp].name, tmp, TEXT_LEN);
    prj_rename_refs(p, -1, "tpqy", old, p->sprites[sp].name);
}

int prj_find_costume(const Sprite *s, const char *name)
{
    for (int i = 0; i < s->ncostumes; i++) if (strcmp(s->costumes[i].name, name) == 0) return i;
    return -1;
}

int prj_add_costume(Project *p, int sp)
{
    if (!slot_ok(p, sp)) return -1;
    Sprite *s = &p->sprites[sp];
    if (s->ncostumes >= MAX_COSTUMES) return -1;
    int i = s->ncostumes++;
    s->costumes[i] = s->costumes[s->cur_costume];
    unique_name(s->costumes[i].name, s, sp == STAGE_IDX ? "backdrop" : "costume", s->ncostumes, costume_taken);
    s->cur_costume = i;
    return i;
}

int prj_delete_costume(Project *p, int sp, int c)
{
    if (!slot_ok(p, sp)) return -1;
    Sprite *s = &p->sprites[sp];
    if (c < 0 || c >= s->ncostumes || s->ncostumes <= 1) return -1;
    char gone[TEXT_LEN];
    copy_str(gone, s->costumes[c].name, TEXT_LEN);
    for (int i = c; i < s->ncostumes - 1; i++) s->costumes[i] = s->costumes[i + 1];
    s->ncostumes--;
    if (s->cur_costume >= s->ncostumes) s->cur_costume = s->ncostumes - 1;
    prj_rename_refs(p, sp, "c", gone, s->costumes[0].name);
    return 0;
}

int prj_rename_costume(Project *p, int sp, int c, const char *name)
{
    if (!slot_ok(p, sp) || !name[0]) return -1;
    Sprite *s = &p->sprites[sp];
    if (c < 0 || c >= s->ncostumes) return -1;
    char nn[TEXT_LEN], old[TEXT_LEN];
    copy_str(nn, name, TEXT_LEN);
    int f = prj_find_costume(s, nn);
    if (f >= 0 && f != c) return -1;
    copy_str(old, s->costumes[c].name, TEXT_LEN);
    copy_str(s->costumes[c].name, nn, TEXT_LEN);
    prj_rename_refs(p, sp, "c", old, nn);
    return 0;
}

int prj_find_sound(const Sprite *s, const char *name)
{
    for (int i = 0; i < s->nsounds; i++) if (strcmp(s->sounds[i].name, name) == 0) return i;
    return -1;
}

int prj_add_sound(Project *p, int sp)
{
    if (!slot_ok(p, sp)) return -1;
    Sprite *s = &p->sprites[sp];
    if (s->nsounds >= MAX_SOUNDS) return -1;
    int i = s->nsounds++;
    snd_default(&s->sounds[i]);
    s->sounds[i].name[0] = 0;
    unique_name(s->sounds[i].name, s, "beep", s->nsounds, sound_taken);
    return i;
}

int prj_add_recording(Project *p, int sp, const int16_t *pcm, int n, int rate)
{
    if (!slot_ok(p, sp)) return -1;
    Sprite *s = &p->sprites[sp];
    if (s->nsounds >= MAX_SOUNDS) return -1;
    int i = s->nsounds;
    Sound *snd = &s->sounds[i];
    snd_default(snd);
    if (snd_set_pcm(snd, pcm, n, rate) != 0) return -1;
    s->nsounds++;
    snd->vol = 100;
    snd->name[0] = 0;
    unique_name(snd->name, s, "recording", s->nsounds, sound_taken);
    return i;
}

int prj_delete_sound(Project *p, int sp, int snd)
{
    if (!slot_ok(p, sp)) return -1;
    Sprite *s = &p->sprites[sp];
    if (snd < 0 || snd >= s->nsounds) return -1;
    char gone[TEXT_LEN];
    copy_str(gone, s->sounds[snd].name, TEXT_LEN);
    snd_free(&s->sounds[snd]);
    for (int i = snd; i < s->nsounds - 1; i++) s->sounds[i] = s->sounds[i + 1];
    memset(&s->sounds[s->nsounds - 1], 0, sizeof(Sound));
    s->nsounds--;
    prj_rename_refs(p, sp, "o", gone, s->nsounds > 0 ? s->sounds[0].name : "");
    return 0;
}

int prj_rename_sound(Project *p, int sp, int snd, const char *name)
{
    if (!slot_ok(p, sp) || !name[0]) return -1;
    Sprite *s = &p->sprites[sp];
    if (snd < 0 || snd >= s->nsounds) return -1;
    char nn[TEXT_LEN], old[TEXT_LEN];
    copy_str(nn, name, TEXT_LEN);
    int f = prj_find_sound(s, nn);
    if (f >= 0 && f != snd) return -1;
    copy_str(old, s->sounds[snd].name, TEXT_LEN);
    copy_str(s->sounds[snd].name, nn, TEXT_LEN);
    prj_rename_refs(p, sp, "o", old, nn);
    return 0;
}

int prj_find_var(const Project *p, const char *name)
{
    for (int i = 0; i < p->nvars; i++) if (strcmp(p->vars[i].name, name) == 0) return i;
    return -1;
}

int prj_add_var(Project *p, const char *name)
{
    if (!name[0]) return -1;
    int f = prj_find_var(p, name);
    if (f >= 0) return f;
    if (p->nvars >= MAX_VARS) return -1;
    Var *v = &p->vars[p->nvars];
    memset(v, 0, sizeof *v);
    copy_str(v->name, name, TEXT_LEN);
    strcpy(v->init, "0");
    return p->nvars++;
}

int prj_delete_var(Project *p, int i)
{
    if (i < 0 || i >= p->nvars) return -1;
    char gone[TEXT_LEN];
    copy_str(gone, p->vars[i].name, TEXT_LEN);
    for (int k = i; k < p->nvars - 1; k++) p->vars[k] = p->vars[k + 1];
    p->nvars--;
    memset(&p->vars[p->nvars], 0, sizeof(Var));
    prj_rename_refs(p, -1, "v", gone, p->nvars > 0 ? p->vars[0].name : "");
    return 0;
}

int prj_find_list(const Project *p, const char *name)
{
    for (int i = 0; i < p->nlists; i++) if (strcmp(p->lists[i].name, name) == 0) return i;
    return -1;
}

int prj_add_list(Project *p, const char *name)
{
    if (!name[0]) return -1;
    int f = prj_find_list(p, name);
    if (f >= 0) return f;
    if (p->nlists >= MAX_LISTS) return -1;
    ListDef *l = &p->lists[p->nlists];
    memset(l, 0, sizeof *l);
    copy_str(l->name, name, TEXT_LEN);
    return p->nlists++;
}

int prj_delete_list(Project *p, int i)
{
    if (i < 0 || i >= p->nlists) return -1;
    char gone[TEXT_LEN];
    copy_str(gone, p->lists[i].name, TEXT_LEN);
    for (int k = i; k < p->nlists - 1; k++) p->lists[k] = p->lists[k + 1];
    p->nlists--;
    memset(&p->lists[p->nlists], 0, sizeof(ListDef));
    prj_rename_refs(p, -1, "l", gone, p->nlists > 0 ? p->lists[0].name : "");
    return 0;
}

void prj_fill_defaults(const Project *p, int sp, Block *b)
{
    int ns = block_nslots(b->kind);
    const Sprite *s = sprite_ok(p, sp) ? &p->sprites[sp] : NULL;
    for (int k = 0; k < ns && k < MAX_ARGS; k++) {
        if (b->a[k].text[0]) continue;
        switch (BLOCK_INFO[b->kind].slots[k]) {
        case 'c': if (s && s->ncostumes > 0) copy_str(b->a[k].text, s->costumes[s->cur_costume].name, TEXT_LEN); break;
        case 'o': if (s && s->nsounds > 0) copy_str(b->a[k].text, s->sounds[0].name, TEXT_LEN); break;
        case 'v': if (p->nvars > 0) copy_str(b->a[k].text, p->vars[0].name, TEXT_LEN); break;
        case 'l': if (p->nlists > 0) copy_str(b->a[k].text, p->lists[0].name, TEXT_LEN); break;
        case 'q': if (s) copy_str(b->a[k].text, s->name, TEXT_LEN); break;
        default: break;
        }
    }
}

int prj_new_script(Project *p, int sp, BlockKind hat)
{
    if (!sprite_ok(p, sp) || hat < 0 || hat >= BK_COUNT || !block_is_hat(hat)) return -1;
    Sprite *sprite = &p->sprites[sp];
    if (sprite->nscripts >= MAX_SCRIPTS) return -1;
    int i = sprite->nscripts++;
    Script *s = &sprite->scripts[i];
    memset(s, 0, sizeof *s);
    s->x = 10 + (i % 3) * 20;
    s->y = 10 + i * 40;
    s->blocks[0] = block_default(hat);
    prj_fill_defaults(p, sp, &s->blocks[0]);
    s->nblocks = 1;
    return i;
}

int prj_delete_script(Project *p, int sp, int s)
{
    if (!sprite_ok(p, sp)) return -1;
    Sprite *sprite = &p->sprites[sp];
    if (s < 0 || s >= sprite->nscripts || sprite->nscripts <= 1) return -1;
    for (int i = s; i < sprite->nscripts - 1; i++) sprite->scripts[i] = sprite->scripts[i + 1];
    sprite->nscripts--;
    memset(&sprite->scripts[sprite->nscripts], 0, sizeof(Script));
    return 0;
}

static void free_tree(Script *s, int idx)
{
    if (idx < 0 || idx >= MAX_EXPR || !s->ex_used[idx]) return;
    s->ex_used[idx] = 0;
    for (int k = 0; k < MAX_ARGS; k++) free_tree(s, s->ex[idx].a[k].expr);
}

static void free_block_args(Script *s, Block *b)
{
    for (int k = 0; k < MAX_ARGS; k++) { free_tree(s, b->a[k].expr); b->a[k].expr = -1; }
}

int prj_insert_block(Project *p, int sp, int s, int after, BlockKind k)
{
    if (!sprite_ok(p, sp) || k < 0 || k >= BK_COUNT) return -1;
    int shape = BLOCK_INFO[k].shape;
    if (shape == SH_HAT || shape == SH_REP || shape == SH_BOOL || shape == SH_END || shape == SH_ELSE) return -1;
    Sprite *sprite = &p->sprites[sp];
    if (s < 0 || s >= sprite->nscripts) return -1;
    Script *sc = &sprite->scripts[s];
    int extra = shape == SH_C ? 1 : (shape == SH_CELSE ? 2 : 0);
    if (sc->nblocks + 1 + extra > MAX_BLOCKS) return -1;
    if (after < 0) after = 0;
    if (after > sc->nblocks - 1) after = sc->nblocks - 1;
    int at = after + 1, add = 1 + extra;
    for (int i = sc->nblocks - 1; i >= at; i--) sc->blocks[i + add] = sc->blocks[i];
    sc->blocks[at] = block_default(k);
    prj_fill_defaults(p, sp, &sc->blocks[at]);
    if (shape == SH_CELSE) { sc->blocks[at + 1] = block_default(BK_ELSE); sc->blocks[at + 2] = block_default(BK_END); }
    else if (shape == SH_C) sc->blocks[at + 1] = block_default(BK_END);
    sc->nblocks += add;
    return at;
}

static void remove_at(Script *sc, int b)
{
    free_block_args(sc, &sc->blocks[b]);
    for (int i = b; i < sc->nblocks - 1; i++) sc->blocks[i] = sc->blocks[i + 1];
    sc->nblocks--;
}

int prj_delete_block(Project *p, int sp, int s, int b)
{
    if (!sprite_ok(p, sp)) return -1;
    Sprite *sprite = &p->sprites[sp];
    if (s < 0 || s >= sprite->nscripts) return -1;
    Script *sc = &sprite->scripts[s];
    if (b <= 0 || b >= sc->nblocks) return -1;
    int shape = BLOCK_INFO[sc->blocks[b].kind].shape;
    if (shape == SH_END || shape == SH_ELSE) return -1;
    if (shape == SH_C || shape == SH_CELSE) {
        int e = prj_match_end(sc, b), el = prj_match_else(sc, b);
        if (e >= 0) remove_at(sc, e);
        if (el >= 0) remove_at(sc, el);
    }
    remove_at(sc, b);
    return 0;
}

int prj_match_end(const Script *s, int head)
{
    int depth = 0;
    for (int i = head + 1; i < s->nblocks; i++) {
        int sh = BLOCK_INFO[s->blocks[i].kind].shape;
        if (sh == SH_C || sh == SH_CELSE) depth++;
        else if (sh == SH_END) { if (depth == 0) return i; depth--; }
    }
    return -1;
}

int prj_match_else(const Script *s, int head)
{
    int depth = 0;
    for (int i = head + 1; i < s->nblocks; i++) {
        int sh = BLOCK_INFO[s->blocks[i].kind].shape;
        if (sh == SH_C || sh == SH_CELSE) depth++;
        else if (sh == SH_END) { if (depth == 0) return -1; depth--; }
        else if (sh == SH_ELSE && depth == 0) return i;
    }
    return -1;
}

int prj_indent(const Script *s, int b)
{
    int d = 0;
    for (int i = 0; i < b && i < s->nblocks; i++) {
        int sh = BLOCK_INFO[s->blocks[i].kind].shape;
        if (sh == SH_C || sh == SH_CELSE) d++;
        else if (sh == SH_END && d > 0) d--;
    }
    if (b < s->nblocks) {
        int sh = BLOCK_INFO[s->blocks[b].kind].shape;
        if ((sh == SH_END || sh == SH_ELSE) && d > 0) d--;
    }
    return d;
}

Block *prj_node(Script *s, int blk, const int *path, int depth)
{
    if (blk < 0 || blk >= s->nblocks) return NULL;
    Block *n = &s->blocks[blk];
    for (int d = 0; d < depth; d++) {
        int slot = path[d];
        if (slot < 0 || slot >= MAX_ARGS) return NULL;
        int e = n->a[slot].expr;
        if (e < 0 || e >= MAX_EXPR || !s->ex_used[e]) return NULL;
        n = &s->ex[e];
    }
    return n;
}

int prj_plug(Project *p, int sp, Script *s, Block *node, int slot, BlockKind kind, const char *param)
{
    if (!node || slot < 0 || slot >= block_nslots(node->kind)) return -1;
    if (kind < 0 || kind >= BK_COUNT || !block_is_reporter(kind)) return -1;
    if (BLOCK_INFO[node->kind].slots[slot] == 'b' && BLOCK_INFO[kind].shape != SH_BOOL) return -3;
    free_tree(s, node->a[slot].expr);
    node->a[slot].expr = -1;
    int idx = -1;
    for (int i = 0; i < MAX_EXPR; i++) if (!s->ex_used[i]) { idx = i; break; }
    if (idx < 0) return -2;
    s->ex[idx] = block_default(kind);
    if (kind == BK_VAR && param) copy_str(s->ex[idx].a[0].text, param, TEXT_LEN);
    prj_fill_defaults(p, sp, &s->ex[idx]);
    s->ex_used[idx] = 1;
    node->a[slot].expr = (int16_t)idx;
    return 0;
}

int prj_unplug(Script *s, Block *node, int slot)
{
    if (!node || slot < 0 || slot >= MAX_ARGS) return -1;
    if (node->a[slot].expr < 0) return -1;
    free_tree(s, node->a[slot].expr);
    node->a[slot].expr = -1;
    return 0;
}

typedef struct { char *p; int n, o; } Out;

static void put(Out *w, const char *s)
{
    while (*s && w->o < w->n - 1) w->p[w->o++] = *s++;
    w->p[w->o] = 0;
}

static void fmt_block(Out *w, const Script *s, const Block *b, int depth);

static void fmt_arg(Out *w, const Script *s, const Arg *a, char slot, int depth)
{
    if (a->expr >= 0 && a->expr < MAX_EXPR && s && s->ex_used[a->expr] && depth < MAX_DEPTH + 2) {
        const Block *e = &s->ex[a->expr];
        int boolean = BLOCK_INFO[e->kind].shape == SH_BOOL;
        put(w, boolean ? "<" : "(");
        fmt_block(w, s, e, depth + 1);
        put(w, boolean ? ">" : ")");
        return;
    }
    if (slot == 'b') { put(w, "<>"); return; }
    if (!a->text[0]) { put(w, (slot == 'v' || slot == 'l' || slot == 'c' || slot == 'o' || slot == 'q') ? "?" : (slot == 'n' ? "0" : "_")); return; }
    put(w, a->text);
}

static void fmt_block(Out *w, const Script *s, const Block *b, int depth)
{
    const char *l = BLOCK_INFO[b->kind].label;
    while (*l && w->o < w->n - 1) {
        if (l[0] == '%' && l[1] >= '1' && l[1] <= '3') {
            int k = l[1] - '1';
            fmt_arg(w, s, &b->a[k], slot_char(b->kind, k), depth);
            l += 2;
        } else {
            char c[2] = { *l++, 0 };
            put(w, c);
        }
    }
}

void prj_format_block(const Script *s, const Block *b, char *out, int outlen)
{
    Out w = { out, outlen, 0 };
    out[0] = 0;
    fmt_block(&w, s, b, 0);
}

void prj_format_arg(const Script *s, const Arg *a, char slot, char *out, int outlen)
{
    Out w = { out, outlen, 0 };
    out[0] = 0;
    fmt_arg(&w, s, a, slot, 0);
}

int slot_is_text(char slot) { return slot == 'n' || slot == 's'; }
int slot_is_menu(char slot) { return slot != 'b' && !slot_is_text(slot) && slot != 0; }

typedef struct { char (*out)[TEXT_LEN]; int n, max; } MsgCtx;

static void add_item(MsgCtx *c, const char *s)
{
    if (!s[0] || c->n >= c->max) return;
    for (int i = 0; i < c->n; i++) if (strcmp(c->out[i], s) == 0) return;
    copy_str(c->out[c->n++], s, TEXT_LEN);
}

static void msg_cb(Arg *a, char slot, void *ctx)
{
    if (slot == 'm') add_item((MsgCtx *)ctx, a->text);
}

int prj_menu_items(const Project *p, int sp, char slot, char out[][TEXT_LEN], int max)
{
    MsgCtx c = { out, 0, max };
    const Sprite *s = sprite_ok(p, sp) ? &p->sprites[sp] : NULL;
    switch (slot) {
    case 'c': if (s) for (int i = 0; i < s->ncostumes; i++) add_item(&c, s->costumes[i].name); break;
    case 'o': if (s) for (int i = 0; i < s->nsounds; i++) add_item(&c, s->sounds[i].name); break;
    case 'k': for (int i = 0; i < KEY_NAME_COUNT; i++) add_item(&c, KEY_NAMES[i]); break;
    case 'm':
        for (int i = 0; i < p->nsprites; i++)
            for (int j = 0; j < p->sprites[i].nscripts; j++) walk_script((Script *)&p->sprites[i].scripts[j], msg_cb, &c);
        if (c.n >= max) c.n = max - 1;
        copy_str(out[c.n++], "new message...", TEXT_LEN);
        break;
    case 't': add_item(&c, "mouse-pointer"); add_item(&c, "edge");
              for (int i = 0; i < p->nsprites; i++) if (i != sp) add_item(&c, p->sprites[i].name);
              break;
    case 'p': add_item(&c, "mouse-pointer");
              for (int i = 0; i < p->nsprites; i++) if (i != sp) add_item(&c, p->sprites[i].name);
              break;
    case 'q': for (int i = 0; i < p->nsprites; i++) add_item(&c, p->sprites[i].name); break;
    case 'y': add_item(&c, "myself");
              for (int i = 0; i < p->nsprites; i++) if (i != sp) add_item(&c, p->sprites[i].name);
              break;
    case 'v': for (int i = 0; i < p->nvars; i++) add_item(&c, p->vars[i].name); break;
    case 'l': for (int i = 0; i < p->nlists; i++) add_item(&c, p->lists[i].name); break;
    case 'e': {
        static const char *e[] = { "color", "fisheye", "whirl", "pixelate", "mosaic", "brightness", "ghost" };
        for (unsigned i = 0; i < sizeof e / sizeof e[0]; i++) add_item(&c, e[i]);
        break; }
    case 'f': {
        static const char *f[] = { "abs", "sqrt", "sin", "cos", "tan", "asin", "acos", "atan", "ln", "log", "e ^", "10 ^" };
        for (unsigned i = 0; i < sizeof f / sizeof f[0]; i++) add_item(&c, f[i]);
        break; }
    case 'a': {
        static const char *a[] = { "x position", "y position", "direction", "costume #", "size", "volume" };
        for (unsigned i = 0; i < sizeof a / sizeof a[0]; i++) add_item(&c, a[i]);
        break; }
    case 'x': for (int i = 1; i < PAL_N; i++) add_item(&c, PALETTE_NAMES[i]); break;
    case 'i': add_item(&c, "loudness"); add_item(&c, "timer"); break;
    case 'z': {
        static const char *z[] = { "slider", "sound", "resistance-A", "resistance-B", "resistance-C" };
        for (unsigned i = 0; i < sizeof z / sizeof z[0]; i++) add_item(&c, z[i]);
        break; }
    case 'u': {
        static const char *u[] = { "button pressed", "A connected", "B connected", "C connected", "D connected" };
        for (unsigned i = 0; i < sizeof u / sizeof u[0]; i++) add_item(&c, u[i]);
        break; }
    default: break;
    }
    return c.n;
}

int prj_move_block(Project *p, int sp, int s, int from, int after)
{
    if (!sprite_ok(p, sp) || s < 0 || s >= p->sprites[sp].nscripts) return -1;
    Script *sc = &p->sprites[sp].scripts[s];
    if (from < 1 || from >= sc->nblocks) return -1;
    int shape = BLOCK_INFO[sc->blocks[from].kind].shape;
    if (shape == SH_HAT || shape == SH_END || shape == SH_ELSE) return -1;
    int end = from + 1;
    if (shape == SH_C || shape == SH_CELSE) {
        int m = prj_match_end(sc, from);
        if (m < 0) return -1;
        end = m + 1;
    }
    if (after < 0) after = 0;
    if (after >= sc->nblocks) after = sc->nblocks - 1;
    if (after >= from && after < end) return -2;
    int len = end - from;
    Block tmp[MAX_BLOCKS];
    memcpy(tmp, &sc->blocks[from], (size_t)len * sizeof(Block));
    memmove(&sc->blocks[from], &sc->blocks[end], (size_t)(sc->nblocks - end) * sizeof(Block));
    int d = after + 1;
    if (d > from) d -= len;
    int rest = sc->nblocks - len;
    memmove(&sc->blocks[d + len], &sc->blocks[d], (size_t)(rest - d) * sizeof(Block));
    memcpy(&sc->blocks[d], tmp, (size_t)len * sizeof(Block));
    return d;
}

static void snap_free(UndoSnap *s) { free(s->sc); s->sc = NULL; s->nscripts = 0; }

static int snap_take(UndoSnap *out, const Project *p, int sp)
{
    const Sprite *s = &p->sprites[sp];
    out->sp = sp;
    out->nscripts = s->nscripts;
    out->sc = malloc((size_t)(s->nscripts ? s->nscripts : 1) * sizeof(Script));
    if (!out->sc) return -1;
    memcpy(out->sc, s->scripts, (size_t)s->nscripts * sizeof(Script));
    return 0;
}

static void stack_clear(UndoSnap *a, int *n)
{
    for (int i = 0; i < *n; i++) snap_free(&a[i]);
    *n = 0;
}

static void stack_push(UndoSnap *a, int *n, UndoSnap s)
{
    if (*n == UNDO_DEPTH) { snap_free(&a[0]); memmove(&a[0], &a[1], sizeof(UndoSnap) * (UNDO_DEPTH - 1)); (*n)--; }
    a[(*n)++] = s;
}

void undo_clear(UndoStack *u)
{
    stack_clear(u->undo, &u->nundo);
    stack_clear(u->redo, &u->nredo);
}

void undo_checkpoint(UndoStack *u, const Project *p, int sp)
{
    if (!sprite_ok(p, sp)) return;
    stack_clear(u->redo, &u->nredo);
    UndoSnap s;
    if (snap_take(&s, p, sp) == 0) stack_push(u->undo, &u->nundo, s);
}

static int restore(Project *p, UndoSnap *s)
{
    if (!sprite_ok(p, s->sp)) return -1;
    Sprite *d = &p->sprites[s->sp];
    memset(d->scripts, 0, sizeof d->scripts);
    memcpy(d->scripts, s->sc, (size_t)s->nscripts * sizeof(Script));
    d->nscripts = s->nscripts;
    return s->sp;
}

static int step(UndoSnap *from, int *nfrom, UndoSnap *to, int *nto, Project *p)
{
    while (*nfrom > 0) {
        UndoSnap s = from[--(*nfrom)];
        if (!sprite_ok(p, s.sp)) { snap_free(&s); continue; }
        UndoSnap now;
        if (snap_take(&now, p, s.sp) == 0) stack_push(to, nto, now);
        int r = restore(p, &s);
        snap_free(&s);
        return r;
    }
    return -1;
}

int undo_undo(UndoStack *u, Project *p) { return step(u->undo, &u->nundo, u->redo, &u->nredo, p); }
int undo_redo(UndoStack *u, Project *p) { return step(u->redo, &u->nredo, u->undo, &u->nundo, p); }

int prj_duplicate_script(Project *p, int sp, int s)
{
    if (!sprite_ok(p, sp) || s < 0 || s >= p->sprites[sp].nscripts) return -1;
    Sprite *sprite = &p->sprites[sp];
    if (sprite->nscripts >= MAX_SCRIPTS) return -1;
    int i = sprite->nscripts++;
    sprite->scripts[i] = sprite->scripts[s];
    sprite->scripts[i].x = 10 + (i % 3) * 20;
    sprite->scripts[i].y = 10 + i * 40;
    return i;
}

static int clone_tree(Script *s, int idx)
{
    if (idx < 0 || idx >= MAX_EXPR || !s->ex_used[idx]) return -1;
    int n = -1;
    for (int i = 0; i < MAX_EXPR; i++) if (!s->ex_used[i]) { n = i; break; }
    if (n < 0) return -2;
    s->ex[n] = s->ex[idx];
    s->ex_used[n] = 1;
    for (int k = 0; k < MAX_ARGS; k++) {
        int c = clone_tree(s, s->ex[idx].a[k].expr);
        if (c == -2) return -2;
        s->ex[n].a[k].expr = (int16_t)c;
    }
    return n;
}

int prj_duplicate_block(Project *p, int sp, int s, int b)
{
    if (!sprite_ok(p, sp) || s < 0 || s >= p->sprites[sp].nscripts) return -1;
    Script *sc = &p->sprites[sp].scripts[s];
    if (b < 1 || b >= sc->nblocks) return -1;
    int shape = BLOCK_INFO[sc->blocks[b].kind].shape;
    if (shape == SH_HAT || shape == SH_END || shape == SH_ELSE) return -1;
    int end = b + 1;
    if (shape == SH_C || shape == SH_CELSE) { int m = prj_match_end(sc, b); if (m < 0) return -1; end = m + 1; }
    int len = end - b;
    if (sc->nblocks + len > MAX_BLOCKS) return -1;
    Script *bak = malloc(sizeof *bak);
    if (!bak) return -1;
    *bak = *sc;
    memmove(&sc->blocks[end + len], &sc->blocks[end], (size_t)(sc->nblocks - end) * sizeof(Block));
    memcpy(&sc->blocks[end], &sc->blocks[b], (size_t)len * sizeof(Block));
    sc->nblocks += len;
    for (int i = end; i < end + len; i++)
        for (int k = 0; k < MAX_ARGS; k++) {
            int c = clone_tree(sc, sc->blocks[i].a[k].expr);
            if (c == -2) { *sc = *bak; free(bak); return -2; }
            sc->blocks[i].a[k].expr = (int16_t)c;
        }
    free(bak);
    return end;
}

void undo_discard(UndoStack *u)
{
    if (u->nundo > 0) snap_free(&u->undo[--u->nundo]);
}

int prj_add_effect(Project *p, int sp, int preset)
{
    if (!slot_ok(p, sp) || preset < 0 || preset >= SND_PRESET_COUNT) return -1;
    Sprite *s = &p->sprites[sp];
    if (s->nsounds >= MAX_SOUNDS) return -1;
    int i = s->nsounds;
    Sound *snd = &s->sounds[i];
    snd_default(snd);
    if (snd_make_preset(snd, preset) != 0) return -1;
    s->nsounds++;
    snd->name[0] = 0;
    unique_name(snd->name, s, SND_PRESET_NAMES[preset], s->nsounds, sound_taken);
    return i;
}

int prj_duplicate_sound(Project *p, int sp, int snd)
{
    if (!slot_ok(p, sp)) return -1;
    Sprite *s = &p->sprites[sp];
    if (snd < 0 || snd >= s->nsounds || s->nsounds >= MAX_SOUNDS) return -1;
    int i = s->nsounds;
    Sound *d = &s->sounds[i];
    *d = s->sounds[snd];
    d->pcm = NULL; d->npcm = 0;
    if (s->sounds[snd].pcm && snd_set_pcm(d, s->sounds[snd].pcm, s->sounds[snd].npcm, s->sounds[snd].rate) != 0) return -1;
    s->nsounds++;
    char base[TEXT_LEN];
    copy_str(base, s->sounds[snd].name, TEXT_LEN);
    d->name[0] = 0;
    unique_name(d->name, s, base, s->nsounds, sound_taken);
    return i;
}
