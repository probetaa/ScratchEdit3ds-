#include <3ds.h>
#include <citro2d.h>

#include <ctype.h>
#include <dirent.h>
#include <malloc.h>
#include <math.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>

#include "assets.h"
#include "editor.h"
#include "importer.h"
#include "runtime.h"
#include "sb3_writer.h"
#include "templates.h"
#include "about.h"

#define Z 0.5f

#define CRGB(hex)  C2D_Color32(((hex) >> 16) & 255, ((hex) >> 8) & 255, (hex) & 255, 255)
#define CRGBA(hex, a) C2D_Color32(((hex) >> 16) & 255, ((hex) >> 8) & 255, (hex) & 255, (a))
static int g_light = 0;

static unsigned th_hex(unsigned h)
{
    if (!g_light) return h;
    unsigned r = (h >> 16) & 255, g = (h >> 8) & 255, b = h & 255;
    unsigned mx = r > g ? (r > b ? r : b) : (g > b ? g : b), mn = r < g ? (r < b ? r : b) : (g < b ? g : b);
    if (mx - mn > 48) return h;
    return ((255 - r) << 16) | ((255 - g) << 8) | (255 - b);
}
#define RGB(hex)  CRGB(th_hex(hex))
#define RGBA(hex, a) CRGBA(th_hex(hex), a)

#define SAVE_DIR  "sdmc:/3ds/scratch-editor"
#define IMPORT_DIR SAVE_DIR "/sprites"

#define TAB_H      15
#define SPR_Y      17
#define SPR_H      14
#define BTN_Y      208
#define BTN_H      18

#define CAT_Y      34
#define CAT_H      13
#define CAT_W      30
#define CAT_STEP   31
#define PAL_X      2
#define PAL_W      120
#define PAL_Y      50
#define PAL_ROW    15
#define PAL_ROWS   8
#define PALBTN_Y   171
#define PALBTN_H   14
#define SCRNAV_Y   188
#define SCRNAV_H   16
#define SCR_X      126
#define SCR_Y      48
#define SCR_ROW    20
#define SCR_ROWS   7
#define SCRBTN_X   304
#define SCRBTN_W   15
#define SCRBTN_H   66
#define SCRBTN_GAP 8
#define ARG_Y      190
#define ARG_H      16
#define ARG_UP_W   16
#define ARG_X      144
#define ARG_W      56
#define ARG_STEP   58

#define BTN_N      7
#define BTN_STEP   46
#define BTN_W      44

#define PK_Y       50
#define PK_ROW     20
#define PK_ROWS    6
#define PK_COLW    156
#define PK_COLSTEP 158
#define PK_NAV_Y   176
#define PK_PER_PAGE (PK_ROWS * 2)

#define CV_X       4
#define CV_Y       36
#define CV_WIN     80
#define PNL_X      168

#define SN_LIST_Y  36
#define SN_ROW     19
#define SN_BTN_Y   152
#define SN_REC_Y   172

#define STAGE_S    0.6f
#define STAGE_OX   56
#define STAGE_OY   12
#define PAD_S      (320.0f / STAGE_W)

enum { MODE_SCRIPTS = 0, MODE_COSTUMES, MODE_SOUNDS, MODE_ABOUT, MODE_COUNT };
enum { PK_NONE = 0, PK_ARG, PK_DEL_VAR, PK_DEL_LIST, PK_SPRITE_LIST, PK_SPRITE_MENU, PK_IMPORT, PK_FX, PK_TEMPLATE, PK_TEMPLATE_OK, PK_OPEN, PK_OPEN_OK, PK_PLAYFILE, PK_MKBLOCK, PK_REPORT, PK_SCRIPT_LIST };
enum { SM_RENAME = 0, SM_DUPLICATE, SM_BACK, SM_FRONT, SM_X, SM_Y, SM_DIR, SM_SIZE, SM_VISIBLE, SM_IMPORT, SM_OPEN, SM_PLAYFILE, SM_TEMPLATES, SM_IMPORT_ALL, SM_COUNT };

enum { PE_NEW_VAR = -1, PE_DEL_VAR = -2, PE_NEW_LIST = -3, PE_DEL_LIST = -4, PE_MAKE_BLOCK = -5 };
typedef struct { int kind; int param; } PalEntry;
#define PAL_MAX (BK_COUNT + MAX_VARS + 8)

static C2D_TextBuf g_text;
static Project     g_prj;
static Runtime     g_rt;

static int  g_mode   = MODE_SCRIPTS;
static int  g_sprite = 0;
static int  g_script = 0, g_sel = 0, g_scroll = 0, g_cat = CAT_MOTION, g_pal_scroll = 0;

enum { BS_OFF = 0, BS_MOVE, BS_PICK };
static int  g_bs = BS_OFF;
static int  g_about_scroll;
#define ABOUT_ROWS 15
#define ABOUT_ROW_H 12
#define BS_BTN_Y 2
enum { T_PEN, T_FILL, T_LINE, T_RECT, T_OVAL, T_PICK, T_SEL, T_COUNT };
static const int BRUSHES[5] = { 1, 2, 3, 5, 8 };
static Px  g_col = 0x8C63;
static int g_tool = T_PEN, g_brush = 0, g_solid = 0, g_zoom = 2, g_vx = 0, g_vy = 0;
static int g_cv_down = 0, g_cv_sx = 0, g_cv_sy = 0, g_cv_lx = -1, g_cv_ly = -1;
static int g_selon = 0, g_sx0, g_sy0, g_sx1, g_sy1, g_mv = 0, g_mv_gx, g_mv_gy, g_mv_w, g_mv_h;
static Costume g_cv_bak, g_cv_undo;
static int g_undo_sp = -1, g_undo_co = -1;
static void cv_reset(void)
{
    g_undo_sp = -1; g_undo_co = -1;
    g_selon = 0; g_mv = 0; g_cv_down = 0; g_cv_lx = -1; g_cv_ly = -1;
    g_vx = 0; g_vy = 0;
}
static Px g_clip[COSTUME_W * COSTUME_H], g_mv_buf[COSTUME_W * COSTUME_H];
static int g_clip_w = 0, g_clip_h = 0;
static int g_budget;
static int  g_snd    = -1;
static int  g_run_bottom = 0;
static int  g_play   = 0;
static char g_name[TEXT_LEN] = "project";
static char g_status[96] = "Tap a block to add it. Tabs: Scripts / Costumes / Sounds.";

static struct { int depth; int path[MAX_EXPR]; int slot; } g_foc;

static UndoStack g_undo;
static void checkpoint(void) { if (g_sprite != STAGE_IDX) undo_checkpoint(&g_undo, &g_prj, g_sprite); }

static struct { int action; char title[40]; int n; char items[MENU_MAX][TEXT_LEN]; int page; char slot; } g_pk;

static Sprite *cur(void) { return &g_prj.sprites[g_sprite]; }
static Script *cur_script(void) { return &cur()->scripts[g_script]; }

static void set_status(const char *fmt, ...) __attribute__((format(printf, 1, 2)));
#define DEBUG_LOG SAVE_DIR "/debug.log"
static int g_dirty;
static int g_debug = 0;
static unsigned long long g_dbg_t0 = 0;

static void dbg_log(const char *line)
{
    FILE *f = fopen(DEBUG_LOG, "a");
    if (!f) return;
    fprintf(f, "%llu %s\n", osGetTime() - g_dbg_t0, line);
    fclose(f);
}

static void set_status(const char *fmt, ...)
{
    va_list ap;
    va_start(ap, fmt);
    vsnprintf(g_status, sizeof g_status, fmt, ap);
    va_end(ap);
    if (g_debug) dbg_log(g_status);
}

#define VOICES 4
typedef struct { ndspWaveBuf wb; int16_t *buf; } Voice;
static Voice g_voice[VOICES];
static int   g_next_voice = 0;
static int   g_audio_ok   = 0;
static Result g_audio_err = 0;

static void audio_init(void)
{
    g_audio_err = ndspInit();
    if (R_FAILED(g_audio_err)) return;
    ndspSetOutputMode(NDSP_OUTPUT_STEREO);
    for (int i = 0; i < VOICES; i++) {
        g_voice[i].buf = (int16_t *)linearAlloc(SND_BUF_MAX * sizeof(int16_t));
        if (!g_voice[i].buf) { g_audio_err = -1; return; }
        ndspChnReset(i);
        ndspChnSetInterp(i, NDSP_INTERP_LINEAR);
        ndspChnSetRate(i, (float)SND_RATE);
        ndspChnSetFormat(i, NDSP_FORMAT_MONO_PCM16);
        float mix[12] = { 0 };
        mix[0] = 1.0f; mix[1] = 1.0f;
        ndspChnSetMix(i, mix);
        memset(&g_voice[i].wb, 0, sizeof g_voice[i].wb);
    }
    g_audio_ok = 1;
}

static void audio_explain(void)
{
    if (g_audio_err == -1) set_status("%s", "No sound: not enough linear memory for the audio buffers.");
    else set_status("No sound: ndspInit failed (0x%08X). Put dspfirm.cdc in sd:/3ds/ (emulator: sdmc/3ds/).", (unsigned)g_audio_err);
}

static void audio_exit(void)
{
    if (!g_audio_ok) return;
    for (int i = 0; i < VOICES; i++) { ndspChnWaveBufClear(i); linearFree(g_voice[i].buf); }
    ndspExit();
}

static void audio_stop_all(void)
{
    if (!g_audio_ok) return;
    for (int i = 0; i < VOICES; i++) ndspChnWaveBufClear(i);
}

static void audio_play(const Sound *s, int vol_pct)
{
    if (!g_audio_ok) { audio_explain(); return; }
    Sound tmp = *s;
    tmp.vol = tmp.vol * vol_pct / 100;
    int ch = g_next_voice;
    g_next_voice = (g_next_voice + 1) % VOICES;
    Voice *v = &g_voice[ch];
    ndspChnWaveBufClear(ch);
    int n = snd_render(&tmp, v->buf, SND_BUF_MAX);
    ndspChnSetRate(ch, (float)snd_rate(&tmp));
    DSP_FlushDataCache(v->buf, (u32)n * sizeof(int16_t));
    memset(&v->wb, 0, sizeof v->wb);
    v->wb.data_vaddr = v->buf;
    v->wb.nsamples = (u32)n;
    ndspChnWaveBufAdd(ch, &v->wb);
}

static void audio_tone(int freq, int ms, int wave, int vol)
{
    if (!g_audio_ok) return;
    Sound t;
    snd_default(&t);
    t.freq = freq; t.ms = ms; t.wave = wave; t.vol = 100;
    audio_play(&t, vol);
}

#define MIC_BUF_BYTES 0x30000
static u8      *g_micbuf;
static u32      g_micsize;
static int      g_mic_ok;
static int      g_mic_running;
static Recorder g_rec;
static int16_t *g_recbuf;
static int      g_recording;
static int      g_new3ds;
static int      g_monitoring;

static void mic_init(void)
{
    g_recbuf = (int16_t *)malloc(REC_MAX_SAMPLES * sizeof(int16_t));
    g_micbuf = (u8 *)memalign(0x1000, MIC_BUF_BYTES);
    if (!g_recbuf || !g_micbuf) return;
    if (R_FAILED(micInit(g_micbuf, MIC_BUF_BYTES))) return;
    g_micsize = micGetSampleDataSize();
    if (g_micsize < 0x1000) { micExit(); return; }
    g_mic_ok = 1;
}

static void mic_exit(void)
{
    if (g_mic_ok) {
        if (g_mic_running) { MICU_StopSampling(); MICU_SetPower(false); }
        micExit();
    }
    free(g_micbuf);
    free(g_recbuf);
}

static int mic_start(int monitor)
{
    if (!g_mic_ok) return -1;
    if (g_mic_running) { MICU_StopSampling(); g_mic_running = 0; }
    MICU_SetPower(true);
    if (R_FAILED(MICU_StartSampling(MICU_ENCODING_PCM16_SIGNED, MICU_SAMPLE_RATE_10910, 0, g_micsize, true))) return -1;
    g_mic_running = 1;
    rec_begin(&g_rec, g_recbuf, REC_MAX_SAMPLES, monitor);
    g_rec.pos = micGetLastSampleOffset() & ~1u;
    return 0;
}

static void mic_stop(void)
{
    if (g_mic_running) { MICU_StopSampling(); MICU_SetPower(false); }
    g_mic_running = 0;
}

static void mic_poll(void)
{
    if (!g_mic_running) return;
    rec_consume(&g_rec, g_micbuf, g_micsize, micGetLastSampleOffset());
}

static void text(const char *s, float x, float y, float scale, u32 color)
{
    C2D_Text t;
    C2D_TextParse(&t, g_text, s);
    C2D_TextOptimize(&t);
    C2D_DrawText(&t, C2D_WithColor, x, y, Z, scale, scale, color);
}

static int hit(int px, int py, int x, int y, int w, int h)
{
    return px >= x && px < x + w && py >= y && py < y + h;
}

static void rect(float x, float y, float w, float h, u32 hex)
{
    C2D_DrawRectSolid(x, y, Z, w, h, RGB(hex));
}

static void rectc(float x, float y, float w, float h, u32 hex)
{
    C2D_DrawRectSolid(x, y, Z, w, h, CRGB(hex));
}

static void frame(float x, float y, float w, float h, u32 hex)
{
    rect(x - 1, y - 1, w + 2, 1, hex);
    rect(x - 1, y + h, w + 2, 1, hex);
    rect(x - 1, y, 1, h, hex);
    rect(x + w, y, 1, h, hex);
}

static void fit(char *out, const char *s, int maxc)
{
    int n = (int)strlen(s);
    if (n <= maxc) { strcpy(out, s); return; }
    if (maxc < 3) maxc = 3;
    memcpy(out, s, (size_t)maxc - 2);
    out[maxc - 2] = '.'; out[maxc - 1] = '.'; out[maxc] = 0;
}

static void button(float x, float y, float w, float h, const char *label, u32 hex, int on)
{
    rect(x, y, w, h, hex);
    if (on) frame(x, y, w, h, 0xFFFFFF);
    char lab[48];
    fit(lab, label, (int)(w / 5.6f));
    text(lab, x + 3, y + (h > 16 ? 2 : 0), 0.42f, RGB(0xFFFFFF));
}

static int px_cell(const Costume *c, int x0, int y0, int x1, int y1, int stride, int gx, int gy)
{
    int x = x0 + gx * stride + stride / 2, y = y0 + gy * stride + stride / 2;
    if (x >= x1) x = x1 - 1;
    if (y >= y1) y = y1 - 1;
    return c->px[y * COSTUME_W + x];
}

static int px_scan(const Costume *c, float x, float y, float cw, float ch, int x0, int y0, int x1, int y1, int stride, int alpha, int emit)
{
    static uint8_t used[COSTUME_W * COSTUME_H];
    int gw = (x1 - x0 + stride - 1) / stride, gh = (y1 - y0 + stride - 1) / stride, n = 0;
    if (gw <= 0 || gh <= 0) return 0;
    memset(used, 0, (size_t)(gw * gh));
    float pad = alpha >= 255 ? 0.4f : 0.f;
    for (int gy = 0; gy < gh; gy++)
        for (int gx = 0; gx < gw; gx++) {
            if (used[gy * gw + gx]) continue;
            int v = px_cell(c, x0, y0, x1, y1, stride, gx, gy);
            int e = gx + 1;
            while (e < gw && !used[gy * gw + e] && px_cell(c, x0, y0, x1, y1, stride, e, gy) == v) e++;
            int h = 1;
            while (gy + h < gh) {
                int same = 1;
                for (int k = gx; k < e && same; k++) if (used[(gy + h) * gw + k] || px_cell(c, x0, y0, x1, y1, stride, k, gy + h) != v) same = 0;
                if (!same) break;
                h++;
            }
            for (int yy = gy; yy < gy + h; yy++) memset(&used[yy * gw + gx], 1, (size_t)(e - gx));
            if (!(v & 0x8000)) continue;
            n++;
            if (emit) C2D_DrawRectSolid(x + gx * stride * cw, y + gy * stride * ch, Z, (e - gx) * stride * cw + pad, h * stride * ch + pad, CRGBA(px_rgb((Px)v), alpha));
        }
    return n;
}

static void draw_px(const Costume *c, float x, float y, float cw, float ch, int x0, int y0, int x1, int y1, int alpha)
{
    int stride = 1;
    float m = cw < ch ? cw : ch;
    if (m < 0.75f) { stride = (int)ceilf(0.75f / m); if (stride > 6) stride = 6; }
    for (;; stride++) {
        int n = px_scan(c, x, y, cw, ch, x0, y0, x1, y1, stride, alpha, 0);
        if (n <= g_budget || stride >= 6) { g_budget -= n; break; }
    }
    px_scan(c, x, y, cw, ch, x0, y0, x1, y1, stride, alpha, 1);
}

static void fx_hsv(uint32_t rgb, float *h, float *sat, float *v)
{
    float r = ((rgb >> 16) & 255) / 255.f, g = ((rgb >> 8) & 255) / 255.f, b = (rgb & 255) / 255.f;
    float mx = fmaxf(r, fmaxf(g, b)), mn = fminf(r, fminf(g, b)), d = mx - mn;
    *v = mx;
    *sat = mx > 0.f ? d / mx : 0.f;
    float hh = 0.f;
    if (d > 0.f) {
        if (mx == r) hh = fmodf((g - b) / d, 6.f);
        else if (mx == g) hh = (b - r) / d + 2.f;
        else hh = (r - g) / d + 4.f;
        hh /= 6.f;
        if (hh < 0.f) hh += 1.f;
    }
    *h = hh;
}

static uint32_t fx_rgb(float h, float sat, float v)
{
    h = h - floorf(h);
    float c = v * sat, x = c * (1.f - fabsf(fmodf(h * 6.f, 2.f) - 1.f)), m = v - c, r = 0, g = 0, b = 0;
    int k = (int)(h * 6.f);
    switch (k) {
    case 0: r = c; g = x; break;
    case 1: r = x; g = c; break;
    case 2: g = c; b = x; break;
    case 3: g = x; b = c; break;
    case 4: r = x; b = c; break;
    default: r = c; b = x; break;
    }
    int R = (int)((r + m) * 255.f + 0.5f), G = (int)((g + m) * 255.f + 0.5f), B = (int)((b + m) * 255.f + 0.5f);
    return ((uint32_t)R << 16) | ((uint32_t)G << 8) | (uint32_t)B;
}

static int fx_active(const float *fx)
{
    for (int i = 0; i < 6; i++) if (fx[i] != 0.f) return 1;
    return 0;
}

static void fx_bake(const Costume *c, const float *fx, Costume *out)
{
    float color = fx[0], fish = fx[1], whirl = fx[2], pix = fx[3], mos = fx[4], bri = fx[5];
    int blk = 1 + (int)(fabsf(pix) * COSTUME_W / 800.f);
    if (blk > 48) blk = 48;
    int tiles = (int)floorf((fabsf(mos) + 10.f) / 10.f + 0.5f);
    if (tiles < 1) tiles = 1;
    if (tiles > 32) tiles = 32;
    float fisheye = (fish + 100.f) / 100.f;
    if (fisheye < 0.f) fisheye = 0.f;
    float wh = -whirl * 3.14159265f / 180.f;
    strcpy(out->name, c->name);
    for (int y = 0; y < COSTUME_H; y++) {
        for (int x = 0; x < COSTUME_W; x++) {
            float u = ((float)x + 0.5f) / COSTUME_W, v = ((float)y + 0.5f) / COSTUME_H;
            if (tiles > 1) {
                u = u * tiles; u -= floorf(u);
                v = v * tiles; v -= floorf(v);
            }
            if (blk > 1) {
                float bw = (float)blk / COSTUME_W;
                u = (floorf(u / bw) + 0.5f) * bw;
                v = (floorf(v / bw) + 0.5f) * bw;
            }
            if (whirl != 0.f) {
                float ox = u - 0.5f, oy = v - 0.5f, d = sqrtf(ox * ox + oy * oy) / 0.5f;
                float f = 1.f - d;
                if (f < 0.f) f = 0.f;
                float ang = wh * f * f, sn = sinf(ang), cs = cosf(ang);
                u = 0.5f + cs * ox - sn * oy;
                v = 0.5f + sn * ox + cs * oy;
            }
            if (fish != 0.f) {
                float ox = (u - 0.5f) / 0.5f, oy = (v - 0.5f) / 0.5f, len = sqrtf(ox * ox + oy * oy);
                if (len > 0.f) {
                    float r = powf(fminf(len, 1.f), fisheye) * fmaxf(1.f, len);
                    u = 0.5f + (ox / len) * r * 0.5f;
                    v = 0.5f + (oy / len) * r * 0.5f;
                }
            }
            int i = y * COSTUME_W + x;
            out->px[i] = 0;
            if (u < 0.f || v < 0.f || u >= 1.f || v >= 1.f) continue;
            Px px = c->px[(int)(v * COSTUME_H) * COSTUME_W + (int)(u * COSTUME_W)];
            if (!(px & 0x8000)) continue;
            uint32_t col = px_rgb(px);
            if (color != 0.f) {
                float h, sat, val;
                fx_hsv(col, &h, &sat, &val);
                col = fx_rgb(h + color / 200.f, sat, val);
            }
            if (bri != 0.f) {
                int add = (int)(bri * 2.55f);
                int R = (int)((col >> 16) & 255) + add, G = (int)((col >> 8) & 255) + add, B = (int)(col & 255) + add;
                R = R < 0 ? 0 : R > 255 ? 255 : R;
                G = G < 0 ? 0 : G > 255 ? 255 : G;
                B = B < 0 ? 0 : B > 255 ? 255 : B;
                col = ((uint32_t)R << 16) | ((uint32_t)G << 8) | (uint32_t)B;
            }
            out->px[i] = px_make(col);
        }
    }
}

static void draw_costume_fx(const Costume *c, float x, float y, float s, const float *fx)
{
    static Costume tmp;
    float gh = fx ? fx[6] : 0.f;
    if (gh < 0.f) gh = 0.f;
    if (gh > 100.f) gh = 100.f;
    int alpha = (int)(255.f * (100.f - gh) / 100.f);
    if (fx && fx_active(fx)) {
        fx_bake(c, fx, &tmp);
        c = &tmp;
    }
    draw_px(c, x, y, s, s, 0, 0, COSTUME_W, COSTUME_H, alpha);
}

static void draw_costume(const Costume *c, float x, float y, float s) { draw_costume_fx(c, x, y, s, NULL); }

static void format_val(const Val *v, char *out, int n) { val_to_str(v, out, n); }

static void draw_backdrop(const Costume *c, float x, float y, float w, float h)
{
    draw_px(c, x, y, w / COSTUME_W, h / COSTUME_H, 0, 0, COSTUME_W, COSTUME_H, 255);
}

static void draw_stage_view(float ox, float oy, float S)
{
    frame(ox, oy, STAGE_W * S, STAGE_H * S, 0x555555);
    rect(ox, oy, STAGE_W * S, STAGE_H * S, 0xFFFFFF);
    {
        const Sprite *stg = &g_prj.sprites[STAGE_IDX];
        if (stg->ncostumes > 0) draw_backdrop(&stg->costumes[(g_play && g_rt.backdrop >= 0 && g_rt.backdrop < stg->ncostumes) ? g_rt.backdrop : stg->cur_costume], ox, oy, STAGE_W * S, STAGE_H * S);
    }

    for (int i = 0; i < g_rt.pen_count; i++) {
        const PenSeg *g = &g_rt.pen[(g_rt.pen_head + i) % PEN_SEGS];
        float w = g->size * S + 0.5f;
        if (g->x0 == g->x1 && g->y0 == g->y1)
            rectc(ox + (STAGE_W / 2 + g->x0) * S - w / 2, oy + (STAGE_H / 2 - g->y0) * S - w / 2, w, w, g->rgb);
        else
            C2D_DrawLine(ox + (STAGE_W / 2 + g->x0) * S, oy + (STAGE_H / 2 - g->y0) * S, CRGB(g->rgb),
                         ox + (STAGE_W / 2 + g->x1) * S, oy + (STAGE_H / 2 - g->y1) * S, CRGB(g->rgb), w, Z);
    }
    for (int i = 0; i < g_rt.nstamps; i++) {
        const Stamp *st = &g_rt.stamps[i];
        float cs = COSTUME_SB_SCALE * S * st->size / 100.f, half = COSTUME_W * cs / 2;
        draw_costume_fx(&g_prj.sprites[st->sprite].costumes[st->costume],
                       ox + (STAGE_W / 2 + st->x) * S - half, oy + (STAGE_H / 2 - st->y) * S - half, cs, st->effect);
    }
    for (int k = 0; k < g_rt.norder; k++) {
        int i = g_rt.order[k];
        const SpriteRT *r = &g_rt.spr[i];
        const Sprite *sp = &g_prj.sprites[r->def];
        if (!r->visible) continue;
        float cs = COSTUME_SB_SCALE * S * r->size / 100.f;
        float cx = ox + (STAGE_W / 2 + r->x) * S;
        float cy = oy + (STAGE_H / 2 - r->y) * S;
        float half = COSTUME_W * cs / 2;
        if (i == g_sprite && !r->is_clone && !g_play) frame(cx - half, cy - half, 2 * half, 2 * half, 0x3B7DD8);
        draw_costume_fx(&sp->costumes[r->costume], cx - half, cy - half, cs, r->effect);
        if (i == g_sprite && !r->is_clone && !g_play) {
            float rad = r->dir * 3.14159265f / 180.f;
            C2D_DrawLine(cx, cy, CRGB(0x1A1A1A), cx + 14 * sinf(rad), cy - 14 * cosf(rad), CRGB(0x1A1A1A), 2, Z);
        }
    }
    for (int i = 0; i < RT_SLOTS; i++) {
        const SpriteRT *r = &g_rt.spr[i];
        if (!r->alive || !r->visible || !r->say[0]) continue;
        float cx = ox + (STAGE_W / 2 + r->x) * S, cy = oy + (STAGE_H / 2 - r->y) * S;
        float w = 6.0f * (float)strlen(r->say) + 8;
        rect(cx - 5, cy - 40, w + 2, 18, r->thinking ? 0x8888AA : 0x333333);
        rect(cx - 4, cy - 39, w, 16, 0xFFFFFF);
        text(r->say, cx, cy - 38, 0.45f, RGB(0x000000));
    }
    int row = 0;
    for (int v = 0; v < g_prj.nvars; v++) {
        if (!g_rt.var_shown[v]) continue;
        char val[TEXT_LEN], line[2 * TEXT_LEN + 4];
        format_val(&g_rt.var[v], val, sizeof val);
        snprintf(line, sizeof line, "%s: %s", g_prj.vars[v].name, val);
        rect(ox + 4, oy + 4 + row * 14, 6.0f * (float)strlen(line) + 6, 13, 0xEE7D16);
        text(line, ox + 7, oy + 4 + row * 14, 0.4f, RGB(0xFFFFFF));
        row++;
    }
}

static void draw_top_stage(void)
{
    draw_stage_view(STAGE_OX, STAGE_OY, STAGE_S);

    text(g_new3ds ? APP_NAME " v" APP_VERSION "  (New 3DS speed-up on)" : APP_NAME " v" APP_VERSION, 8, 0, 0.4f, RGB(0xCCCCCC));
    char info[96];
    const SpriteRT *r = &g_rt.spr[g_sprite];
    if (g_play) snprintf(info, sizeof info, "%s  x:%d y:%d dir:%d  mouse:%d,%d", cur()->name, (int)r->x, (int)r->y, (int)r->dir,
                         (int)g_rt.mouse_x, (int)g_rt.mouse_y);
    else snprintf(info, sizeof info, "%s  x:%d y:%d dir:%d", cur()->name, (int)r->x, (int)r->y, (int)r->dir);
    text(info, 8, 226, 0.4f, RGB(0xCCCCCC));
    if (g_play && g_monitoring) {
        char lv[24];
        snprintf(lv, sizeof lv, "mic %d", (int)g_rt.loudness);
        text(lv, 350, 226, 0.4f, RGB(0xCCCCCC));
    }
}

static void draw_top_costume(void)
{
    const Sprite *sp = cur();
    const float s = 2.25f, x = 92, y = 6;
    for (int r = 0; r < 9; r++)
        for (int c = 0; c < 9; c++) rect(x + c * 24, y + r * 24, 24, 24, ((r + c) & 1) ? 0x3A3A44 : 0x2E2E36);
    draw_costume(&sp->costumes[sp->cur_costume], x, y, s);
    char info[96];
    snprintf(info, sizeof info, "%s: costume %d/%d  \"%s\"", sp->name, sp->cur_costume + 1, sp->ncostumes,
             sp->costumes[sp->cur_costume].name);
    text(info, 8, 226, 0.42f, RGB(0xCCCCCC));
}

static void draw_top_sound(void)
{
    rect(20, 30, 360, 160, 0x2A2A32);
    rect(20, 109, 360, 1, 0x55555F);
    if (g_recording) {
        float lv = g_rec.level;
        rect(20, 30, 360 * lv / 100.f, 160, 0x7A2A2A);
        char info[96];
        snprintf(info, sizeof info, "Recording...  %.1f s / %d s   level %d", (float)g_rec.n / REC_RATE, REC_MAX_SECS, (int)lv);
        text(info, 24, 34, 0.5f, RGB(0xFFFFFF));
        text("Tap Stop to finish.", 24, 52, 0.42f, RGB(0xDDDDDD));
        return;
    }
    if (g_snd >= 0 && g_snd < cur()->nsounds) {
        const Sound *s = &cur()->sounds[g_snd];
        if (snd_is_recorded(s)) {
            for (int col = 0; col < 358; col++) {
                int i0 = (int)((int64_t)col * s->npcm / 358), i1 = (int)((int64_t)(col + 1) * s->npcm / 358);
                if (i1 <= i0) i1 = i0 + 1;
                int lo = 0, hi = 0;
                for (int i = i0; i < i1 && i < s->npcm; i++) { if (s->pcm[i] < lo) lo = s->pcm[i]; if (s->pcm[i] > hi) hi = s->pcm[i]; }
                float y0 = 109 - hi * 75.0f / 32768.0f, y1 = 109 - lo * 75.0f / 32768.0f;
                rect(21 + col, y0, 1, y1 - y0 + 1, 0xE0804A);
            }
        } else {
            static int16_t pcm[1000];
            Sound tmp = *s;
            if (tmp.ms > 90) tmp.ms = 90;
            int n = snd_render(&tmp, pcm, 1000);
            for (int col = 0; col < 359 && n > 1; col++) {
                int i0 = col * (n - 1) / 359, i1 = (col + 1) * (n - 1) / 359;
                float y0 = 109 - pcm[i0] * 75.0f / 32768.0f, y1 = 109 - pcm[i1] * 75.0f / 32768.0f;
                C2D_DrawLine(20 + col, y0, RGB(0x4AD0E0), 21 + col, y1, RGB(0x4AD0E0), 1.5f, Z);
            }
        }
        char info[96];
        if (snd_is_recorded(s))
            snprintf(info, sizeof info, "\"%s\"  recording  %.2f s  %d Hz  vol %d%%", s->name, snd_duration_ms(s) / 1000.f, s->rate, s->vol);
        else
            snprintf(info, sizeof info, "\"%s\"  %s  %d Hz  %d ms  vol %d%%", s->name, snd_wave_name(s->wave), s->freq, s->ms, s->vol);
        text(info, 8, 226, 0.42f, RGB(0xCCCCCC));
    } else {
        text("No sound selected. Tap New or Rec.", 90, 100, 0.5f, RGB(0xAAAAAA));
    }
}

static int palette_entries(int cat, PalEntry *out)
{
    int n = 0;
    if (cat == CAT_VARIABLES) {
        out[n++] = (PalEntry){ PE_NEW_VAR, 0 };
        out[n++] = (PalEntry){ PE_DEL_VAR, 0 };
        for (int v = 0; v < g_prj.nvars; v++) out[n++] = (PalEntry){ BK_VAR, v };
    } else if (cat == CAT_LISTS) {
        out[n++] = (PalEntry){ PE_NEW_LIST, 0 };
        out[n++] = (PalEntry){ PE_DEL_LIST, 0 };
    }
    if (cat == CAT_MORE) {
        out[n++] = (PalEntry){ PE_MAKE_BLOCK, 0 };
        if (g_sprite != STAGE_IDX) {
            const Sprite *sp = &g_prj.sprites[g_sprite];
            const Block *h = &sp->scripts[g_script < sp->nscripts ? g_script : 0].blocks[0];
            if (h->kind == BK_HAT_DEFINE)
                for (int k = 0; k < h->np && k < MAX_ARGS; k++) out[n++] = (PalEntry){ h->pt[k] == 'b' ? BK_PARAMB : BK_PARAM, k };
            for (int i = 0; i < sp->nscripts; i++)
                if (sp->scripts[i].nblocks > 0 && sp->scripts[i].blocks[0].kind == BK_HAT_DEFINE) out[n++] = (PalEntry){ BK_CALL, i };
        }
        return n;
    }
    for (int k = 0; k < BK_COUNT; k++)
        if (BLOCK_INFO[k].category == cat && k != BK_VAR) out[n++] = (PalEntry){ k, 0 };
    return n;
}

static void palette_label(const PalEntry *e, char *out, int n)
{
    switch (e->kind) {
    case PE_NEW_VAR:  snprintf(out, (size_t)n, "%s", "+ New variable"); return;
    case PE_DEL_VAR:  snprintf(out, (size_t)n, "%s", "- Delete variable"); return;
    case PE_NEW_LIST: snprintf(out, (size_t)n, "%s", "+ New list"); return;
    case PE_DEL_LIST: snprintf(out, (size_t)n, "%s", "- Delete list"); return;
    case PE_MAKE_BLOCK: snprintf(out, (size_t)n, "%s", "+ Make a Block"); return;
    default: break;
    }
    char body[64];
    if (e->kind == BK_VAR) snprintf(body, sizeof body, "%s", g_prj.vars[e->param].name);
    else if (e->kind == BK_PARAM || e->kind == BK_PARAMB) snprintf(body, sizeof body, "%s", cur()->scripts[g_script].blocks[0].a[e->param].text);
    else if (e->kind == BK_CALL) {
        const Block *h = &cur()->scripts[e->param].blocks[0];
        Block c = block_default(BK_CALL);
        project_copy_text(c.label, h->label);
        c.np = h->np;
        for (int k = 0; k < h->np && k < MAX_ARGS; k++) c.pt[k] = h->pt[k];
        prj_format_block(NULL, &c, body, sizeof body);
    }
    else { Block d = block_default(e->kind); prj_format_block(NULL, &d, body, sizeof body); }
    int sh = BLOCK_INFO[e->kind].shape;
    snprintf(out, (size_t)n, sh == SH_REP ? "(%s)" : (sh == SH_BOOL ? "<%s>" : "%s"), body);
}

static char g_search[24];

static int ci_contains(const char *h, const char *nd)
{
    size_t nl = strlen(nd);
    for (; *h; h++) {
        size_t i = 0;
        while (i < nl && h[i] && tolower((unsigned char)h[i]) == tolower((unsigned char)nd[i])) i++;
        if (i == nl) return 1;
    }
    return 0;
}

static int palette_list(PalEntry *out)
{
    if (!g_search[0]) return palette_entries(g_cat, out);
    PalEntry tmp[PAL_MAX];
    int n = 0;
    for (int c = 0; c < CAT_COUNT; c++) {
        int m = palette_entries(c, tmp);
        for (int i = 0; i < m && n < PAL_MAX; i++) {
            char lab[64];
            palette_label(&tmp[i], lab, sizeof lab);
            if (ci_contains(lab, g_search)) out[n++] = tmp[i];
        }
    }
    return n;
}

static u32 palette_color(const PalEntry *e)
{
    return e->kind == PE_MAKE_BLOCK ? COL_MORE : (e->kind < 0 ? 0x666670 : category_color(BLOCK_INFO[e->kind].category));
}

static void focus_reset(void)
{
    g_foc.depth = 0;
    g_foc.slot = 0;
}

static Block *focus_node(void)
{
    Script *s = cur_script();
    if (g_sel < 0 || g_sel >= s->nblocks) return NULL;
    return prj_node(s, g_sel, g_foc.path, g_foc.depth);
}

static char focus_slot_char(const Block *node, int slot)
{
    return block_slot(node, slot);
}

static void select_block(int b)
{
    Script *s = cur_script();
    if (b < 0) b = 0;
    if (b >= s->nblocks) b = s->nblocks - 1;
    if (b != g_sel) focus_reset();
    g_sel = b;
    if (g_sel < g_scroll) g_scroll = g_sel;
    if (g_sel >= g_scroll + SCR_ROWS) g_scroll = g_sel - SCR_ROWS + 1;
}

static void script_page(int dir)
{
    int max = cur_script()->nblocks - SCR_ROWS;
    if (max < 0) max = 0;
    g_scroll += dir * (SCR_ROWS - 1);
    if (g_scroll < 0) g_scroll = 0;
    if (g_scroll > max) g_scroll = max;
}

static void script_jump(int end)
{
    select_block(end ? cur_script()->nblocks - 1 : 0);
    if (!end) g_scroll = 0;
}

static void draw_picker(void)
{
    rect(0, 34, 320, 172, 0x24242C);
    text(g_pk.title, 4, 36, 0.45f, RGB(0xFFFFFF));
    int first = g_pk.page * PK_PER_PAGE;
    for (int i = 0; i < PK_PER_PAGE && first + i < g_pk.n; i++) {
        int col = i / PK_ROWS, row = i % PK_ROWS;
        button(2 + col * PK_COLSTEP, PK_Y + row * PK_ROW, PK_COLW, PK_ROW - 2, g_pk.items[first + i], 0x4A4A58, 0);
    }
    button(2, PK_NAV_Y, 100, 18, "< Prev", 0x66666F, 0);
    button(110, PK_NAV_Y, 100, 18, "Cancel", 0xC0392B, 0);
    button(218, PK_NAV_Y, 100, 18, "Next >", 0x66666F, 0);
}

#define NOTCH_X 7
static void draw_block_row(float x, float y, float w, float h, u32 color, const char *label, int selected,
                           u32 bg, int style, float nx)
{
    if (selected) frame(x, y, w, h - 1, 0xFFFFFF);
    rect(x, y, w, h - 1, color);
    if (style == 2) {
        rect(x, y, 2, 1, bg); rect(x + w - 2, y, 2, 1, bg);
        rect(x, y + h - 2, 2, 1, bg); rect(x + w - 2, y + h - 2, 2, 1, bg);
        rect(x, y, 1, 2, bg); rect(x + w - 1, y, 1, 2, bg);
        rect(x, y + h - 3, 1, 2, bg); rect(x + w - 1, y + h - 3, 1, 2, bg);
    } else {
        if (style == 1) {
            rect(x, y, 4, 1, bg); rect(x, y + 1, 2, 1, bg); rect(x + w - 2, y, 2, 1, bg);
        } else {
            rect(x, y, 1, 1, bg); rect(x + w - 1, y, 1, 1, bg);
            rect(x + NOTCH_X, y, 16, 1, bg); rect(x + NOTCH_X + 2, y + 1, 12, 1, bg);
        }
        rect(x, y + h - 2, 1, 1, bg); rect(x + w - 1, y + h - 2, 1, 1, bg);
        if (nx >= 0) {
            rect(nx + NOTCH_X, y + h - 1, 16, 2, color);
            rect(nx + NOTCH_X + 2, y + h + 1, 12, 1, color);
        }
    }
    char lab[64];
    fit(lab, label, (int)((w - 4) / 5.2f));
    text(lab, x + 3, y + 1, 0.42f, RGB(0xFFFFFF));
}

typedef struct {
    int  src;
    int  active;
    int  sx, sy, x, y;
    PalEntry pe;
    int  block;
    char label[64];
    u32  color;
} Drag;
static Drag g_drag;
#define DRAG_THRESHOLD 6

static int script_gap(int y)
{
    int k = y - SCR_Y + SCR_ROW / 2;
    k = k < 0 ? 0 : k / SCR_ROW;
    return k > SCR_ROWS ? SCR_ROWS : k;
}
static int gap_after(int k)
{
    int a = g_scroll + k - 1, n = g_prj.sprites[g_sprite].scripts[g_script].nblocks;
    if (a > n - 1) a = n - 1;
    return a < 0 ? 0 : a;
}

static void draw_drag(void)
{
    if (!g_drag.active) return;
    int in_script = g_drag.x >= SCR_X - 4 && g_drag.y >= SCR_Y - 4 && g_drag.y < SCR_Y + SCR_ROWS * SCR_ROW + 4;
    int reporter = g_drag.src == 1 && g_drag.pe.kind >= 0 && block_is_reporter(g_drag.pe.kind);
    int hat = g_drag.src == 1 && g_drag.pe.kind >= 0 && block_is_hat(g_drag.pe.kind);
    if (g_drag.src == 2 && g_drag.x >= PAL_X && g_drag.x < PAL_X + PAL_W && g_drag.y >= PAL_Y && g_drag.y < PAL_Y + PAL_ROWS * PAL_ROW)
        frame(PAL_X, PAL_Y, PAL_W, PAL_ROWS * PAL_ROW, 0xFF4040);
    else if (reporter) {
        if (in_script) {
            int r = (g_drag.y - SCR_Y) / SCR_ROW;
            if (r >= 0 && r < SCR_ROWS) frame(SCR_X - 2, SCR_Y + r * SCR_ROW - 1, 320 - SCR_X + 2, SCR_ROW + 1, 0xFFFFFF);
        }
        for (int i = 0; i < MAX_ARGS; i++)
            if (g_drag.x >= ARG_X + i * ARG_STEP && g_drag.x < ARG_X + i * ARG_STEP + ARG_W && g_drag.y >= ARG_Y && g_drag.y < ARG_Y + ARG_H)
                frame(ARG_X + i * ARG_STEP, ARG_Y, ARG_W, ARG_H, 0xFFFFFF);
    } else if (in_script && !hat) {
        int shown = gap_after(script_gap(g_drag.y)) + 1 - g_scroll;
        if (shown < 0) shown = 0;
        if (shown > SCR_ROWS) shown = SCR_ROWS;
        rect(SCR_X - 2, SCR_Y + shown * SCR_ROW - 1, 320 - SCR_X + 2, 3, 0xFFFFFF);
    }
    float w = 6.0f * (float)strlen(g_drag.label) + 10;
    if (w > 150) w = 150;
    rect(g_drag.x - 12, g_drag.y - 20, w, SCR_ROW - 2, g_drag.color);
    frame(g_drag.x - 12, g_drag.y - 20, w, SCR_ROW - 2, 0xFFFFFF);
    text(g_drag.label, g_drag.x - 8, g_drag.y - 18, 0.4f, RGB(0xFFFFFF));
}

static void draw_bottom_scripts(void)
{
    static const char *cat_names[CAT_COUNT] = { "Mot", "Look", "Snd", "Pen", "Ctl", "Sens", "Ops", "Var", "List", "More" };
    for (int c = 0; c < CAT_COUNT; c++) button(2 + c * CAT_STEP, CAT_Y, CAT_W, CAT_H, cat_names[c], category_color(c), c == g_cat);

    PalEntry pe[PAL_MAX];
    int n = palette_list(pe);
    int pn = n - g_pal_scroll < PAL_ROWS ? n - g_pal_scroll : PAL_ROWS;
    for (int i = pn - 1; i >= 0; i--) {
        char lab[64];
        const PalEntry *e = &pe[g_pal_scroll + i];
        palette_label(e, lab, sizeof lab);
        int st = e->kind >= 0 && block_is_reporter(e->kind) ? 2 : (e->kind >= 0 && block_is_hat(e->kind) ? 1 : 0);
        draw_block_row(PAL_X, PAL_Y + i * PAL_ROW, PAL_W, PAL_ROW, palette_color(e), lab, 0, 0x2B2B33, st, i + 1 < pn ? PAL_X : -1);
    }
    button(PAL_X, PALBTN_Y, 36, PALBTN_H, "^", 0x66666F, 0);
    button(PAL_X + 38, PALBTN_Y, 44, PALBTN_H, g_search[0] ? g_search : "Find", 0x3A6EA5, g_search[0] != 0);
    button(PAL_X + 84, PALBTN_Y, 36, PALBTN_H, "v", 0x66666F, 0);

    const Sprite *sp = cur();
    const Script *s = &sp->scripts[g_script];
    char head[32];
    snprintf(head, sizeof head, "S%d/%d", g_script + 1, sp->nscripts);
    button(PAL_X, SCRNAV_Y, 17, SCRNAV_H, "<", 0x66666F, 0);
    button(PAL_X + 19, SCRNAV_Y, 17, SCRNAV_H, ">", 0x66666F, 0);
    button(PAL_X + 38, SCRNAV_Y, 30, SCRNAV_H, head, 0x4A4A58, 0);
    button(PAL_X + 70, SCRNAV_Y, 24, SCRNAV_H, "Top", 0x3A6EA5, 0);
    button(PAL_X + 96, SCRNAV_Y, 24, SCRNAV_H, "End", 0x3A6EA5, 0);

    rect(SCR_X - 2, SCR_Y - 1, 320 - SCR_X + 2, SCR_ROWS * SCR_ROW + 2, 0x3A3A46);
    int srows = s->nblocks - g_scroll < SCR_ROWS ? s->nblocks - g_scroll : SCR_ROWS;
    for (int row = srows - 1; row >= 0; row--) {
        int b = g_scroll + row;
        char lab[96];
        prj_format_block(s, &s->blocks[b], lab, sizeof lab);
        float x = SCR_X + prj_indent(s, b) * 8;
        int sh = BLOCK_INFO[s->blocks[b].kind].shape;
        u32 col = (sh == SH_END || sh == SH_ELSE) ? COL_CONTROL : category_color(BLOCK_INFO[s->blocks[b].kind].category);
        float nx = row + 1 < srows ? SCR_X + prj_indent(s, b + 1) * 8 : -1;
        draw_block_row(x, SCR_Y + row * SCR_ROW, SCRBTN_X - 3 - x, SCR_ROW, col, lab, b == g_sel, 0x3A3A46, sh == SH_HAT ? 1 : 0, nx);
    }

    button(SCRBTN_X, SCR_Y, SCRBTN_W, SCRBTN_H, "^", 0x66666F, 0);
    button(SCRBTN_X, SCR_Y + SCRBTN_H + SCRBTN_GAP, SCRBTN_W, SCRBTN_H, "v", 0x66666F, 0);

    Block *node = (g_sel < s->nblocks) ? prj_node((Script *)s, g_sel, g_foc.path, g_foc.depth) : NULL;
    button(SCR_X, ARG_Y, ARG_UP_W, ARG_H, "^", g_foc.depth > 0 ? 0x2E9E4F : 0x555560, 0);
    int ns = node ? block_nslots_b(node) : 0;
    for (int i = 0; i < MAX_ARGS; i++) {
        float x = ARG_X + i * ARG_STEP;
        if (i >= ns) { rect(x, ARG_Y, ARG_W, ARG_H, 0x33333B); continue; }
        char lab[64];
        prj_format_arg(s, &node->a[i], focus_slot_char(node, i), lab, sizeof lab);
        button(x, ARG_Y, ARG_W, ARG_H, lab, 0x4A4A58, i == g_foc.slot);
    }
    draw_drag();
}

static int cv_win(void) { return g_zoom == 1 ? COSTUME_W : CV_WIN; }

static void cv_clamp_view(void)
{
    int mx = COSTUME_W - cv_win();
    if (g_vx < 0) g_vx = 0;
    if (g_vy < 0) g_vy = 0;
    if (g_vx > mx) g_vx = mx;
    if (g_vy > mx) g_vy = mx;
}

static void draw_bottom_costumes(void)
{
    const Sprite *sp = cur();
    const Costume *c = &sp->costumes[sp->cur_costume];
    int win = cv_win(), cell = g_zoom, sz = win * cell;
    cv_clamp_view();
    frame(CV_X, CV_Y, sz, sz, 0x888888);
    for (int r = 0; r * 16 < sz; r++)
        for (int q = 0; q * 16 < sz; q++) {
            int w = sz - q * 16 < 16 ? sz - q * 16 : 16, h = sz - r * 16 < 16 ? sz - r * 16 : 16;
            rect(CV_X + q * 16, CV_Y + r * 16, w, h, ((r + q) & 1) ? 0x3C3C46 : 0x33333C);
        }
    draw_px(c, CV_X, CV_Y, (float)cell, (float)cell, g_vx, g_vy, g_vx + win, g_vy + win, 255);
    if (g_selon) {
        int x0 = g_sx0 < g_sx1 ? g_sx0 : g_sx1, x1 = g_sx0 < g_sx1 ? g_sx1 : g_sx0;
        int y0 = g_sy0 < g_sy1 ? g_sy0 : g_sy1, y1 = g_sy0 < g_sy1 ? g_sy1 : g_sy0;
        int a0 = x0 < g_vx ? g_vx : x0, a1 = x1 >= g_vx + win ? g_vx + win - 1 : x1;
        int b0 = y0 < g_vy ? g_vy : y0, b1 = y1 >= g_vy + win ? g_vy + win - 1 : y1;
        if (a0 <= a1 && b0 <= b1) frame(CV_X + (a0 - g_vx) * cell, CV_Y + (b0 - g_vy) * cell, (a1 - a0 + 1) * cell, (b1 - b0 + 1) * cell, 0xFFFFFF);
    }

    for (int i = 0; i < PAL_N; i++) {
        float x = PNL_X + (i % 8) * 18, y = 36 + (i / 8) * 18;
        if (px_pal(i) == g_col) frame(x, y, 17, 17, 0xFFFFFF);
        if (i == 0) { rect(x + 1, y + 1, 15, 15, 0x55555F); text("x", x + 5, y, 0.5f, RGB(0xFFFFFF)); }
        else rectc(x + 1, y + 1, 15, 15, PALETTE_RGB[i]);
    }
    if (g_col & 0x8000u) rectc(PNL_X, 74, 18, 18, px_rgb(g_col)); else rect(PNL_X, 74, 18, 18, 0x55555F);
    frame(PNL_X, 74, 18, 18, 0xFFFFFF);
    char lab[24];
    button(PNL_X + 20, 74, 40, 18, "RGB...", 0x66666F, 0);
    snprintf(lab, sizeof lab, "Size %d", BRUSHES[g_brush]);
    button(PNL_X + 62, 74, 40, 18, lab, 0x66666F, 0);
    snprintf(lab, sizeof lab, "Zoom %dx", g_zoom);
    button(PNL_X + 104, 74, 44, 18, lab, 0x66666F, 0);
    static const char *tools[T_COUNT] = { "Pen", "Fill", "Line", "Rect", "Oval", "Pick", "Sel" };
    for (int i = 0; i < T_COUNT; i++)
        button(PNL_X + (i % 4) * 37, 94 + (i / 4) * 20, 36, 18, tools[i], 0x3B7DD8, g_tool == i);
    button(PNL_X + 3 * 37, 114, 36, 18, g_solid ? "Solid" : "Line", 0x4C8F8F, g_solid);
    static const char *sel[4] = { "Copy", "Cut", "Paste", "Del" };
    for (int i = 0; i < 4; i++) button(PNL_X + i * 37, 134, 36, 18, sel[i], 0x7A5CA8, 0);
    static const char *ops[4] = { "Flip", "Clear", "New", "Name" };
    for (int i = 0; i < 4; i++) button(PNL_X + i * 37, 154, 36, 18, ops[i], 0x66666F, 0);
    button(PNL_X, 174, 36, 18, "Prev", 0x66666F, 0);
    button(PNL_X + 37, 174, 36, 18, "Next", 0x66666F, 0);
    char info[64];
    snprintf(info, sizeof info, "%d/%d", sp->cur_costume + 1, sp->ncostumes);
    text(info, PNL_X + 78, 176, 0.42f, RGB(0xFFFFFF));
    text(c->name, PNL_X + 78, 188, 0.38f, RGB(0xCCCCCC));
    static const char *pan[4] = { "<", ">", "^", "v" };
    for (int i = 0; i < 4; i++) button(PNL_X + i * 30, 194, 28, 12, pan[i], g_zoom == 2 ? 0x66666F : 0x44444C, 0);
}

static void draw_bottom_sounds(void)
{
    const Sprite *sp = cur();
    for (int i = 0; i < sp->nsounds; i++) {
        char lab[64];
        snprintf(lab, sizeof lab, "%s (%s)", sp->sounds[i].name, snd_is_recorded(&sp->sounds[i]) ? "mic" : snd_wave_name(sp->sounds[i].wave));
        button(2, SN_LIST_Y + i * SN_ROW, 148, 18, lab, COL_SOUND, i == g_snd);
    }
    button(2, SN_BTN_Y, 46, 18, "New", 0x3B7DD8, 0);
    button(52, SN_BTN_Y, 46, 18, "Play", 0x2E9E4F, 0);
    button(102, SN_BTN_Y, 46, 18, "Name", 0x66666F, 0);
    button(2, SN_REC_Y, 146, 22, g_recording ? "Stop recording" : "Rec (microphone)", g_recording ? 0xC0392B : 0xA03030, g_recording);
    button(156, SN_REC_Y, 160, 22, "Sound effects...", 0x4C8F8F, 0);
    if (!g_mic_ok) text("No microphone available.", 4, 198, 0.38f, RGB(0xAAAAAA));

    if (g_snd >= 0 && g_snd < sp->nsounds && !g_recording) {
        const Sound *s = &sp->sounds[g_snd];
        if (snd_is_recorded(s)) {
            static const char *edit[3] = { "Trim silence", "Normalize", "Reverse" };
            for (int k = 0; k < 3; k++) button(156, 36 + k * 28, 160, 24, edit[k], 0x66666F, 0);
            char v[40];
            snprintf(v, 40, "Vol: %d%%", s->vol);
            rect(156, 36 + 3 * 28, 102, 24, 0x3A3A46);
            text(v, 160, 36 + 3 * 28 + 5, 0.45f, RGB(0xFFFFFF));
            button(262, 36 + 3 * 28, 26, 24, "-", 0x66666F, 0);
            button(290, 36 + 3 * 28, 26, 24, "+", 0x66666F, 0);
        } else {
            char v[4][40];
            snprintf(v[0], 40, "Wave: %s", snd_wave_name(s->wave));
            snprintf(v[1], 40, "Freq: %d Hz", s->freq);
            snprintf(v[2], 40, "Time: %d ms", s->ms);
            snprintf(v[3], 40, "Vol: %d%%", s->vol);
            for (int k = 0; k < 4; k++) {
                float y = 36 + k * 28;
                rect(156, y, 102, 24, 0x3A3A46);
                text(v[k], 160, y + 5, 0.45f, RGB(0xFFFFFF));
                button(262, y, 26, 24, "-", 0x66666F, 0);
                button(290, y, 26, 24, "+", 0x66666F, 0);
            }
            text("Tap a value to type it.", 156, 152, 0.38f, RGB(0xAAAAAA));
        }
    }
}

static void draw_bottom_stage(void)
{
    draw_stage_view(0, 0, PAD_S);
    if (g_rt.mouse_down) rect(g_rt.mouse_x * PAD_S + 160 - 3, 120 - g_rt.mouse_y * PAD_S - 3, 6, 6, 0x000000);
    text("B = stop", 270, 228, 0.4f, RGB(0x666666));
}

static void draw_top_run_info(void)
{
    text("Project running on the bottom screen", 8, 4, 0.5f, RGB(0xFFFFFF));
    text("Touch = mouse   D-pad/A/X/Y/L/R = keys   B = stop", 8, 20, 0.36f, RGB(0xBBBBBB));
    int y = 40;
    for (int i = 0; i < g_prj.nsprites && y < 150; i++) {
        const SpriteRT *r = &g_rt.spr[i];
        char line[96];
        snprintf(line, sizeof line, "%s  x:%d y:%d dir:%d%s", g_prj.sprites[i].name, (int)r->x, (int)r->y, (int)r->dir, r->visible ? "" : " (hidden)");
        text(line, 8, y, 0.4f, RGB(0xDDDDDD));
        y += 13;
    }
    y += 6;
    for (int v = 0; v < g_prj.nvars && y < 210; v++) {
        char val[TEXT_LEN], line[2 * TEXT_LEN + 4];
        format_val(&g_rt.var[v], val, sizeof val);
        snprintf(line, sizeof line, "%s = %s", g_prj.vars[v].name, val);
        text(line, 8, y, 0.4f, RGB(0xEE9D46));
        y += 13;
    }
    char info[64];
    snprintf(info, sizeof info, "timer %.1f  answer: %.14s%s%s", g_rt.timer, g_rt.answer, g_monitoring ? "  mic on" : "", "");
    text(info, 8, 226, 0.4f, RGB(0xCCCCCC));
}

static void draw_top_about(void)
{
    rect(0, 0, 400, 240, 0x20242C);
    text(APP_NAME, 100, 70, 0.9f, RGB(0xFFAB19));
    text("version " APP_VERSION, 150, 110, 0.5f, RGB(0xFFFFFF));
    text("unofficial block editor, by probeta", 100, 136, 0.45f, RGB(0xCCCCCC));
    text("Scratch is a project of the MIT Media Lab.", 90, 156, 0.4f, RGB(0x999999));
    text("Not affiliated with or endorsed by MIT or Scratch.", 78, 170, 0.4f, RGB(0x999999));
}

static void draw_bottom_about(void)
{
    for (int r = 0; r < ABOUT_ROWS; r++) {
        int i = g_about_scroll + r;
        if (i >= ABOUT_N) break;
        const char *l = ABOUT_LINES[i];
        float y = 20 + r * ABOUT_ROW_H;
        if (l[0] == '#') text(l + 1, 6, y, 0.46f, RGB(0xFFAB19));
        else if (l[0] == '*') text(l + 1, 6, y, 0.44f, RGB(0x4C97FF));
        else text(l, 6, y, 0.38f, RGB(0xDDDDDD));
    }
    button(294, 20, 24, 40, "^", 0x66666F, 0);
    button(294, 162, 24, 40, "v", 0x66666F, 0);
}

static void draw_top(void)
{
    g_budget = 6500;
    if (g_play) { if (g_run_bottom) draw_top_run_info(); else draw_top_stage(); return; }
    switch (g_mode) {
    case MODE_SCRIPTS:  draw_top_stage();   break;
    case MODE_COSTUMES: draw_top_costume(); break;
    case MODE_ABOUT:    draw_top_about();   break;
    default:            draw_top_sound();   break;
    }
}

static void draw_debug(int frame_no, int used)
{
    static unsigned long long last = 0;
    static float fps = 0.f, ms = 0.f;
    unsigned long long now = osGetTime();
    if (last) {
        float d = (float)(now - last);
        if (d < 1.f) d = 1.f;
        ms = ms * 0.9f + d * 0.1f;
        fps = 1000.f / ms;
    }
    last = now;
    int alive = 0, clones = 0, scripts = 0;
    for (int i = 0; i < RT_SLOTS; i++) {
        const SpriteRT *r = &g_rt.spr[i];
        if (!r->alive) continue;
        alive++;
        if (r->is_clone) clones++;
        for (int k = 0; k < MAX_SCRIPTS; k++) if (r->run[k].active) scripts++;
    }
    char l[6][80];
    snprintf(l[0], sizeof l[0], "DEBUG %s  %.1f fps  %.1f ms  frame %d", APP_VERSION, fps, ms, frame_no);
    snprintf(l[1], sizeof l[1], "mode %d  sprite %d  play %d  dirty %d", g_mode, g_sprite, g_play, g_dirty);
    snprintf(l[2], sizeof l[2], "sprites %d (clones %d)  scripts running %d  stamps %d  pen %d", alive, clones, scripts, g_rt.nstamps, g_rt.pen_count);
    snprintf(l[3], sizeof l[3], "draw rects %d / 6500  new3ds %d", used, g_new3ds);
    snprintf(l[4], sizeof l[4], "linear free %u KB", (unsigned)(linearSpaceFree() / 1024));
    snprintf(l[5], sizeof l[5], "status: %.60s", g_status);
    rect(0, 0, 400, 6 * 12 + 4, 0x000000);
    for (int i = 0; i < 6; i++) text(l[i], 3, 2 + i * 12, 0.4f, RGB(0x66FF99));
    static int last_log = -1000;
    if (frame_no - last_log >= 120) {
        last_log = frame_no;
        char line[300];
        snprintf(line, sizeof line, "fps %.1f ms %.1f rects %d sprites %d clones %d scripts %d linear %uKB | %s",
                 fps, ms, used, alive, clones, scripts, (unsigned)(linearSpaceFree() / 1024), g_status);
        dbg_log(line);
    }
}

static void draw_bottom_pad(void)
{
    rect(0, 0, 320, 240, 0x20242C);
    for (int k = 0; k < g_rt.norder; k++) {
        int i = g_rt.order[k];
        const SpriteRT *r = &g_rt.spr[i];
        if (!r->visible) continue;
        float h = COSTUME_W * COSTUME_SB_SCALE / 2.0f * r->size / 100.f * PAD_S;
        float cx = (STAGE_W / 2 + r->x) * PAD_S, cy = (STAGE_H / 2 - r->y) * PAD_S;
        Px px = g_prj.sprites[r->def].costumes[r->costume].px[(COSTUME_H / 2) * COSTUME_W + COSTUME_W / 2];
        rect(cx - h, cy - h, 2 * h, 2 * h, (px & 0x8000u) ? px_rgb(px) : 0x888888);
    }
    if (g_rt.mouse_down) rect(g_rt.mouse_x * PAD_S + 160 - 3, 120 - g_rt.mouse_y * PAD_S - 3, 6, 6, 0xFFFFFF);
    text("Touch = mouse     B = stop", 6, 226, 0.42f, RGB(0xCCCCCC));
}

static void draw_bottom_bstage(void)
{
    draw_stage_view(0, 0, PAD_S);
    if (g_bs == BS_PICK) {
        button(2, BS_BTN_Y, 36, 16, "List", 0x66666F, 0);
        button(40, BS_BTN_Y, 48, 16, "Cancel", 0xC0392B, 0);
        rect(0, 222, 320, 18, 0x20242C);
        text("Eyedropper: tap a colour on the stage", 4, 225, 0.42f, RGB(0xFFFFFF));
    } else {
        button(2, BS_BTN_Y, 44, 16, "Done", 0x2E9E4F, 0);
        rect(0, 222, 320, 18, 0x20242C);
        char info[64];
        snprintf(info, sizeof info, "%.14s  x:%d y:%d  (drag to move)", cur()->name, cur()->x, cur()->y);
        text(info, 4, 225, 0.42f, RGB(0xFFFFFF));
    }
}

static void draw_bottom(void)
{
    g_budget = 6500;
    if (g_play) { if (g_run_bottom) draw_bottom_stage(); else draw_bottom_pad(); return; }
    if (g_bs && g_pk.action == PK_NONE) { draw_bottom_bstage(); return; }
    static const char *tabs[MODE_COUNT] = { "Scripts", "Costumes", "Sounds", "About" };
    for (int m = 0; m < MODE_COUNT; m++) button(1 + m * 70, 0, 68, TAB_H, tabs[m], 0x4A4A58, m == g_mode);
    if (g_mode == MODE_ABOUT) {
        draw_bottom_about();
        static const char *lb[BTN_N] = { "Flag", "Stop", "Save", "Del", "Undo", "Redo", "Dup" };
        static const u32 cl[BTN_N] = { 0x2E9E4F, 0xC0392B, 0x3B7DD8, 0x777777, 0x7A5CC0, 0x7A5CC0, 0x4C8F8F };
        for (int i = 0; i < BTN_N; i++) button(i * BTN_STEP + 1, BTN_Y, BTN_W, BTN_H, lb[i], cl[i], 0);
        text(g_status, 4, 228, 0.38f, RGB(0xDDDDDD));
        return;
    }

    char lab[64];
    if (g_sprite == STAGE_IDX) snprintf(lab, sizeof lab, "Stage: %d backdrop(s)", cur()->ncostumes);
    else snprintf(lab, sizeof lab, "%d/%d %s", g_sprite + 1, g_prj.nsprites, cur()->name);
    text(lab, 4, SPR_Y + 1, 0.42f, RGB(0xFFFFFF));
    button(160, SPR_Y, 34, SPR_H, g_run_bottom ? "Run:B" : "Run:T", 0x8A55D7, 0);
    button(196, SPR_Y, 22, SPR_H, "<", 0x66666F, 0);
    button(220, SPR_Y, 22, SPR_H, ">", 0x66666F, 0);
    button(244, SPR_Y, 22, SPR_H, "+", 0x2E9E4F, 0);
    button(268, SPR_Y, 22, SPR_H, "-", 0xC0392B, 0);
    button(292, SPR_Y, 26, SPR_H, "Spr", 0x3B7DD8, 0);

    if (g_pk.action != PK_NONE) draw_picker();
    else switch (g_mode) {
    case MODE_SCRIPTS:  draw_bottom_scripts();  break;
    case MODE_COSTUMES: draw_bottom_costumes(); break;
    default:            draw_bottom_sounds();   break;
    }

    static const char *labels[BTN_N] = { "Flag", "Stop", "Save", "Del", "Undo", "Redo", "Dup" };
    static const u32 cols[BTN_N] = { 0x2E9E4F, 0xC0392B, 0x3B7DD8, 0x777777, 0x7A5CC0, 0x7A5CC0, 0x4C8F8F };
    for (int i = 0; i < BTN_N; i++) button(i * BTN_STEP + 1, BTN_Y, BTN_W, BTN_H, labels[i], cols[i], 0);
    text(g_status, 4, 228, 0.38f, RGB(0xDDDDDD));
}

static int ask(const char *hint, const char *init, char *out, size_t outlen)
{
    SwkbdState kb;
    swkbdInit(&kb, SWKBD_TYPE_NORMAL, 2, (int)outlen - 1);
    swkbdSetHintText(&kb, hint);
    swkbdSetInitialText(&kb, init);
    swkbdSetButton(&kb, SWKBD_BUTTON_LEFT, "Cancel", false);
    swkbdSetButton(&kb, SWKBD_BUTTON_RIGHT, "OK", true);
    return swkbdInputText(&kb, out, outlen) == SWKBD_BUTTON_RIGHT;
}

static int ask_numpad(const char *hint, const char *init, char *out, size_t outlen, const char *left_label)
{
    SwkbdState kb;
    swkbdInit(&kb, SWKBD_TYPE_NUMPAD, 2, (int)outlen - 1);
    swkbdSetHintText(&kb, hint);
    swkbdSetInitialText(&kb, init);
    swkbdSetNumpadKeys(&kb, '-', '.');
    swkbdSetButton(&kb, SWKBD_BUTTON_LEFT, left_label, false);
    swkbdSetButton(&kb, SWKBD_BUTTON_RIGHT, "OK", true);
    SwkbdButton b = swkbdInputText(&kb, out, outlen);
    return b == SWKBD_BUTTON_RIGHT ? 1 : (b == SWKBD_BUTTON_LEFT ? 2 : 0);
}

static int ask_slot(char slot, const char *hint, const char *init, char *out, size_t outlen)
{
    if (slot != 'n') return ask(hint, init, out, outlen);
    int r = ask_numpad(hint, init, out, outlen, "Abc");
    if (r == 2) return ask(hint, init, out, outlen);
    return r == 1;
}

static int ask_number(const char *hint, int current, int *value)
{
    char init[TEXT_LEN], buf[TEXT_LEN];
    snprintf(init, sizeof init, "%d", current);
    if (ask_numpad(hint, init, buf, sizeof buf, "Cancel") != 1) return 0;
    *value = atoi(buf);
    return 1;
}

static void select_sprite(int i)
{
    if (i != STAGE_IDX && (i < 0 || i >= g_prj.nsprites)) return;
    g_sprite = i;
    cv_reset();
    g_script = 0; g_sel = 0; g_scroll = 0;
    focus_reset();
    g_snd = cur()->nsounds > 0 ? 0 : -1;
    if (i == STAGE_IDX && g_mode == MODE_SCRIPTS) g_mode = MODE_COSTUMES;
}

static void sprite_step(int d)
{
    if (g_sprite == STAGE_IDX) select_sprite(d < 0 ? g_prj.nsprites - 1 : 0);
    else select_sprite(g_sprite + d);
}

static ImportEntry g_imp[IMP_MAX_ENTRIES];
static int         g_nimp;
static Sprite      g_imp_sprite;

static void open_sprite_menu(void)
{
    char t[40];
    const Sprite *sp = cur();
    static const char *fixed[SM_COUNT] = { "Rename...", "Duplicate", "Layer back <", "Layer front >", "", "", "", "", "", "Import sprite...", "Open project (.sb3)...", "Play project (.sb3)...", "New from template...", "Import ALL" };
    for (int i = 0; i < SM_COUNT; i++) project_copy_text(g_pk.items[i], fixed[i]);
    snprintf(g_pk.items[SM_X], TEXT_LEN, "x: %d", sp->x);
    snprintf(g_pk.items[SM_Y], TEXT_LEN, "y: %d", sp->y);
    snprintf(g_pk.items[SM_DIR], TEXT_LEN, "Direction: %d", sp->direction);
    snprintf(g_pk.items[SM_SIZE], TEXT_LEN, "Size: %d%%", sp->size > 0 ? sp->size : 100);
    snprintf(g_pk.items[SM_VISIBLE], TEXT_LEN, "Visible: %s", sp->visible ? "yes" : "no");
    snprintf(t, sizeof t, "Sprite: %.24s", sp->name);
    g_pk.action = PK_SPRITE_MENU; g_pk.n = SM_COUNT; g_pk.page = 0; g_pk.slot = 0;
    snprintf(g_pk.title, sizeof g_pk.title, "%s", t);
}

static void import_one(int idx)
{
    char err[96];
    if (g_prj.nsprites >= MAX_SPRITES) { set_status("%s", "Maximum number of sprites reached."); return; }
    if (imp_load_sprite(&g_imp[idx], &g_imp_sprite, err, sizeof err) != 0) { set_status("%s: %s", g_imp[idx].name, err); return; }
    int i = prj_add_imported(&g_prj, &g_imp_sprite);
    if (i < 0) {
        for (int k = 0; k < MAX_SOUNDS; k++) snd_free(&g_imp_sprite.sounds[k]);
        set_status("%s", "Could not add the sprite.");
        return;
    }
    select_sprite(i);
    if (err[0]) set_status("Imported %s (%s)", g_prj.sprites[i].name, err); else set_status("Imported %s", g_prj.sprites[i].name);
}

static void open_import(int all)
{
    g_nimp = imp_scan(IMPORT_DIR, g_imp, IMP_MAX_ENTRIES);
    if (g_nimp == 0) { set_status("%s", "Nothing in sd:/3ds/scratch-editor/sprites/"); return; }
    if (all) {
        int ok = 0, fail = 0;
        for (int i = 0; i < g_nimp && g_prj.nsprites < MAX_SPRITES; i++) {
            char err[96];
            if (imp_load_sprite(&g_imp[i], &g_imp_sprite, err, sizeof err) != 0) { fail++; continue; }
            if (prj_add_imported(&g_prj, &g_imp_sprite) >= 0) { ok++; select_sprite(g_prj.nsprites - 1); }
            else { for (int k = 0; k < MAX_SOUNDS; k++) snd_free(&g_imp_sprite.sounds[k]); fail++; }
        }
        set_status("Imported %d sprite(s)%s", ok, fail ? ", some failed or did not fit" : "");
        return;
    }
    int n = g_nimp < MENU_MAX ? g_nimp : MENU_MAX;
    for (int i = 0; i < n; i++) snprintf(g_pk.items[i], TEXT_LEN, "%s%.20s", g_imp[i].is_dir ? "[+] " : "", g_imp[i].name);
    g_pk.action = PK_IMPORT; g_pk.n = n; g_pk.page = 0; g_pk.slot = 0;
    snprintf(g_pk.title, sizeof g_pk.title, "%s", "Import which sprite?  [+] = folder");
}

static void open_templates(void)
{
    for (int i = 0; i < tpl_count() && i < MENU_MAX; i++) project_copy_text(g_pk.items[i], tpl_name(i));
    g_pk.action = PK_TEMPLATE; g_pk.n = tpl_count(); g_pk.page = 0; g_pk.slot = 0;
    snprintf(g_pk.title, sizeof g_pk.title, "%s", "New from template (replaces project)");
}

static int g_tpl_idx;

static void load_template(int idx)
{
    if (tpl_build(&g_prj, idx) != 0) { set_status("%s", "Could not build the template."); return; }
    undo_clear(&g_undo); cv_reset();
    snprintf(g_name, sizeof g_name, "%s", "project");
    g_sprite = 0; g_mode = MODE_SCRIPTS;
    select_sprite(0);
    rt_reset(&g_rt, &g_prj);
    set_status("Template: %s. %s", tpl_name(idx), tpl_info(idx));
}

static char g_ofile[MENU_MAX][64];
static int  g_nofile, g_open_idx;

static int cmp_ofile(const void *a, const void *b) { return strcmp((const char *)a, (const char *)b); }

static int scan_projects(void)
{
    g_nofile = 0;
    DIR *d = opendir(SAVE_DIR);
    if (!d) return 0;
    struct dirent *e;
    while ((e = readdir(d)) != NULL && g_nofile < MENU_MAX) {
        size_t l = strlen(e->d_name);
        if (l > 4 && l < sizeof g_ofile[0] && strcmp(e->d_name + l - 4, ".sb3") == 0) {
            memcpy(g_ofile[g_nofile], e->d_name, l + 1);
            g_nofile++;
        }
    }
    closedir(d);
    qsort(g_ofile, (size_t)g_nofile, sizeof g_ofile[0], cmp_ofile);
    return g_nofile;
}

static void open_projects(int play)
{
    if (scan_projects() == 0) { set_status("%s", "No .sb3 files in sd:/3ds/scratch-editor/"); return; }
    for (int i = 0; i < g_nofile; i++) {
        char stem[64];
        snprintf(stem, sizeof stem, "%s", g_ofile[i]);
        stem[strlen(stem) - 4] = 0;
        project_copy_text(g_pk.items[i], stem);
    }
    g_pk.action = play ? PK_PLAYFILE : PK_OPEN; g_pk.n = g_nofile; g_pk.page = 0; g_pk.slot = 0;
    snprintf(g_pk.title, sizeof g_pk.title, "%s", play ? "Play which project?" : "Open which project?");
}

static void show_report(void);

static void load_project_file(int idx)
{
    char path[160], err[96];
    int skipped = 0;
    if (idx < 0 || idx >= g_nofile) return;
    snprintf(path, sizeof path, SAVE_DIR "/%s", g_ofile[idx]);
    if (sb3_read_project(path, &g_prj, &skipped, err, sizeof err) != 0) { set_status("%s", err); return; }
    undo_clear(&g_undo); cv_reset();
    {
        size_t stem = strlen(g_ofile[idx]) - 4;
        if (stem > TEXT_LEN - 1) stem = TEXT_LEN - 1;
        memcpy(g_name, g_ofile[idx], stem);
        g_name[stem] = 0;
    }
    g_sprite = 0; g_mode = MODE_SCRIPTS;
    select_sprite(0);
    rt_reset(&g_rt, &g_prj);
    if (skipped) set_status("Opened %s (%d item(s) not supported, skipped)", g_name, skipped);
    else set_status("Opened %s", g_name);
    if (skipped) show_report();
}

static Project g_stash;
static int g_player, g_stash_sprite, g_stash_mode;

static void start_play(void);

static void play_file(int idx)
{
    char path[160], err[96];
    int skipped = 0;
    if (idx < 0 || idx >= g_nofile) return;
    snprintf(path, sizeof path, SAVE_DIR "/%s", g_ofile[idx]);
    g_stash = g_prj;
    memset(&g_prj, 0, sizeof g_prj);
    if (sb3_read_project(path, &g_prj, &skipped, err, sizeof err) != 0) {
        g_prj = g_stash;
        cv_reset();
        memset(&g_stash, 0, sizeof g_stash);
        set_status("%s", err);
        return;
    }
    g_player = 1; g_stash_sprite = g_sprite; g_stash_mode = g_mode;
    g_sprite = 0; g_mode = MODE_SCRIPTS;
    select_sprite(0);
    start_play();
    if (skipped) set_status("Playing (%d item(s) not supported, skipped). B = stop.", skipped);
    else set_status("%s", "Playing the project. B = stop and go back to your project.");
}

static void sprite_menu_choose(int idx)
{
    Sprite *sp = cur();
    char buf[TEXT_LEN];
    int v, reopen = 1;
    switch (idx) {
    case SM_RENAME: if (ask("Sprite name", sp->name, buf, sizeof buf)) prj_rename_sprite(&g_prj, g_sprite, buf); break;
    case SM_DUPLICATE: { int i = prj_duplicate_sprite(&g_prj, g_sprite); if (i < 0) set_status("%s", "Maximum number of sprites reached."); else select_sprite(i); break; }
    case SM_BACK:  undo_clear(&g_undo); cv_reset(); g_sprite = prj_move_sprite(&g_prj, g_sprite, -1); break;
    case SM_FRONT: undo_clear(&g_undo); cv_reset(); g_sprite = prj_move_sprite(&g_prj, g_sprite, +1); break;
    case SM_X:   if (ask_number("x (-240..240)", sp->x, &v)) sp->x = v < -STAGE_W / 2 ? -STAGE_W / 2 : v > STAGE_W / 2 ? STAGE_W / 2 : v; break;
    case SM_Y:   if (ask_number("y (-180..180)", sp->y, &v)) sp->y = v < -STAGE_H / 2 ? -STAGE_H / 2 : v > STAGE_H / 2 ? STAGE_H / 2 : v; break;
    case SM_DIR: if (ask_number("Direction (90 = right)", sp->direction, &v)) { v %= 360; if (v > 180) v -= 360; if (v <= -180) v += 360; sp->direction = v; } break;
    case SM_SIZE: if (ask_number("Size % (5..500)", sp->size, &v)) sp->size = v < 5 ? 5 : v > 500 ? 500 : v; break;
    case SM_VISIBLE: sp->visible = !sp->visible; break;
    case SM_IMPORT: open_import(0); reopen = 0; break;
    case SM_IMPORT_ALL: open_import(1); reopen = 0; break;
    case SM_TEMPLATES: open_templates(); reopen = 0; break;
    case SM_OPEN: open_projects(0); reopen = 0; break;
    case SM_PLAYFILE: open_projects(1); reopen = 0; break;
    default: reopen = 0; break;
    }
    if (reopen && idx != SM_DUPLICATE) open_sprite_menu();
}

static void clamp_state(void)
{
    if (g_sprite != STAGE_IDX && g_sprite >= g_prj.nsprites) g_sprite = g_prj.nsprites - 1;
    Sprite *sp = cur();
    if (g_sprite == STAGE_IDX) {
        if (g_snd >= sp->nsounds) g_snd = sp->nsounds - 1;
        return;
    }
    if (g_script >= sp->nscripts) g_script = sp->nscripts - 1;
    if (g_sel >= sp->scripts[g_script].nblocks) g_sel = sp->scripts[g_script].nblocks - 1;
    if (g_sel < 0) g_sel = 0;
    if (g_scroll > g_sel) g_scroll = g_sel;
    if (g_snd >= sp->nsounds) g_snd = sp->nsounds - 1;
    if (!focus_node()) focus_reset();
}

static void picker_open(int action, const char *title, char slot, int n)
{
    g_pk.action = action;
    g_pk.n = n;
    g_pk.page = 0;
    g_pk.slot = slot;
    snprintf(g_pk.title, sizeof g_pk.title, "%s", title);
}

static void picker_close(void) { g_pk.action = PK_NONE; }

static void show_report(void)
{
    int n = sb3_report_count();
    if (n > MENU_MAX) n = MENU_MAX;
    if (n <= 0) return;
    for (int i = 0; i < n; i++) project_copy_text(g_pk.items[i], sb3_report_line(i));
    picker_open(PK_REPORT, "Not imported (tap to close)", 0, n);
}

static char g_mk_name[TEXT_LEN];
static int  g_mk_np;
static char g_mk_types[MAX_ARGS];
static char g_mk_names[MAX_ARGS][TEXT_LEN];

static void clean_block_text(char *s)
{
    int o = 0;
    for (int i = 0; s[i]; i++) if (s[i] != '%' && (unsigned char)s[i] >= 32) s[o++] = s[i];
    s[o] = 0;
    while (o > 0 && s[o - 1] == ' ') s[--o] = 0;
    int lead = 0;
    while (s[lead] == ' ') lead++;
    if (lead) memmove(s, s + lead, strlen(s + lead) + 1);
}

static void mk_reopen(void)
{
    char title[64];
    int o = snprintf(title, sizeof title, "Make: %.12s", g_mk_name);
    for (int k = 0; k < g_mk_np && o < 38; k++)
        o += snprintf(title + o, sizeof title - (size_t)o, g_mk_types[k] == 'b' ? " <%.6s>" : " (%.6s)", g_mk_names[k]);
    project_copy_text(g_pk.items[0], "+ Text / number input");
    project_copy_text(g_pk.items[1], "+ Boolean input");
    project_copy_text(g_pk.items[2], "Done: create the block");
    picker_open(PK_MKBLOCK, title, 0, 3);
    g_pk.title[39] = 0;
}

static void make_block_begin(void)
{
    char buf[TEXT_LEN];
    if (!ask("Block name", "", buf, sizeof buf)) return;
    clean_block_text(buf);
    if (!buf[0]) { set_status("%s", "The block needs a name."); return; }
    memset(g_mk_names, 0, sizeof g_mk_names);
    memset(g_mk_types, 0, sizeof g_mk_types);
    g_mk_np = 0;
    project_copy_text(g_mk_name, buf);
    mk_reopen();
}

static void mk_choose(int idx)
{
    if (idx == 2) {
        checkpoint();
        int s = prj_make_block(&g_prj, g_sprite, g_mk_name, g_mk_np, g_mk_types, g_mk_names);
        if (s < 0) {
            undo_discard(&g_undo);
            set_status("%s", s == -2 ? "A block with that name and inputs already exists." : (s == -1 ? "Maximum number of scripts reached." : "Invalid block or input name."));
            return;
        }
        g_script = s; g_sel = 0; g_scroll = 0;
        focus_reset();
        g_cat = CAT_MORE; g_pal_scroll = 0;
        set_status("%s", "Block created: build it under the define hat, use it from More.");
        return;
    }
    if (g_mk_np >= MAX_ARGS) { set_status("%s", "A block can have up to 3 inputs."); mk_reopen(); return; }
    char buf[TEXT_LEN];
    if (ask(idx == 0 ? "Input name" : "Boolean input name", "", buf, sizeof buf)) {
        clean_block_text(buf);
        int dup = 0;
        for (int k = 0; k < g_mk_np; k++) if (strcmp(g_mk_names[k], buf) == 0) dup = 1;
        if (!buf[0] || dup) set_status("%s", "Each input needs its own name.");
        else {
            project_copy_text(g_mk_names[g_mk_np], buf);
            g_mk_types[g_mk_np] = idx == 1 ? 'b' : 's';
            g_mk_np++;
        }
    }
    mk_reopen();
}

static void picker_choose(int idx)
{
    int action = g_pk.action;
    char slot = g_pk.slot;
    int last = g_pk.n - 1;
    picker_close();
    switch (action) {
    case PK_ARG: {
        Block *node = focus_node();
        if (!node || g_foc.slot >= block_nslots_b(node)) return;
        Arg *a = &node->a[g_foc.slot];
        if (slot == 'm' && idx == last) {
            char buf[TEXT_LEN];
            if (ask("Message", a->text, buf, sizeof buf) && buf[0]) { checkpoint(); project_copy_text(a->text, buf); }
        } else { checkpoint(); project_copy_text(a->text, g_pk.items[idx]); }
        break; }
    case PK_DEL_VAR:  prj_delete_var(&g_prj, idx);  set_status("%s", "Variable deleted."); break;
    case PK_DEL_LIST: prj_delete_list(&g_prj, idx); set_status("%s", "List deleted."); break;
    case PK_SPRITE_LIST: select_sprite(idx == g_prj.nsprites ? STAGE_IDX : idx); break;
    case PK_SPRITE_MENU: sprite_menu_choose(idx); break;
    case PK_IMPORT: if (idx < g_nimp) import_one(idx); break;
    case PK_FX: {
        int i = prj_add_effect(&g_prj, g_sprite, idx);
        if (i < 0) { set_status("%s", "Maximum number of sounds reached."); break; }
        g_snd = i;
        audio_play(&cur()->sounds[i], 100);
        set_status("Added %s.", cur()->sounds[i].name);
        break; }
    case PK_TEMPLATE:
        g_tpl_idx = idx;
        project_copy_text(g_pk.items[0], "Yes: replace the project");
        project_copy_text(g_pk.items[1], "No: keep working");
        picker_open(PK_TEMPLATE_OK, "Unsaved work will be lost. Continue?", 0, 2);
        break;
    case PK_TEMPLATE_OK: if (idx == 0) load_template(g_tpl_idx); break;
    case PK_OPEN:
        g_open_idx = idx;
        project_copy_text(g_pk.items[0], "Yes: replace the project");
        project_copy_text(g_pk.items[1], "No: keep working");
        picker_open(PK_OPEN_OK, "Unsaved work will be lost. Continue?", 0, 2);
        break;
    case PK_OPEN_OK: if (idx == 0) load_project_file(g_open_idx); break;
    case PK_PLAYFILE: play_file(idx); break;
    case PK_MKBLOCK: mk_choose(idx); break;
    case PK_SCRIPT_LIST: if (idx < cur()->nscripts) { g_script = idx; g_sel = 0; g_scroll = 0; focus_reset(); } break;
    default: break;
    }
}

static const char *slot_hint(char slot)
{
    switch (slot) {
    case 'n': return "Number";
    case 's': return "Text";
    default:  return "Value";
    }
}

static void open_arg_menu(char sl)
{
    int n = prj_menu_items(&g_prj, g_sprite, sl, g_pk.items, MENU_MAX);
    if (n == 0) {
        set_status("%s", sl == 'v' ? "No variables yet: Var tab, + New variable."
                       : sl == 'l' ? "No lists yet: List tab, + New list."
                       : sl == 'o' ? "This sprite has no sounds (Sounds tab)." : "Nothing to choose.");
        return;
    }
    picker_open(PK_ARG, "Choose a value", sl, n);
}

static void edit_focused(void)
{
    Block *node = focus_node();
    if (!node) return;
    if (g_foc.slot >= block_nslots_b(node)) { set_status("%s", "This block has no argument."); return; }
    Arg *a = &node->a[g_foc.slot];
    char sl = focus_slot_char(node, g_foc.slot);
    if (a->expr >= 0) {
        if (g_foc.depth >= MAX_EXPR - 1) return;
        g_foc.path[g_foc.depth++] = g_foc.slot;
        g_foc.slot = 0;
        return;
    }
    if (sl == 'b') { set_status("%s", "Needs a <boolean> block: pick one from Sens/Ops."); return; }
    if (slot_is_text(sl)) {
        char buf[TEXT_LEN];
        if (ask_slot(sl, slot_hint(sl), a->text, buf, sizeof buf)) { checkpoint(); project_copy_text(a->text, buf); }
        return;
    }
    if (sl == 'x' && (node->kind == BK_TOUCHING_COLOR || node->kind == BK_COLOR_SEES)) {
        g_bs = BS_PICK;
        set_status("%s", "Tap a colour on the stage. List = colour menu.");
        return;
    }
    open_arg_menu(sl);
}

static void focus_up(void)
{
    if (g_foc.depth > 0) { g_foc.depth--; g_foc.slot = g_foc.path[g_foc.depth]; }
}

static void focus_move(int d)
{
    Block *node = focus_node();
    if (!node) return;
    int ns = block_nslots_b(node), s = g_foc.slot + d;
    if (d > 0 && s >= ns && ns > 0) s = 0;
    if (s >= 0 && s < ns) g_foc.slot = s;
}

static void plug_reporter(int kind, const char *param)
{
    Block *node = focus_node();
    if (!node || block_nslots_b(node) == 0) { set_status("%s", "Select a block with an argument box first."); return; }
    checkpoint();
    int rc = prj_plug(&g_prj, g_sprite, cur_script(), node, g_foc.slot, (BlockKind)kind, param);
    if (rc != 0) undo_discard(&g_undo);
    switch (rc) {
    case 0:
        if (block_nslots(kind) > 0 && g_foc.depth < MAX_EXPR - 1) {
            g_foc.path[g_foc.depth++] = g_foc.slot;
            g_foc.slot = 0;
        }
        set_status("%s", "Plugged in. ^ goes back up.");
        break;
    case -2: set_status("%s", "Too many reporters in this script."); break;
    case -3: set_status("%s", "That slot needs a <boolean> block."); break;
    default: set_status("%s", "Can't plug that here."); break;
    }
}

static const char *pal_param(const PalEntry *e)
{
    if (e->kind == BK_VAR) return g_prj.vars[e->param].name;
    if (e->kind == BK_PARAM || e->kind == BK_PARAMB) return cur_script()->blocks[0].a[e->param].text;
    return NULL;
}

static void add_from_palette(const PalEntry *e)
{
    char buf[TEXT_LEN];
    switch (e->kind) {
    case PE_NEW_VAR:
        if (ask("Variable name", "", buf, sizeof buf) && buf[0]) {
            if (prj_add_var(&g_prj, buf) < 0) set_status("%s", "Too many variables."); else set_status("Variable %s created.", buf);
        }
        return;
    case PE_NEW_LIST:
        if (ask("List name", "", buf, sizeof buf) && buf[0]) {
            if (prj_add_list(&g_prj, buf) < 0) set_status("%s", "Too many lists."); else set_status("List %s created.", buf);
        }
        return;
    case PE_MAKE_BLOCK:
        if (g_sprite == STAGE_IDX) { set_status("%s", "Select a sprite first."); return; }
        make_block_begin();
        return;
    case PE_DEL_VAR:
    case PE_DEL_LIST: {
        int isvar = e->kind == PE_DEL_VAR;
        int n = isvar ? g_prj.nvars : g_prj.nlists;
        if (n == 0) { set_status("%s", "Nothing to delete."); return; }
        for (int i = 0; i < n; i++) project_copy_text(g_pk.items[i], isvar ? g_prj.vars[i].name : g_prj.lists[i].name);
        picker_open(isvar ? PK_DEL_VAR : PK_DEL_LIST, isvar ? "Delete which variable?" : "Delete which list?", 0, n);
        return; }
    default: break;
    }
    BlockKind kind = (BlockKind)e->kind;
    if (kind == BK_CALL) {
        checkpoint();
        int at = prj_insert_call(&g_prj, g_sprite, g_script, g_sel, e->param);
        if (at < 0) { undo_discard(&g_undo); set_status("%s", "Script is full."); return; }
        g_sel = -1;
        select_block(at);
        return;
    }
    if (block_is_hat(kind)) {
        checkpoint();
        int s = prj_new_script(&g_prj, g_sprite, kind);
        if (s < 0) { undo_discard(&g_undo); set_status("%s", "Maximum number of scripts reached."); return; }
        g_script = s; g_sel = 0; g_scroll = 0;
        focus_reset();
        return;
    }
    if (block_is_reporter(kind)) { plug_reporter(kind, pal_param(e)); return; }
    checkpoint();
    int at = prj_insert_block(&g_prj, g_sprite, g_script, g_sel, kind);
    if (at < 0) { undo_discard(&g_undo); set_status("%s", "Script is full."); return; }
    g_sel = -1;
    select_block(at);
}

static void plug_into_row(int row, int kind, const char *param)
{
    select_block(row);
    Script *sc = cur_script();
    int ns = block_nslots_b(&sc->blocks[row]);
    if (ns == 0) { set_status("%s", "That block has no argument box."); return; }
    int want_bool = BLOCK_INFO[kind].shape == SH_BOOL;
    checkpoint();
    for (int pass = 0; pass < 2; pass++)
        for (int k = 0; k < ns; k++) {
            int is_bool = block_slot(&sc->blocks[row], k) == 'b';
            if (pass == 0 && is_bool != want_bool) continue;
            if (prj_plug(&g_prj, g_sprite, sc, &sc->blocks[row], k, (BlockKind)kind, param) == 0) {
                g_foc.depth = 0;
                g_foc.slot = k;
                if (block_nslots(kind) > 0) { g_foc.path[g_foc.depth++] = k; g_foc.slot = 0; }
                set_status("%s", "Plugged in. ^ goes back up.");
                return;
            }
        }
    undo_discard(&g_undo);
    set_status("%s", "No free slot accepts that block.");
}

static void handle_touch(int x, int y);

static void drag_begin(int x, int y)
{
    memset(&g_drag, 0, sizeof g_drag);
    if (g_mode == MODE_SCRIPTS && g_pk.action == PK_NONE && !g_recording && !g_play && g_sprite != STAGE_IDX) {
        PalEntry pe[PAL_MAX];
        int n = palette_list(pe);
        if (hit(x, y, PAL_X, PAL_Y, PAL_W, PAL_ROWS * PAL_ROW)) {
            int i = g_pal_scroll + (y - PAL_Y) / PAL_ROW;
            if (i < n && pe[i].kind >= 0) {
                g_drag.src = 1; g_drag.pe = pe[i];
                palette_label(&pe[i], g_drag.label, sizeof g_drag.label);
                g_drag.color = RGB(palette_color(&pe[i]));
            }
        } else if (hit(x, y, SCR_X, SCR_Y, SCRBTN_X - SCR_X, SCR_ROWS * SCR_ROW)) {
            const Script *sc = cur_script();
            int b = g_scroll + (y - SCR_Y) / SCR_ROW;
            if (b >= 1 && b < sc->nblocks) {
                int sh = BLOCK_INFO[sc->blocks[b].kind].shape;
                if (sh != SH_END && sh != SH_ELSE && sh != SH_HAT) {
                    g_drag.src = 2; g_drag.block = b;
                    prj_format_block(sc, &sc->blocks[b], g_drag.label, sizeof g_drag.label);
                    g_drag.color = RGB(category_color(BLOCK_INFO[sc->blocks[b].kind].category));
                }
            }
        }
    }
    if (!g_drag.src) { handle_touch(x, y); return; }
    g_drag.sx = g_drag.x = x;
    g_drag.sy = g_drag.y = y;
}

static void drag_move(int x, int y)
{
    if (!g_drag.src) return;
    g_drag.x = x; g_drag.y = y;
    if (!g_drag.active && (x - g_drag.sx) * (x - g_drag.sx) + (y - g_drag.sy) * (y - g_drag.sy) > DRAG_THRESHOLD * DRAG_THRESHOLD) g_drag.active = 1;
    if (g_drag.active && x >= SCR_X) {
        static int tick;
        if (++tick % 6 == 0) {
            if (y < SCR_Y + 8 && g_scroll > 0) g_scroll--;
            else if (y > SCR_Y + SCR_ROWS * SCR_ROW - 8 && g_scroll + SCR_ROWS < cur_script()->nblocks) g_scroll++;
        }
    }
}

static void drag_end(void)
{
    if (!g_drag.src) return;
    Drag d = g_drag;
    memset(&g_drag, 0, sizeof g_drag);
    if (!d.active) { handle_touch(d.sx, d.sy); return; }
    int in_script = d.x >= SCR_X - 4 && d.y >= SCR_Y - 4 && d.y < SCR_Y + SCR_ROWS * SCR_ROW + 4;
    if (d.src == 2) {
        if (hit(d.x, d.y, PAL_X, PAL_Y, PAL_W, PAL_ROWS * PAL_ROW)) {
            checkpoint();
            if (prj_delete_block(&g_prj, g_sprite, g_script, d.block) < 0) { undo_discard(&g_undo); set_status("%s", "Can't delete that block."); }
            else { focus_reset(); set_status("%s", "Block deleted."); }
            clamp_state();
        } else if (in_script) {
            checkpoint();
            int r = prj_move_block(&g_prj, g_sprite, g_script, d.block, gap_after(script_gap(d.y)));
            if (r < 0) { undo_discard(&g_undo); set_status("%s", "Can't drop a block inside itself."); }
            else { g_sel = -1; select_block(r); }
        }
        return;
    }
    int kind = d.pe.kind;
    if (block_is_reporter(kind)) {
        const char *param = pal_param(&d.pe);
        for (int i = 0; i < MAX_ARGS; i++)
            if (hit(d.x, d.y, ARG_X + i * ARG_STEP, ARG_Y, ARG_W, ARG_H)) {
                Block *node = focus_node();
                if (!node || i >= block_nslots_b(node)) return;
                g_foc.slot = i;
                plug_reporter(kind, param);
                return;
            }
        if (in_script) {
            int row = g_scroll + (d.y - SCR_Y) / SCR_ROW;
            if (row >= 0 && row < cur_script()->nblocks) plug_into_row(row, kind, param);
        }
        return;
    }
    if (block_is_hat(kind)) { if (in_script) add_from_palette(&d.pe); return; }
    if (!in_script) return;
    checkpoint();
    int at = kind == BK_CALL ? prj_insert_call(&g_prj, g_sprite, g_script, gap_after(script_gap(d.y)), d.pe.param)
                             : prj_insert_block(&g_prj, g_sprite, g_script, gap_after(script_gap(d.y)), (BlockKind)kind);
    if (at < 0) { undo_discard(&g_undo); set_status("%s", "Script is full."); return; }
    g_sel = -1;
    select_block(at);
}

static void script_list(void)
{
    const Sprite *sp = cur();
    int n = sp->nscripts < MENU_MAX ? sp->nscripts : MENU_MAX;
    for (int i = 0; i < n; i++) {
        char lab[TEXT_LEN - 6];
        prj_format_block(&sp->scripts[i], &sp->scripts[i].blocks[0], lab, sizeof lab);
        snprintf(g_pk.items[i], TEXT_LEN, "%d: %s", i + 1, lab);
    }
    picker_open(PK_SCRIPT_LIST, "Go to script", 0, n);
    g_pk.page = g_script / PK_PER_PAGE;
}

static void select_script(int delta)
{
    int n = g_script + delta;
    if (n < 0 || n >= cur()->nscripts) return;
    g_script = n; g_sel = 0; g_scroll = 0;
    focus_reset();
}

static void touch_scripts(int x, int y)
{
    for (int c = 0; c < CAT_COUNT; c++)
        if (hit(x, y, 2 + c * CAT_STEP, CAT_Y, CAT_W, CAT_H)) { g_cat = c; g_pal_scroll = 0; g_search[0] = 0; return; }

    PalEntry pe[PAL_MAX];
    int n = palette_list(pe);
    if (hit(x, y, PAL_X, PAL_Y, PAL_W, PAL_ROWS * PAL_ROW)) {
        int i = g_pal_scroll + (y - PAL_Y) / PAL_ROW;
        if (i < n) add_from_palette(&pe[i]);
        return;
    }
    if (hit(x, y, PAL_X, PALBTN_Y, 36, PALBTN_H)) { g_pal_scroll -= PAL_ROWS - 1; if (g_pal_scroll < 0) g_pal_scroll = 0; return; }
    if (hit(x, y, PAL_X + 38, PALBTN_Y, 44, PALBTN_H)) {
        char buf[sizeof g_search];
        if (ask("Search blocks (empty = all)", g_search, buf, sizeof buf)) { snprintf(g_search, sizeof g_search, "%s", buf); g_pal_scroll = 0; }
        return;
    }
    if (hit(x, y, PAL_X + 84, PALBTN_Y, 36, PALBTN_H)) {
        if (g_pal_scroll + PAL_ROWS < n) g_pal_scroll += PAL_ROWS - 1;
        return;
    }
    if (hit(x, y, PAL_X, SCRNAV_Y, 17, SCRNAV_H)) { select_script(-1); return; }
    if (hit(x, y, PAL_X + 19, SCRNAV_Y, 17, SCRNAV_H)) { select_script(+1); return; }
    if (hit(x, y, PAL_X + 38, SCRNAV_Y, 30, SCRNAV_H)) { script_list(); return; }
    if (hit(x, y, PAL_X + 70, SCRNAV_Y, 24, SCRNAV_H)) { script_jump(0); return; }
    if (hit(x, y, PAL_X + 96, SCRNAV_Y, 24, SCRNAV_H)) { script_jump(1); return; }

    if (hit(x, y, SCRBTN_X, SCR_Y, SCRBTN_W, SCRBTN_H)) { script_page(-1); return; }
    if (hit(x, y, SCRBTN_X, SCR_Y + SCRBTN_H + SCRBTN_GAP, SCRBTN_W, SCRBTN_H)) { script_page(+1); return; }
    if (hit(x, y, SCR_X, SCR_Y, SCRBTN_X - SCR_X, SCR_ROWS * SCR_ROW)) {
        int b = g_scroll + (y - SCR_Y) / SCR_ROW;
        if (b < cur_script()->nblocks) select_block(b);
        return;
    }
    if (hit(x, y, SCR_X, ARG_Y, ARG_UP_W, ARG_H)) { focus_up(); return; }
    for (int i = 0; i < MAX_ARGS; i++)
        if (hit(x, y, ARG_X + i * ARG_STEP, ARG_Y, ARG_W, ARG_H)) {
            Block *node = focus_node();
            if (!node || i >= block_nslots_b(node)) return;
            if (i != g_foc.slot) g_foc.slot = i; else edit_focused();
            return;
        }
}

static void bs_toggle_move(void)
{
    if (g_bs) { g_bs = BS_OFF; return; }
    if (g_sprite == STAGE_IDX) { set_status("%s", "Pick a sprite (name) to move it on the stage."); return; }
    g_bs = BS_MOVE;
    set_status("%s", "Drag on the stage to move the sprite. D-pad up / B = back.");
}

static void bs_touch(int x, int y, int pressed)
{
    float sx = (float)x / PAD_S - STAGE_W / 2.0f, sy = STAGE_H / 2.0f - (float)y / PAD_S;
    if (g_bs == BS_PICK) {
        if (!pressed) return;
        if (hit(x, y, 2, BS_BTN_Y, 36, 16)) { g_bs = BS_OFF; Block *n = focus_node(); if (n) open_arg_menu(focus_slot_char(n, g_foc.slot)); return; }
        if (hit(x, y, 40, BS_BTN_Y, 48, 16)) { g_bs = BS_OFF; set_status("%s", "Cancelled."); return; }
        int idx = rt_pixel_at(&g_rt, &g_prj, sx, sy);
        Block *n = focus_node();
        if (idx <= 0) { set_status("%s", "Nothing there (white). Tap a coloured pixel, or use List."); return; }
        if (!n || g_foc.slot >= block_nslots_b(n)) { g_bs = BS_OFF; return; }
        checkpoint();
        project_copy_text(n->a[g_foc.slot].text, PALETTE_NAMES[idx]);
        set_status("Picked %s.", PALETTE_NAMES[idx]);
        g_bs = BS_OFF;
        return;
    }
    if (g_bs == BS_MOVE) {
        if (hit(x, y, 2, BS_BTN_Y, 44, 16)) { if (pressed) g_bs = BS_OFF; return; }
        if (g_sprite == STAGE_IDX) return;
        float hx = STAGE_W / 2.0f, hy = STAGE_H / 2.0f;
        g_prj.sprites[g_sprite].x = (int)lroundf(sx < -hx ? -hx : (sx > hx ? hx : sx));
        g_prj.sprites[g_sprite].y = (int)lroundf(sy < -hy ? -hy : (sy > hy ? hy : sy));
    }
}

static void costume_nav(int d)
{
    Sprite *sp = cur();
    int n = sp->cur_costume + d;
    if (n >= 0 && n < sp->ncostumes) { sp->cur_costume = n; cv_reset(); }
}

static void cv_begin_edit(void)
{
    const Sprite *sp = cur();
    g_cv_undo = sp->costumes[sp->cur_costume];
    g_undo_sp = g_sprite;
    g_undo_co = sp->cur_costume;
}

static void cv_undo(void)
{
    Sprite *sp = cur();
    if (g_undo_sp != g_sprite || g_undo_co != sp->cur_costume || g_undo_co < 0) { set_status("%s", "Nothing to undo in this costume."); return; }
    Costume *c = &sp->costumes[sp->cur_costume];
    Costume now = *c;
    memcpy(c->px, g_cv_undo.px, sizeof c->px);
    g_cv_undo = now;
    set_status("%s", "Costume undone (press again to redo).");
}

static int cv_pos(int x, int y, int clamp, int *ix, int *iy)
{
    int win = cv_win();
    if (!clamp && (x < CV_X || y < CV_Y || x >= CV_X + win * g_zoom || y >= CV_Y + win * g_zoom)) return 0;
    int cx = (x - CV_X) / g_zoom, cy = (y - CV_Y) / g_zoom;
    if (x < CV_X) cx = 0;
    if (y < CV_Y) cy = 0;
    if (cx >= win) cx = win - 1;
    if (cy >= win) cy = win - 1;
    *ix = g_vx + cx; *iy = g_vy + cy;
    return 1;
}

static void sel_norm(int *x0, int *y0, int *x1, int *y1)
{
    *x0 = g_sx0 < g_sx1 ? g_sx0 : g_sx1; *x1 = g_sx0 < g_sx1 ? g_sx1 : g_sx0;
    *y0 = g_sy0 < g_sy1 ? g_sy0 : g_sy1; *y1 = g_sy0 < g_sy1 ? g_sy1 : g_sy0;
}

static void draw_shape(Costume *c, int tool, int x0, int y0, int x1, int y1)
{
    int sz = BRUSHES[g_brush];
    if (tool == T_LINE) costume_line(c, x0, y0, x1, y1, g_col, sz);
    else if (tool == T_RECT) costume_rect(c, x0, y0, x1, y1, g_col, sz, g_solid);
    else costume_oval(c, x0, y0, x1, y1, g_col, sz, g_solid);
}

static void canvas_press(int x, int y)
{
    int ix, iy;
    g_cv_down = 0; g_mv = 0;
    if (!cv_pos(x, y, 0, &ix, &iy)) return;
    Costume *c = &cur()->costumes[cur()->cur_costume];
    switch (g_tool) {
    case T_PEN:
        cv_begin_edit();
        costume_plot(c, ix, iy, g_col, BRUSHES[g_brush]);
        g_cv_lx = ix; g_cv_ly = iy; g_cv_down = 1;
        break;
    case T_FILL:
        cv_begin_edit();
        costume_fill(c, ix, iy, g_col);
        break;
    case T_PICK:
        g_col = costume_get(c, ix, iy);
        break;
    case T_LINE: case T_RECT: case T_OVAL:
        cv_begin_edit();
        g_cv_bak = *c;
        g_cv_sx = ix; g_cv_sy = iy; g_cv_down = 1;
        draw_shape(c, g_tool, ix, iy, ix, iy);
        break;
    case T_SEL: {
        int x0, y0, x1, y1;
        sel_norm(&x0, &y0, &x1, &y1);
        if (g_selon && ix >= x0 && ix <= x1 && iy >= y0 && iy <= y1) {
            cv_begin_edit();
            g_mv_w = x1 - x0 + 1; g_mv_h = y1 - y0 + 1;
            costume_grab(c, x0, y0, x1, y1, g_mv_buf);
            g_cv_bak = *c;
            costume_clear_rect(&g_cv_bak, x0, y0, x1, y1);
            g_mv_gx = ix - x0; g_mv_gy = iy - y0;
            g_mv = 1; g_cv_down = 1;
        } else {
            g_selon = 1; g_sx0 = g_sx1 = ix; g_sy0 = g_sy1 = iy; g_cv_down = 1;
        }
        break; }
    default: break;
    }
}

static void canvas_drag(int x, int y)
{
    if (!g_cv_down) return;
    int ix, iy;
    cv_pos(x, y, 1, &ix, &iy);
    Costume *c = &cur()->costumes[cur()->cur_costume];
    switch (g_tool) {
    case T_PEN:
        costume_line(c, g_cv_lx, g_cv_ly, ix, iy, g_col, BRUSHES[g_brush]);
        g_cv_lx = ix; g_cv_ly = iy;
        break;
    case T_LINE: case T_RECT: case T_OVAL:
        memcpy(c->px, g_cv_bak.px, sizeof c->px);
        draw_shape(c, g_tool, g_cv_sx, g_cv_sy, ix, iy);
        break;
    case T_SEL:
        if (g_mv) {
            int nx = ix - g_mv_gx, ny = iy - g_mv_gy;
            memcpy(c->px, g_cv_bak.px, sizeof c->px);
            costume_blit(c, g_mv_buf, g_mv_w, g_mv_h, nx, ny);
            g_sx0 = nx; g_sy0 = ny; g_sx1 = nx + g_mv_w - 1; g_sy1 = ny + g_mv_h - 1;
        } else { g_sx1 = ix; g_sy1 = iy; }
        break;
    default: break;
    }
}

static void canvas_release(void)
{
    if (g_cv_down && g_tool == T_SEL && !g_mv) {
        int x0, y0, x1, y1;
        sel_norm(&x0, &y0, &x1, &y1);
        g_sx0 = x0; g_sy0 = y0; g_sx1 = x1; g_sy1 = y1;
    }
    g_cv_down = 0; g_mv = 0; g_cv_lx = -1; g_cv_ly = -1;
}

static void paint_canvas(int x, int y, int pressed)
{
    if (pressed) canvas_press(x, y); else canvas_drag(x, y);
}

static void sel_op(int i)
{
    Costume *c = &cur()->costumes[cur()->cur_costume];
    int x0, y0, x1, y1;
    sel_norm(&x0, &y0, &x1, &y1);
    if (i == 2) {
        if (g_clip_w <= 0) { set_status("%s", "Nothing copied yet."); return; }
        int dx = g_selon ? x0 : g_vx, dy = g_selon ? y0 : g_vy;
        cv_begin_edit();
        costume_blit(c, g_clip, g_clip_w, g_clip_h, dx, dy);
        g_selon = 1; g_sx0 = dx; g_sy0 = dy; g_sx1 = dx + g_clip_w - 1; g_sy1 = dy + g_clip_h - 1;
        if (g_sx1 >= COSTUME_W) g_sx1 = COSTUME_W - 1;
        if (g_sy1 >= COSTUME_H) g_sy1 = COSTUME_H - 1;
        set_status("%s", "Pasted. With Sel you can drag it.");
        return;
    }
    if (!g_selon) { set_status("%s", "Pick Sel and drag an area first."); return; }
    if (i == 0 || i == 1) {
        g_clip_w = x1 - x0 + 1; g_clip_h = y1 - y0 + 1;
        costume_grab(c, x0, y0, x1, y1, g_clip);
        if (i == 1) { cv_begin_edit(); costume_clear_rect(c, x0, y0, x1, y1); }
        set_status("%s", i == 0 ? "Copied." : "Cut.");
    } else {
        cv_begin_edit();
        costume_clear_rect(c, x0, y0, x1, y1);
    }
}

static void touch_costumes(int x, int y)
{
    Sprite *sp = cur();
    Costume *c = &sp->costumes[sp->cur_costume];
    char buf[TEXT_LEN];
    for (int i = 0; i < PAL_N; i++)
        if (hit(x, y, PNL_X + (i % 8) * 18, 36 + (i / 8) * 18, 17, 17)) { g_col = px_pal(i); return; }
    if (hit(x, y, PNL_X + 20, 74, 40, 18)) {
        if (ask("Color as RRGGBB (hex)", "", buf, sizeof buf)) {
            const char *h = buf[0] == '#' ? buf + 1 : buf;
            char *end = NULL;
            unsigned long v = strtoul(h, &end, 16);
            if (strlen(h) == 6 && end && !*end) g_col = px_make((uint32_t)v);
            else set_status("%s", "Type 6 hex digits, for example FF8800.");
        }
        return;
    }
    if (hit(x, y, PNL_X + 62, 74, 40, 18)) { g_brush = (g_brush + 1) % 5; return; }
    if (hit(x, y, PNL_X + 104, 74, 44, 18)) { g_zoom = g_zoom == 2 ? 1 : 2; cv_clamp_view(); return; }
    for (int i = 0; i < T_COUNT; i++)
        if (hit(x, y, PNL_X + (i % 4) * 37, 94 + (i / 4) * 20, 36, 18)) { g_tool = i; return; }
    if (hit(x, y, PNL_X + 3 * 37, 114, 36, 18)) { g_solid = !g_solid; return; }
    for (int i = 0; i < 4; i++) if (hit(x, y, PNL_X + i * 37, 134, 36, 18)) { sel_op(i); return; }
    for (int i = 0; i < 4; i++)
        if (hit(x, y, PNL_X + i * 37, 154, 36, 18)) {
            switch (i) {
            case 0: cv_begin_edit(); costume_flip_h(c); break;
            case 1: cv_begin_edit(); costume_clear(c); break;
            case 2:
                cv_reset();
        if (prj_add_costume(&g_prj, g_sprite) < 0) set_status("%s", "Maximum number of costumes reached.");
                else set_status("%s", "New costume = copy of the previous one.");
                break;
            default:
                if (ask("Costume name", c->name, buf, sizeof buf) && buf[0]) {
                    if (prj_rename_costume(&g_prj, g_sprite, sp->cur_costume, buf) < 0) set_status("%s", "Name already used.");
                }
                break;
            }
            return;
        }
    if (hit(x, y, PNL_X, 174, 36, 18)) { costume_nav(-1); return; }
    if (hit(x, y, PNL_X + 37, 174, 36, 18)) { costume_nav(+1); return; }
    for (int i = 0; i < 4; i++)
        if (hit(x, y, PNL_X + i * 30, 194, 28, 12)) {
            if (g_zoom == 1) return;
            int mx = COSTUME_W - CV_WIN;
            if (i == 0) g_vx -= 8; else if (i == 1) g_vx += 8; else if (i == 2) g_vy -= 8; else g_vy += 8;
            if (g_vx < 0) g_vx = 0;
            if (g_vy < 0) g_vy = 0;
            if (g_vx > mx) g_vx = mx;
            if (g_vy > mx) g_vy = mx;
            return;
        }
}

static void rec_finish(void)
{
    mic_stop();
    g_recording = 0;
    if (g_rec.n < REC_RATE / 20) { set_status("%s", "Too short: nothing recorded."); return; }
    int i = prj_add_recording(&g_prj, g_sprite, g_rec.buf, g_rec.n, REC_RATE);
    if (i < 0) { set_status("%s", "Maximum number of sounds reached."); return; }
    g_snd = i;
    char msg[64];
    snprintf(msg, sizeof msg, "Recorded %.1f s. Use Trim / Normalize.", (float)g_rec.n / REC_RATE);
    set_status("%s", msg);
}

static void rec_toggle(void)
{
    if (g_recording) { rec_finish(); return; }
    if (!g_mic_ok) { set_status("%s", "Microphone not available."); return; }
    if (cur()->nsounds >= MAX_SOUNDS) { set_status("%s", "Maximum number of sounds reached."); return; }
    if (mic_start(0) != 0) { set_status("%s", "Could not start the microphone."); return; }
    g_recording = 1;
    set_status("%s", "Recording... tap Stop when done.");
}

static void touch_sounds(int x, int y)
{
    Sprite *sp = cur();
    if (hit(x, y, 2, SN_REC_Y, 146, 22)) { rec_toggle(); return; }
    if (g_recording) return;
    if (hit(x, y, 156, SN_REC_Y, 160, 22)) {
        for (int i = 0; i < SND_PRESET_COUNT; i++) project_copy_text(g_pk.items[i], SND_PRESET_NAMES[i]);
        picker_open(PK_FX, "Add a sound effect", 0, SND_PRESET_COUNT);
        return;
    }
    for (int i = 0; i < sp->nsounds; i++)
        if (hit(x, y, 2, SN_LIST_Y + i * SN_ROW, 148, 18)) { g_snd = i; return; }
    if (hit(x, y, 2, SN_BTN_Y, 46, 18)) {
        int i = prj_add_sound(&g_prj, g_sprite);
        if (i < 0) set_status("%s", "Maximum number of sounds reached."); else g_snd = i;
        return;
    }
    if (g_snd < 0 || g_snd >= sp->nsounds) return;
    Sound *s = &sp->sounds[g_snd];
    if (hit(x, y, 52, SN_BTN_Y, 46, 18)) { audio_play(s, 100); return; }
    if (hit(x, y, 102, SN_BTN_Y, 46, 18)) {
        char buf[TEXT_LEN];
        if (ask("Sound name", s->name, buf, sizeof buf) && buf[0]) {
            if (prj_rename_sound(&g_prj, g_sprite, g_snd, buf) < 0) set_status("%s", "Name already used.");
        }
        return;
    }
    if (snd_is_recorded(s)) {
        for (int k = 0; k < 3; k++)
            if (hit(x, y, 156, 36 + k * 28, 160, 24)) {
                int rc = k == 0 ? snd_trim(s) : (k == 1 ? snd_normalize(s) : snd_reverse(s));
                set_status("%s", rc == 0 ? (k == 0 ? "Trimmed." : (k == 1 ? "Normalized." : "Reversed.")) : "Nothing to do (silent?).");
                return;
            }
        int yy = 36 + 3 * 28;
        if (hit(x, y, 262, yy, 26, 24) || hit(x, y, 290, yy, 26, 24)) {
            s->vol += hit(x, y, 290, yy, 26, 24) ? 10 : -10;
            snd_clamp(s);
            if (s->vol == 0 && s->npcm) s->vol = 0;
        }
        return;
    }
    for (int k = 0; k < 4; k++) {
        float yy = 36 + k * 28;
        int dec = hit(x, y, 262, (int)yy, 26, 24), inc = hit(x, y, 290, (int)yy, 26, 24);
        int lab = hit(x, y, 156, (int)yy, 102, 24);
        if (!dec && !inc && !lab) continue;
        int dir = inc ? +1 : -1;
        switch (k) {
        case 0: if (dec || inc) s->wave += dir; else s->wave = (s->wave + 1) % WAVE_COUNT; break;
        case 1:
            if (lab) { int v; if (ask_number("Frequency (Hz)", s->freq, &v)) s->freq = v; }
            else { int f = (int)lroundf((float)s->freq * (inc ? 1.0595f : 1.0f / 1.0595f)); s->freq = (f == s->freq) ? s->freq + dir : f; }
            break;
        case 2:
            if (lab) { int v; if (ask_number("Duration (ms)", s->ms, &v)) s->ms = v; }
            else s->ms += dir * 50;
            break;
        default:
            if (lab) { int v; if (ask_number("Volume (0-100)", s->vol, &v)) s->vol = v; }
            else s->vol += dir * 10;
            break;
        }
        snd_clamp(s);
        return;
    }
}

static void sanitize(char *s)
{
    for (; *s; s++)
        if (!((*s >= '0' && *s <= '9') || (*s >= 'a' && *s <= 'z') || (*s >= 'A' && *s <= 'Z') ||
              *s == '-' || *s == '_' || *s == ' '))
            *s = '_';
}

static void save_settings(void)
{
    mkdir("sdmc:/3ds", 0777);
    mkdir(SAVE_DIR, 0777);
    FILE *f = fopen(SAVE_DIR "/settings.txt", "w");
    if (!f) return;
    fprintf(f, "run_screen=%s\n", g_run_bottom ? "bottom" : "top");
    fclose(f);
}

static void load_settings(void)
{
    FILE *f = fopen(SAVE_DIR "/settings.txt", "r");
    if (!f) return;
    char line[64];
    while (fgets(line, sizeof line, f)) if (!strncmp(line, "run_screen=", 11)) g_run_bottom = !strncmp(line + 11, "bottom", 6);
    fclose(f);
}

static void save_project(void)
{
    char buf[TEXT_LEN], init[TEXT_LEN];
    snprintf(init, sizeof init, "%s", g_name);
    if (!ask("File name (without .sb3)", init, buf, sizeof buf) || !buf[0]) return;
    sanitize(buf);
    snprintf(g_name, sizeof g_name, "%s", buf);

    mkdir("sdmc:/3ds", 0777);
    mkdir(SAVE_DIR, 0777);
    mkdir(IMPORT_DIR, 0777);
    char path[128];
    snprintf(path, sizeof path, SAVE_DIR "/%s.sb3", g_name);
    if (sb3_write_project(&g_prj, path) == 0) set_status("Saved %s", path + 5);
    else set_status("%s", "ERROR: could not write the file.");
}

#define AUTOSAVE_FILE SAVE_DIR "/autosave.sb3"
#define AUTOSAVE_FRAMES (60 * 180)

static void autosave(void)
{
    if (!g_dirty || g_play || g_player || g_recording || g_pk.action != PK_NONE || g_drag.src) return;
    mkdir("sdmc:/3ds", 0777);
    mkdir(SAVE_DIR, 0777);
    if (sb3_write_project(&g_prj, AUTOSAVE_FILE) == 0) { g_dirty = 0; set_status("%s", "Autosaved (autosave.sb3)."); }
}

static void start_play(void)
{
    g_bs = BS_OFF;
    if (g_recording) rec_finish();
    picker_close();
    if (g_sprite == STAGE_IDX) { select_sprite(0); g_mode = MODE_SCRIPTS; }
    rt_green_flag(&g_rt, &g_prj);
    g_play = 1;
    g_monitoring = (mic_start(1) == 0);
    set_status("%s", g_monitoring ? "Playing (mic on): D-pad/A = keys, B = stop." : "Playing: D-pad/A = keys, B = stop.");
}

static void stop_play(void)
{
    rt_stop(&g_rt);
    if (g_monitoring) mic_stop();
    g_monitoring = 0;
    g_play = 0;
    audio_stop_all();
    if (g_player) {
        prj_clear(&g_prj);
        g_prj = g_stash;
        cv_reset();
        memset(&g_stash, 0, sizeof g_stash);
        g_player = 0;
        g_mode = g_stash_mode;
        select_sprite(g_stash_sprite);
        rt_reset(&g_rt, &g_prj);
    }
    set_status("%s", "Stopped.");
}

static void do_delete(void)
{
    if (g_mode == MODE_ABOUT) return;
    Sprite *sp = cur();
    switch (g_mode) {
    case MODE_SCRIPTS: {
        Block *node = focus_node();
        checkpoint();
        if (node && g_foc.slot < block_nslots_b(node) && node->a[g_foc.slot].expr >= 0) {
            prj_unplug(cur_script(), node, g_foc.slot);
            break;
        }
        if (g_foc.depth > 0) {
            int slot = g_foc.path[g_foc.depth - 1];
            focus_up();
            Block *parent = focus_node();
            if (parent) prj_unplug(cur_script(), parent, slot);
            break;
        }
        if (g_sel == 0) {
            if (prj_delete_script(&g_prj, g_sprite, g_script) == 0) { g_sel = 0; g_scroll = 0; focus_reset(); }
            else { undo_discard(&g_undo); set_status("%s", "Can't delete the only script."); }
        } else if (prj_delete_block(&g_prj, g_sprite, g_script, g_sel) < 0) {
            undo_discard(&g_undo);
            set_status("%s", "Select the C block itself (if / forever...) to delete it.");
        } else focus_reset();
        break; }
    case MODE_COSTUMES:
        cv_reset();
        if (prj_delete_costume(&g_prj, g_sprite, sp->cur_costume) < 0) set_status("%s", "A sprite needs at least one costume.");
        break;
    default:
        if (g_snd >= 0 && prj_delete_sound(&g_prj, g_sprite, g_snd) == 0 && g_snd >= sp->nsounds) g_snd = sp->nsounds - 1;
        break;
    }
    clamp_state();
}

static void do_undo(int redo)
{
    if (g_mode == MODE_COSTUMES) { cv_undo(); return; }
    if (g_mode != MODE_SCRIPTS) { set_status("%s", "Undo / redo work on scripts and costumes."); return; }
    int sp = redo ? undo_redo(&g_undo, &g_prj) : undo_undo(&g_undo, &g_prj);
    if (sp < 0) { set_status("%s", redo ? "Nothing to redo." : "Nothing to undo."); return; }
    if (sp != g_sprite) select_sprite(sp);
    focus_reset();
    clamp_state();
    set_status("%s", redo ? "Redone." : "Undone.");
}

static void do_duplicate(void)
{
    if (g_mode == MODE_ABOUT) return;
    switch (g_mode) {
    case MODE_SCRIPTS: {
        if (g_sprite == STAGE_IDX) return;
        checkpoint();
        if (g_sel == 0) {
            int n = prj_duplicate_script(&g_prj, g_sprite, g_script);
            if (n < 0) { undo_discard(&g_undo); set_status("%s", "Maximum number of scripts reached."); return; }
            g_script = n; g_sel = 0; g_scroll = 0;
            focus_reset();
            set_status("%s", "Script duplicated.");
        } else {
            int n = prj_duplicate_block(&g_prj, g_sprite, g_script, g_sel);
            if (n == -2) { undo_discard(&g_undo); set_status("%s", "Too many reporters in this script to copy it."); return; }
            if (n < 0) { undo_discard(&g_undo); set_status("%s", "Select a block (not its end / else marker) with room left in the script."); return; }
            g_sel = -1;
            select_block(n);
            set_status("%s", "Block duplicated.");
        }
        break; }
    case MODE_COSTUMES:
        cv_reset();
        if (prj_add_costume(&g_prj, g_sprite) < 0) set_status("%s", "Maximum number of costumes reached.");
        else set_status("%s", "Costume duplicated.");
        break;
    default: {
        int i = g_snd >= 0 ? prj_duplicate_sound(&g_prj, g_sprite, g_snd) : -1;
        if (i < 0) set_status("%s", g_snd < 0 ? "Select a sound first." : "Maximum number of sounds reached.");
        else { g_snd = i; set_status("%s", "Sound duplicated."); }
        break; }
    }
}

static void about_scroll(int d)
{
    int max = ABOUT_N - ABOUT_ROWS;
    g_about_scroll += d;
    if (g_about_scroll > max) g_about_scroll = max;
    if (g_about_scroll < 0) g_about_scroll = 0;
}

static void touch_about(int x, int y)
{
    if (hit(x, y, 294, 20, 24, 40)) about_scroll(-5);
    else if (hit(x, y, 294, 162, 24, 40)) about_scroll(+5);
}

static void touch_picker(int x, int y)
{
    if (hit(x, y, 2, PK_NAV_Y, 100, 18)) { if (g_pk.page > 0) g_pk.page--; return; }
    if (hit(x, y, 110, PK_NAV_Y, 100, 18)) { picker_close(); return; }
    if (hit(x, y, 218, PK_NAV_Y, 100, 18)) { if ((g_pk.page + 1) * PK_PER_PAGE < g_pk.n) g_pk.page++; return; }
    for (int i = 0; i < PK_PER_PAGE; i++) {
        int col = i / PK_ROWS, row = i % PK_ROWS, idx = g_pk.page * PK_PER_PAGE + i;
        if (idx < g_pk.n && hit(x, y, 2 + col * PK_COLSTEP, PK_Y + row * PK_ROW, PK_COLW, PK_ROW - 2)) { picker_choose(idx); return; }
    }
}

static void handle_touch(int x, int y)
{
    if (g_play) return;
    if (y < TAB_H) {
        for (int m = 0; m < MODE_COUNT; m++) if (hit(x, y, 1 + m * 70, 0, 68, TAB_H)) {
            if (m == MODE_SCRIPTS && g_sprite == STAGE_IDX) set_status("%s", "The Stage has no scripts: pick a sprite (name) to edit scripts.");
            else g_mode = m;
        }
        if (g_mode == MODE_SOUNDS && g_snd < 0 && cur()->nsounds > 0) g_snd = 0;
        picker_close();
        return;
    }
    if (g_mode != MODE_ABOUT && hit(x, y, 0, SPR_Y, 320, SPR_H)) {
        picker_close();
        if (g_recording) return;
        if (hit(x, y, 160, SPR_Y, 34, SPR_H)) {
            g_run_bottom = !g_run_bottom;
            save_settings();
            set_status("%s", g_run_bottom ? "Projects run on the BOTTOM screen (touch = stage)." : "Projects run on the TOP screen (bottom = touch pad).");
        } else if (hit(x, y, 0, SPR_Y, 158, SPR_H)) {
            for (int i = 0; i < g_prj.nsprites; i++) {
                char tmp[48];
                snprintf(tmp, sizeof tmp, "%d %.20s", i + 1, g_prj.sprites[i].name);
                project_copy_text(g_pk.items[i], tmp);
            }
            project_copy_text(g_pk.items[g_prj.nsprites], "Stage (backdrops)");
            g_pk.action = PK_SPRITE_LIST; g_pk.n = g_prj.nsprites + 1; g_pk.page = 0; g_pk.slot = 0;
            snprintf(g_pk.title, sizeof g_pk.title, "%s", "Go to sprite or Stage");
        } else if (hit(x, y, 196, SPR_Y, 22, SPR_H)) sprite_step(-1);
        else if (hit(x, y, 220, SPR_Y, 22, SPR_H)) sprite_step(+1);
        else if (hit(x, y, 244, SPR_Y, 22, SPR_H)) {
            int i = prj_add_sprite(&g_prj);
            if (i < 0) set_status("%s", "Maximum number of sprites reached."); else select_sprite(i);
        } else if (hit(x, y, 268, SPR_Y, 22, SPR_H)) {
            if (g_sprite == STAGE_IDX) set_status("%s", "The Stage can't be deleted (use Delete in Costumes for a backdrop).");
            else if (prj_delete_sprite(&g_prj, g_sprite) == 0) { undo_clear(&g_undo); cv_reset(); select_sprite(g_sprite < g_prj.nsprites ? g_sprite : g_prj.nsprites - 1); }
            else set_status("%s", "A project needs at least one sprite.");
        } else if (hit(x, y, 292, SPR_Y, 26, SPR_H)) {
            if (g_sprite == STAGE_IDX) set_status("%s", "Stage: draw backdrops in Costumes; the selected one is shown.");
            else open_sprite_menu();
        }
        return;
    }
    if (hit(x, y, 0, BTN_Y, 320, BTN_H)) {
        picker_close();
        switch (x / BTN_STEP) {
        case 0: start_play(); break;
        case 1: stop_play(); break;
        case 2: save_project(); break;
        case 3: if (!g_recording) do_delete(); break;
        case 4: if (!g_recording) do_undo(0); break;
        case 5: if (!g_recording) do_undo(1); break;
        default: if (!g_recording) do_duplicate(); break;
        }
        return;
    }
    if (g_pk.action != PK_NONE) { touch_picker(x, y); return; }
    switch (g_mode) {
    case MODE_SCRIPTS:  touch_scripts(x, y);  break;
    case MODE_COSTUMES: touch_costumes(x, y); break;
    case MODE_ABOUT:    touch_about(x, y);    break;
    default:            touch_sounds(x, y);   break;
    }
}

static void play_pointer(int x, int y, int down, int pressed)
{
    float sx = (float)x / PAD_S - STAGE_W / 2.0f, sy = STAGE_H / 2.0f - (float)y / PAD_S;
    rt_pointer(&g_rt, sx, sy, down);
    if (pressed) rt_click(&g_rt, &g_prj, sx, sy);
}

static void play_audio_events(void)
{
    SoundEvt ev;
    while (rt_pop_sound(&g_rt, &ev)) {
        if (ev.sound == SND_STOP) audio_stop_all();
        else if (ev.sound == SND_TONE) audio_tone(ev.freq, ev.ms, ev.wave, ev.vol);
        else if (ev.sound >= 0 && ev.sound < g_prj.sprites[ev.sprite].nsounds) audio_play(&g_prj.sprites[ev.sprite].sounds[ev.sound], ev.vol);
    }
}

static void play_ask(void)
{
    const char *prompt = rt_ask_pending(&g_rt);
    if (!prompt) return;
    char buf[TEXT_LEN];
    if (!ask(prompt, "", buf, sizeof buf)) buf[0] = 0;
    rt_answer(&g_rt, buf);
}

int main(void)
{
    gfxInitDefault();
    {
        bool is_new = false;
        if (R_SUCCEEDED(APT_CheckNew3DS(&is_new)) && is_new) { osSetSpeedupEnable(true); g_new3ds = 1; }
    }
    C3D_Init(C3D_DEFAULT_CMDBUF_SIZE);
    C2D_Init(C2D_DEFAULT_MAX_OBJECTS * 4);
    C2D_Prepare();
    C3D_RenderTarget *top = C2D_CreateScreenTarget(GFX_TOP, GFX_LEFT);
    C3D_RenderTarget *bot = C2D_CreateScreenTarget(GFX_BOTTOM, GFX_LEFT);
    g_text = C2D_TextBufNew(4096);
    audio_init();
    mic_init();
    load_settings();
    if (!g_audio_ok) audio_explain();
    mkdir("sdmc:/3ds", 0777);
    mkdir(SAVE_DIR, 0777);
    mkdir(IMPORT_DIR, 0777);

    prj_init(&g_prj);
    rt_reset(&g_rt, &g_prj);
    {
        struct stat st;
        if (stat(AUTOSAVE_FILE, &st) == 0) set_status("%s", "Found autosave.sb3: Spr > Open project to recover it.");
    }

    int frame_no = 0;
    while (aptMainLoop()) {
        hidScanInput();
        u32 kd = hidKeysDown(), kh = hidKeysHeld();
        if ((kh & KEY_L) && (kh & KEY_R) && (kd & KEY_Y)) {
            g_debug = !g_debug;
            if (g_debug) {
                g_dbg_t0 = osGetTime();
                dbg_log("debug on " APP_VERSION);
                set_status("%s", "Debug on (L+R+Y again to stop). Log: debug.log");
            } else set_status("%s", "Debug off.");
            frame_no++;
            continue;
        }
        if (kd & KEY_SELECT) { if (g_debug) dbg_log("exit"); autosave(); break; }
        if (!g_play && (kd || (kh & KEY_TOUCH))) g_dirty = 1;
        if (frame_no > 0 && frame_no % AUTOSAVE_FRAMES == 0) autosave();

        touchPosition tp;
        hidTouchRead(&tp);
        if (g_play) {
            if (kh & KEY_TOUCH) play_pointer(tp.px, tp.py, 1, (kd & KEY_TOUCH) != 0);
            else g_rt.mouse_down = 0;
        } else if (g_bs && g_pk.action == PK_NONE) {
            if (kh & KEY_TOUCH) bs_touch(tp.px, tp.py, (kd & KEY_TOUCH) != 0);
        } else {
            if (kd & KEY_TOUCH) drag_begin(tp.px, tp.py);
            else if (kh & KEY_TOUCH) drag_move(tp.px, tp.py);
            if (g_drag.src && !(kh & KEY_TOUCH)) drag_end();
            if (g_mode == MODE_COSTUMES && (kh & KEY_TOUCH)) paint_canvas(tp.px, tp.py, kd & KEY_TOUCH);
            if (hidKeysUp() & KEY_TOUCH) canvas_release();
        }

        if (g_play) {

            u32 k = kd | (((frame_no % 4) == 0) ? kh : 0);
            static const struct { u32 bit; const char *name; } map[] = {
                { KEY_DUP, "up arrow" }, { KEY_DDOWN, "down arrow" }, { KEY_DLEFT, "left arrow" }, { KEY_DRIGHT, "right arrow" },
                { KEY_A, "space" }, { KEY_X, "x" }, { KEY_Y, "y" }, { KEY_L, "l" }, { KEY_R, "r" },
            };
            for (unsigned i = 0; i < sizeof map / sizeof map[0]; i++) {
                rt_set_key(&g_rt, map[i].name, (kh & map[i].bit) != 0);
                if (k & map[i].bit) rt_key(&g_rt, &g_prj, map[i].name);
            }
            if (g_monitoring) { mic_poll(); rt_set_loudness(&g_rt, g_rec.level); }

            circlePosition cp;
            hidCircleRead(&cp);
            rt_set_pico(&g_rt, 50.f + cp.dx * 50.f / 156.f, 50.f + cp.dy * 50.f / 156.f,
                        (kh & KEY_TOUCH) ? tp.px * 100.f / 320.f : g_rt.pico_b,
                        (kh & KEY_TOUCH) ? 100.f - tp.py * 100.f / 240.f : g_rt.pico_c, (kh & KEY_A) != 0);
            if (kd & KEY_B) stop_play();
        } else {
            if (g_mode == MODE_ABOUT) {
                if (kd & KEY_DUP) about_scroll(-1);
                if (kd & KEY_DDOWN) about_scroll(+1);
            } else if (g_pk.action == PK_NONE && !g_recording && (kd & KEY_DUP)) bs_toggle_move();
            if ((kd & KEY_DLEFT) && !g_recording && g_pk.action == PK_NONE) g_light = !g_light;
            if (g_mode == MODE_SCRIPTS && g_pk.action == PK_NONE && !g_bs) {
                Sprite *sp = cur();
                if (kd & KEY_DDOWN) select_block(g_sel + 1);
                if (kd & KEY_DRIGHT) focus_move(+1);
                if (kd & KEY_A) edit_focused();
                (void)sp;
            }
            if (kd & KEY_L) sprite_step(-1);
            if (kd & KEY_R) sprite_step(+1);
            if ((kd & KEY_X) && !g_recording && !g_bs) do_delete();
            if (kd & KEY_Y) start_play();
            if (kd & KEY_B) { if (g_bs) g_bs = BS_OFF; else if (g_pk.action != PK_NONE) picker_close(); else stop_play(); }
            if (kd & KEY_START) save_project();
            if (g_recording) { mic_poll(); if (g_rec.full) rec_finish(); }
        }
        clamp_state();

        if (g_play) {
            rt_tick(&g_rt, &g_prj, 1.0f / 30.0f);
            play_audio_events();
            play_ask();
        } else rt_reset(&g_rt, &g_prj);
        frame_no++;

        C3D_FrameBegin(C3D_FRAME_SYNCDRAW);
        C2D_TextBufClear(g_text);
        C2D_TargetClear(top, RGB(0x1B1B20));
        C2D_TargetClear(bot, RGB(0x2B2B33));
        C2D_SceneBegin(top);
        draw_top();
        if (g_debug) draw_debug(frame_no, 6500 - g_budget);
        C2D_SceneBegin(bot);
        draw_bottom();
        C3D_FrameEnd(0);
    }

    if (g_recording) mic_stop();
    stop_play();
    audio_exit();
    mic_exit();
    prj_clear(&g_prj);
    C2D_TextBufDelete(g_text);
    C2D_Fini();
    C3D_Fini();
    gfxExit();
    return 0;
}
