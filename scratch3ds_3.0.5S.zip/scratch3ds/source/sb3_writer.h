#ifndef SB3_WRITER_H
#define SB3_WRITER_H

#include <stddef.h>
#include "project.h"

int sb3_write_project(const Project *p, const char *path);

void sb3_md5_hex(const void *data, size_t n, char out[33]);
unsigned sb3_crc32(const void *data, size_t n);

#endif
