#include "importer.h"

#include <ctype.h>
#include <dirent.h>
#include <math.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>

#include "assets.h"

#define MAX_DIM    4096
#define MAX_PIXELS (4u * 1024u * 1024u)
#define MAX_FILE   (16u * 1024u * 1024u)

static void seterr(char *err, size_t n, const char *msg) { if (err && n) snprintf(err, n, "%s", msg); }

static void clean_name(char *dst, const char *src)
{
    int n = 0;
    while (*src == ' ') src++;
    for (; *src && n < TEXT_LEN - 1; src++) if ((unsigned char)*src >= 32 && *src != 127) dst[n++] = *src;
    while (n > 0 && dst[n - 1] == ' ') n--;
    dst[n] = 0;
    if (!n) strcpy(dst, "sprite");
}

static int ext_is(const char *name, const char *ext)
{
    size_t a = strlen(name), b = strlen(ext);
    if (a <= b) return 0;
    for (size_t i = 0; i < b; i++) if (tolower((unsigned char)name[a - b + i]) != ext[i]) return 0;
    return name[a - b - 1] == '.';
}
static int is_image_name(const char *n) { return ext_is(n, "png") || ext_is(n, "bmp") || ext_is(n, "ppm"); }
static int is_wav_name(const char *n)   { return ext_is(n, "wav"); }

static void stem_of(const char *file, char *out)
{
    char tmp[256];
    snprintf(tmp, sizeof tmp, "%s", file);
    char *dot = strrchr(tmp, '.');
    if (dot) *dot = 0;
    clean_name(out, tmp);
}

static int ci_cmp(const char *a, const char *b)
{
    for (; *a && *b; a++, b++) {
        int x = tolower((unsigned char)*a), y = tolower((unsigned char)*b);
        if (x != y) return x - y;
    }
    return tolower((unsigned char)*a) - tolower((unsigned char)*b);
}
static int cmp_entry(const void *a, const void *b) { return ci_cmp(((const ImportEntry *)a)->name, ((const ImportEntry *)b)->name); }

static unsigned char *read_file(const char *path, size_t *len, char *err, size_t errn)
{
    FILE *f = fopen(path, "rb");
    if (!f) { seterr(err, errn, "Can't open file."); return NULL; }
    fseek(f, 0, SEEK_END);
    long sz = ftell(f);
    fseek(f, 0, SEEK_SET);
    if (sz <= 0 || (unsigned long)sz > MAX_FILE) { fclose(f); seterr(err, errn, sz <= 0 ? "Empty file." : "File too large (16 MB max)."); return NULL; }
    unsigned char *buf = malloc((size_t)sz);
    if (!buf || fread(buf, 1, (size_t)sz, f) != (size_t)sz) { free(buf); fclose(f); seterr(err, errn, "Read error."); return NULL; }
    fclose(f);
    *len = (size_t)sz;
    return buf;
}

typedef struct { const unsigned char *src; size_t n, pos; unsigned bitbuf; int bitcnt; unsigned char *dst; size_t cap, out; int err; } Inf;
typedef struct { unsigned short count[16], sym[288]; } Huff;

static unsigned inf_bits(Inf *s, int need)
{
    unsigned v = s->bitbuf;
    while (s->bitcnt < need) {
        if (s->pos >= s->n) { s->err = 1; return 0; }
        v |= (unsigned)s->src[s->pos++] << s->bitcnt;
        s->bitcnt += 8;
    }
    s->bitbuf = v >> need;
    s->bitcnt -= need;
    return v & ((1u << need) - 1);
}

static void huff_build(Huff *h, const unsigned char *len, int n)
{
    unsigned short offs[16];
    memset(h->count, 0, sizeof h->count);
    for (int i = 0; i < n; i++) h->count[len[i]]++;
    h->count[0] = 0;
    offs[1] = 0;
    for (int i = 1; i < 15; i++) offs[i + 1] = (unsigned short)(offs[i] + h->count[i]);
    for (int i = 0; i < n; i++) if (len[i]) h->sym[offs[len[i]]++] = (unsigned short)i;
}

static int huff_decode(Inf *s, const Huff *h)
{
    int code = 0, first = 0, index = 0;
    for (int len = 1; len <= 15; len++) {
        code |= (int)inf_bits(s, 1);
        if (s->err) return -1;
        int count = h->count[len];
        if (code - count < first) return h->sym[index + (code - first)];
        index += count; first += count; first <<= 1; code <<= 1;
    }
    return -1;
}

static const unsigned short LBASE[29] = { 3,4,5,6,7,8,9,10,11,13,15,17,19,23,27,31,35,43,51,59,67,83,99,115,131,163,195,227,258 };
static const unsigned short LEXT[29]  = { 0,0,0,0,0,0,0,0,1,1,1,1,2,2,2,2,3,3,3,3,4,4,4,4,5,5,5,5,0 };
static const unsigned short DBASE[30] = { 1,2,3,4,5,7,9,13,17,25,33,49,65,97,129,193,257,385,513,769,1025,1537,2049,3073,4097,6145,8193,12289,16385,24577 };
static const unsigned short DEXT[30]  = { 0,0,0,0,1,1,2,2,3,3,4,4,5,5,6,6,7,7,8,8,9,9,10,10,11,11,12,12,13,13 };

static int inf_codes(Inf *s, const Huff *lit, const Huff *dist)
{
    for (;;) {
        int sym = huff_decode(s, lit);
        if (sym < 0) return -1;
        if (sym < 256) {
            if (s->out >= s->cap) return -1;
            s->dst[s->out++] = (unsigned char)sym;
        } else if (sym == 256) {
            return 0;
        } else {
            sym -= 257;
            if (sym >= 29) return -1;
            size_t len = LBASE[sym] + inf_bits(s, LEXT[sym]);
            int ds = huff_decode(s, dist);
            if (ds < 0 || ds >= 30) return -1;
            size_t d = DBASE[ds] + inf_bits(s, DEXT[ds]);
            if (s->err || d > s->out || s->out + len > s->cap) return -1;
            for (size_t i = 0; i < len; i++) { s->dst[s->out] = s->dst[s->out - d]; s->out++; }
        }
    }
}

static int inf_dynamic(Inf *s)
{
    static const unsigned char ORDER[19] = { 16,17,18,0,8,7,9,6,10,5,11,4,12,3,13,2,14,1,15 };
    unsigned char lens[320];
    Huff lit, dist, lc;
    unsigned nlen = inf_bits(s, 5) + 257, ndist = inf_bits(s, 5) + 1, ncode = inf_bits(s, 4) + 4;
    if (s->err || nlen > 286 || ndist > 30) return -1;
    memset(lens, 0, sizeof lens);
    for (unsigned i = 0; i < ncode; i++) lens[ORDER[i]] = (unsigned char)inf_bits(s, 3);
    huff_build(&lc, lens, 19);
    unsigned idx = 0;
    unsigned char all[320];
    while (idx < nlen + ndist) {
        int sym = huff_decode(s, &lc);
        if (sym < 0) return -1;
        if (sym < 16) all[idx++] = (unsigned char)sym;
        else {
            int rep, val = 0;
            if (sym == 16) { if (idx == 0) return -1; val = all[idx - 1]; rep = 3 + (int)inf_bits(s, 2); }
            else if (sym == 17) rep = 3 + (int)inf_bits(s, 3);
            else rep = 11 + (int)inf_bits(s, 7);
            if (idx + (unsigned)rep > nlen + ndist) return -1;
            while (rep--) all[idx++] = (unsigned char)val;
        }
        if (s->err) return -1;
    }
    huff_build(&lit, all, (int)nlen);
    huff_build(&dist, all + nlen, (int)ndist);
    return inf_codes(s, &lit, &dist);
}

int inflate_zlib(const unsigned char *src, size_t n, unsigned char *dst, size_t cap, size_t *outlen)
{
    if (n < 6 || (src[0] & 15) != 8 || ((src[0] << 8) | src[1]) % 31) return -1;
    Inf s; memset(&s, 0, sizeof s);
    s.src = src; s.n = n; s.pos = 2; s.dst = dst; s.cap = cap;
    if (src[1] & 0x20) return -1;
    static Huff fixl, fixd; static int fixed_ready;
    if (!fixed_ready) {
        unsigned char l[288];
        for (int i = 0; i < 144; i++) l[i] = 8;
        for (int i = 144; i < 256; i++) l[i] = 9;
        for (int i = 256; i < 280; i++) l[i] = 7;
        for (int i = 280; i < 288; i++) l[i] = 8;
        huff_build(&fixl, l, 288);
        for (int i = 0; i < 30; i++) l[i] = 5;
        huff_build(&fixd, l, 30);
        fixed_ready = 1;
    }
    int last;
    do {
        last = (int)inf_bits(&s, 1);
        int type = (int)inf_bits(&s, 2), rc;
        if (s.err) return -1;
        if (type == 0) {
            s.bitbuf = 0; s.bitcnt = 0;
            if (s.pos + 4 > s.n) return -1;
            unsigned len = s.src[s.pos] | (unsigned)s.src[s.pos + 1] << 8, nlen = s.src[s.pos + 2] | (unsigned)s.src[s.pos + 3] << 8;
            s.pos += 4;
            if ((len ^ 0xFFFF) != nlen || s.pos + len > s.n || s.out + len > s.cap) return -1;
            memcpy(s.dst + s.out, s.src + s.pos, len);
            s.pos += len; s.out += len;
            rc = 0;
        } else if (type == 1) rc = inf_codes(&s, &fixl, &fixd);
        else if (type == 2) rc = inf_dynamic(&s);
        else return -1;
        if (rc) return -1;
    } while (!last);
    *outlen = s.out;
    return 0;
}

static unsigned be32(const unsigned char *p) { return (unsigned)p[0] << 24 | (unsigned)p[1] << 16 | (unsigned)p[2] << 8 | p[3]; }

static int png_decode(const unsigned char *d, size_t n, int *ow, int *oh, unsigned char **orgba, char *err, size_t errn)
{
    static const unsigned char SIG[8] = { 137, 80, 78, 71, 13, 10, 26, 10 };
    if (n < 33 || memcmp(d, SIG, 8)) { seterr(err, errn, "Not a PNG."); return -1; }
    unsigned w = 0, h = 0; int depth = 0, ctype = 0, inter = 0;
    unsigned char pal[256][4]; int npal = 0;
    for (int i = 0; i < 256; i++) { pal[i][0] = pal[i][1] = pal[i][2] = 0; pal[i][3] = 255; }
    int have_key = 0; unsigned key[3] = { 0, 0, 0 };
    unsigned char *idat = malloc(n); size_t nidat = 0;
    unsigned char *raw = NULL, *rgba = NULL;
    int rc = -1;
    if (!idat) { seterr(err, errn, "Out of memory."); return -1; }
    size_t pos = 8;
    int seen_end = 0;
    while (pos + 12 <= n) {
        unsigned len = be32(d + pos);
        const unsigned char *t = d + pos + 4, *body = d + pos + 8;
        if (len > n || pos + 12 + len > n) break;
        if (!memcmp(t, "IHDR", 4) && len >= 13) {
            w = be32(body); h = be32(body + 4); depth = body[8]; ctype = body[9]; inter = body[12];
        } else if (!memcmp(t, "PLTE", 4)) {
            npal = (int)(len / 3); if (npal > 256) npal = 256;
            for (int i = 0; i < npal; i++) { pal[i][0] = body[3 * i]; pal[i][1] = body[3 * i + 1]; pal[i][2] = body[3 * i + 2]; }
        } else if (!memcmp(t, "tRNS", 4)) {
            if (ctype == 3) for (unsigned i = 0; i < len && i < 256; i++) pal[i][3] = body[i];
            else if (ctype == 0 && len >= 2) { have_key = 1; key[0] = body[0] << 8 | body[1]; }
            else if (ctype == 2 && len >= 6) { have_key = 1; for (int c = 0; c < 3; c++) key[c] = body[2 * c] << 8 | body[2 * c + 1]; }
        } else if (!memcmp(t, "IDAT", 4)) {
            memcpy(idat + nidat, body, len); nidat += len;
        } else if (!memcmp(t, "IEND", 4)) { seen_end = 1; break; }
        pos += 12 + len;
    }
    (void)seen_end;
    int chans = ctype == 0 ? 1 : ctype == 2 ? 3 : ctype == 3 ? 1 : ctype == 4 ? 2 : ctype == 6 ? 4 : 0;
    if (!w || !h || w > MAX_DIM || h > MAX_DIM || (unsigned long)w * h > MAX_PIXELS || !chans || !nidat) { seterr(err, errn, "Unsupported or damaged PNG."); goto done; }
    if (inter) { seterr(err, errn, "Interlaced PNG not supported."); goto done; }
    if (!(depth == 8 || depth == 16 || ((ctype == 0 || ctype == 3) && (depth == 1 || depth == 2 || depth == 4)))) { seterr(err, errn, "Unsupported PNG bit depth."); goto done; }
    if (ctype == 3 && !npal) { seterr(err, errn, "PNG has no palette."); goto done; }
    size_t bits = (size_t)chans * (size_t)depth, stride = (w * bits + 7) / 8, bpp = bits >= 8 ? bits / 8 : 1;
    size_t rawsz = (stride + 1) * h, got = 0;
    raw = malloc(rawsz);
    rgba = malloc((size_t)w * h * 4);
    if (!raw || !rgba) { seterr(err, errn, "Out of memory."); goto done; }
    if (inflate_zlib(idat, nidat, raw, rawsz, &got) != 0 || got < rawsz) { seterr(err, errn, "PNG data is damaged."); goto done; }
    for (unsigned y = 0; y < h; y++) {
        unsigned char *row = raw + y * (stride + 1) + 1, *prev = y ? row - (stride + 1) : NULL;
        int f = row[-1];
        if (f > 4) { seterr(err, errn, "PNG data is damaged."); goto done; }
        for (size_t i = 0; i < stride; i++) {
            int a = i >= bpp ? row[i - bpp] : 0, b = prev ? prev[i] : 0, c = (prev && i >= bpp) ? prev[i - bpp] : 0, v = row[i];
            switch (f) {
            case 1: v += a; break;
            case 2: v += b; break;
            case 3: v += (a + b) / 2; break;
            case 4: { int p = a + b - c, pa = abs(p - a), pb = abs(p - b), pc = abs(p - c); v += (pa <= pb && pa <= pc) ? a : (pb <= pc ? b : c); break; }
            default: break;
            }
            row[i] = (unsigned char)v;
        }
    }
    for (unsigned y = 0; y < h; y++) {
        const unsigned char *row = raw + y * (stride + 1) + 1;
        for (unsigned x = 0; x < w; x++) {
            unsigned char *o = rgba + ((size_t)y * w + x) * 4;
            unsigned s[4] = { 0, 0, 0, 0 };
            for (int c = 0; c < chans; c++) {
                if (depth == 8) s[c] = row[x * chans + c];
                else if (depth == 16) s[c] = row[(x * chans + c) * 2] << 8 | row[(x * chans + c) * 2 + 1];
                else { size_t bit = (size_t)x * depth; s[c] = (row[bit / 8] >> (8 - depth - bit % 8)) & ((1u << depth) - 1); }
            }
            unsigned r, g, b, a = 255, sc = depth == 16 ? 8 : 0;
            if (ctype == 3) { unsigned i = s[0] < 256 ? s[0] : 0; r = pal[i][0]; g = pal[i][1]; b = pal[i][2]; a = pal[i][3]; }
            else if (ctype == 0) {
                unsigned v = depth < 8 ? s[0] * 255 / ((1u << depth) - 1) : s[0] >> sc;
                r = g = b = v;
                if (have_key && s[0] == key[0]) a = 0;
            } else if (ctype == 4) { r = g = b = s[0] >> sc; a = s[1] >> sc; }
            else {
                r = s[0] >> sc; g = s[1] >> sc; b = s[2] >> sc;
                if (ctype == 6) a = s[3] >> sc;
                else if (have_key && s[0] == key[0] && s[1] == key[1] && s[2] == key[2]) a = 0;
            }
            o[0] = (unsigned char)r; o[1] = (unsigned char)g; o[2] = (unsigned char)b; o[3] = (unsigned char)a;
        }
    }
    *ow = (int)w; *oh = (int)h; *orgba = rgba; rgba = NULL; rc = 0;
done:
    free(idat); free(raw); free(rgba);
    return rc;
}

static unsigned le16(const unsigned char *p) { return p[0] | (unsigned)p[1] << 8; }
static unsigned le32(const unsigned char *p) { return p[0] | (unsigned)p[1] << 8 | (unsigned)p[2] << 16 | (unsigned)p[3] << 24; }

static int bmp_decode(const unsigned char *d, size_t n, int *ow, int *oh, unsigned char **orgba, char *err, size_t errn)
{
    if (n < 54 || d[0] != 'B' || d[1] != 'M') { seterr(err, errn, "Not a BMP."); return -1; }
    unsigned off = le32(d + 10), dib = le32(d + 14);
    if (dib < 40) { seterr(err, errn, "Old BMP header not supported."); return -1; }
    int w = (int)le32(d + 18), h = (int)le32(d + 22), bpp = (int)le16(d + 28);
    unsigned comp = le32(d + 30), ncol = le32(d + 46);
    int top_down = h < 0;
    if (top_down) h = -h;
    if (w <= 0 || h <= 0 || w > MAX_DIM || h > MAX_DIM || (unsigned long)w * (unsigned long)h > MAX_PIXELS) { seterr(err, errn, "Bad BMP size."); return -1; }
    if (comp != 0 && !(comp == 3 && bpp == 32)) { seterr(err, errn, "Compressed BMP not supported."); return -1; }
    if (bpp != 8 && bpp != 24 && bpp != 32) { seterr(err, errn, "BMP must be 8, 24 or 32 bit."); return -1; }
    size_t stride = (((size_t)w * (size_t)bpp + 31) / 32) * 4;
    if (off >= n || off + stride * (size_t)h > n) { seterr(err, errn, "BMP data is truncated."); return -1; }
    const unsigned char *pal = d + 14 + dib;
    unsigned npal = ncol ? ncol : 256;
    if (bpp == 8 && (14 + (size_t)dib + 4 * (size_t)npal > n)) { seterr(err, errn, "BMP palette is truncated."); return -1; }
    unsigned char *rgba = malloc((size_t)w * (size_t)h * 4);
    if (!rgba) { seterr(err, errn, "Out of memory."); return -1; }
    int any_alpha = 0;
    for (int y = 0; y < h; y++) {
        const unsigned char *row = d + off + stride * (size_t)(top_down ? y : h - 1 - y);
        for (int x = 0; x < w; x++) {
            unsigned char *o = rgba + ((size_t)y * (size_t)w + (size_t)x) * 4;
            const unsigned char *p;
            if (bpp == 8) { unsigned i = row[x]; if (i >= npal) i = 0; p = pal + 4 * i; }
            else p = row + (size_t)x * (size_t)(bpp / 8);
            o[0] = p[2]; o[1] = p[1]; o[2] = p[0];
            o[3] = bpp == 32 ? p[3] : 255;
            if (bpp == 32 && p[3]) any_alpha = 1;
        }
    }
    for (size_t i = 0; i < (size_t)w * (size_t)h; i++) {
        unsigned char *o = rgba + i * 4;
        if (bpp == 32 && !any_alpha) o[3] = 255;
        if (o[0] == 255 && o[1] == 0 && o[2] == 255) o[3] = 0;
    }
    *ow = w; *oh = h; *orgba = rgba;
    return 0;
}

static int ppm_next(const unsigned char *d, size_t n, size_t *pos)
{
    while (*pos < n) {
        if (isspace(d[*pos])) (*pos)++;
        else if (d[*pos] == '#') { while (*pos < n && d[*pos] != '\n') (*pos)++; }
        else break;
    }
    if (*pos >= n || !isdigit(d[*pos])) return -1;
    long v = 0;
    while (*pos < n && isdigit(d[*pos])) { v = v * 10 + (d[*pos] - '0'); (*pos)++; if (v > 100000) return -1; }
    return (int)v;
}

static int ppm_decode(const unsigned char *d, size_t n, int *ow, int *oh, unsigned char **orgba, char *err, size_t errn)
{
    if (n < 10 || d[0] != 'P' || d[1] != '6') { seterr(err, errn, "Only binary PPM (P6) is supported."); return -1; }
    size_t pos = 2;
    int w = ppm_next(d, n, &pos), h = ppm_next(d, n, &pos), mx = ppm_next(d, n, &pos);
    if (w <= 0 || h <= 0 || w > MAX_DIM || h > MAX_DIM || mx != 255 || (unsigned long)w * (unsigned long)h > MAX_PIXELS) { seterr(err, errn, "Bad PPM header."); return -1; }
    pos++;
    if (pos + (size_t)w * (size_t)h * 3 > n) { seterr(err, errn, "PPM data is truncated."); return -1; }
    unsigned char *rgba = malloc((size_t)w * (size_t)h * 4);
    if (!rgba) { seterr(err, errn, "Out of memory."); return -1; }
    for (size_t i = 0; i < (size_t)w * (size_t)h; i++) {
        const unsigned char *p = d + pos + i * 3;
        rgba[4 * i] = p[0]; rgba[4 * i + 1] = p[1]; rgba[4 * i + 2] = p[2];
        rgba[4 * i + 3] = (p[0] == 255 && p[1] == 0 && p[2] == 255) ? 0 : 255;
    }
    *ow = w; *oh = h; *orgba = rgba;
    return 0;
}

int img_decode(const char *path, int *w, int *h, unsigned char **rgba, char *err, size_t errn)
{
    size_t len;
    unsigned char *d = read_file(path, &len, err, errn);
    if (!d) return -1;
    int rc;
    if (len > 8 && d[0] == 137 && d[1] == 'P') rc = png_decode(d, len, w, h, rgba, err, errn);
    else if (len > 2 && d[0] == 'B' && d[1] == 'M') rc = bmp_decode(d, len, w, h, rgba, err, errn);
    else if (len > 2 && d[0] == 'P') rc = ppm_decode(d, len, w, h, rgba, err, errn);
    else { seterr(err, errn, "Unknown image format (use PNG, BMP or PPM)."); rc = -1; }
    free(d);
    return rc;
}

void img_to_costume(const unsigned char *rgba, int w, int h, Costume *c)
{
    costume_clear(c);
    float s = (float)COSTUME_W / (float)(w > h ? w : h);
    int dw = (int)(w * s + 0.5f), dh = (int)(h * s + 0.5f);
    if (dw < 1) dw = 1;
    if (dh < 1) dh = 1;
    if (dw > COSTUME_W) dw = COSTUME_W;
    if (dh > COSTUME_H) dh = COSTUME_H;
    int ox = (COSTUME_W - dw) / 2, oy = (COSTUME_H - dh) / 2;
    for (int y = 0; y < dh; y++) for (int x = 0; x < dw; x++) {
        int x0 = x * w / dw, x1 = (x + 1) * w / dw, y0 = y * h / dh, y1 = (y + 1) * h / dh;
        if (x1 <= x0) x1 = x0 + 1;
        if (y1 <= y0) y1 = y0 + 1;
        unsigned long sa = 0, sr = 0, sg = 0, sb = 0, cnt = 0;
        for (int yy = y0; yy < y1 && yy < h; yy++) for (int xx = x0; xx < x1 && xx < w; xx++) {
            const unsigned char *p = rgba + ((size_t)yy * (size_t)w + (size_t)xx) * 4;
            sa += p[3]; sr += (unsigned long)p[0] * p[3]; sg += (unsigned long)p[1] * p[3]; sb += (unsigned long)p[2] * p[3]; cnt++;
        }
        if (!cnt || sa * 2 < cnt * 128) continue;
        int r = (int)(sr / sa), g = (int)(sg / sa), b = (int)(sb / sa), best = 1;
        long bd = 1L << 40;
        for (int i = 1; i < PAL_N; i++) {
            int pr = (PALETTE_RGB[i] >> 16) & 255, pg = (PALETTE_RGB[i] >> 8) & 255, pb = PALETTE_RGB[i] & 255;
            long d = 2L * (r - pr) * (r - pr) + 4L * (g - pg) * (g - pg) + 3L * (b - pb) * (b - pb);
            if (d < bd) { bd = d; best = i; }
        }
        c->px[(oy + y) * COSTUME_W + ox + x] = (uint8_t)best;
    }
}

int wav_load(const char *path, int16_t **pcm, int *n, int *rate, char *err, size_t errn)
{
    FILE *f = fopen(path, "rb");
    if (!f) { seterr(err, errn, "Can't open file."); return -1; }
    unsigned char h[12];
    if (fread(h, 1, 12, f) != 12 || memcmp(h, "RIFF", 4) || memcmp(h + 8, "WAVE", 4)) { fclose(f); seterr(err, errn, "Not a WAV file."); return -1; }
    int fmt_ok = 0, ch = 0, bits = 0, src_rate = 0, rc = -1;
    long data_pos = -1; unsigned data_len = 0;
    for (;;) {
        unsigned char ck[8];
        if (fread(ck, 1, 8, f) != 8) break;
        unsigned len = le32(ck + 4);
        if (!memcmp(ck, "fmt ", 4) && len >= 16 && len < 256) {
            unsigned char b[256];
            if (fread(b, 1, len, f) != len) break;
            unsigned tag = le16(b);
            if (tag == 0xFFFE && len >= 26) tag = le16(b + 24);
            ch = (int)le16(b + 2); src_rate = (int)le32(b + 4); bits = (int)le16(b + 14);
            fmt_ok = (tag == 1);
            if (len & 1) fseek(f, 1, SEEK_CUR);
        } else if (!memcmp(ck, "data", 4)) {
            data_pos = ftell(f); data_len = len;
            break;
        } else {
            if (fseek(f, (long)len + (long)(len & 1), SEEK_CUR) != 0) break;
        }
    }
    if (!fmt_ok || (bits != 8 && bits != 16) || ch < 1 || ch > 2 || src_rate < 2000 || src_rate > 192000) {
        fclose(f); seterr(err, errn, "WAV must be PCM 8/16-bit, mono or stereo."); return -1;
    }
    if (data_pos < 0) { fclose(f); seterr(err, errn, "WAV has no data."); return -1; }
    fseek(f, 0, SEEK_END);
    long fsz = ftell(f);
    fseek(f, data_pos, SEEK_SET);
    if (data_len > (unsigned long)(fsz - data_pos)) data_len = (unsigned)(fsz - data_pos);
    int out_rate = src_rate > SND_RATE ? SND_RATE : src_rate;
    double step = (double)src_rate / out_rate;
    int16_t *out = malloc(REC_MAX_SAMPLES * sizeof(int16_t));
    if (!out) { fclose(f); seterr(err, errn, "Out of memory."); return -1; }
    size_t frame = (size_t)ch * (size_t)(bits / 8), frames = data_len / frame, no = 0;
    unsigned char buf[4096];
    double acc = 0; int cnt = 0; long cur = 0; size_t done = 0;
    while (done < frames && no < REC_MAX_SAMPLES) {
        size_t want = frames - done < sizeof buf / frame ? frames - done : sizeof buf / frame;
        if (fread(buf, frame, want, f) != want) break;
        for (size_t i = 0; i < want && no < REC_MAX_SAMPLES; i++, done++) {
            double m = 0;
            for (int c = 0; c < ch; c++) {
                const unsigned char *p = buf + i * frame + (size_t)c * (size_t)(bits / 8);
                m += bits == 8 ? ((int)p[0] - 128) * 256.0 : (double)(int16_t)le16(p);
            }
            m /= ch;
            long o = (long)((double)done / step);
            if (o != cur && cnt) { out[no++] = (int16_t)(acc / cnt); acc = 0; cnt = 0; cur = o; if (no >= REC_MAX_SAMPLES) break; }
            acc += m; cnt++; cur = o;
        }
    }
    if (cnt && no < REC_MAX_SAMPLES) out[no++] = (int16_t)(acc / cnt);
    fclose(f);
    if (no < 16) { free(out); seterr(err, errn, "WAV is empty."); return -1; }
    *pcm = out; *n = (int)no; *rate = out_rate; rc = 0;
    return rc;
}

int imp_scan(const char *root, ImportEntry *out, int max)
{
    DIR *d = opendir(root);
    if (!d) return 0;
    int n = 0;
    struct dirent *de;
    while ((de = readdir(d)) && n < max) {
        if (de->d_name[0] == '.') continue;
        ImportEntry *e = &out[n];
        int len = snprintf(e->path, sizeof e->path, "%s/%s", root, de->d_name);
        if (len < 0 || len >= (int)sizeof e->path) continue;
        struct stat st;
        if (stat(e->path, &st) != 0) continue;
        if (S_ISDIR(st.st_mode)) { e->is_dir = 1; clean_name(e->name, de->d_name); }
        else if (S_ISREG(st.st_mode) && is_image_name(de->d_name)) { e->is_dir = 0; stem_of(de->d_name, e->name); }
        else continue;
        n++;
    }
    closedir(d);
    qsort(out, (size_t)n, sizeof *out, cmp_entry);
    return n;
}

typedef struct { char name[256]; } FName;
static int cmp_fname(const void *a, const void *b) { return ci_cmp(((const FName *)a)->name, ((const FName *)b)->name); }

static void unique_in(char *name, char (*existing)[TEXT_LEN], int n)
{
    char base[TEXT_LEN];
    snprintf(base, sizeof base, "%s", name);
    for (int k = 2; k < 1000; k++) {
        int clash = 0;
        for (int i = 0; i < n; i++) if (strcmp(existing[i], name) == 0) clash = 1;
        if (!clash) return;
        char suf[8];
        snprintf(suf, sizeof suf, "%d", k);
        size_t room = TEXT_LEN - 1 - strlen(suf);
        snprintf(name, TEXT_LEN, "%.*s%s", (int)room, base, suf);
    }
}

static int clampi(int v, int lo, int hi) { return v < lo ? lo : v > hi ? hi : v; }

static void read_props(const char *dir, Sprite *s, char *want_costume, size_t wn)
{
    char path[IMP_PATH_LEN + 16];
    snprintf(path, sizeof path, "%s/sprite.txt", dir);
    FILE *f = fopen(path, "r");
    want_costume[0] = 0;
    if (!f) return;
    char line[256];
    while (fgets(line, sizeof line, f)) {
        char *p = line;
        while (*p == ' ' || *p == '\t') p++;
        if (*p == '#' || *p == ';' || !*p || *p == '\n') continue;
        char *sep = strpbrk(p, "=:");
        if (!sep) continue;
        *sep = 0;
        char *key = p, *val = sep + 1;
        for (char *q = key + strlen(key); q > key && (q[-1] == ' ' || q[-1] == '\t'); ) *--q = 0;
        while (*val == ' ' || *val == '\t') val++;
        for (char *q = val + strlen(val); q > val && (q[-1] == ' ' || q[-1] == '\t' || q[-1] == '\n' || q[-1] == '\r'); ) *--q = 0;
        for (char *q = key; *q; q++) *q = (char)tolower((unsigned char)*q);
        if (!strcmp(key, "name") && *val) clean_name(s->name, val);
        else if (!strcmp(key, "x")) s->x = clampi(atoi(val), -STAGE_W / 2, STAGE_W / 2);
        else if (!strcmp(key, "y")) s->y = clampi(atoi(val), -STAGE_H / 2, STAGE_H / 2);
        else if (!strcmp(key, "direction")) { int dir = atoi(val) % 360; if (dir > 180) dir -= 360; if (dir <= -180) dir += 360; s->direction = dir; }
        else if (!strcmp(key, "size")) s->size = clampi(atoi(val), 5, 500);
        else if (!strcmp(key, "visible")) s->visible = !(!strcmp(val, "0") || !ci_cmp(val, "false") || !ci_cmp(val, "no") || !ci_cmp(val, "off") || !ci_cmp(val, "hidden"));
        else if (!strcmp(key, "costume")) snprintf(want_costume, wn, "%s", val);
    }
    fclose(f);
}

int imp_load_sprite(const ImportEntry *e, Sprite *out, char *err, size_t errn)
{
    memset(out, 0, sizeof *out);
    out->direction = 90; out->visible = 1; out->size = 100;
    clean_name(out->name, e->name);
    if (err && errn) err[0] = 0;
    int bad = 0, extra = 0;
    char lasterr[96] = "";
    char want[TEXT_LEN];
    want[0] = 0;

    if (!e->is_dir) {
        int w, h; unsigned char *px;
        if (img_decode(e->path, &w, &h, &px, lasterr, sizeof lasterr) != 0) { seterr(err, errn, lasterr); return -1; }
        img_to_costume(px, w, h, &out->costumes[0]);
        free(px);
        snprintf(out->costumes[0].name, TEXT_LEN, "costume1");
        out->ncostumes = 1;
        return 0;
    }

    read_props(e->path, out, want, sizeof want);
    DIR *d = opendir(e->path);
    if (!d) { seterr(err, errn, "Can't open the folder."); return -1; }
    FName *files = malloc(256 * sizeof *files);
    int nf = 0;
    struct dirent *de;
    while (files && (de = readdir(d)) && nf < 256) {
        if (de->d_name[0] == '.') continue;
        if (is_image_name(de->d_name) || is_wav_name(de->d_name)) snprintf(files[nf++].name, sizeof files[0].name, "%s", de->d_name);
    }
    closedir(d);
    if (!files) { seterr(err, errn, "Out of memory."); return -1; }
    qsort(files, (size_t)nf, sizeof *files, cmp_fname);

    char cnames[MAX_COSTUMES][TEXT_LEN], snames[MAX_SOUNDS][TEXT_LEN];
    for (int i = 0; i < nf; i++) {
        char path[IMP_PATH_LEN + 270];
        snprintf(path, sizeof path, "%s/%s", e->path, files[i].name);
        if (is_image_name(files[i].name)) {
            if (out->ncostumes >= MAX_COSTUMES) { extra++; continue; }
            int w, h; unsigned char *px;
            if (img_decode(path, &w, &h, &px, lasterr, sizeof lasterr) != 0) { bad++; continue; }
            Costume *c = &out->costumes[out->ncostumes];
            img_to_costume(px, w, h, c);
            free(px);
            stem_of(files[i].name, c->name);
            unique_in(c->name, cnames, out->ncostumes);
            snprintf(cnames[out->ncostumes], TEXT_LEN, "%s", c->name);
            out->ncostumes++;
        } else {
            if (out->nsounds >= MAX_SOUNDS) { extra++; continue; }
            int16_t *pcm; int n, rate;
            if (wav_load(path, &pcm, &n, &rate, lasterr, sizeof lasterr) != 0) { bad++; continue; }
            Sound *s = &out->sounds[out->nsounds];
            snd_default(s);
            int rc = snd_set_pcm(s, pcm, n, rate);
            free(pcm);
            if (rc != 0) { bad++; continue; }
            s->vol = 100;
            stem_of(files[i].name, s->name);
            unique_in(s->name, snames, out->nsounds);
            snprintf(snames[out->nsounds], TEXT_LEN, "%s", s->name);
            out->nsounds++;
        }
    }
    free(files);
    if (out->ncostumes == 0) {
        for (int k = 0; k < MAX_SOUNDS; k++) snd_free(&out->sounds[k]);
        memset(out, 0, sizeof *out);
        seterr(err, errn, bad ? lasterr : "The folder has no images (.png .bmp .ppm).");
        return -1;
    }
    if (want[0]) {
        int idx = -1;
        for (int i = 0; i < out->ncostumes; i++) if (strcmp(out->costumes[i].name, want) == 0) idx = i;
        if (idx < 0 && atoi(want) >= 1 && atoi(want) <= out->ncostumes) idx = atoi(want) - 1;
        if (idx >= 0) out->cur_costume = idx;
    }
    if (err && errn && (bad || extra)) snprintf(err, errn, "%d file(s) skipped%s%s", bad + extra, bad ? ": " : "", bad ? lasterr : " (limit reached)");
    return 0;
}
