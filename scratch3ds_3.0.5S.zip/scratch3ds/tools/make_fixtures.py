#!/usr/bin/env python3
"""Writes a sample import folder (PNG/BMP/PPM/WAV + sprite.txt) the way a game or PC tool would. Usage: make_fixtures.py DIR"""
import math, os, struct, sys, zlib, wave

def png(path, w, h, ctype, pix, depth=8, level=9, palette=None, trns=None, filt=0):
    """pix: list of rows, each a bytes object of packed samples (already at `depth`)."""
    def chunk(t, d): c = t + d; return struct.pack(">I", len(d)) + c + struct.pack(">I", zlib.crc32(c) & 0xffffffff)
    raw = b""
    prev = None
    bpp = max(1, {0: 1, 2: 3, 3: 1, 4: 2, 6: 4}[ctype] * depth // 8)
    for row in pix:
        if filt == 0: raw += b"\0" + row
        else:
            f = filt; out = bytearray()
            for i, v in enumerate(row):
                a = row[i - bpp] if i >= bpp else 0
                b = prev[i] if prev else 0
                c = prev[i - bpp] if prev and i >= bpp else 0
                if f == 1: p = a
                elif f == 2: p = b
                elif f == 3: p = (a + b) // 2
                else:
                    pp = a + b - c; pa, pb, pc = abs(pp - a), abs(pp - b), abs(pp - c)
                    p = a if pa <= pb and pa <= pc else (b if pb <= pc else c)
                out.append((v - p) & 255)
            raw += bytes([f]) + bytes(out)
        prev = row
    data = b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", struct.pack(">IIBBBBB", w, h, depth, ctype, 0, 0, 0))
    if palette: data += chunk(b"PLTE", b"".join(bytes(c) for c in palette))
    if trns: data += chunk(b"tRNS", trns)
    z = zlib.compress(raw, level)
    half = len(z) // 2
    data += chunk(b"IDAT", z[:half]) + chunk(b"IDAT", z[half:]) + chunk(b"IEND", b"")
    open(path, "wb").write(data)

def rgba_img(w, h, fn):
    return [b"".join(bytes(fn(x, y)) for x in range(w)) for y in range(h)]

def disc(x, y, cx, cy, r, col):
    return col + [255] if (x - cx) ** 2 + (y - cy) ** 2 <= r * r else [0, 0, 0, 0]

def bmp(path, w, h, bpp=24):
    stride = (w * bpp // 8 + 3) // 4 * 4
    rows = []
    for y in range(h - 1, -1, -1):
        r = bytearray()
        for x in range(w):
            c = (255, 0, 255) if (x < 4) else (0, 128, 255) if y < h // 2 else (255, 255, 0)
            r += bytes([c[2], c[1], c[0]]) + (b"\xff" if bpp == 32 else b"")
        r += bytes(stride - len(r)); rows.append(bytes(r))
    body = b"".join(rows)
    hdr = b"BM" + struct.pack("<IHHI", 54 + len(body), 0, 0, 54) + struct.pack("<IiiHHIIiiII", 40, w, h, 1, bpp, 0, len(body), 2835, 2835, 0, 0)
    open(path, "wb").write(hdr + body)

def wav(path, rate, ch, width, secs, freq):
    w = wave.open(path, "wb"); w.setnchannels(ch); w.setsampwidth(width); w.setframerate(rate)
    frames = bytearray()
    for i in range(int(rate * secs)):
        v = math.sin(2 * math.pi * freq * i / rate)
        for _ in range(ch):
            frames += struct.pack("<h", int(v * 12000)) if width == 2 else bytes([int(128 + v * 100)])
    w.writeframes(bytes(frames)); w.close()

root = sys.argv[1]
os.makedirs(root + "/Hero", exist_ok=True)
os.makedirs(root + "/Empty", exist_ok=True)
os.makedirs(root + "/Mixed", exist_ok=True)

png(root + "/Hero/a_walk.png", 64, 48, 6, rgba_img(64, 48, lambda x, y: disc(x, y, 32, 24, 20, [220, 30, 30])), level=9, filt=4)
png(root + "/Hero/b_walk.png", 20, 20, 2, rgba_img(20, 20, lambda x, y: disc(x, y, 10, 10, 9, [30, 30, 220])[:3]), level=1, filt=1)
png(root + "/Hero/c_gray.png", 16, 16, 0, [bytes((x * 16 + y) & 255 for x in range(16)) for y in range(16)], level=0, filt=2)
png(root + "/Hero/d_pal.png", 8, 8, 3, [bytes(((x // 2 + y // 2) % 2) for x in range(8)) for y in range(8)], palette=[(0, 200, 0), (200, 0, 200)], trns=bytes([0, 255]), level=6, filt=3)
open(root + "/Hero/e_broken.png", "wb").write(b"\x89PNG\r\n\x1a\nnot really")
wav(root + "/Hero/jump.wav", 22050, 2, 2, 0.5, 440)
wav(root + "/Hero/hit.wav", 8000, 1, 1, 0.25, 300)
open(root + "/Hero/sprite.txt", "w").write("# made by a game\nname = Knight\nx=120\ny: -80\ndirection=0\nsize=150\nvisible=no\ncostume=b_walk\n")

bmp(root + "/Mixed/1.bmp", 30, 20, 24)
bmp(root + "/Mixed/2.bmp", 10, 10, 32)
open(root + "/Mixed/3.ppm", "wb").write(b"P6\n# c\n4 4\n255\n" + bytes([255, 128, 0] * 16))

png(root + "/coin.png", 12, 12, 6, rgba_img(12, 12, lambda x, y: disc(x, y, 6, 6, 5, [255, 220, 0])))
open(root + "/readme.txt", "w").write("ignored")
