#!/usr/bin/env python3
"""Structural validator for .sb3 files written by source/sb3_writer.c.
Usage: sb3check.py file.sb3 [--coverage]   (--coverage: every opcode in sb3_writer.c's table must appear)"""
import hashlib, json, os, re, sys, zipfile

def fail(msg): print("INVALID:", msg); sys.exit(1)

path = sys.argv[1]
z = zipfile.ZipFile(path)
if z.testzip(): fail("corrupt zip")
names = z.namelist()
if names[0] != "project.json": fail("project.json must be first")
for n in names[1:]:
    stem, ext = os.path.splitext(n)
    if ext in (".png", ".wav", ".svg") and hashlib.md5(z.read(n)).hexdigest() != stem: fail("md5 mismatch for " + n)
    if ext == ".png" and z.read(n)[:8] != b"\x89PNG\r\n\x1a\n": fail("bad PNG " + n)
    if ext == ".wav" and z.read(n)[:4] != b"RIFF": fail("bad WAV " + n)
if len(set(names)) != len(names): fail("duplicate entries")
j = json.loads(z.read("project.json"))
if j["meta"]["semver"] != "3.0.0": fail("semver")
T = j["targets"]
if not T[0]["isStage"] or any(t["isStage"] for t in T[1:]): fail("stage must be the first and only stage")
stage = T[0]
ops = set(); nblocks = 0; nass = 0
for t in T:
    for c in t["costumes"] + t["sounds"]:
        nass += 1
        if c["md5ext"] not in names: fail("missing asset " + c["md5ext"])
    if not t["costumes"]: fail(t["name"] + " has no costume")
    if not 0 <= t["currentCostume"] < len(t["costumes"]): fail("currentCostume")
    B = t["blocks"]
    known_vars = set(stage["variables"]) | set(t["variables"]); known_lists = set(stage["lists"]) | set(t["lists"])
    msgs = set(stage["broadcasts"])
    for bid, b in B.items():
        nblocks += 1; ops.add(b["opcode"])
        for k in ("next", "parent"):
            if b[k] is not None and b[k] not in B: fail(f"{t['name']}: {bid}.{k} -> {b[k]} missing")
        if b["topLevel"] != (b["parent"] is None): fail(f"{t['name']}: {bid} topLevel/parent mismatch")
        if b["topLevel"] and ("x" not in b or "y" not in b): fail("top-level block without position")
        if b["next"] is not None and B[b["next"]]["parent"] != bid: fail(f"{bid}: next block's parent is not me")
        for name, inp in b["inputs"].items():
            if inp[0] not in (1, 2, 3): fail(f"{bid}.{name}: bad input shape")
            for x in inp[1:]:
                if isinstance(x, str):
                    if x not in B: fail(f"{bid}.{name} -> {x} missing")
                    if B[x]["parent"] != bid: fail(f"{bid}.{name} child {x} has parent {B[x]['parent']}")
                elif isinstance(x, list):
                    if x[0] == 12 and x[2] not in known_vars: fail(f"unknown variable {x}")
                    if x[0] == 13 and x[2] not in known_lists: fail(f"unknown list {x}")
                    if x[0] == 11 and x[2] not in msgs: fail(f"unknown broadcast {x}")
        for name, f in b["fields"].items():
            if name in ("VARIABLE",) and f[1] not in known_vars: fail(f"{bid}: unknown variable {f}")
            if name == "LIST" and f[1] not in known_lists: fail(f"{bid}: unknown list {f}")
            if name == "BROADCAST_OPTION" and f[1] not in msgs: fail(f"{bid}: unknown broadcast {f}")
        if b["shadow"] and (b["next"] is not None or b["topLevel"]): fail("bad shadow block")

    seen = set()
    def walk(i):
        if i in seen: return
        seen.add(i); b = B[i]
        if b["next"]: walk(b["next"])
        for inp in b["inputs"].values():
            for x in inp[1:]:
                if isinstance(x, str): walk(x)
    for i, b in B.items():
        if b["topLevel"]: walk(i)
    if len(seen) != len(B): fail(f"{t['name']}: {len(B) - len(seen)} unreachable blocks")
print(f"{os.path.basename(path)}: ok - {len(T)-1} sprites, {nblocks} blocks, {len(ops)} opcodes, {nass} costume/sound entries, {len(names)-1} asset files, extensions {j['extensions']}")
if "--coverage" in sys.argv:
    src = open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "source", "sb3_writer.c")).read()
    want = set(re.findall(r'\{ BK_\w+, "(\w+)"', src)) - {"data_variable"}
    missing = sorted(want - ops)
    print(f"opcode coverage: {len(want) - len(missing)}/{len(want)}" + (" missing: " + ", ".join(missing) if missing else ""))
    if missing: sys.exit(1)
