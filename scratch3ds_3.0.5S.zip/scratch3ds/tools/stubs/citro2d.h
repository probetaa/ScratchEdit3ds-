#pragma once
#include <3ds.h>
typedef struct C3D_RenderTarget C3D_RenderTarget;
typedef struct C2D_TextBuf_s *C2D_TextBuf;
typedef struct { int x; } C2D_Text;
#define C3D_DEFAULT_CMDBUF_SIZE 1
#define C2D_DEFAULT_MAX_OBJECTS 4096
#define C3D_FRAME_SYNCDRAW 1
#define C2D_WithColor 1
#define C2D_Color32(r,g,b,a) ((u32)((((u32)(a))<<24)|(((u32)(b))<<16)|(((u32)(g))<<8)|((u32)(r))))
void C3D_Init(size_t); void C3D_Fini(void); void C2D_Init(size_t); void C2D_Fini(void); void C2D_Prepare(void);
C3D_RenderTarget *C2D_CreateScreenTarget(int, int);
C2D_TextBuf C2D_TextBufNew(size_t); void C2D_TextBufDelete(C2D_TextBuf); void C2D_TextBufClear(C2D_TextBuf);
const char *C2D_TextParse(C2D_Text*, C2D_TextBuf, const char*); void C2D_TextOptimize(const C2D_Text*);
void C2D_DrawText(const C2D_Text*, u32, float, float, float, float, float, ...);
bool C3D_FrameBegin(u8); void C3D_FrameEnd(u8);
void C2D_TargetClear(C3D_RenderTarget*, u32); void C2D_SceneBegin(C3D_RenderTarget*);
bool C2D_DrawRectSolid(float,float,float,float,float,u32);
bool C2D_DrawCircleSolid(float,float,float,float,u32);
bool C2D_DrawCircle(float,float,float,float,u32,u32,u32,u32);
bool C2D_DrawLine(float,float,u32,float,float,u32,float,float);
