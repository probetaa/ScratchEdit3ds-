
#ifndef ABOUT_H
#define ABOUT_H

#define APP_NAME    "ScratchEdit3DS"
#define APP_VERSION "3.0.5GS"

static const char *const ABOUT_LINES[] = {
    "#ScratchEdit3DS " APP_VERSION,
    "An unofficial block editor for the Nintendo 3DS.",
    "Made by probeta. It saves real .sb3 projects to",
    "SD:/3ds/scratch-editor/ that open in Scratch 3.",
    "",
    "Scratch is a project of the Lifelong Kindergarten",
    "Group at the MIT Media Lab. This editor is NOT",
    "made, reviewed or endorsed by MIT or the Scratch",
    "Team. To RUN Scratch projects on a 3DS, try",
    "Scratch Everywhere! by NateXS.",
    "",
    "#Controls",
    "Tap a block to add it, or drag it into the script.",
    "D-pad up: stage on the bottom screen, drag to",
    "  move the selected sprite (up / B / Done: back).",
    "D-pad left: light / dark interface.",
    "Y: run   B: stop / back   START: save   X: delete",
    "L / R: previous / next sprite",
    "Colour sensors: tap the colour box to use the",
    "  eyedropper on the stage.",
    "",
    "Known issues: microphone and sound are",
    "experimental and may not work on every system.",
};
#define ABOUT_N ((int)(sizeof ABOUT_LINES / sizeof ABOUT_LINES[0]))

#endif
