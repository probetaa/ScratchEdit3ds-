
#ifndef RUNTIME_H
#define RUNTIME_H

#include "project.h"

enum { V_NUM = 0, V_STR, V_BOOL };
typedef struct { uint8_t t; float n; char s[TEXT_LEN]; } Val;

typedef struct { int head; int left; } LoopFrame;

enum { WK_NONE = 0, WK_TIME, WK_GLIDE, WK_ASK, WK_ASKQ, WK_BCAST };
enum { POST_NONE = 0, POST_CLEAR_SAY };

typedef struct {
    int   active;
    int   pc;
    int   nframes;
    LoopFrame fr[MAX_DEPTH];
    int   wk;
    float wait_left, wait_total;
    int   post;
    float gsx, gsy, gtx, gty;
    char  wait_msg[TEXT_LEN];
    char  from_msg[TEXT_LEN];
} ScriptRun;

#define MAX_CLONES 16
#define RT_SLOTS (MAX_SPRITES + MAX_CLONES)

typedef struct {
    int   alive;
    int   def;
    int   is_clone;
    float x, y, dir;
    int   visible;
    int   costume;
    float size;
    float ghost;
    float effect[7];
    char  say[TEXT_LEN];
    int   thinking;
    float volume, tempo;
    int   instrument;
    int   pen_down;
    float pen_hue, pen_shade, pen_size;
    uint32_t pen_rgb;
    ScriptRun run[MAX_SCRIPTS];
} SpriteRT;

enum { SND_PROJECT = 0, SND_TONE = -1, SND_STOP = -2 };
typedef struct { int sprite, sound, freq, ms, wave, vol; } SoundEvt;

typedef struct { float x0, y0, x1, y1, size; uint32_t rgb; } PenSeg;
typedef struct { int sprite, costume; float x, y, size, ghost; } Stamp;

#define PEN_SEGS 1024
#define MAX_STAMPS 4

typedef struct {
    SpriteRT spr[RT_SLOTS];
    int      order[RT_SLOTS];
    int      norder;
    Val      var[MAX_VARS];
    uint8_t  var_shown[MAX_VARS];
    struct { int n; Val item[LIST_ITEMS]; } list[MAX_LISTS];
    char     msgq[8][TEXT_LEN];
    int      nmsg;
    SoundEvt snd[8];
    int      nsnd;
    PenSeg   pen[PEN_SEGS];
    int      pen_head, pen_count;
    Stamp    stamps[MAX_STAMPS];
    int      nstamps;
    float    timer;
    uint32_t rng;

    float    mouse_x, mouse_y;
    int      mouse_down;
    uint8_t  keys[KEY_NAME_COUNT];
    float    loudness;
    float    pico_slider, pico_a, pico_b, pico_c;
    int      pico_button;
    uint8_t  hat_prev[MAX_SPRITES][MAX_SCRIPTS];

    int      ask_state;
    int      ask_owner;
    char     ask_prompt[TEXT_LEN];
    char     answer[TEXT_LEN];
} Runtime;

void rt_reset(Runtime *rt, const Project *p);
void rt_green_flag(Runtime *rt, const Project *p);
void rt_key(Runtime *rt, const Project *p, const char *keyname);
void rt_set_key(Runtime *rt, const char *keyname, int down);
void rt_pointer(Runtime *rt, float stage_x, float stage_y, int down);
void rt_click(Runtime *rt, const Project *p, float stage_x, float stage_y);
void rt_stop(Runtime *rt);
int  rt_nclones(const Runtime *rt);
void rt_tick(Runtime *rt, const Project *p, float dt);
int  rt_running(const Runtime *rt);
int  rt_pop_sound(Runtime *rt, SoundEvt *out);
const char *rt_ask_pending(const Runtime *rt);
void rt_answer(Runtime *rt, const char *text);
int  rt_pixel_at(const Runtime *rt, const Project *p, float x, float y);
void rt_set_loudness(Runtime *rt, float level);
void rt_set_pico(Runtime *rt, float slider, float a, float b, float c, int button);
void rt_sprite_box(const Runtime *rt, int i, float *x0, float *y0, float *x1, float *y1);
void val_to_str(const Val *v, char *out, int n);

#endif
