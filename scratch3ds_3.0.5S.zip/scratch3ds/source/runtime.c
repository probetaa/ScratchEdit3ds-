#include "runtime.h"
#include "assets.h"
#include "editor.h"

#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define PI_F 3.14159265f
#define HALF_COSTUME (COSTUME_W * COSTUME_SB_SCALE / 2.0f)

typedef struct { Runtime *rt; const Project *p; int si; const Script *sc; } Ctx;

static void copy_str(char *dst, const char *src, int n)
{
    int i = 0;
    for (; i < n - 1 && src[i]; i++) dst[i] = src[i];
    dst[i] = 0;
}

static Val vnum(float n)        { Val v; memset(&v, 0, sizeof v); v.t = V_NUM; v.n = n; return v; }
static Val vbool(int b)         { Val v; memset(&v, 0, sizeof v); v.t = V_BOOL; v.n = b ? 1.f : 0.f; return v; }
static Val vstr(const char *s)  { Val v; memset(&v, 0, sizeof v); v.t = V_STR; copy_str(v.s, s, TEXT_LEN); return v; }

static int parse_num(const char *s, float *out)
{
    while (*s == ' ') s++;
    if (!*s) return 0;
    char *end;
    double d = strtod(s, &end);
    while (*end == ' ') end++;
    if (*end || end == s) return 0;
    if (d != d) return 0;
    *out = (float)d;
    return 1;
}

static int is_numeric(const Val *v)
{
    float f;
    return v->t != V_STR || parse_num(v->s, &f);
}

static float to_num(const Val *v)
{
    if (v->t != V_STR) return v->n;
    float f;
    return parse_num(v->s, &f) ? f : 0.f;
}

void val_to_str(const Val *v, char *out, int n)
{
    if (v->t == V_STR) { copy_str(out, v->s, n); return; }
    if (v->t == V_BOOL) { copy_str(out, v->n != 0.f ? "true" : "false", n); return; }
    float f = v->n;
    if (fabsf(f - roundf(f)) < 1e-6f && fabsf(f) < 1e9f) snprintf(out, (size_t)n, "%d", (int)roundf(f));
    else snprintf(out, (size_t)n, "%.6g", (double)f);
}

static int truthy(const Val *v)
{
    if (v->t == V_STR) return strcmp(v->s, "true") == 0;
    return v->n != 0.f;
}

static int str_ieq(const char *a, const char *b)
{
    for (; *a && *b; a++, b++) {
        char x = (*a >= 'A' && *a <= 'Z') ? *a + 32 : *a, y = (*b >= 'A' && *b <= 'Z') ? *b + 32 : *b;
        if (x != y) return 0;
    }
    return *a == *b;
}

static void pen_update_rgb(SpriteRT *s) { s->pen_rgb = pen_rgb(s->pen_hue, s->pen_shade); }

static void reset_sprite(SpriteRT *r, const Sprite *s)
{
    memset(r, 0, sizeof *r);
    r->alive = 1;
    r->x = (float)s->x;
    r->y = (float)s->y;
    r->dir = (float)s->direction;
    r->visible = s->visible;
    r->costume = s->cur_costume;
    r->size = s->size > 0 ? (float)s->size : 100.f;
    r->volume = 100.f;
    r->tempo = 60.f;
    r->instrument = 1;
    r->pen_hue = 0.f; r->pen_shade = 50.f; r->pen_size = 1.f;
    pen_update_rgb(r);
}

void rt_reset(Runtime *rt, const Project *p)
{
    memset(rt, 0, sizeof *rt);
    rt->rng = 0x2545F491u;
    for (int i = 0; i < p->nsprites; i++) { reset_sprite(&rt->spr[i], &p->sprites[i]); rt->spr[i].def = i; rt->order[i] = i; }
    rt->norder = p->nsprites;
    for (int i = 0; i < p->nvars; i++) {
        float f;
        rt->var[i] = parse_num(p->vars[i].init, &f) ? vnum(f) : vstr(p->vars[i].init);
    }
}

static void order_remove(Runtime *rt, int slot)
{
    int k = 0;
    while (k < rt->norder && rt->order[k] != slot) k++;
    if (k == rt->norder) return;
    for (; k < rt->norder - 1; k++) rt->order[k] = rt->order[k + 1];
    rt->norder--;
}

static void kill_clone(Runtime *rt, int slot)
{
    SpriteRT *s = &rt->spr[slot];
    if (!s->is_clone || !s->alive) return;
    for (int i = 0; i < MAX_SCRIPTS; i++) s->run[i].active = 0;
    s->alive = 0;
    order_remove(rt, slot);
}

void rt_stop(Runtime *rt)
{
    for (int s = 0; s < RT_SLOTS; s++)
        for (int i = 0; i < MAX_SCRIPTS; i++) rt->spr[s].run[i].active = 0;
    for (int s = MAX_SPRITES; s < RT_SLOTS; s++) kill_clone(rt, s);
    rt->nmsg = 0;
    rt->ask_state = 0;
}

int rt_nclones(const Runtime *rt)
{
    int n = 0;
    for (int s = MAX_SPRITES; s < RT_SLOTS; s++) n += rt->spr[s].alive;
    return n;
}

int rt_running(const Runtime *rt)
{
    for (int s = 0; s < RT_SLOTS; s++)
        for (int i = 0; i < MAX_SCRIPTS; i++) if (rt->spr[s].run[i].active) return 1;
    return 0;
}

int rt_pop_sound(Runtime *rt, SoundEvt *out)
{
    if (rt->nsnd == 0) return 0;
    *out = rt->snd[0];
    for (int i = 1; i < rt->nsnd; i++) rt->snd[i - 1] = rt->snd[i];
    rt->nsnd--;
    return 1;
}

const char *rt_ask_pending(const Runtime *rt) { return rt->ask_state == 1 ? rt->ask_prompt : NULL; }

void rt_answer(Runtime *rt, const char *text)
{
    if (rt->ask_state != 1) return;
    copy_str(rt->answer, text, TEXT_LEN);
    rt->ask_state = 2;
}

static float clamp100(float v) { return v < 0 ? 0 : (v > 100 ? 100 : v); }
void rt_set_pico(Runtime *rt, float slider, float a, float b, float c, int button)
{
    rt->pico_slider = clamp100(slider); rt->pico_a = clamp100(a);
    rt->pico_b = clamp100(b); rt->pico_c = clamp100(c);
    rt->pico_button = button != 0;
}
void rt_set_loudness(Runtime *rt, float level) { rt->loudness = level < 0 ? 0 : (level > 100 ? 100 : level); }

void rt_pointer(Runtime *rt, float x, float y, int down)
{
    rt->mouse_x = x; rt->mouse_y = y; rt->mouse_down = down;
}

void rt_set_key(Runtime *rt, const char *keyname, int down)
{
    int k = key_index(keyname);
    if (k >= 0) rt->keys[k] = down ? 1 : 0;
}

void rt_sprite_box(const Runtime *rt, int i, float *x0, float *y0, float *x1, float *y1)
{
    const SpriteRT *s = &rt->spr[i];
    float h = HALF_COSTUME * s->size / 100.f;
    *x0 = s->x - h; *x1 = s->x + h; *y0 = s->y - h; *y1 = s->y + h;
}

static int find_sprite(const Project *p, const char *name)
{
    for (int i = 0; i < p->nsprites; i++) if (strcmp(p->sprites[i].name, name) == 0) return i;
    return -1;
}

static void start_script(Runtime *rt, int si, int i, const char *from_msg)
{
    ScriptRun *run = &rt->spr[si].run[i];
    memset(run, 0, sizeof *run);
    run->active = 1;
    run->pc = 1;
    if (from_msg) copy_str(run->from_msg, from_msg, TEXT_LEN);
}

void rt_green_flag(Runtime *rt, const Project *p)
{
    rt_reset(rt, p);
    for (int s = 0; s < p->nsprites; s++)
        for (int i = 0; i < p->sprites[s].nscripts; i++) {
            const Script *sc = &p->sprites[s].scripts[i];
            if (sc->nblocks > 0 && sc->blocks[0].kind == BK_HAT_FLAG) start_script(rt, s, i, NULL);
        }
}

static void start_matching(Runtime *rt, const Project *p, BlockKind hat, const char *text)
{
    for (int s = 0; s < RT_SLOTS; s++) {
        if (!rt->spr[s].alive) continue;
        const Sprite *d = &p->sprites[rt->spr[s].def];
        for (int i = 0; i < d->nscripts; i++) {
            const Script *sc = &d->scripts[i];
            if (sc->nblocks > 0 && sc->blocks[0].kind == (int)hat && strcmp(sc->blocks[0].a[0].text, text) == 0)
                start_script(rt, s, i, hat == BK_HAT_RECV ? text : NULL);
        }
    }
}

void rt_key(Runtime *rt, const Project *p, const char *keyname)
{
    start_matching(rt, p, BK_HAT_KEY, keyname);
}

void rt_click(Runtime *rt, const Project *p, float x, float y)
{
    for (int k = rt->norder - 1; k >= 0; k--) {
        int s = rt->order[k];
        const SpriteRT *r = &rt->spr[s];
        float x0, y0, x1, y1;
        rt_sprite_box(rt, s, &x0, &y0, &x1, &y1);
        if (!r->visible || x < x0 || x > x1 || y < y0 || y > y1) continue;
        for (int i = 0; i < p->sprites[r->def].nscripts; i++) {
            const Script *sc = &p->sprites[r->def].scripts[i];
            if (sc->nblocks > 0 && sc->blocks[0].kind == BK_HAT_CLICK) start_script(rt, s, i, NULL);
        }
        return;
    }
}

static uint32_t rnd(Runtime *rt)
{
    uint32_t x = rt->rng ? rt->rng : 1;
    x ^= x << 13; x ^= x >> 17; x ^= x << 5;
    rt->rng = x;
    return x;
}

static Val eval_arg(Ctx *c, const Arg *a, char slot, int depth);

static int var_index(const Project *p, const char *name) { return prj_find_var(p, name); }

static Val list_get(Ctx *c, const char *name, const Val *idx)
{
    int l = prj_find_list(c->p, name);
    if (l < 0) return vstr("");
    int n = c->rt->list[l].n, i;
    if (idx->t == V_STR && str_ieq(idx->s, "last")) i = n;
    else if (idx->t == V_STR && str_ieq(idx->s, "random")) i = n ? (int)(rnd(c->rt) % (uint32_t)n) + 1 : 0;
    else i = (int)to_num(idx);
    if (i < 1 || i > n) return vstr("");
    return c->rt->list[l].item[i - 1];
}

static int stage_pixel(const Runtime *rt, const Project *p, float x, float y, int skip)
{
    for (int k = rt->norder - 1; k >= 0; k--) {
        int i = rt->order[k];
        const SpriteRT *r = &rt->spr[i];
        if (i == skip || !r->alive || !r->visible || r->ghost >= 100.f) continue;
        const Sprite *sp = &p->sprites[r->def];
        if (r->costume < 0 || r->costume >= sp->ncostumes) continue;
        float cs = COSTUME_SB_SCALE * r->size / 100.f;
        if (cs <= 0.f) continue;
        int u = (int)floorf((x - r->x) / cs + COSTUME_W / 2.f), v = (int)floorf(COSTUME_H / 2.f - (y - r->y) / cs);
        if (u < 0 || u >= COSTUME_W || v < 0 || v >= COSTUME_H) continue;
        int idx = sp->costumes[r->costume].px[v * COSTUME_W + u];
        if (idx) return idx;
    }
    const Sprite *stg = &p->sprites[STAGE_IDX];
    if (stg->ncostumes > 0 && stg->cur_costume >= 0 && stg->cur_costume < stg->ncostumes) {
        int col = (int)floorf((x + STAGE_W / 2.f) * COSTUME_W / (float)STAGE_W);
        int row = (int)floorf((STAGE_H / 2.f - y) * COSTUME_H / (float)STAGE_H);
        if (col >= 0 && col < COSTUME_W && row >= 0 && row < COSTUME_H) return stg->costumes[stg->cur_costume].px[row * COSTUME_W + col];
    }
    return 0;
}

int rt_pixel_at(const Runtime *rt, const Project *p, float x, float y) { return stage_pixel(rt, p, x, y, -1); }

static int sprite_over_color(Ctx *c, int mine, int under)
{
    const Runtime *rt = c->rt;
    const SpriteRT *me = &rt->spr[c->si];
    const Sprite *sp = &c->p->sprites[me->def];
    if (!me->visible || me->costume < 0 || me->costume >= sp->ncostumes) return 0;
    const Costume *co = &sp->costumes[me->costume];
    float cs = COSTUME_SB_SCALE * me->size / 100.f;
    for (int v = 0; v < COSTUME_H; v++)
        for (int u = 0; u < COSTUME_W; u++) {
            int idx = co->px[v * COSTUME_W + u];
            if (!idx || (mine && idx != mine)) continue;
            float x = me->x + (u + 0.5f - COSTUME_W / 2.f) * cs, y = me->y + (COSTUME_H / 2.f - v - 0.5f) * cs;
            if (stage_pixel(rt, c->p, x, y, c->si) == under) return 1;
        }
    return 0;
}

static int touching_target(Ctx *c, const char *target)
{
    Runtime *rt = c->rt;
    const SpriteRT *me = &rt->spr[c->si];
    float ax0, ay0, ax1, ay1;
    rt_sprite_box(rt, c->si, &ax0, &ay0, &ax1, &ay1);
    if (!me->visible) return 0;
    if (strcmp(target, "mouse-pointer") == 0)
        return rt->mouse_down && rt->mouse_x >= ax0 && rt->mouse_x <= ax1 && rt->mouse_y >= ay0 && rt->mouse_y <= ay1;
    if (strcmp(target, "edge") == 0)
        return ax0 <= -STAGE_W / 2 || ax1 >= STAGE_W / 2 || ay0 <= -STAGE_H / 2 || ay1 >= STAGE_H / 2;
    int o = find_sprite(c->p, target);
    if (o < 0) return 0;
    for (int s = 0; s < RT_SLOTS; s++) {
        if (!rt->spr[s].alive || rt->spr[s].def != o || s == c->si || !rt->spr[s].visible) continue;
        float bx0, by0, bx1, by1;
        rt_sprite_box(rt, s, &bx0, &by0, &bx1, &by1);
        if (ax0 < bx1 && ax1 > bx0 && ay0 < by1 && ay1 > by0) return 1;
    }
    return 0;
}

static int target_pos(Ctx *c, const char *target, float *x, float *y)
{
    if (strcmp(target, "mouse-pointer") == 0) {
        if (!c->rt->mouse_down) return 0;
        *x = c->rt->mouse_x; *y = c->rt->mouse_y; return 1;
    }
    int o = find_sprite(c->p, target);
    if (o < 0) return 0;
    *x = c->rt->spr[o].x; *y = c->rt->spr[o].y;
    return 1;
}

static Val attr_of(Ctx *c, const char *attr, const char *sprite)
{
    int o = find_sprite(c->p, sprite);
    if (o < 0) return vnum(0);
    const SpriteRT *s = &c->rt->spr[o];
    if (strcmp(attr, "x position") == 0) return vnum(s->x);
    if (strcmp(attr, "y position") == 0) return vnum(s->y);
    if (strcmp(attr, "direction") == 0) return vnum(s->dir);
    if (strcmp(attr, "costume #") == 0) return vnum((float)s->costume + 1);
    if (strcmp(attr, "size") == 0) return vnum(s->size);
    if (strcmp(attr, "volume") == 0) return vnum(s->volume);
    return vnum(0);
}

static float math_fn(const char *f, float x)
{
    if (strcmp(f, "abs") == 0) return fabsf(x);
    if (strcmp(f, "sqrt") == 0) return x < 0 ? 0.f : sqrtf(x);
    if (strcmp(f, "sin") == 0) return sinf(x * PI_F / 180.f);
    if (strcmp(f, "cos") == 0) return cosf(x * PI_F / 180.f);
    if (strcmp(f, "tan") == 0) return tanf(x * PI_F / 180.f);
    if (strcmp(f, "asin") == 0) return (x < -1 || x > 1) ? 0.f : asinf(x) * 180.f / PI_F;
    if (strcmp(f, "acos") == 0) return (x < -1 || x > 1) ? 0.f : acosf(x) * 180.f / PI_F;
    if (strcmp(f, "atan") == 0) return atanf(x) * 180.f / PI_F;
    if (strcmp(f, "ln") == 0) return x <= 0 ? 0.f : logf(x);
    if (strcmp(f, "log") == 0) return x <= 0 ? 0.f : log10f(x);
    if (strcmp(f, "e ^") == 0) return expf(x);
    if (strcmp(f, "10 ^") == 0) return powf(10.f, x);
    return 0.f;
}

static Val eval_expr(Ctx *c, const Block *e, int depth)
{
    Runtime *rt = c->rt;
    const SpriteRT *me = &rt->spr[c->si];
    char slots[MAX_ARGS];
    for (int k = 0; k < MAX_ARGS; k++) slots[k] = k < block_nslots(e->kind) ? BLOCK_INFO[e->kind].slots[k] : 0;
#define ARG(k) eval_arg(c, &e->a[k], slots[k], depth + 1)
#define NUM(k) ({ Val _v = ARG(k); to_num(&_v); })
#define STR(k, buf) ({ Val _v = ARG(k); val_to_str(&_v, buf, TEXT_LEN); })
    char b1[TEXT_LEN], b2[TEXT_LEN];
    switch (e->kind) {
    case BK_XPOS:       return vnum(me->x);
    case BK_YPOS:       return vnum(me->y);
    case BK_DIRECTION:  return vnum(me->dir);
    case BK_COSTUME_NUM:return vnum((float)me->costume + 1);
    case BK_SIZE:       return vnum(me->size);
    case BK_VOLUME:     return vnum(me->volume);
    case BK_TEMPO:      return vnum(me->tempo);
    case BK_ANSWER:     return vstr(rt->answer);
    case BK_MOUSE_X:    return vnum(rt->mouse_x);
    case BK_MOUSE_Y:    return vnum(rt->mouse_y);
    case BK_MOUSE_DOWN: return vbool(rt->mouse_down);
    case BK_TIMER:      return vnum(rt->timer);
    case BK_LOUDNESS:   return vnum(rt->loudness);
    case BK_LOUD:       return vbool(rt->loudness > 30.f);
    case BK_SENSOR_VALUE: {
        STR(0, b1);
        if (!strcmp(b1, "slider"))       return vnum(rt->pico_slider);
        if (!strcmp(b1, "sound"))        return vnum(rt->loudness);
        if (!strcmp(b1, "resistance-A")) return vnum(rt->pico_a);
        if (!strcmp(b1, "resistance-B")) return vnum(rt->pico_b);
        if (!strcmp(b1, "resistance-C")) return vnum(rt->pico_c);
        return vnum(0);
    }
    case BK_SENSOR_BTN: {
        STR(0, b1);
        if (!strcmp(b1, "button pressed")) return vbool(rt->pico_button);
        return vbool(!strcmp(b1, "A connected") || !strcmp(b1, "B connected") || !strcmp(b1, "C connected"));
    }
    case BK_PEN_IS_DOWN: return vbool(me->pen_down);
    case BK_KEY_PRESSED: { STR(0, b1); int k = key_index(b1); return vbool(k >= 0 && rt->keys[k]); }
    case BK_TOUCHING:   { STR(0, b1); return vbool(touching_target(c, b1)); }
    case BK_TOUCHING_COLOR: { STR(0, b1); return vbool(sprite_over_color(c, 0, pal_find(b1))); }
    case BK_COLOR_SEES:     { STR(0, b1); STR(1, b2); return vbool(sprite_over_color(c, pal_find(b1), pal_find(b2))); }
    case BK_DISTANCE: {
        STR(0, b1);
        float x, y;
        if (!target_pos(c, b1, &x, &y)) return vnum(0);
        return vnum(sqrtf((x - me->x) * (x - me->x) + (y - me->y) * (y - me->y)));
    }
    case BK_ATTR_OF:    { STR(0, b1); STR(1, b2); return attr_of(c, b1, b2); }
    case BK_ADD:        return vnum(NUM(0) + NUM(1));
    case BK_SUB:        return vnum(NUM(0) - NUM(1));
    case BK_MUL:        return vnum(NUM(0) * NUM(1));
    case BK_DIV:        { float a = NUM(0), b = NUM(1); return vnum(b == 0.f ? 0.f : a / b); }
    case BK_MOD: {
        float a = NUM(0), b = NUM(1);
        if (b == 0.f) return vnum(0);
        float r = fmodf(a, b);
        if (r != 0.f && ((r < 0) != (b < 0))) r += b;
        return vnum(r);
    }
    case BK_ROUND:      return vnum(roundf(NUM(0)));
    case BK_FUNC:       { STR(0, b1); return vnum(math_fn(b1, NUM(1))); }
    case BK_RANDOM: {
        float a = NUM(0), b = NUM(1);
        if (a > b) { float t = a; a = b; b = t; }
        if (a == floorf(a) && b == floorf(b)) return vnum(a + (float)(rnd(rt) % (uint32_t)(b - a + 1)));
        return vnum(a + (b - a) * ((float)(rnd(rt) & 0xFFFF) / 65535.f));
    }
    case BK_LT:         return vbool(NUM(0) < NUM(1));
    case BK_GT:         return vbool(NUM(0) > NUM(1));
    case BK_EQ: {
        Val a = ARG(0), b = ARG(1);
        if (is_numeric(&a) && is_numeric(&b)) return vbool(to_num(&a) == to_num(&b));
        val_to_str(&a, b1, TEXT_LEN); val_to_str(&b, b2, TEXT_LEN);
        return vbool(str_ieq(b1, b2));
    }
    case BK_AND:        { Val a = ARG(0); if (!truthy(&a)) return vbool(0); Val b = ARG(1); return vbool(truthy(&b)); }
    case BK_OR:         { Val a = ARG(0); if (truthy(&a)) return vbool(1); Val b = ARG(1); return vbool(truthy(&b)); }
    case BK_NOT:        { Val a = ARG(0); return vbool(!truthy(&a)); }
    case BK_JOIN: {
        STR(0, b1); STR(1, b2);
        char out[TEXT_LEN * 2];
        snprintf(out, sizeof out, "%s%s", b1, b2);
        return vstr(out);
    }
    case BK_LETTER: {
        int i = (int)NUM(0);
        STR(1, b1);
        if (i < 1 || i > (int)strlen(b1)) return vstr("");
        char one[2] = { b1[i - 1], 0 };
        return vstr(one);
    }
    case BK_LENGTH:     { STR(0, b1); return vnum((float)strlen(b1)); }
    case BK_VAR: {
        int i = var_index(c->p, e->a[0].text);
        return i >= 0 ? rt->var[i] : vnum(0);
    }
    case BK_LIST_ITEM:  { Val idx = ARG(0); STR(1, b1); return list_get(c, b1, &idx); }
    case BK_LIST_LEN: {
        STR(0, b1);
        int l = prj_find_list(c->p, b1);
        return vnum(l >= 0 ? (float)rt->list[l].n : 0.f);
    }
    default: return vnum(0);
    }
#undef ARG
#undef NUM
#undef STR
}

static Val eval_arg(Ctx *c, const Arg *a, char slot, int depth)
{
    if (a->expr >= 0 && a->expr < MAX_EXPR && c->sc->ex_used[a->expr] && depth < MAX_DEPTH * 3)
        return eval_expr(c, &c->sc->ex[a->expr], depth);
    if (a->expr >= 0) return vnum(0);
    switch (slot) {
    case 'n': {
        float f;
        if (!a->text[0]) return vnum(0);
        return parse_num(a->text, &f) ? vnum(f) : vstr(a->text);
    }
    case 'b': return vbool(0);
    default:  return vstr(a->text);
    }
}

static float norm_dir(float d)
{
    while (d > 180.f)   d -= 360.f;
    while (d <= -180.f) d += 360.f;
    return d;
}

static void pen_add(Runtime *rt, const SpriteRT *s, float x0, float y0, float x1, float y1)
{
    PenSeg *g = &rt->pen[(rt->pen_head + rt->pen_count) % PEN_SEGS];
    if (rt->pen_count == PEN_SEGS) { rt->pen_head = (rt->pen_head + 1) % PEN_SEGS; }
    else rt->pen_count++;
    g->x0 = x0; g->y0 = y0; g->x1 = x1; g->y1 = y1; g->size = s->pen_size; g->rgb = s->pen_rgb;
}

static void fence(const SpriteRT *s, float *nx, float *ny)
{
    float h = HALF_COSTUME * s->size / 100.f;
    if (h < 1.f) h = 1.f;
    float inset = h < 15.f ? h : 15.f;
    float lx = STAGE_W / 2.f + h - inset, ly = STAGE_H / 2.f + h - inset;
    if (!(*nx == *nx)) *nx = s->x;
    if (!(*ny == *ny)) *ny = s->y;
    if (*nx > lx) *nx = lx;
    if (*nx < -lx) *nx = -lx;
    if (*ny > ly) *ny = ly;
    if (*ny < -ly) *ny = -ly;
}

static void move_to(Runtime *rt, int si, float nx, float ny)
{
    SpriteRT *s = &rt->spr[si];
    fence(s, &nx, &ny);
    if (s->pen_down && (nx != s->x || ny != s->y)) pen_add(rt, s, s->x, s->y, nx, ny);
    s->x = nx; s->y = ny;
}

static void snd_push(Runtime *rt, int sprite, int sound, int freq, int ms, int wave, int vol)
{
    if (rt->nsnd >= 8) return;
    SoundEvt *e = &rt->snd[rt->nsnd++];
    e->sprite = sprite; e->sound = sound; e->freq = freq; e->ms = ms; e->wave = wave; e->vol = vol;
}

static void wait_secs(ScriptRun *r, float secs)
{
    if (secs <= 0.f) return;
    r->wk = WK_TIME;
    r->wait_left = r->wait_total = secs;
}

static int effect_index(const char *n)
{
    static const char *e[7] = { "color", "fisheye", "whirl", "pixelate", "mosaic", "brightness", "ghost" };
    for (int i = 0; i < 7; i++) if (strcmp(e[i], n) == 0) return i;
    return -1;
}

static int clone_create(Runtime *rt, const Project *p, int src, int def)
{
    int slot = -1;
    for (int i = MAX_SPRITES; i < RT_SLOTS; i++) if (!rt->spr[i].alive) { slot = i; break; }
    if (slot < 0) return -1;
    SpriteRT *c = &rt->spr[slot];
    *c = rt->spr[src];
    memset(c->run, 0, sizeof c->run);
    c->alive = 1; c->is_clone = 1; c->def = def;
    c->say[0] = 0;
    int pos = 0;
    while (pos < rt->norder && rt->order[pos] != src) pos++;
    for (int k = rt->norder; k > pos; k--) rt->order[k] = rt->order[k - 1];
    rt->order[pos] = slot;
    rt->norder++;
    const Sprite *d = &p->sprites[def];
    for (int i = 0; i < d->nscripts; i++)
        if (d->scripts[i].nblocks > 0 && d->scripts[i].blocks[0].kind == BK_HAT_CLONE) start_script(rt, slot, i, NULL);
    return slot;
}

static void exec_block(Ctx *c, ScriptRun *r, const Block *b, int id)
{
    Runtime *rt = c->rt;
    const Project *p = c->p;
    SpriteRT *sp = &rt->spr[c->si];
    const Sprite *def = &p->sprites[sp->def];
    char slots[MAX_ARGS];
    for (int k = 0; k < MAX_ARGS; k++) slots[k] = k < block_nslots(b->kind) ? BLOCK_INFO[b->kind].slots[k] : 0;
#define ARG(k) eval_arg(c, &b->a[k], slots[k], 0)
#define NUM(k) ({ Val _v = ARG(k); to_num(&_v); })
#define STR(k, buf) ({ Val _v = ARG(k); val_to_str(&_v, buf, TEXT_LEN); })
    char b1[TEXT_LEN], b2[TEXT_LEN];
    float rad = sp->dir * PI_F / 180.f;
    (void)id;

    switch (b->kind) {

    case BK_MOVE: { float n = NUM(0); move_to(rt, c->si, sp->x + n * sinf(rad), sp->y + n * cosf(rad)); break; }
    case BK_TURN_R:     sp->dir = norm_dir(sp->dir + NUM(0)); break;
    case BK_TURN_L:     sp->dir = norm_dir(sp->dir - NUM(0)); break;
    case BK_POINT_DIR:  sp->dir = norm_dir(NUM(0)); break;
    case BK_POINT_TOWARDS: {
        STR(0, b1);
        float x, y;
        if (target_pos(c, b1, &x, &y) && (x != sp->x || y != sp->y)) sp->dir = norm_dir(atan2f(x - sp->x, y - sp->y) * 180.f / PI_F);
        break;
    }
    case BK_GOTO_XY:    { float x = NUM(0), y = NUM(1); move_to(rt, c->si, x, y); break; }
    case BK_GOTO_SPRITE: {
        STR(0, b1);
        float x, y;
        if (target_pos(c, b1, &x, &y)) move_to(rt, c->si, x, y);
        break;
    }
    case BK_GLIDE: {
        float secs = NUM(0), x = NUM(1), y = NUM(2);
        if (secs <= 0.f) { move_to(rt, c->si, x, y); break; }
        r->gsx = sp->x; r->gsy = sp->y; r->gtx = x; r->gty = y;
        r->wk = WK_GLIDE; r->wait_left = r->wait_total = secs;
        break;
    }
    case BK_CHANGE_X:   { float n = NUM(0); move_to(rt, c->si, sp->x + n, sp->y); break; }
    case BK_SET_X:      { float n = NUM(0); move_to(rt, c->si, n, sp->y); break; }
    case BK_CHANGE_Y:   { float n = NUM(0); move_to(rt, c->si, sp->x, sp->y + n); break; }
    case BK_SET_Y:      { float n = NUM(0); move_to(rt, c->si, sp->x, n); break; }
    case BK_BOUNCE: {
        float h = HALF_COSTUME * sp->size / 100.f, ex = STAGE_W / 2 - h, ey = STAGE_H / 2 - h;
        if (sp->x > ex)  { sp->x = ex;  sp->dir = norm_dir(-sp->dir); }
        if (sp->x < -ex) { sp->x = -ex; sp->dir = norm_dir(-sp->dir); }
        if (sp->y > ey)  { sp->y = ey;  sp->dir = norm_dir(180.f - sp->dir); }
        if (sp->y < -ey) { sp->y = -ey; sp->dir = norm_dir(180.f - sp->dir); }
        break;
    }

    case BK_SWITCH_COSTUME: {
        Val v = ARG(0);
        int ci;
        if (v.t != V_STR) ci = (int)v.n - 1;
        else { ci = prj_find_costume(def, v.s); if (ci < 0 && is_numeric(&v)) ci = (int)to_num(&v) - 1; }
        if (ci >= 0 && ci < def->ncostumes) sp->costume = ci;
        break;
    }
    case BK_NEXT_COSTUME: if (def->ncostumes > 0) sp->costume = (sp->costume + 1) % def->ncostumes; break;
    case BK_SAY:   STR(0, b1); copy_str(sp->say, b1, TEXT_LEN); sp->thinking = 0; break;
    case BK_THINK: STR(0, b1); copy_str(sp->say, b1, TEXT_LEN); sp->thinking = 1; break;
    case BK_SAY_FOR: case BK_THINK_FOR: {
        STR(0, b1);
        float secs = NUM(1);
        copy_str(sp->say, b1, TEXT_LEN);
        sp->thinking = b->kind == BK_THINK_FOR;
        r->post = POST_CLEAR_SAY;
        wait_secs(r, secs);
        if (r->wk == WK_NONE) { sp->say[0] = 0; r->post = POST_NONE; }
        break;
    }
    case BK_CHANGE_EFFECT: case BK_SET_EFFECT: {
        STR(0, b1);
        float v = NUM(1);
        int e = effect_index(b1);
        if (e < 0) break;
        sp->effect[e] = b->kind == BK_CHANGE_EFFECT ? sp->effect[e] + v : v;
        if (e == 6) { if (sp->effect[6] < 0) sp->effect[6] = 0; if (sp->effect[6] > 100) sp->effect[6] = 100; sp->ghost = sp->effect[6]; }
        break;
    }
    case BK_CLEAR_EFFECTS: memset(sp->effect, 0, sizeof sp->effect); sp->ghost = 0.f; break;
    case BK_CHANGE_SIZE: case BK_SET_SIZE: {
        float v = NUM(0);
        sp->size = b->kind == BK_CHANGE_SIZE ? sp->size + v : v;
        if (sp->size < 5.f) sp->size = 5.f;
        if (sp->size > 500.f) sp->size = 500.f;
        break;
    }
    case BK_SHOW: sp->visible = 1; break;
    case BK_HIDE: sp->visible = 0; break;
    case BK_FRONT: case BK_BACK: {
        int n = rt->norder, pos = 0;
        while (pos < n && rt->order[pos] != c->si) pos++;
        if (pos >= n) break;
        int to = b->kind == BK_FRONT ? n - 1 : pos - (int)NUM(0);
        if (to < 0) to = 0;
        if (to > n - 1) to = n - 1;
        int me = rt->order[pos];
        if (to > pos) for (int i = pos; i < to; i++) rt->order[i] = rt->order[i + 1];
        else for (int i = pos; i > to; i--) rt->order[i] = rt->order[i - 1];
        rt->order[to] = me;
        break;
    }

    case BK_PLAY_SOUND: case BK_PLAY_SOUND_WAIT: {
        STR(0, b1);
        int s = prj_find_sound(def, b1);
        if (s < 0) break;
        snd_push(rt, sp->def, s, 0, 0, 0, (int)sp->volume);
        if (b->kind == BK_PLAY_SOUND_WAIT) wait_secs(r, snd_duration_ms(&def->sounds[s]) / 1000.f);
        break;
    }
    case BK_STOP_SOUNDS: snd_push(rt, sp->def, SND_STOP, 0, 0, 0, 0); break;
    case BK_DRUM: {
        float beats = NUM(1);
        int n = (int)NUM(0);
        snd_push(rt, sp->def, SND_TONE, 80 + (n % 24) * 25, 70, WAVE_NOISE, (int)sp->volume);
        wait_secs(r, beats * 60.f / sp->tempo);
        break;
    }
    case BK_REST: wait_secs(r, NUM(0) * 60.f / sp->tempo); break;
    case BK_NOTE: {
        float note = NUM(0), beats = NUM(1);
        float f = 440.f * powf(2.f, (note - 69.f) / 12.f);
        int ms = (int)(beats * 60000.f / sp->tempo);
        int wave = (sp->instrument - 1) % 3;
        if (wave < 0) wave = 0;
        snd_push(rt, sp->def, SND_TONE, (int)f, ms, wave, (int)sp->volume);
        wait_secs(r, beats * 60.f / sp->tempo);
        break;
    }
    case BK_INSTRUMENT: { int v = (int)NUM(0); sp->instrument = v < 1 ? 1 : (v > 21 ? 21 : v); break; }
    case BK_CHANGE_VOLUME: case BK_SET_VOLUME: {
        float v = NUM(0);
        sp->volume = b->kind == BK_CHANGE_VOLUME ? sp->volume + v : v;
        if (sp->volume < 0) sp->volume = 0;
        if (sp->volume > 100) sp->volume = 100;
        break;
    }
    case BK_CHANGE_TEMPO: case BK_SET_TEMPO: {
        float v = NUM(0);
        sp->tempo = b->kind == BK_CHANGE_TEMPO ? sp->tempo + v : v;
        if (sp->tempo < 20) sp->tempo = 20;
        if (sp->tempo > 500) sp->tempo = 500;
        break;
    }

    case BK_PEN_CLEAR: rt->pen_count = 0; rt->pen_head = 0; rt->nstamps = 0; break;
    case BK_PEN_DOWN:  sp->pen_down = 1; pen_add(rt, sp, sp->x, sp->y, sp->x, sp->y); break;
    case BK_PEN_UP:    sp->pen_down = 0; break;
    case BK_PEN_COLOR: {
        STR(0, b1);
        sp->pen_rgb = PALETTE_RGB[pal_find(b1)];
        sp->pen_hue = pen_hue_of(sp->pen_rgb);
        sp->pen_shade = 50.f;
        break;
    }
    case BK_PEN_HUE_CHANGE: sp->pen_hue = fmodf(sp->pen_hue + NUM(0), 200.f); if (sp->pen_hue < 0) sp->pen_hue += 200.f; pen_update_rgb(sp); break;
    case BK_PEN_HUE_SET:    sp->pen_hue = fmodf(NUM(0), 200.f); if (sp->pen_hue < 0) sp->pen_hue += 200.f; pen_update_rgb(sp); break;
    case BK_PEN_SHADE_CHANGE: case BK_PEN_SHADE_SET: {
        float v = NUM(0);
        sp->pen_shade = b->kind == BK_PEN_SHADE_CHANGE ? sp->pen_shade + v : v;
        if (sp->pen_shade < 0) sp->pen_shade = 0;
        if (sp->pen_shade > 100) sp->pen_shade = 100;
        pen_update_rgb(sp);
        break;
    }
    case BK_PEN_SIZE_CHANGE: case BK_PEN_SIZE_SET: {
        float v = NUM(0);
        sp->pen_size = b->kind == BK_PEN_SIZE_CHANGE ? sp->pen_size + v : v;
        if (sp->pen_size < 1) sp->pen_size = 1;
        if (sp->pen_size > 40) sp->pen_size = 40;
        break;
    }
    case BK_STAMP: {
        if (rt->nstamps == MAX_STAMPS) { memmove(&rt->stamps[0], &rt->stamps[1], sizeof(Stamp) * (MAX_STAMPS - 1)); rt->nstamps--; }
        Stamp *st = &rt->stamps[rt->nstamps++];
        st->sprite = sp->def; st->costume = sp->costume; st->x = sp->x; st->y = sp->y; st->size = sp->size; st->ghost = sp->ghost;
        break;
    }

    case BK_WAIT:  wait_secs(r, NUM(0)); break;
    case BK_BROADCAST: case BK_BROADCAST_WAIT: {
        STR(0, b1);
        if (rt->nmsg < 8) copy_str(rt->msgq[rt->nmsg++], b1, TEXT_LEN);
        if (b->kind == BK_BROADCAST_WAIT) { r->wk = WK_BCAST; copy_str(r->wait_msg, b1, TEXT_LEN); }
        break;
    }
    case BK_STOP_ALL: {
        int keep_snd = rt->nsnd;
        rt_stop(rt);
        rt->nsnd = keep_snd;
        break;
    }
    case BK_STOP_SCRIPT: r->active = 0; break;
    case BK_CLONE: {
        STR(0, b1);
        int src = c->si, d = sp->def;
        if (!str_ieq(b1, "myself")) { src = find_sprite(p, b1); d = src; }
        if (src >= 0 && rt->spr[src].alive) clone_create(rt, p, src, d);
        break;
    }
    case BK_CLONE_DEL:
        if (sp->is_clone) { kill_clone(rt, c->si); r->active = 0; }
        break;

    case BK_ASK: {
        if (rt->ask_state != 0) { r->wk = WK_ASKQ; r->pc--; break; }
        STR(0, b1);
        rt->ask_state = 1; rt->ask_owner = id;
        copy_str(rt->ask_prompt, b1, TEXT_LEN);
        r->wk = WK_ASK;
        break;
    }
    case BK_TIMER_RESET: rt->timer = 0.f; break;

    case BK_SET_VAR: {
        STR(0, b1);
        int i = var_index(p, b1);
        if (i >= 0) rt->var[i] = ARG(1);
        break;
    }
    case BK_CHANGE_VAR: {
        STR(0, b1);
        float d = NUM(1);
        int i = var_index(p, b1);
        if (i >= 0) rt->var[i] = vnum(to_num(&rt->var[i]) + d);
        break;
    }
    case BK_SHOW_VAR: case BK_HIDE_VAR: {
        STR(0, b1);
        int i = var_index(p, b1);
        if (i >= 0) rt->var_shown[i] = b->kind == BK_SHOW_VAR;
        break;
    }

    case BK_LIST_ADD: {
        Val v = ARG(0);
        STR(1, b1);
        int l = prj_find_list(p, b1);
        if (l >= 0 && rt->list[l].n < LIST_ITEMS) rt->list[l].item[rt->list[l].n++] = v;
        break;
    }
    case BK_LIST_DELETE: {
        Val idx = ARG(0);
        STR(1, b1);
        int l = prj_find_list(p, b1);
        if (l < 0) break;
        int n = rt->list[l].n, i;
        if (idx.t == V_STR && str_ieq(idx.s, "all")) { rt->list[l].n = 0; break; }
        if (idx.t == V_STR && str_ieq(idx.s, "last")) i = n;
        else i = (int)to_num(&idx);
        if (i < 1 || i > n) break;
        for (int k = i - 1; k < n - 1; k++) rt->list[l].item[k] = rt->list[l].item[k + 1];
        rt->list[l].n--;
        break;
    }
    case BK_LIST_INSERT: {
        Val v = ARG(0), idx = ARG(1);
        STR(2, b1);
        int l = prj_find_list(p, b1);
        if (l < 0) break;
        int n = rt->list[l].n, i;
        if (n >= LIST_ITEMS) break;
        if (idx.t == V_STR && str_ieq(idx.s, "last")) i = n + 1;
        else i = (int)to_num(&idx);
        if (i < 1 || i > n + 1) break;
        for (int k = n; k > i - 1; k--) rt->list[l].item[k] = rt->list[l].item[k - 1];
        rt->list[l].item[i - 1] = v;
        rt->list[l].n++;
        break;
    }
    case BK_LIST_REPLACE: {
        Val idx = ARG(0), v = ARG(2);
        STR(1, b1);
        int l = prj_find_list(p, b1);
        if (l < 0) break;
        int n = rt->list[l].n, i;
        if (idx.t == V_STR && str_ieq(idx.s, "last")) i = n;
        else i = (int)to_num(&idx);
        if (i >= 1 && i <= n) rt->list[l].item[i - 1] = v;
        break;
    }
    default: break;
    }
    (void)b2;
#undef ARG
#undef NUM
#undef STR
}

static int msg_running(const Runtime *rt, const Project *p, const char *msg)
{
    (void)p;
    for (int s = 0; s < RT_SLOTS; s++)
        for (int i = 0; i < MAX_SCRIPTS; i++) {
            const ScriptRun *r = &rt->spr[s].run[i];
            if (r->active && strcmp(r->from_msg, msg) == 0) return 1;
        }
    return 0;
}

static int push_frame(ScriptRun *r, int head, int left)
{
    if (r->nframes >= MAX_DEPTH) { r->active = 0; return 0; }
    r->fr[r->nframes].head = head;
    r->fr[r->nframes].left = left;
    r->nframes++;
    return 1;
}

static void run_one(Runtime *rt, const Project *p, int si, int sc_idx, float dt)
{
    if (!rt->spr[si].alive) return;
    const Script *s = &p->sprites[rt->spr[si].def].scripts[sc_idx];
    ScriptRun *r = &rt->spr[si].run[sc_idx];
    if (!r->active) return;
    SpriteRT *sp = &rt->spr[si];
    Ctx cx = { rt, p, si, s };
    int id = si * MAX_SCRIPTS + sc_idx;

    switch (r->wk) {
    case WK_TIME:
        r->wait_left -= dt;
        if (r->wait_left > 0.f) return;
        r->wk = WK_NONE;
        if (r->post == POST_CLEAR_SAY) sp->say[0] = 0;
        r->post = POST_NONE;
        break;
    case WK_GLIDE: {
        r->wait_left -= dt;
        if (r->wait_left > 0.f) {
            float t = 1.f - r->wait_left / r->wait_total;
            move_to(rt, si, r->gsx + (r->gtx - r->gsx) * t, r->gsy + (r->gty - r->gsy) * t);
            return;
        }
        move_to(rt, si, r->gtx, r->gty);
        r->wk = WK_NONE;
        break;
    }
    case WK_ASK:
        if (rt->ask_state == 2 && rt->ask_owner == id) { rt->ask_state = 0; r->wk = WK_NONE; break; }
        return;
    case WK_ASKQ:
        if (rt->ask_state == 0) { r->wk = WK_NONE; break; }
        return;
    case WK_BCAST:
        if (msg_running(rt, p, r->wait_msg)) return;
        r->wk = WK_NONE;
        break;
    default: break;
    }

    for (int guard = 0; guard < 8 * MAX_BLOCKS; guard++) {
        if (!r->active) return;
        if (r->pc >= s->nblocks) { r->active = 0; return; }
        const Block *b = &s->blocks[r->pc];
        int shape = BLOCK_INFO[b->kind].shape;

        if (shape == SH_C || shape == SH_CELSE) {
            int head = r->pc, end = prj_match_end(s, head);
            if (end < 0) { r->active = 0; return; }
            char sl = BLOCK_INFO[b->kind].slots[0];
            Val v = vnum(0);
            if (sl) v = eval_arg(&cx, &b->a[0], sl, 0);
            switch (b->kind) {
            case BK_FOREVER: if (!push_frame(r, head, -1)) return; r->pc = head + 1; break;
            case BK_REPEAT: {
                int n = (int)to_num(&v);
                if (n <= 0) r->pc = end + 1;
                else { if (!push_frame(r, head, n)) return; r->pc = head + 1; }
                break;
            }
            case BK_UNTIL:
                if (truthy(&v)) r->pc = end + 1;
                else { if (!push_frame(r, head, 0)) return; r->pc = head + 1; }
                break;
            case BK_FOREVER_IF:
                if (!truthy(&v)) return;
                if (!push_frame(r, head, 0)) return;
                r->pc = head + 1;
                break;
            case BK_IF:
                if (truthy(&v)) { if (!push_frame(r, head, 0)) return; r->pc = head + 1; }
                else r->pc = end + 1;
                break;
            default: {
                int el = prj_match_else(s, head);
                if (truthy(&v)) { if (!push_frame(r, head, 0)) return; r->pc = head + 1; }
                else if (el >= 0) { if (!push_frame(r, head, 0)) return; r->pc = el + 1; }
                else r->pc = end + 1;
                break;
            }
            }
            continue;
        }
        if (shape == SH_ELSE) {
            if (r->nframes == 0) { r->pc++; continue; }
            int end = prj_match_end(s, r->fr[r->nframes - 1].head);
            r->nframes--;
            r->pc = end >= 0 ? end + 1 : s->nblocks;
            continue;
        }
        if (shape == SH_END) {
            if (r->nframes == 0) { r->pc++; continue; }
            LoopFrame *f = &r->fr[r->nframes - 1];
            int head = f->head;
            switch (s->blocks[head].kind) {
            case BK_FOREVER:     r->pc = head + 1; return;
            case BK_REPEAT:
                if (--f->left > 0) { r->pc = head + 1; return; }
                r->nframes--; r->pc++; break;
            case BK_UNTIL: case BK_FOREVER_IF:
                r->nframes--; r->pc = head; return;
            default:             r->nframes--; r->pc++; break;
            }
            continue;
        }
        if (b->kind == BK_WAIT_UNTIL) {
            Val v = eval_arg(&cx, &b->a[0], 'b', 0);
            if (!truthy(&v)) return;
            r->pc++;
            continue;
        }
        r->pc++;
        exec_block(&cx, r, b, id);
        if (r->wk != WK_NONE) return;
    }
}

static float sensor_value(const Runtime *rt, const char *name)
{
    return strcmp(name, "timer") == 0 ? rt->timer : rt->loudness;
}

void rt_tick(Runtime *rt, const Project *p, float dt)
{
    rt->timer += dt;

    for (int s = 0; s < p->nsprites; s++)
        for (int i = 0; i < p->sprites[s].nscripts; i++) {
            const Script *sc = &p->sprites[s].scripts[i];
            if (sc->nblocks == 0 || sc->blocks[0].kind != BK_HAT_SENSOR) continue;
            float thr = 0.f;
            parse_num(sc->blocks[0].a[1].text, &thr);
            int above = sensor_value(rt, sc->blocks[0].a[0].text) > thr;
            if (above && !rt->hat_prev[s][i] && !rt->spr[s].run[i].active) start_script(rt, s, i, NULL);
            rt->hat_prev[s][i] = (uint8_t)above;
        }

    for (int s = 0; s < RT_SLOTS; s++) {
        if (!rt->spr[s].alive) continue;
        for (int i = 0; i < p->sprites[rt->spr[s].def].nscripts; i++) run_one(rt, p, s, i, dt);
    }

    int n = rt->nmsg;
    char msgs[8][TEXT_LEN];
    memcpy(msgs, rt->msgq, sizeof msgs);
    rt->nmsg = 0;
    for (int m = 0; m < n; m++) start_matching(rt, p, BK_HAT_RECV, msgs[m]);
}
