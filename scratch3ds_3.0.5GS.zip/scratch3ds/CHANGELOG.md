# ScratchEdit3DS — version history

Version codes: **BR** beta release (debugged major release, emulator-tested) · **BE** beta (debugged minor release, emulator-tested, not on real hardware) · **NS** not stable (newest build, not tested on real hardware) · **S** stable (recommended).


## v3.0.5GS

- Removed: camera support (the Camera button in Costumes and the `cam:u` permission)

## v3.0.4NS

- Changed: when the camera can't start, the status line now names the step that failed and its error code (e.g. `Camera failed: Activate 0xE0E...`), to find out why it fails on real hardware

## v3.0.3NS

- Fixed: a sprite could be sent off the stage without limit (e.g. `forever move 10`), and its pen trail with it, which broke the drawing of the whole screen. Like Scratch, at least a few pixels of the sprite now always stay on the stage

## v3.0.2NS

- Added: ^ / v buttons beside the script to slide the view page by page in long scripts (the selected block does not change)
- Added: D-pad left switches the interface between dark and light theme (outside a run)
- Removed: the `light` PicoBoard channel and its D-pad toggle; D-pad right now wraps through a block's arguments

## v3.0.1NS

- Added: `pen down?` block (Pen category), usable inside `if`; it only works inside ScratchEdit3DS and is empty (false) when opened in Scratch 3

## v3.0.0BR

- Added: PicoBoard sensor blocks (Circle Pad, touch, microphone, A button, light via D-pad left)
- Added: Colour sensors work, with an eyedropper
- Added: D-pad up: stage on the bottom screen, move sprites
- Added: New 3DS: faster CPU switched on automatically
- Added: Blocks drawn as puzzle pieces
- Added: Top / End buttons to jump around long scripts
- Added: This About tab and the version history
- Fixed: go to / point towards mouse-pointer do nothing when the screen is not touched
- Fixed: pen down draws a dot, like Scratch
- Fixed: the direction line is no longer drawn while a project runs

## v2.0.0NS

- Added: Drag and drop of blocks with the stylus
- Added: Undo / redo and duplicate
- Added: Clones, 6 starter templates
- Added: Camera costumes, preset sound effects
- Added: Keyboard and numeric keypad input

## v1.0.0NS

- Added: First version: block editor with the Scratch 1.x blocks, saved as .sb3 (and .sb)
- Added: Several sprites and a Stage with backdrops
- Added: Pixel costume editor, sound editor, microphone
- Added: Run the project on either screen

Known issues: camera, microphone and sound are
