
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "assets.h"
#include "editor.h"
#include "sb_writer.h"
#include "sb3_writer.h"

static Project P;

static int ins(int sp, int s, int after, BlockKind k)
{
    int at = prj_insert_block(&P, sp, s, after, k);
    if (at < 0) { fprintf(stderr, "insert failed (%d)\n", k); exit(2); }
    return at;
}
static Block *blk(int sp, int s, int b) { return &P.sprites[sp].scripts[s].blocks[b]; }
static void arg(int sp, int s, int b, int slot, const char *text) { strcpy(blk(sp, s, b)->a[slot].text, text); }
static Block *plug(int sp, int s, Block *node, int slot, BlockKind k, const char *param)
{
    Script *sc = &P.sprites[sp].scripts[s];
    int rc = prj_plug(&P, sp, sc, node, slot, k, param);
    if (rc != 0) { fprintf(stderr, "plug failed (%d) rc=%d\n", k, rc); exit(2); }
    return &sc->ex[node->a[slot].expr];
}

static void make_sample(void)
{
    prj_init(&P);
    prj_add_sprite(&P);
    prj_add_var(&P, "score");
    int16_t tone[3000];
    for (int i = 0; i < 3000; i++) tone[i] = (int16_t)(sinf(i * 0.15f) * 9000.0f * (1.0f - i / 3000.0f));
    prj_add_recording(&P, 1, tone, 3000, REC_RATE);
    prj_add_sound(&P, 0);
    P.sprites[0].sounds[0].freq = 660; P.sprites[0].sounds[0].wave = WAVE_SQUARE;
    {
        Costume *bd = &P.sprites[STAGE_IDX].costumes[0];
        for (int y = 0; y < COSTUME_H; y++) for (int x = 0; x < COSTUME_W; x++) bd->px[y * COSTUME_W + x] = y < 24 ? 8 : 6;
        strcpy(bd->name, "meadow");
    }
    prj_rename_sprite(&P, 0, "Cat");
    prj_rename_sprite(&P, 1, "Ball");
    prj_add_costume(&P, 0);
    costume_fill(&P.sprites[0].costumes[1], 0, 0, 8);
    P.sprites[0].cur_costume = 0;

    int g = ins(0, 0, 0, BK_GOTO_XY); arg(0, 0, g, 0, "0"); arg(0, 0, g, 1, "-120");
    int sv = ins(0, 0, g, BK_SET_VAR); arg(0, 0, sv, 1, "0");
    int f = ins(0, 0, sv, BK_FOREVER);
    int i1 = ins(0, 0, f, BK_IF);
    plug(0, 0, blk(0, 0, i1), 0, BK_KEY_PRESSED, NULL);
    arg(0, 0, i1, 0, "");
    prj_node(&P.sprites[0].scripts[0], i1, (int[]){ 0 }, 1)->a[0].text[0] = 0;
    strcpy(prj_node(&P.sprites[0].scripts[0], i1, (int[]){ 0 }, 1)->a[0].text, "left arrow");
    int cx1 = ins(0, 0, i1, BK_CHANGE_X); arg(0, 0, cx1, 0, "-10");
    int i2 = ins(0, 0, prj_match_end(&P.sprites[0].scripts[0], i1), BK_IF);
    plug(0, 0, blk(0, 0, i2), 0, BK_KEY_PRESSED, NULL);
    strcpy(prj_node(&P.sprites[0].scripts[0], i2, (int[]){ 0 }, 1)->a[0].text, "right arrow");
    ins(0, 0, i2, BK_CHANGE_X);
    int i3 = ins(0, 0, prj_match_end(&P.sprites[0].scripts[0], i2), BK_IF);
    plug(0, 0, blk(0, 0, i3), 0, BK_TOUCHING, NULL);
    strcpy(prj_node(&P.sprites[0].scripts[0], i3, (int[]){ 0 }, 1)->a[0].text, "Ball");
    int cv = ins(0, 0, i3, BK_CHANGE_VAR); arg(0, 0, cv, 1, "1");
    int bc = ins(0, 0, cv, BK_BROADCAST); arg(0, 0, bc, 0, "caught");
    ins(0, 0, bc, BK_NEXT_COSTUME);

    int g2 = ins(1, 0, 0, BK_GOTO_XY); arg(1, 0, g2, 0, "0"); arg(1, 0, g2, 1, "150");
    int f2 = ins(1, 0, g2, BK_FOREVER);
    int cy = ins(1, 0, f2, BK_CHANGE_Y); arg(1, 0, cy, 0, "-5");
    int ie = ins(1, 0, cy, BK_IF_ELSE);
    Block *lt = plug(1, 0, blk(1, 0, ie), 0, BK_LT, NULL);
    plug(1, 0, lt, 0, BK_YPOS, NULL);
    strcpy(lt->a[1].text, "-150");
    int gt = ins(1, 0, ie, BK_GOTO_XY);
    Block *rn = plug(1, 0, blk(1, 0, gt), 0, BK_RANDOM, NULL);
    strcpy(rn->a[0].text, "-200"); strcpy(rn->a[1].text, "200");
    arg(1, 0, gt, 1, "150");
    int el = prj_match_else(&P.sprites[1].scripts[0], ie);
    ins(1, 0, el, BK_TURN_R);
    arg(1, 0, el + 1, 0, "0");
    int r = prj_new_script(&P, 1, BK_HAT_RECV);
    arg(1, r, 0, 0, "caught");
    int ps = ins(1, r, 0, BK_PLAY_SOUND);
    int sy = ins(1, r, ps, BK_SAY_FOR); arg(1, r, sy, 0, "Caught!"); arg(1, r, sy, 1, "0.5");
    int gt2 = ins(1, r, sy, BK_GOTO_XY);
    Block *rn2 = plug(1, r, blk(1, r, gt2), 0, BK_RANDOM, NULL);
    strcpy(rn2->a[0].text, "-200"); strcpy(rn2->a[1].text, "200");
    arg(1, r, gt2, 1, "150");
}

static void make_all(void)
{
    prj_init(&P);
    prj_add_var(&P, "score"); prj_add_var(&P, "lives");
    prj_add_list(&P, "items");
    prj_add_sprite(&P);
    prj_add_sound(&P, 0);
    int sp = 0, sc = 0, last = 0;
    int nreport = 0;
    for (int k = 0; k < BK_COUNT; k++) {
        int shape = BLOCK_INFO[k].shape;
        if (shape == SH_END || shape == SH_ELSE) continue;
        if (shape == SH_HAT) {
            if (P.sprites[sp].nscripts >= MAX_SCRIPTS) { sp = 1; }
            sc = (k == BK_HAT_FLAG && P.sprites[sp].scripts[0].nblocks == 1) ? 0 : prj_new_script(&P, sp, (BlockKind)k);
            last = 0;
            if (sc < 0) { fprintf(stderr, "no room for hat %d\n", k); exit(2); }
            continue;
        }
        if (shape == SH_REP || shape == SH_BOOL) {

            Sprite *s1 = &P.sprites[1];
            static int rs = -1, used = 0, nsay = 0;
            if (rs < 0 || used >= MAX_EXPR - 1 || nsay >= 30) {
                rs = prj_new_script(&P, 1, BK_HAT_FLAG);
                if (rs < 0) { fprintf(stderr, "no room for reporters\n"); exit(2); }
                used = 0; nsay = 0; last = 0;
            }
            int say = prj_insert_block(&P, 1, rs, nsay, BK_SAY);
            nsay++;
            Block *node = &s1->scripts[rs].blocks[say];
            plug(1, rs, node, 0, (BlockKind)k, k == BK_VAR ? "score" : NULL);
            used++; nreport++;
            continue;
        }
        if (P.sprites[sp].scripts[sc].nblocks + 3 >= MAX_BLOCKS) {
            sc = prj_new_script(&P, sp, BK_HAT_FLAG);
            if (sc < 0) { sp = 1; sc = prj_new_script(&P, sp, BK_HAT_FLAG); }
            last = 0;
        }
        last = ins(sp, sc, last, (BlockKind)k);
        if (shape == SH_C || shape == SH_CELSE) {

            if (BLOCK_INFO[k].slots[0] == 'b') {
                Script *scr = &P.sprites[sp].scripts[sc];
                Block *c = plug(sp, sc, &scr->blocks[last], 0, BK_NOT, NULL);
                plug(sp, sc, c, 0, BK_TOUCHING_COLOR, NULL);
            }
        }
    }
    printf("all_blocks: %d reporters plugged\n", nreport);
}

int main(int argc, char **argv)
{
    const char *out1 = argc > 1 ? argv[1] : "sample.sb";
    make_sample();
    int rc = sb_write_project(&P, out1, "tester");
    printf("sb_write_project -> %d (%s)\n", rc, out1);
    if (rc != 0) return rc;
    { char p3[512]; snprintf(p3, sizeof p3, "%s3", out1); rc = sb3_write_project(&P, p3); printf("sb3_write_project -> %d (%s)\n", rc, p3); if (rc) return rc; }
    if (argc > 2) {
        make_all();
        rc = sb_write_project(&P, argv[2], "tester");
        printf("sb_write_project -> %d (%s)\n", rc, argv[2]);
        if (rc == 0) { char p3[512]; snprintf(p3, sizeof p3, "%s3", argv[2]); rc = sb3_write_project(&P, p3); printf("sb3_write_project -> %d (%s)\n", rc, p3); }
    }
    prj_clear(&P);
    return rc;
}
