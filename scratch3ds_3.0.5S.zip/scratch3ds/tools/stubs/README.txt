Minimal fake libctru / citro2d headers (only the calls used by source/main.c).
They exist so main.c can be compiled and exercised on a PC by test_ui.c.
They are NOT the real libraries; build the real thing with devkitPro.
