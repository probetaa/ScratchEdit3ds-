# ScratchEdit3DS!

Touch-screen editor for the Nintendo 3DS (homebrew) with multiple sprites, a costume editor
(pixel art), a sound editor and a block editor, which saves projects in `.sb3` (Scratch 3)
format. It is not a port of the official Scratch editor: the official editor (Scratch 3) is
JavaScript/HTML and does not fit on a 3DS, so this is a new editor written in C with libctru +
citro2d that produces `.sb3` files.

> Unofficial project; "Scratch" is a trademark of MIT / the Scratch Foundation. This project is not affiliated with or endorsed by them.

## Status: read before using

| Part | Status |
|---|---|
| `.sb3` writer (`source/sb3_writer.c`) | Uncompressed ZIP with `project.json` + PNG/WAV files named by MD5, with MD5/CRC32/PNG implemented by hand. Verified with the real Scratch 3 engine: the example project passes `scratch-parser` (official schema), loads in `scratch-vm`, and when the green flag is pressed the sprites move and the variables change as in the editor; all 114 opcodes in the table appear in `all_blocks.sb3` and `tools/sb3check.py` checks references, MD5 and reachability. I have not opened it in the Scratch web interface. |
| `.sb` writer (Scratch 1.x, `sb_writer.c`) | No longer used by the editor; kept with its tests. Not verified against Scratch 1.4. |
| Editor, interpreter, assets, recorder, importer | Tested on PC (`tools/test_*.c`). |
| `.sb3` reader (`source/sb3_reader.c`) | Tested on PC only with files written by this app (plus corrupted/deflated variants) and by running exported custom blocks in the real `scratch-vm`. (Not tested with projects made in real Scratch). |
| User interface (`source/main.c`) | The touch logic was tested on PC by compiling `main.c` against mock libraries (`tools/test_ui.c`). Not compiled against the real libctru/citro2d and not tested on a console. |
| Microphone (`mic*` from libctru) | Written from memory of the API; in the tests it is a simulated microphone. Not tested on hardware. |
| Numeric keyboard (`SWKBD_TYPE_NUMPAD`) | Calls written according to the libctru API; in the tests it is a simulated keyboard. Not tested on the console. |
| Audio (`ndsp`) | Written according to the libctru API, untested. Needs `sd:/3ds/dspfirm.cdc`, also in emulators (the emulator's `sdmc/3ds/` folder); if `ndspInit` fails, the editor says so in the status line with the error code. |

Differences when exporting to Scratch 3 (format limitations, not interface ones):
`forever if` is saved as `forever { if }`; `loud?` as `loudness > 10`; variables and lists
are global (belong to the Stage) and lists start empty; costumes are saved as 64×64 PNG
(each editor pixel = 2×2); synthesized tones are saved as WAV. Pen and music blocks use the
Scratch 3 `pen` and `music` extensions, which are enabled automatically when such blocks are
present. `touching color` / `color is touching` are simulated (see below).

## Building

1. Install devkitPro and the libraries: `sudo dkp-pacman -S 3ds-dev` (includes citro2d/citro3d).
2. `export DEVKITPRO=/opt/devkitpro` and `export DEVKITARM=$DEVKITPRO/devkitARM`
3. `make` → produces `scratch3ds.3dsx`.
4. Copy `scratch3ds.3dsx` to `sd:/3ds/` and launch it from the Homebrew Launcher.

CIA (installable with FBI): in addition to the above you need `makerom` and `bannertool` in the PATH
(binaries from [3DSGuy/Project_CTR](https://github.com/3DSGuy/Project_CTR) and
[Epicpkmn11/bannertool](https://github.com/Epicpkmn11/bannertool)). Then `make cia` produces `scratch3ds.cia`
(it uses `resources/icon.png`, `banner.png`, `audio.wav` and `app.rsf`). Install it with FBI. Audio still needs `sd:/3ds/dspfirm.cdc`. The `.rsf` and `make cia` are untested: if `makerom` complains about a key, the `.rsf` is the cause.

Projects are saved to `sd:/3ds/scratch-editor/<name>.sb3` and open in Scratch 3 (scratch.mit.edu or the desktop editor: File → Load from your computer).

Opening and playing projects. The Spr menu has two more entries: *Open project (.sb3)...* loads an `.sb3` from that folder so you can keep editing it (it replaces the current project and asks for confirmation) and *Play project (.sb3)...* runs it directly without touching your project: when you stop with B you go back to what you were editing. Files saved by this app are read correctly. Projects made in Scratch 3 open with whatever the editor understands: blocks that do not exist here, SVG costumes that are not rectangles, sounds that are not WAV, sprites or scripts that do not fit are skipped and disappear (the status bar says how many, and a report lists what was left out; tap an entry or Cancel to close it). Synthesized sounds come back as recordings.

## Make a Block (custom blocks)

In the More category (pink) there is + Make a Block: you type the name and add up to 3 inputs (text/number or boolean, each with its own name). A `define name (inputs)` script is created and you build the body there; the inputs appear in More as reporters that you can plug into the blocks of the body. The new blocks also appear in More, ready to use (with inputs, inside loops, recursive...). Each custom block belongs to the sprite where it is created. They are saved in the `.sb3` as real Scratch 3 custom blocks (`define`, calls and inputs) and are read back when the project is opened.

Limits: an existing block cannot be edited (delete it and create it again), there is no "run without screen refresh", there are 24 scripts per sprite in total (each `define` counts as one) and recursion goes up to 12 nested calls. Deleting a `define` leaves its calls doing nothing. The Scratch 1.x `.sb` format has no custom blocks, so they are skipped there.

## Usage

The bottom screen has three tabs (Scripts, Costumes, Sounds), the sprite selector below
them and the buttons Flag / Stop / Save / Del / Undo / Redo / Dup at the bottom. The top screen shows
the stage (Scripts), the costume enlarged (Costumes) or the waveform (Sounds).

Sprites (up to 12): `<` `>` switch sprite, `+` creates a new one, `-` deletes the current one and tapping
the name opens the sprite list. The `Spr` button opens the sprite menu: rename,
duplicate (copies scripts, costumes and recordings), move in the list / layer, edit `x`, `y`,
direction, size (%) and visibility (initial values saved in the `.sb3`), and import.

Backdrops (Stage): tap the sprite name and choose `Stage (backdrops)` at the end of the list. With the
Stage selected, the Costumes tab edits the backdrops (same canvas, colours, `New`, `Name`, `Flip`,
`Delete`; the backdrop shown is the selected one) and Sounds edits its sounds. The first backdrop is white; 
transparent shows as white. `<` `>` / L R go back to the sprites. The Stage has no scripts: pressing
Flag from the Stage switches the editor to the first sprite. In the `.sb3` each backdrop is saved as a 480×360 SVG.

Importing sprites from a folder (for example one created by a game or a PC tool):
put folders in `sd:/3ds/scratch-editor/sprites/` (the editor creates it) and use `Spr → Import sprite...`
(one) or `Import ALL` (all of them).

```
sprites/
  Hero/              one folder = one sprite called "Hero"
    sprite.txt       optional: name=  x=  y=  direction=  size=  visible=  costume=  ("key=value" lines, # comments)
    walk1.png        .png / .bmp / .ppm images -> costumes, in alphabetical order (max 6)
    walk2.png
    jump.wav         PCM .wav 8/16 bit, mono or stereo -> sounds (max 6; downsampled to ≤ 11025 Hz and 4 s)
  coin.png           a single loose image = a one-costume sprite
```

Images are fitted to 96×96 (keeping the aspect ratio) in full colour (15 bits); alpha
< 128 is transparent, and in BMP/PPM magenta `#FF00FF` is transparent too. Interlaced PNGs
and compressed BMPs are not supported. Files that fail are skipped and the editor reports how many. Repeated
names are numbered (`Hero`, `Hero2`...). `tools/make_fixtures.py DIR` generates an example folder.

Scripts: 9 categories (Motion, Looks, Sound, Pen, Control, Sensing, Operators, Variables,
Lists) with 133 blocks (those of Scratch 1.x, PicoBoard, clones, `pen down?` and the Scratch 2 ones: backdrops, `stop other scripts`, `current`, `days since 2000`, `username`, rotation style) and Make a Block. Tap a block in the palette to add it after the
selected block (hats create a new script; `forever`, `repeat`, `if`, `if else`... create
their body with `end`/`else` markers). The `^`/`v` buttons scroll the palette, and Find between them searches all categories by name (tap a category to leave the search; empty text clears it). The S1/N box under the palette lists all scripts of the sprite so you can jump to any of them.

*Arguments:* the bar at the bottom of the script shows the 3 slots of the selected block. Tap a
slot to focus it and again to edit it: keyboard, or a menu (costume, sound, key,
message, variable, list, effect, pen colour, sprite...). If you tap a reporter
(round, `( )`) or boolean (`< >`) block in the palette while a slot is focused, it is plugged
into it and you enter that reporter to fill in its own slots (`^` goes up a level). `Delete`
removes the plugged reporter. Reporters nest (up to 16 per script).

*Variables and lists* (up to 10 and 4): `Make a variable` / `Make a list` in their category, with
a reporter per variable and `set/change/show/hide`, `add/delete/insert/replace`... blocks.

*Run screen*: the purple `Run:T` / `Run:B` button in the sprite bar chooses where the
project runs. `Run:T` (default): the stage on the top screen and the bottom one as a touch panel (mouse).
`Run:B`: the stage takes the touch screen (480×360 → 320×240, tap = mouse) and the top one shows
positions, variables, timer and answer. It is remembered in `sd:/3ds/scratch-editor/settings.txt`.

*Running* (Flag/Y): the touch screen becomes a panel that acts as the mouse; the D-pad,
A, X, Y, L and R are keys; B stops. Pen blocks (trail and stamp), sensing
(mouse, key, timer, `ask`/`answer`, microphone volume, `when loudness > n`),
operators, lists and `broadcast and wait` work.

Costumes (up to 6 per sprite, 96×96 pixels, 15-bit colour): tap a colour in the palette, or `RGB...` for any
colour, and draw on the canvas. Tools: `Pen`, `Fill`, `Line`, `Rect`, `Oval` (`Solid`/`Line` switches
filled or outline shapes), `Pick` (eyedropper) and `Sel` (drag an area, then `Copy`, `Cut`, `Paste`, `Del`).
`Size` changes the brush, `Zoom` the canvas zoom, `Flip` flips, `Clear` clears, `New` creates a costume
copying the current one, `Name` renames it, `Prev`/`Next` switch costume. The `x` colour erases.

Graphic effects (color, fisheye, whirl, pixelate, mosaic, brightness, ghost) are drawn on the stage and on
stamps; they are an approximation of Scratch's effects on the 96×96 grid and are not shown in the costume editor.

SVG costumes in `.sb3` projects are rasterized to 96×96 when opened (basic shapes, paths, fills, strokes and
transforms; gradients, text and filters are not supported). Costumes are saved as PNG. IMA ADPCM `.wav`
sounds are decoded when opened.

Sounds (up to 6 per sprite): synthesized tones (sine / square / sawtooth / noise) with
frequency, duration and volume, or microphone recordings: `Rec (microphone)` starts
and tapping again stops (maximum 4 s at 10910 Hz; it stops by itself when full and discards anything
shorter than 50 ms). A recording can be trimmed (`Trim silence`), normalized, reversed and
volume-adjusted; it is saved in the `.sb3` as WAV and plays with `play sound`.

Debug mode: hold L and R and press Y. A green panel on the top screen shows FPS, frame time, sprites, clones, running
scripts, drawn rectangles and free memory. While it is on, every status message and a summary every 4 seconds are appended to
`sd:/3ds/scratch-editor/debug.log`. Press L+R+Y again to turn it off. Send that file when reporting a bug.

| Button | Action |
|---|---|
| L / R | Previous / next sprite |
| D-pad ↑ ↓ | Move the block selection (Scripts tab) |
| D-pad ← → | Move the focus between slots |
| A | Edit the focused slot |
| X | Delete (block, reporter, script, costume or sound depending on the tab) |
| (screen) Undo / Redo / Dup | Undo, redo, duplicate (see below) |
| Y / B | Run (green flag) / stop |
| START | Save `.sb3` |
| SELECT | Exit |

Next to the script there are two buttons `^` and `v` that scroll it by pages without changing the selected block (plus *Top* and *End*).

### Stage limits

As in Scratch, a sprite never leaves the stage completely: at least a part of it (up to 15 px) always stays inside. So a `forever move 10` stays at the edge instead of drifting away forever.

### Autosave

Every 3 minutes (only if you touched something) and when you exit with SELECT, the project is written to `sd:/3ds/scratch-editor/autosave.sb3`. If that file exists when the app starts, the status line says so; open it from `Spr → Open project`. It is not written while a project is running or while a menu is open. It does not replace your own saves, and the next autosave overwrites the previous one.

### Light / dark theme

D-pad left (outside a run) switches the interface between dark and light theme. The stage, costumes and pen keep their colours. During a run, D-pad left remains the project's left arrow. Inside a block, D-pad right moves to the next argument and, after the last one, goes back to the first.

### About tab and version history

The fourth tab, About, shows the name (ScratchEdit3DS), the version, credits, the controls and the legal notice (the version history is in `CHANGELOG.md`). The texts are in `source/about.h`; to publish a new version change `APP_VERSION` there (format `3.0.0BR`: BR = beta release, BE = beta, NS = not stable, S = stable; see `CHANGELOG.md`) and add its lines. Scroll with `^` `v` or with the D-pad.

### Stage on the bottom, eyedropper and moving sprites

- D-pad up (while not running): the stage moves to the touch screen. Drag to place the selected sprite; it is saved as its starting position. D-pad up, B or Done go back. (That is why D-pad up no longer selects the previous block: tap the block or use D-pad down, Top and End.)
- In `touching color` and `color is touching`, tapping the colour box opens an eyedropper: the stage appears on the bottom screen and tapping a pixel picks its colour (from the palette). List opens the usual colour menu and Cancel leaves.

### Pointer and long scripts

- `go to mouse-pointer`, `point towards mouse-pointer`, `touching mouse-pointer?` and `distance to mouse-pointer` only act while you are touching the touch screen: if there is no finger, the block is skipped (the sprite stays where it is) instead of going to a corner.
- Below the palette, next to `<` `>` (previous/next script), the Top and End buttons jump to the first and last block of the script.

### PicoBoard-style sensors

`<channel> sensor value` and `sensor <…>?` (Sensing category) read the console while the project runs:

| Channel | What it reads |
|---------|---------------|
| `slider` | Circle Pad horizontal (0–100, centre 50) |
| `resistance-A` | Circle Pad vertical (0–100, centre 50) |
| `resistance-B` / `resistance-C` | touch position X / Y (0–100) |
| `sound` | microphone (same as `loudness`) |
| `sensor button pressed?` | A button |
| `sensor A/B/C connected?` | always true (D, false) |

Not tested on a real 3DS (`hidCircleRead` and touch only in the PC simulation).

### Dragging blocks (touch screen)

In the scripts tab you can drag with the stylus/finger:

- Palette → script: drop the block between two rows (a white line shows where it will be inserted). A loose event (hat) block dropped in the scripts area creates a new script.
- Reporters/booleans (operators, variables…): drop them on an argument box of the bottom bar or on a script row (they go into the first free slot that accepts them).
- Reordering: drag a script row to another position. A C block (if, forever…) moves with all its contents; dropping it inside itself does nothing. Dropping right below the header of a C block puts it inside.
- Deleting: drag a row to the palette (it turns red).
- Near the top/bottom edge of the script it scrolls by itself. A tap without moving works as before (select/add). Hats cannot be dragged.

> Tested only with the PC tests (simulated screen); I have not run it on a 3DS or in an emulator.

### Undo, redo and duplicate

- Undo / Redo (bottom buttons): undo and redo changes to the sprite's scripts (adding, deleting,
  moving or duplicating blocks, plugging reporters, changing a value, creating or deleting scripts). There are 20 steps. A new
  edit clears the "redo" history; deleting or reordering sprites clears the whole history. They do not cover
  costumes, sounds, variables or lists.
- Dup (bottom button): in Scripts it duplicates the selected block (with its body if it is a C block, and with the
  plugged reporters); with the hat selected it duplicates the whole script. In Costumes and Sounds
  it duplicates the current costume / sound.

### Clones

In Control: `when I start as a clone`, `create clone of [myself / sprite]` and `delete this clone`. A clone copies
the original's position, direction, size, costume and effects, runs its sprite's scripts, responds to
messages and keys and can touch or be touched. There can be up to 16 clones at once; with Stop (or `stop all`) they disappear.
They are exported to the `.sb3` as the normal Scratch 3 blocks (`control_create_clone_of`...).

### Keyboard

Tapping a slot already opened the system keyboard. Now numeric slots and the sprite menu values (`x`, `y`,
direction, size, frequency...) open the numeric keyboard (digits, `-` and `.`); in block slots the
`Abc` button opens the full keyboard (to type `last`, `all`...).

### Sound effects

Sounds → Sound effects... adds one of 10 synthesized effects as a normal sound (exported as WAV):
`laser`, `jump`, `coin`, `power-up`, `explosion`, `hit`, `blip`, `siren`, `fall`, `click`.

### Templates

`Spr → New from template...` (asks for confirmation, and replaces the current project; save first):
`Blank project`, `Catch the apples`, `Pong`, `Space shooter (clones)`, `Pen sketch` and `Music keys`. They are
normal projects with sprites, costumes, sounds and scripts that can be edited. In the PC tests they are played in the
interpreter and the `.sb3` files are validated with `scratch-parser`; five of the six were loaded in the real Scratch engine (`scratch-vm`, headless: collisions
and bounces cannot be tested there) and in the shooter `create clone of` was executed; `Music keys` was not tested there. `examples/templates/` contains the ready-made `.sb3` files.

## Prototype limits

- At most 12 sprites, 24 scripts per sprite, 40 blocks per script, 6 costumes and 6 sounds per sprite.
- The Stage has backdrops (up to 6) and sounds, but no scripts; backdrops are 32×32 pixels stretched to 480×360 and costumes are saved enlarged 2× (64×64).
- `touching color` / `color touching color` only look at sprites and backdrop (not the pen, stamps or rotation); the visual rotation of sprites is not simulated.
- Excluded: video blocks. The PicoBoard blocks (`… sensor value`, `sensor …?`) are simulated with the console (see above) and do not exist in Scratch 3: in the `.sb3` they are exported without them (the default value remains); in the Scratch 1.x `.sb` they are saved. Clones are not in Scratch 1.x (added on request).
- Saves `.sb3` (Scratch 3). Opening and playing `.sb3` files only understands what the editor supports (see above): real Scratch projects will lose any blocks, costumes or sounds it does not know.

## Tests and format verification (on PC)

```sh
cd tools
./run_tests.sh                                  # editor, assets, importer, .sb/.sb3 writers and reader, and the interface with mock libraries
python3 sb3check.py ../examples/all_blocks.sb3 --coverage   # validates the .sb3: ZIP, MD5, block references, opcodes
# optional, with the real Scratch 3 engine (needs npm i scratch-vm scratch-storage):
node sb3_vm_run.js ../examples/sample.sb3       # loads the project, presses the green flag and prints positions and variables
```

## Alternative for playing

If what you want is to play Scratch projects on the 3DS, there is
[Scratch Everywhere!](https://github.com/scratch-everywhere/scratch-everywhere) (a runtime for .sb3 files). You can create the project on a PC with Scratch 3 and copy it to `3ds/scratch-everywhere`.

## Structure

```
source/project.h      data model + BLOCK_LIST table (the 133 blocks)
source/sb3_reader.c   .sb3 reader (ZIP + JSON) to open and play projects
source/assets.c/h     palette, costumes, sound synthesis, recorder/trim/normalize (no libctru)
source/importer.c/h   imports sprites from folders (PNG with own inflate, BMP, PPM, WAV, sprite.txt)
source/editor.c/h     project editing: scripts, reporters, variables, lists (no libctru)
source/runtime.c/h    cooperative multi-sprite interpreter with clones (no libctru)
source/templates.c/h  project templates (built with the same editing API)
source/sb3_writer.c/h .sb3 serializer (ZIP + project.json + PNG/WAV)
source/sb_writer.c/h  Scratch 1.x .sb serializer (no longer used by the editor)
source/main.c         3DS interface (citro2d, ndsp, microphone)
tools/                sb3check.py, sb3_vm_run.js, sbdump.py, PC tests, run_tests.sh, stubs/ (mock libctru/citro2d)
examples/             sample.sb3 (catch-the-ball game), all_blocks.sb3 (one block of each kind) and the same in .sb
```

## License

MIT, see `LICENSE`.
